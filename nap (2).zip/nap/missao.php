<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Missão e Visão — ' . setting('site_nome', APP_NAME);
$currentPage = 'missao';
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">O QUE NOS GUIA</p>
        <h1 class="text-4xl md:text-5xl font-bold">Missão e Visão</h1>
    </div>
</section>
<section class="py-16 bg-paciolita-branco-suave">
    <div class="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div class="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm animate-enter">
            <div class="w-14 h-14 bg-ev-gold/20 rounded-xl flex items-center justify-center mb-5"><i class="fas fa-bullseye text-ev-gold text-2xl"></i></div>
            <h2 class="text-2xl font-bold text-ev-dark mb-3">Missão</h2>
            <p class="text-gray-700">Desenvolver soluções tecnológicas acessíveis e eficientes, desde softwares e sites até suporte, conectividade, segurança electrónica e formação.</p>
        </div>
        <div class="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm animate-enter">
            <div class="w-14 h-14 bg-ev-gold/20 rounded-xl flex items-center justify-center mb-5"><i class="fas fa-eye text-ev-gold text-2xl"></i></div>
            <h2 class="text-2xl font-bold text-ev-dark mb-3">Visão</h2>
            <p class="text-gray-700">Ser uma referência tecnológica em Angola, reconhecida pela qualidade, inovação e proximidade com os clientes nas cinco províncias onde estamos presentes.</p>
        </div>
    </div>
    <div class="container mx-auto px-4 mt-10 text-center">
        <a href="<?= site_url('valores') ?>" class="btn-ev-gold">Ver os nossos valores</a>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
