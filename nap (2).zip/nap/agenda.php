<?php
require_once __DIR__ . '/config/app.php';

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM agenda WHERE id = ? AND status = 'publicado' LIMIT 1");
$stmt->execute([$id]);
$evento = $stmt->fetch();

if (!$evento) {
    http_response_code(404);
    $pageTitle = 'Actividade não encontrada';
    $currentPage = '';
    require __DIR__ . '/includes/site_header.php';
    echo '<section class="py-20 container mx-auto px-4 text-center"><h1 class="text-3xl font-bold mb-4">Actividade não encontrada</h1><a class="btn-ev-gold" href="' . e(url('/')) . '">Voltar ao início</a></section>';
    require __DIR__ . '/includes/site_footer.php';
    exit;
}

$pageTitle = $evento['titulo'] . ' — ' . setting('site_nome', APP_NAME);
$currentPage = '';
$fotos = array_values(array_filter([$evento['foto1'], $evento['foto2'], $evento['foto3'], $evento['foto4'], $evento['foto5']]));
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">AGENDA</p>
        <h1 class="text-4xl md:text-5xl font-bold"><?= e($evento['titulo']) ?></h1>
    </div>
</section>
<section class="py-16 bg-white">
    <div class="container mx-auto px-4 max-w-5xl">
        <div class="agenda-detail animate-enter">
            <?php if ($fotos): ?>
                <div class="agenda-detail-gallery">
                    <?php foreach ($fotos as $foto): ?>
                        <img src="<?= e(UPLOAD_URL . $foto) ?>" alt="<?= e($evento['titulo']) ?>">
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <div class="agenda-detail-content">
                <div class="agenda-detail-meta">
                    <?php if (!empty($evento['data_evento'])): ?><span><i class="fas fa-calendar-days"></i><?= e(format_date($evento['data_evento'], 'd/m/Y H:i')) ?></span><?php endif; ?>
                    <?php if (!empty($evento['local_evento'])): ?><span><i class="fas fa-location-dot"></i><?= e($evento['local_evento']) ?></span><?php endif; ?>
                </div>
                <?php if (!empty($evento['resumo'])): ?><p class="agenda-detail-summary"><?= e($evento['resumo']) ?></p><?php endif; ?>
                <div class="agenda-detail-description"><?= nl2br(e($evento['descricao'] ?: 'Descrição em actualização.')) ?></div>
                <a class="btn-ev" href="<?= e(url('/')) ?>#agenda"><i class="fas fa-arrow-left"></i> Voltar à agenda</a>
            </div>
        </div>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
