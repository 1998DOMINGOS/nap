<?php
require_once __DIR__ . '/config/app.php';

$pageTitle = site_nome() . ' — ' . site_tagline();
$pageDescription = site_nome() . ' — ' . site_tagline() . '.';
$currentPage = 'home';

try {
    $servicos = db()->query("SELECT * FROM servicos WHERE status='ativo' ORDER BY ordem, titulo LIMIT 4")->fetchAll();
    $noticias = db()->query("SELECT * FROM noticias WHERE status='publicado' ORDER BY COALESCE(publicado_em, criado_em) DESC LIMIT 3")->fetchAll();
    $depoimentos = db()->query("SELECT * FROM depoimentos WHERE status='ativo' ORDER BY ordem, id DESC LIMIT 6")->fetchAll();
    $agenda = db()->query("SELECT * FROM agenda WHERE status='publicado' ORDER BY COALESCE(data_evento, criado_em) DESC, id DESC LIMIT 12")->fetchAll();
    $pca = db()->query("SELECT * FROM mensagem_pca WHERE ativo=1 ORDER BY id DESC LIMIT 1")->fetch();
    $certificacoes = db()->query("SELECT * FROM certificacoes WHERE status='ativo' ORDER BY ordem, titulo")->fetchAll();
} catch (Throwable $e) {
    $servicos = $noticias = $depoimentos = $agenda = [];
    $pca = null;
    $certificacoes = [];
}

$hero1 = 'https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?auto=format&fit=crop&w=2000&q=85';
$hero2 = 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=2000&q=85';
$hero3 = 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=2000&q=85';
$aboutImg = url('/imgs/quem-somos-tecnologia.jpg');
try {
    $parceiros = db()->query("SELECT * FROM parceiros WHERE status='ativo' ORDER BY ordem, nome")->fetchAll();
    $clientes = db()->query("SELECT * FROM clientes WHERE status='ativo' ORDER BY ordem, nome")->fetchAll();
} catch (Throwable $e) {
    $parceiros = $clientes = [];
}

require __DIR__ . '/includes/site_header.php';
?>
<script>
window.HERO_TEXTS = [
    { tag: 'Reparação de computadores', title: 'O seu computador<br><span class="text-ev-gold">nas melhores mãos</span>', desc: 'Diagnóstico, reparação e manutenção para manter o seu trabalho sempre activo.' },
    { tag: 'Desenvolvimento de software', title: 'Software feito<br><span class="text-ev-gold">para o seu negócio</span>', desc: 'Criamos sistemas modernos, seguros e adaptados aos seus processos.' },
    { tag: 'Instalação de internet', title: 'Internet rápida e estável<br><span class="text-ev-gold">onde precisa</span>', desc: 'Instalamos e configuramos redes para ligar pessoas, equipas e negócios.' }
];
</script>

<section class="hero-slider" id="heroSlider">
    <div class="hero-progress" id="heroProgress"></div>
    <div class="hero-slide active" style="background-image:url('<?= e($hero1) ?>'); background-position:center;"></div>
    <div class="hero-slide" style="background-image:url('<?= e($hero2) ?>'); background-position:center;"></div>
    <div class="hero-slide" style="background-image:url('<?= e($hero3) ?>'); background-position:center;"></div>

    <div class="hero-content container mx-auto px-4">
        <div class="max-w-3xl hero-slide-text" id="heroText">
            <span class="inline-flex items-center gap-2 bg-ev-gold/20 border border-ev-gold/40 text-ev-gold px-4 py-1.5 rounded-full text-sm font-semibold mb-6">
                <i class="fas fa-laptop-medical"></i> <span id="heroTag">Reparação de computadores</span>
            </span>
            <h1 class="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6" id="heroTitle">
                O seu computador<br><span class="text-ev-gold">nas melhores mãos</span>
            </h1>
            <p class="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl" id="heroDesc">
                Diagnóstico, reparação e manutenção para manter o seu trabalho sempre activo.
            </p>
            <div class="flex flex-col sm:flex-row gap-4">
                <a href="<?= site_url('services') ?>" class="btn-ev-gold text-lg"><i class="fas fa-list-check mr-2"></i>Conhecer Serviços</a>
                <a href="<?= site_url('contato') ?>" class="btn-ev-outline text-lg"><i class="fas fa-phone-alt mr-2"></i>Falar Connosco</a>
            </div>
        </div>
    </div>
    <div class="hero-arrow prev" onclick="evSlide(-1)"><i class="fas fa-chevron-left"></i></div>
    <div class="hero-arrow next" onclick="evSlide(1)"><i class="fas fa-chevron-right"></i></div>
    <div class="hero-dots" id="heroDots"></div>
</section>

<section class="bg-ev-dark border-b border-white/10">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-2 md:grid-cols-4 divide-x divide-white/10">
            <div class="py-6 px-4 flex items-center gap-3"><i class="fas fa-code text-ev-gold text-2xl"></i><div><p class="text-white font-bold">Software</p><p class="text-gray-400 text-sm">Soluções à medida</p></div></div>
            <div class="py-6 px-4 flex items-center gap-3"><i class="fas fa-globe text-ev-gold text-2xl"></i><div><p class="text-white font-bold">Sites</p><p class="text-gray-400 text-sm">Presença digital</p></div></div>
            <div class="py-6 px-4 flex items-center gap-3"><i class="fas fa-shield-halved text-ev-gold text-2xl"></i><div><p class="text-white font-bold">Segurança</p><p class="text-gray-400 text-sm">Câmaras e redes</p></div></div>
            <div class="py-6 px-4 flex items-center gap-3"><i class="fas fa-map-location-dot text-ev-gold text-2xl"></i><div><p class="text-white font-bold">5 Províncias</p><p class="text-gray-400 text-sm">Presença em Angola</p></div></div>
        </div>
    </div>
</section>

<section class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-10 animate-enter">
            <span class="inline-block px-4 py-2 bg-ev-gold/10 text-ev-gold rounded-full text-sm font-semibold mb-4">CREDENCIAIS</span>
            <h2 class="text-3xl md:text-4xl font-bold text-ev-dark">As Nossas Certificações</h2>
            <p class="text-gray-600 mt-3 max-w-2xl mx-auto">Conheça as certificações e reconhecimentos que reforçam a nossa capacidade profissional.</p>
        </div>
        <?php if (!$certificacoes): ?>
            <div class="certifications-empty text-center text-gray-500">As nossas certificações serão apresentadas em breve.</div>
        <?php else: ?>
            <div class="certifications-grid">
                <?php foreach ($certificacoes as $cert): ?>
                    <article class="certification-card animate-enter">
                        <?php if (!empty($cert['imagem'])): ?><img src="<?= e($cert['imagem']) ?>" alt="<?= e($cert['titulo']) ?>" class="certification-image"><?php else: ?><div class="certification-icon"><i class="fas fa-certificate"></i></div><?php endif; ?>
                        <h3><?= e($cert['titulo']) ?></h3>
                        <?php if (!empty($cert['entidade'])): ?><p class="certification-entity"><?= e($cert['entidade']) ?></p><?php endif; ?>
                        <?php if (!empty($cert['descricao'])): ?><p><?= e($cert['descricao']) ?></p><?php endif; ?>
                        <?php if (!empty($cert['link'])): ?><a href="<?= e($cert['link']) ?>" target="_blank" rel="noopener">Ver certificação <i class="fas fa-arrow-up-right-from-square"></i></a><?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<section id="agenda" class="py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-14 items-center">
            <div class="relative animate-enter">
                <div class="relative rounded-2xl shadow-2xl w-full h-[460px] overflow-hidden bg-ev-dark">
                    <img src="<?= e($aboutImg) ?>" alt="" aria-hidden="true" class="absolute inset-0 w-full h-full object-cover object-center scale-110 blur-2xl opacity-60">
                    <div class="relative z-10 w-full h-full flex items-center justify-center">
                        <img src="<?= e($aboutImg) ?>" alt="Profissional a desenvolver software num computador" class="max-w-full max-h-full w-auto h-auto object-cover rounded-xl">
                    </div>
                </div>
                <div class="absolute -bottom-8 -right-4 md:right-8 z-20 bg-ev-dark text-white rounded-2xl p-6 shadow-xl border-l-4 border-ev-gold">
                    <div class="text-4xl font-bold text-ev-gold">6</div>
                    <div class="text-sm text-gray-300">anos de experiência<br>em tecnologia</div>
                </div>
            </div>
            <div class="animate-enter">
                <span class="inline-block px-4 py-2 bg-ev-gold/10 text-ev-gold rounded-full text-sm font-semibold mb-4">QUEM SOMOS</span>
                <h2 class="text-3xl md:text-4xl font-bold text-ev-dark mb-6">Mais que tecnologia,<br><span class="text-ev-gold">soluções que funcionam</span></h2>
                <p class="text-lg text-gray-700 mb-5">A <strong class="text-ev-dark"><?= e(setting('site_nome', APP_NAME)) ?></strong> desenvolve soluções tecnológicas para organizações que procuram eficiência, segurança e crescimento sustentável.</p>
                <a href="<?= site_url('sobre') ?>" class="btn-ev"><i class="fas fa-arrow-right mr-2"></i>Conheça a <?= e(setting('site_nome', APP_NAME)) ?></a>
            </div>
        </div>
    </div>
</section>

<section class="py-16 bg-paciolita-branco-suave">
    <div class="container mx-auto px-4 max-w-5xl">
        <?php if ($pca): ?>
        <div class="bg-ev-dark text-white rounded-2xl p-8 md:p-12 shadow-xl border-l-4 border-ev-gold animate-enter">
            <div class="flex flex-col md:flex-row md:items-start gap-6">
                <div class="pca-portrait-wrap">
                    <?php $pcaFoto = !empty($pca['foto']) ? UPLOAD_URL . $pca['foto'] : url('/imgs/domingos-miguel-panzo.jpg'); ?><img src="<?= e($pcaFoto) ?>" alt="<?= e($pca['nome'] . ', ' . $pca['cargo']) ?>" class="pca-portrait">
                </div>
                <div>
                    <span class="text-ev-gold text-sm font-semibold tracking-widest uppercase">Liderança</span>
                    <h2 class="text-3xl font-bold mt-2 mb-5">Mensagem do PCA</h2>
                    <blockquote class="text-lg md:text-xl text-gray-200 leading-relaxed mb-5">
                        “<?= e($pca['mensagem']) ?>”
                    </blockquote>
                    <p class="text-ev-gold font-semibold"><?= e($pca['nome']) ?></p>
                    <p class="text-gray-400 text-sm"><?= e($pca['cargo']) ?> · <?= e(setting('site_nome', APP_NAME)) ?></p>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<section class="py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="text-center mb-12 animate-enter">
            <span class="inline-block px-4 py-2 bg-ev-gold/10 text-ev-gold rounded-full text-sm font-semibold mb-4">ACTIVIDADES</span>
            <h2 class="text-3xl md:text-4xl font-bold text-ev-dark">A Nossa Agenda</h2>
            <p class="text-gray-600 mt-3 max-w-2xl mx-auto">Acompanhe tudo o que a <?= e(setting('site_nome', APP_NAME)) ?> está a fazer e os próximos projectos.</p>
        </div>
        <?php if (!$agenda): ?>
            <div class="agenda-empty text-center text-gray-500">Em breve partilharemos as nossas próximas actividades.</div>
        <?php else: ?>
            <div class="agenda-grid">
                <?php foreach ($agenda as $evento): $fotos = array_values(array_filter([$evento['foto1'], $evento['foto2'], $evento['foto3'], $evento['foto4'], $evento['foto5']])); ?>
                    <article class="agenda-card animate-enter">
                        <?php if ($fotos): ?><div class="agenda-gallery"><div class="agenda-gallery-grid"><?php foreach ($fotos as $foto): ?><img src="<?= e(UPLOAD_URL . $foto) ?>" alt="<?= e($evento['titulo']) ?>"><?php endforeach; ?></div><span><?= count($fotos) ?> foto<?= count($fotos) > 1 ? 's' : '' ?></span></div><?php endif; ?>
                        <div class="agenda-card-body">
                            <?php if (!empty($evento['data_evento'])): ?><p class="agenda-date"><i class="fas fa-calendar-days"></i><?= e(format_date($evento['data_evento'], 'd/m/Y H:i')) ?></p><?php endif; ?>
                            <h3><?= e($evento['titulo']) ?></h3>
                            <?php if (!empty($evento['local_evento'])): ?><p class="agenda-location"><i class="fas fa-location-dot"></i><?= e($evento['local_evento']) ?></p><?php endif; ?>
                            <p class="text-gray-600 text-sm"><?= e($evento['resumo'] ?: $evento['descricao']) ?></p>
                            <a class="agenda-more" href="<?= e(url('/agenda.php?id=' . (int) $evento['id'])) ?>">Ver mais <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="py-20 bg-paciolita-branco-suave">
    <div class="container mx-auto px-4">
        <div class="text-center mb-14 animate-enter">
            <span class="inline-block px-4 py-2 bg-ev-gold/10 text-ev-gold rounded-full text-sm font-semibold mb-4">O QUE FAZEMOS</span>
            <h2 class="text-3xl md:text-4xl font-bold text-ev-dark">Soluções para o seu negócio</h2>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <?php if (!$servicos): ?>
                <div class="col-span-full text-center text-gray-500">Serviços disponíveis em breve.</div>
            <?php else: foreach ($servicos as $s): ?>
                <article class="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 card-hover animate-enter">
                    <div class="w-14 h-14 bg-ev-gold/10 rounded-xl flex items-center justify-center mb-5"><i class="fas <?= e($s['icone']) ?> text-ev-gold text-2xl"></i></div>
                    <h3 class="text-xl font-bold text-ev-dark mb-3" data-service-slug="<?= e($s['slug']) ?>" data-service-field="title"><?= e($s['titulo']) ?></h3>
                    <p class="text-gray-600 text-sm mb-5" data-service-slug="<?= e($s['slug']) ?>" data-service-field="resumo"><?= e($s['resumo'] ?: mb_substr(strip_tags((string)$s['descricao']), 0, 120)) ?></p>
                    <a href="<?= site_url('servico/' . $s['slug']) ?>" class="inline-flex items-center text-ev-gold font-semibold hover:gap-2 transition-all">Saiba mais <i class="fas fa-arrow-right ml-2"></i></a>
                </article>
            <?php endforeach; endif; ?>
        </div>
        <div class="text-center mt-12">
            <a href="<?= site_url('services') ?>" class="btn-ev-gold text-lg"><i class="fas fa-list-check mr-2"></i>Ver Todos os Serviços</a>
        </div>
    </div>
</section>

<section class="py-20 bg-ev-dark text-white">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div class="animate-enter">
                <span class="inline-block px-4 py-2 bg-white/10 text-ev-gold rounded-full text-sm font-semibold mb-4">POR QUE NOS ESCOLHER</span>
                <h2 class="text-3xl md:text-4xl font-bold mb-6">Criamos para quem<br><span class="text-ev-gold">não aceita o comum</span></h2>
                <div class="space-y-5">
                    <div class="flex items-start gap-4"><div class="flex-shrink-0 w-12 h-12 bg-ev-gold/20 rounded-lg flex items-center justify-center"><i class="fas fa-fingerprint text-ev-gold text-lg"></i></div><div><h4 class="font-bold text-lg">Autenticidade</h4><p class="text-gray-300 text-sm">Cada peça reflecte a sua história — nada de produção em série.</p></div></div>
                    <div class="flex items-start gap-4"><div class="flex-shrink-0 w-12 h-12 bg-ev-gold/20 rounded-lg flex items-center justify-center"><i class="fas fa-headset text-ev-gold text-lg"></i></div><div><h4 class="font-bold text-lg">Suporte próximo</h4><p class="text-gray-300 text-sm">Acompanhamos os seus equipamentos e soluções tecnológicas.</p></div></div>
                    <div class="flex items-start gap-4"><div class="flex-shrink-0 w-12 h-12 bg-ev-gold/20 rounded-lg flex items-center justify-center"><i class="fas fa-location-dot text-ev-gold text-lg"></i></div><div><h4 class="font-bold text-lg">Presença local</h4><p class="text-gray-300 text-sm">Estamos em cinco províncias para atender mais perto.</p></div></div>
                </div>
            </div>
            <div class="grid grid-cols-2 gap-5" data-counter>
                <div class="bg-white/5 backdrop-blur rounded-2xl p-7 text-center border border-white/10"><div class="text-4xl md:text-5xl font-bold text-ev-gold mb-2"><span data-count="6">0</span></div><div class="text-gray-300 text-sm">Anos de experiência</div></div>
                <div class="bg-white/5 backdrop-blur rounded-2xl p-7 text-center border border-white/10"><div class="text-4xl md:text-5xl font-bold text-ev-gold mb-2"><span data-count="5">0</span></div><div class="text-gray-300 text-sm">Províncias</div></div>
                <div class="bg-white/5 backdrop-blur rounded-2xl p-7 text-center border border-white/10"><div class="text-4xl md:text-5xl font-bold text-ev-gold mb-2"><span data-count="7">0</span></div><div class="text-gray-300 text-sm">Áreas de serviço</div></div>
                <div class="bg-white/5 backdrop-blur rounded-2xl p-7 text-center border border-white/10"><div class="text-4xl md:text-5xl font-bold text-ev-gold mb-2"><span data-count="1" data-prefix="#">0</span></div><div class="text-gray-300 text-sm">Parceiro tecnológico</div></div>
            </div>
        </div>
    </div>
</section>

<section class="py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-12 animate-enter gap-4">
            <div>
                <span class="inline-block px-4 py-2 bg-ev-gold/10 text-ev-gold rounded-full text-sm font-semibold mb-4">FIQUE POR DENTRO</span>
                <h2 class="text-3xl md:text-4xl font-bold text-ev-dark">Últimas Notícias</h2>
            </div>
            <a href="<?= site_url('news') ?>" class="btn-ev"><i class="fas fa-newspaper mr-2"></i>Todas as notícias</a>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php if (!$noticias): ?>
                <div class="col-span-1 md:col-span-3 bg-white rounded-2xl shadow-lg border border-gray-100 p-10 text-center animate-enter">
                    <div class="text-ev-gold text-5xl mb-6"><i class="fas fa-newspaper"></i></div>
                    <h3 class="text-2xl font-bold text-ev-dark mb-3">Nenhuma notícia publicada</h3>
                    <p class="text-gray-600 mb-6">Publique a primeira notícia no painel administrativo.</p>
                </div>
            <?php else: foreach ($noticias as $n): ?>
                <article class="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 card-hover animate-enter">
                    <div class="h-48 bg-ev-dark bg-cover bg-center" style="background-image:url('<?= e($n['imagem'] ? media_url($n['imagem']) : url('/imgs/hero-1.jpg')) ?>');"></div>
                    <div class="p-6">
                        <p class="text-sm text-ev-gold font-semibold mb-2"><?= e(format_date($n['publicado_em'] ?? $n['criado_em'], 'd/m/Y')) ?></p>
                        <h3 class="text-xl font-bold text-ev-dark mb-3"><?= e($n['titulo']) ?></h3>
                        <p class="text-gray-600 text-sm mb-4"><?= e($n['resumo'] ?: mb_substr(strip_tags($n['conteudo']), 0, 120) . '...') ?></p>
                        <a href="<?= site_url('noticia/' . $n['slug']) ?>" class="text-ev-gold font-semibold">Ler mais <i class="fas fa-arrow-right ml-1"></i></a>
                    </div>
                </article>
            <?php endforeach; endif; ?>
        </div>
    </div>
</section>

<section class="py-20 bg-paciolita-branco-suave">
    <div class="container mx-auto px-4">
        <div class="text-center mb-14 animate-enter">
            <span class="inline-block px-4 py-2 bg-ev-gold/10 text-ev-gold rounded-full text-sm font-semibold mb-4">DEPOIMENTOS</span>
            <h2 class="text-3xl md:text-4xl font-bold text-ev-dark">Quem confia, recomenda</h2>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php if (!$depoimentos): ?>
                <div class="col-span-full text-center text-gray-500 py-4">
                    <p>Ainda não há depoimentos publicados. Se é nosso cliente, deixe o seu testemunho.</p>
                </div>
            <?php else: foreach ($depoimentos as $d): ?>
                <div class="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 animate-enter">
                    <div class="text-ev-gold mb-4"><i class="fas fa-quote-left text-3xl"></i></div>
                    <p class="text-gray-600 italic mb-6">"<?= e($d['texto']) ?>"</p>
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-ev-dark rounded-full flex items-center justify-center text-ev-gold font-bold mr-3"><?= e(mb_strtoupper(mb_substr($d['nome'], 0, 1))) ?></div>
                        <div><p class="font-bold text-ev-dark"><?= e($d['nome']) ?></p><p class="text-sm text-gray-500"><?= e($d['cargo']) ?></p></div>
                    </div>
                    <div class="text-ev-gold mt-4 text-sm"><?php for ($i = 0; $i < (int)$d['nota']; $i++): ?><i class="fas fa-star"></i><?php endfor; ?></div>
                </div>
            <?php endforeach; endif; ?>
        </div>
        <div class="text-center mt-12">
            <a href="<?= site_url('depoimento') ?>" class="btn-ev-gold text-lg"><i class="fas fa-pen-to-square mr-2"></i>Deixe o seu depoimento</a>
            <p class="text-sm text-gray-500 mt-3">O testemunho só é publicado no site após validação da nossa equipa.</p>
        </div>
    </div>
</section>

<section class="partners-section py-20 bg-white">
    <div class="container mx-auto px-4">
        <div class="partners-heading animate-enter">
            <div>
                <span class="inline-block px-4 py-2 bg-ev-gold/10 text-ev-gold rounded-full text-sm font-semibold mb-4">PARCERIAS</span>
                <h2 class="text-3xl md:text-4xl font-bold text-ev-dark">Os Nossos Parceiros</h2>
            </div>
            <p>Trabalhamos com parceiros que ajudam a levar tecnologia, conectividade e segurança a mais organizações.</p>
        </div>
        <?php if (!$parceiros): ?>
            <div class="agenda-empty text-center text-gray-500">Em breve apresentaremos os nossos parceiros.</div>
        <?php else: ?>
            <div class="partner-grid">
                <?php foreach ($parceiros as $parceiro): ?>
                    <?php $partnerTag = !empty($parceiro['link']) ? 'a' : 'div'; ?>
                    <<?= $partnerTag ?> class="partner-card animate-enter"<?= !empty($parceiro['link']) ? ' href="' . e($parceiro['link']) . '" target="_blank" rel="noopener"' : '' ?>>
                        <div class="partner-card-top">
                            <?php $partnerLogo = partner_logo_url($parceiro['imagem'] ?? ''); ?>
                            <?php if ($partnerLogo): ?>
                                <img class="partner-logo partner-logo--solo" src="<?= e($partnerLogo) ?>" alt="<?= e($parceiro['nome']) ?>">
                            <?php else: ?>
                                <div class="partner-icon"><i class="fas <?= e($parceiro['icone'] ?: 'fa-handshake') ?>"></i></div>
                            <?php endif; ?>
                        </div>
                        <h3><?= e($parceiro['nome']) ?></h3>
                        <p><?= e($parceiro['descricao'] ?: 'Parceiro da ' . setting('site_nome', APP_NAME)) ?></p>
                        <?php if (!empty($parceiro['link'])): ?><span class="partner-link">Conhecer parceiro <i class="fas fa-arrow-up-right-from-square"></i></span><?php endif; ?>
                    </<?= $partnerTag ?>>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="py-20 bg-paciolita-branco-suave">
    <div class="container mx-auto px-4">
        <div class="text-center mb-12 animate-enter">
            <span class="inline-block px-4 py-2 bg-ev-gold/10 text-ev-gold rounded-full text-sm font-semibold mb-4">CONFIANÇA</span>
            <h2 class="text-3xl md:text-4xl font-bold text-ev-dark">Os Nossos Clientes</h2>
            <p class="text-gray-600 mt-3 max-w-2xl mx-auto">Apoiamos diferentes sectores com soluções práticas, suporte próximo e tecnologia que funciona.</p>
        </div>
        <div class="carousel-shell max-w-5xl mx-auto" data-carousel data-carousel-count="<?= count($clientes) ?>">
            <button class="carousel-control prev" type="button" data-carousel-prev aria-label="Anterior"><i class="fas fa-chevron-left"></i></button>
            <div class="carousel-viewport"><div class="carousel-track">
                <?php foreach ($clientes as $cliente): ?>
                    <div class="client-card animate-enter">
                        <?php $clientLogo = partner_logo_url($cliente['imagem'] ?? ''); if ($clientLogo): ?>
                            <img class="client-logo" src="<?= e($clientLogo) ?>" alt="<?= e($cliente['nome']) ?>">
                        <?php else: ?>
                            <i class="fas <?= e($cliente['icone']) ?>"></i>
                        <?php endif; ?>
                        <span><?= e($cliente['nome']) ?></span>
                    </div>
                <?php endforeach; ?>
            </div></div>
            <button class="carousel-control next" type="button" data-carousel-next aria-label="Próximo"><i class="fas fa-chevron-right"></i></button>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/site_footer.php'; ?>
