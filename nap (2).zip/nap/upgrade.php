<?php
/**
 * Actualização INFORMATIZA (SU), LDA — galeria + módulo de facturação.
 * Abrir: http://localhost/casa/upgrade.php
 * Apague este ficheiro depois.
 */
require_once __DIR__ . '/config/app.php';

try {
    $pdo = db();

    $pdo->exec("CREATE TABLE IF NOT EXISTS galeria (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      titulo VARCHAR(160) NOT NULL,
      descricao VARCHAR(255) NULL,
      imagem VARCHAR(255) NOT NULL,
      ordem INT NOT NULL DEFAULT 0,
      status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
      criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $settings = [
        'site_nome' => 'INFORMATIZA (SU), LDA',
        'site_email' => 'geralnacionalajudaopais@gmail.com',
        'site_telefone' => '935406556',
        'site_telefone_secundario' => '',
        'site_morada' => 'Sede: Uíge | Luanda: Maianga, Edifício Unitel, 5.º andar | Huíla | Benguela | Mbanza Congo',
        'site_whatsapp' => '935406556',
        'site_instagram' => '',
        'site_linkedin' => '',
    ];
    $stmt = $pdo->prepare('INSERT INTO configuracoes (chave, valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)');
    foreach ($settings as $k => $v) {
        $stmt->execute([$k, $v]);
    }

    $pdo->exec("DELETE FROM servicos WHERE slug IN (
        'seguranca-patrimonial','seguranca-eletronica','escolta-protecao-pessoal','portaria-controle-acesso'
    )");

    $servicos = [
        ['Desenvolvimento de Software', 'desenvolvimento-software', 'fa-code', 'Softwares à medida para simplificar processos e fazer o seu negócio crescer.', 'Analisamos os seus desafios e desenvolvemos sistemas seguros, eficientes e adaptados à realidade da sua organização.', 1],
        ['Criação de Sites', 'criacao-de-sites', 'fa-globe', 'Sites profissionais, rápidos e preparados para todos os dispositivos.', 'Criamos sites institucionais e plataformas digitais com design moderno, boa experiência de utilização e foco nos seus resultados.', 2],
        ['Reparação de Computadores', 'reparacao-de-computadores', 'fa-laptop-medical', 'Diagnóstico, reparação e manutenção de computadores.', 'Prestamos assistência técnica para computadores, com diagnóstico, manutenção preventiva e resolução de problemas de hardware e software.', 3],
        ['Reparação de Impressoras', 'reparacao-de-impressoras', 'fa-print', 'Manutenção e reparação de impressoras para empresas e particulares.', 'Cuidamos da manutenção e reparação de impressoras para reduzir paragens e manter o seu trabalho a funcionar.', 4],
        ['Instalação de Internet', 'instalacao-de-internet', 'fa-wifi', 'Instalação e configuração de redes e internet.', 'Instalamos e configuramos redes, internet e equipamentos para melhorar a cobertura, estabilidade e segurança da sua ligação.', 5],
        ['Câmaras de Segurança', 'cameras-de-seguranca', 'fa-video', 'Soluções de videovigilância para proteger pessoas e espaços.', 'Planeamos e instalamos câmaras de segurança com acompanhamento técnico e soluções adequadas à sua casa ou empresa.', 6],
        ['Formação', 'formacao', 'fa-graduation-cap', 'Formação prática para desenvolver competências digitais.', 'Promovemos formação em informática, ferramentas digitais e soluções tecnológicas para equipas e comunidades.', 7],
    ];
    $ins = $pdo->prepare('INSERT INTO servicos (titulo, slug, icone, resumo, descricao, ordem, status) VALUES (?,?,?,?,?,?,"ativo")
        ON DUPLICATE KEY UPDATE titulo=VALUES(titulo), icone=VALUES(icone), resumo=VALUES(resumo), descricao=VALUES(descricao), ordem=VALUES(ordem), status="ativo"');
    foreach ($servicos as $s) {
        $ins->execute($s);
    }

    ensure_facturacao_schema();

    foreach (['uploads/galeria', 'storage/fat_keys', 'storage/saft'] as $rel) {
        $dir = __DIR__ . '/' . $rel;
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }

    $ok = true;
    $msg = 'Upgrade OK: site INFORMATIZA + módulo de Facturação (tabelas e chaves RSA).';
} catch (Throwable $e) {
    $ok = false;
    $msg = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upgrade — INFORMATIZA (SU), LDA</title>
    <style>
        body{font-family:system-ui,sans-serif;background:#0f1419;color:#e8ecef;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0}
        .box{max-width:520px;background:#161b22;border-radius:14px;padding:28px;border:1px solid rgba(255,255,255,.08)}
        a{color:#FF6200;font-weight:700}
        .ok{color:#ffd0a8}.err{color:#ffb4b4}
        .warn{margin-top:14px;font-size:.85rem;opacity:.85}
    </style>
</head>
<body>
<div class="box">
    <h1>Upgrade INFORMATIZA (SU), LDA</h1>
    <p class="<?= $ok ? 'ok' : 'err' ?>"><?= htmlspecialchars($msg) ?></p>
    <?php if ($ok): ?>
        <p><a href="<?= htmlspecialchars(url('/admin/facturacao/index.php')) ?>">Abrir Facturação</a> ·
           <a href="<?= htmlspecialchars(url('/')) ?>">Site</a></p>
    <?php endif; ?>
    <p style="opacity:.7;font-size:.9rem">Apague o ficheiro <strong>upgrade.php</strong> após usar.</p>
</div>
</body>
</html>
