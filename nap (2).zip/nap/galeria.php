<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Galeria — ' . setting('site_nome', APP_NAME);
$currentPage = 'galeria';
try {
    $fotos = db()->query("SELECT * FROM galeria WHERE status='ativo' ORDER BY ordem ASC, id DESC")->fetchAll();
} catch (Throwable $e) {
    $fotos = [];
}
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">MOMENTOS</p>
        <h1 class="text-4xl md:text-5xl font-bold">Galeria</h1>
        <p class="text-gray-300 mt-3 max-w-2xl">Imagens da nossa operação, equipa e presença no terreno.</p>
    </div>
</section>

<section class="py-16 bg-paciolita-branco-suave">
    <div class="container mx-auto px-4">
        <?php if (!$fotos): ?>
            <div class="bg-white rounded-2xl p-10 text-center border border-gray-100">
                <div class="text-ev-gold text-5xl mb-4"><i class="fas fa-images"></i></div>
                <p class="text-gray-600">Ainda não há fotos publicadas. Cadastre imagens no painel administrativo.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($fotos as $f): ?>
                    <figure class="group bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 card-hover animate-enter">
                        <a href="<?= e(media_url($f['imagem'])) ?>" target="_blank" rel="noopener" class="block relative overflow-hidden">
                            <img src="<?= e(media_url($f['imagem'])) ?>" alt="<?= e($f['titulo']) ?>" class="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-105">
                            <div class="absolute inset-0 bg-ev-dark/0 group-hover:bg-ev-dark/35 transition-colors flex items-center justify-center">
                                <i class="fas fa-search-plus text-white text-2xl opacity-0 group-hover:opacity-100 transition-opacity"></i>
                            </div>
                        </a>
                        <figcaption class="p-5">
                            <h2 class="text-lg font-bold text-ev-dark"><?= e($f['titulo']) ?></h2>
                            <?php if ($f['descricao']): ?>
                                <p class="text-gray-600 text-sm mt-1"><?= e($f['descricao']) ?></p>
                            <?php endif; ?>
                        </figcaption>
                    </figure>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
