<?php
/**
 * Endpoint público para receber mensagens do formulário de contacto do site.
 * POST: nome, email, telefone, assunto, mensagem
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/app.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Método não permitido']);
    exit;
}

$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$telefone = trim($_POST['telefone'] ?? '');
$assunto = trim($_POST['assunto'] ?? '');
$mensagem = trim($_POST['mensagem'] ?? '');

if ($nome === '' || $email === '' || $mensagem === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Nome, email e mensagem são obrigatórios.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Email inválido.']);
    exit;
}

$mailOk = send_contact_mail($nome, $email, $telefone, $assunto, $mensagem);

try {
    db()->prepare('INSERT INTO mensagens (nome, email, telefone, assunto, mensagem, status) VALUES (?,?,?,?,?,"nova")')
        ->execute([$nome, $email, $telefone, $assunto, $mensagem]);
} catch (Throwable $e) {
    // Continua se o email foi enviado.
}

if ($mailOk) {
    echo json_encode(['ok' => true, 'message' => 'Mensagem enviada com sucesso.']);
} else {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Não foi possível enviar a mensagem para o email de atendimento.']);
}
