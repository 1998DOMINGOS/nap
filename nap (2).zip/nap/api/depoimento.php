<?php
/**
 * Endpoint público para depoimentos de clientes.
 * POST: nome, email, cargo, texto, nota
 * O depoimento fica pendente até o administrador validar.
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/app.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Método não permitido']);
    exit;
}

if (trim($_POST['website'] ?? '') !== '') {
    echo json_encode(['ok' => true, 'message' => 'Obrigado. O seu depoimento será publicado após validação.']);
    exit;
}

$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$cargo = trim($_POST['cargo'] ?? '');
$texto = trim($_POST['texto'] ?? '');
$nota = max(1, min(5, (int) ($_POST['nota'] ?? 5)));

if ($nome === '' || $texto === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Nome e depoimento são obrigatórios.']);
    exit;
}

if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Email inválido.']);
    exit;
}

if (mb_strlen($texto) < 20) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Escreva um depoimento com pelo menos 20 caracteres.']);
    exit;
}

if (mb_strlen($texto) > 800) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'O depoimento não pode ultrapassar 800 caracteres.']);
    exit;
}

try {
    if ($email !== '') {
        $dup = db()->prepare("SELECT COUNT(*) FROM depoimentos WHERE email = ? AND status = 'pendente'");
        $dup->execute([$email]);
        if ((int) $dup->fetchColumn() > 0) {
            http_response_code(422);
            echo json_encode(['ok' => false, 'error' => 'Já tem um depoimento à espera de validação.']);
            exit;
        }
    }

    db()->prepare('INSERT INTO depoimentos (nome, email, cargo, texto, nota, status, ordem, origem) VALUES (?,?,?,?,?,"pendente",0,"cliente")')
        ->execute([$nome, $email !== '' ? $email : null, $cargo, $texto, $nota]);

    send_depoimento_mail($nome, $email, $cargo, $texto, $nota);

    echo json_encode(['ok' => true, 'message' => 'Depoimento enviado. Será publicado após validação do administrador.']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Não foi possível guardar o depoimento.']);
}
