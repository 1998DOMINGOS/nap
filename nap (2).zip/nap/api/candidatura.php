<?php
/**
 * Endpoint público para candidaturas (opcional / AJAX).
 * POST: nome, email, telefone, vaga, mensagem, cv (ficheiros)
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/app.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Método não permitido']);
    exit;
}

$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$telefone = trim($_POST['telefone'] ?? '');
$vaga = trim($_POST['vaga'] ?? '');
$mensagem = trim($_POST['mensagem'] ?? '');

if ($nome === '' || $email === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Nome e email são obrigatórios.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Email inválido.']);
    exit;
}

try {
    $cv = null;
    if (!empty($_FILES['cv']['name'])) {
        $cv = upload_file($_FILES['cv'], 'cv', [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'image/jpeg',
            'image/png',
        ], 8 * 1024 * 1024);
    }

    db()->prepare('INSERT INTO candidaturas (nome, email, telefone, vaga, cv_arquivo, mensagem, status) VALUES (?,?,?,?,?,?,"pendente")')
        ->execute([$nome, $email, $telefone, $vaga, $cv, $mensagem]);

    send_candidatura_mail($nome, $email, $telefone, $vaga, $mensagem, $cv);

    echo json_encode(['ok' => true, 'message' => 'Candidatura enviada com sucesso.']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Não foi possível guardar a candidatura.']);
}
