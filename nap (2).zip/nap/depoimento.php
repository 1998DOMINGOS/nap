<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Deixe o seu depoimento — ' . setting('site_nome', APP_NAME);
$pageDescription = 'Partilhe a sua experiência com a ' . setting('site_nome', APP_NAME) . '. O testemunho só é publicado após validação da nossa equipa.';
$currentPage = 'depoimento';
$ok = null;
$err = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $honeypot = trim($_POST['website'] ?? '');
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $cargo = trim($_POST['cargo'] ?? '');
    $texto = trim($_POST['texto'] ?? '');
    $nota = max(1, min(5, (int) ($_POST['nota'] ?? 5)));

    if ($honeypot !== '') {
        $ok = 'Obrigado. O seu depoimento foi recebido e será publicado após validação.';
        $_POST = [];
    } elseif ($nome === '' || $texto === '') {
        $err = 'Nome e depoimento são obrigatórios.';
    } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'Email inválido.';
    } elseif (mb_strlen($texto) < 20) {
        $err = 'Escreva um depoimento com pelo menos 20 caracteres.';
    } elseif (mb_strlen($texto) > 800) {
        $err = 'O depoimento não pode ultrapassar 800 caracteres.';
    } else {
        try {
            if ($email !== '') {
                $dup = db()->prepare("SELECT COUNT(*) FROM depoimentos WHERE email = ? AND status = 'pendente'");
                $dup->execute([$email]);
                if ((int) $dup->fetchColumn() > 0) {
                    throw new RuntimeException('Já tem um depoimento à espera de validação. Aguarde a análise da nossa equipa.');
                }
            }

            db()->prepare('INSERT INTO depoimentos (nome, email, cargo, texto, nota, status, ordem, origem) VALUES (?,?,?,?,?,"pendente",0,"cliente")')
                ->execute([$nome, $email !== '' ? $email : null, $cargo, $texto, $nota]);

            send_depoimento_mail($nome, $email, $cargo, $texto, $nota);
            $ok = 'Obrigado. O seu depoimento foi enviado e só aparecerá no site depois de ser validado pela nossa equipa.';
            $_POST = [];
        } catch (RuntimeException $e) {
            $err = $e->getMessage();
        } catch (Throwable $e) {
            $err = 'Não foi possível enviar o depoimento. Tente novamente.';
        }
    }
}

require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">A SUA OPINIÃO CONTA</p>
        <h1 class="text-4xl md:text-5xl font-bold">Deixe o seu depoimento</h1>
    </div>
</section>
<section class="py-16 bg-white">
    <div class="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div class="animate-enter">
            <h2 class="text-2xl font-bold text-ev-dark mb-4">Quem confia, recomenda</h2>
            <p class="text-gray-600 mb-6">Se é nosso cliente, partilhe a sua experiência. O testemunho é revisto pelo administrador e só depois de aprovado é publicado na página inicial.</p>
            <ul class="space-y-3 text-gray-700">
                <li><i class="fas fa-check text-ev-gold mr-2"></i>Envio rápido pelo formulário</li>
                <li><i class="fas fa-check text-ev-gold mr-2"></i>Validação pela equipa <?= e(setting('site_nome', APP_NAME)) ?></li>
                <li><i class="fas fa-check text-ev-gold mr-2"></i>Publicação apenas após aprovação</li>
            </ul>
        </div>
        <div class="form-card bg-paciolita-branco-suave rounded-2xl p-8 border border-gray-100 animate-enter">
            <?php if ($ok): ?><div class="alert-site ok"><?= e($ok) ?></div><?php endif; ?>
            <?php if ($err): ?><div class="alert-site err"><?= e($err) ?></div><?php endif; ?>
            <form method="post" class="space-y-4">
                <div class="hp-field" aria-hidden="true">
                    <label for="website">Website</label>
                    <input id="website" name="website" tabindex="-1" autocomplete="off">
                </div>
                <div>
                    <label for="nome">Nome *</label>
                    <input id="nome" name="nome" required maxlength="120" value="<?= e($_POST['nome'] ?? '') ?>">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="email">Email</label>
                        <input id="email" type="email" name="email" maxlength="160" value="<?= e($_POST['email'] ?? '') ?>">
                    </div>
                    <div>
                        <label for="cargo">Cargo / Empresa</label>
                        <input id="cargo" name="cargo" maxlength="120" placeholder="Ex.: Gerente, Condomínio..." value="<?= e($_POST['cargo'] ?? '') ?>">
                    </div>
                </div>
                <div>
                    <label for="nota">Avaliação</label>
                    <select id="nota" name="nota">
                        <?php $notaSel = (int) ($_POST['nota'] ?? 5); ?>
                        <?php for ($i = 5; $i >= 1; $i--): ?>
                            <option value="<?= $i ?>" <?= $notaSel === $i ? 'selected' : '' ?>><?= $i ?> estrela<?= $i > 1 ? 's' : '' ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div>
                    <label for="texto">O seu depoimento *</label>
                    <textarea id="texto" name="texto" rows="5" required maxlength="800" placeholder="Conte-nos como foi a sua experiência connosco..."><?= e($_POST['texto'] ?? '') ?></textarea>
                </div>
                <p class="text-sm text-gray-500">O depoimento não é publicado de imediato. A nossa equipa valida o conteúdo antes de aparecer no site.</p>
                <button type="submit" class="btn-ev-gold w-full text-center"><i class="fas fa-paper-plane mr-2"></i>Enviar depoimento</button>
            </form>
        </div>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
