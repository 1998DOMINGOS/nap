<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Carreiras — ' . setting('site_nome', APP_NAME);
$currentPage = 'carreiras';
$ok = null;
$err = null;
$vagasAbertas = [];
try {
    ensure_rh_schema();
    $vagasAbertas = rh_vagas_abertas();
} catch (Throwable $e) {
    $vagasAbertas = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $vaga = trim($_POST['vaga'] ?? '');
    $mensagem = trim($_POST['mensagem'] ?? '');

    if ($nome === '' || $email === '') {
        $err = 'Nome e email são obrigatórios.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'Email inválido.';
    } else {
        try {
            $cv = null;
            if (!empty($_FILES['cv']['name'])) {
                $cv = upload_file($_FILES['cv'], 'cv', [
                    'application/pdf',
                    'application/msword',
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'image/jpeg',
                    'image/png',
                ], 8 * 1024 * 1024);
            }
            db()->prepare('INSERT INTO candidaturas (nome, email, telefone, vaga, cv_arquivo, mensagem, status) VALUES (?,?,?,?,?,?,"pendente")')
                ->execute([$nome, $email, $telefone, $vaga, $cv, $mensagem]);

            send_candidatura_mail($nome, $email, $telefone, $vaga, $mensagem, $cv);
            $ok = 'Candidatura enviada com sucesso. Obrigado!';
            $_POST = [];
        } catch (Throwable $e) {
            $err = $e->getMessage() ?: 'Não foi possível enviar a candidatura.';
        }
    }
}

require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">JUNTE-SE A NÓS</p>
        <h1 class="text-4xl md:text-5xl font-bold">Carreiras</h1>
    </div>
</section>
<?php if ($vagasAbertas): ?>
<section class="py-12 bg-paciolita-branco-suave border-b border-gray-100">
    <div class="container mx-auto px-4">
        <h2 class="text-2xl font-bold text-ev-dark mb-6">Vagas abertas</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php foreach ($vagasAbertas as $v): ?>
            <article class="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
                <h3 class="text-lg font-bold text-ev-dark"><?= e($v['titulo']) ?></h3>
                <p class="text-sm text-gray-500 mb-2"><?= e(trim(($v['departamento'] ?? '') . ' · ' . ($v['local_trabalho'] ?? ''), ' ·')) ?: 'INFORMATIZA' ?></p>
                <?php if (!empty($v['descricao'])): ?><p class="text-gray-600 text-sm mb-3"><?= e(mb_strimwidth(strip_tags($v['descricao']), 0, 220, '…')) ?></p><?php endif; ?>
                <a href="#form-candidatura" class="text-ev-gold font-semibold text-sm">Candidatar-se →</a>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>
<section class="py-16 bg-white" id="form-candidatura">
    <div class="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div class="animate-enter">
            <h2 class="text-2xl font-bold text-ev-dark mb-4">Faça parte da <?= e(setting('site_nome', APP_NAME)) ?></h2>
            <p class="text-gray-600 mb-6">Procuramos pessoas criativas e dedicadas à tecnologia, ao suporte e ao atendimento. Envie a sua candidatura espontânea ou para uma vaga específica.</p>
            <ul class="space-y-3 text-gray-700">
                <li><i class="fas fa-check text-ev-gold mr-2"></i>Ambiente criativo</li>
                <li><i class="fas fa-check text-ev-gold mr-2"></i>Paixão por detalhe e autenticidade</li>
                <li><i class="fas fa-check text-ev-gold mr-2"></i>Oportunidades de crescimento</li>
            </ul>
        </div>
        <div class="form-card bg-paciolita-branco-suave rounded-2xl p-8 border border-gray-100 animate-enter">
            <?php if ($ok): ?><div class="alert-site ok"><?= e($ok) ?></div><?php endif; ?>
            <?php if ($err): ?><div class="alert-site err"><?= e($err) ?></div><?php endif; ?>
            <form method="post" enctype="multipart/form-data" class="space-y-4">
                <div>
                    <label for="nome">Nome completo *</label>
                    <input id="nome" name="nome" required value="<?= e($_POST['nome'] ?? '') ?>">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="email">Email *</label>
                        <input id="email" type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>">
                    </div>
                    <div>
                        <label for="telefone">Telefone</label>
                        <input id="telefone" name="telefone" value="<?= e($_POST['telefone'] ?? '') ?>">
                    </div>
                </div>
                <div>
                    <label for="vaga">Vaga de interesse</label>
                    <input id="vaga" name="vaga" list="vagas-list" placeholder="Ex.: Técnico de suporte..." value="<?= e($_POST['vaga'] ?? '') ?>">
                    <datalist id="vagas-list">
                        <?php foreach ($vagasAbertas as $v): ?><option value="<?= e($v['titulo']) ?>"><?php endforeach; ?>
                    </datalist>
                </div>
                <div>
                    <label for="cv">CV (PDF/DOC, máx. 8MB)</label>
                    <input id="cv" type="file" name="cv" accept=".pdf,.doc,.docx,image/*">
                </div>
                <div>
                    <label for="mensagem">Mensagem</label>
                    <textarea id="mensagem" name="mensagem" rows="4"><?= e($_POST['mensagem'] ?? '') ?></textarea>
                </div>
                <button type="submit" class="btn-ev-gold w-full text-center"><i class="fas fa-paper-plane mr-2"></i>Enviar candidatura</button>
            </form>
        </div>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
