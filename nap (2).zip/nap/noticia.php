<?php
require_once __DIR__ . '/config/app.php';
$slug = trim($_GET['slug'] ?? '');
$stmt = db()->prepare("SELECT * FROM noticias WHERE slug = ? AND status='publicado' LIMIT 1");
$stmt->execute([$slug]);
$noticia = $stmt->fetch();
if (!$noticia) {
    http_response_code(404);
    $pageTitle = 'Notícia não encontrada';
    $currentPage = 'news';
    require __DIR__ . '/includes/site_header.php';
    echo '<section class="py-20 container mx-auto px-4 text-center"><h1 class="text-3xl font-bold mb-4">Notícia não encontrada</h1><a class="btn-ev" href="' . e(site_url('news')) . '">Voltar</a></section>';
    require __DIR__ . '/includes/site_footer.php';
    exit;
}
$pageTitle = $noticia['titulo'] . ' — ' . setting('site_nome', APP_NAME);
$currentPage = 'news';
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4 max-w-4xl">
        <p class="text-ev-gold font-semibold mb-2"><?= e(format_date($noticia['publicado_em'] ?? $noticia['criado_em'], 'd/m/Y')) ?></p>
        <h1 class="text-3xl md:text-5xl font-bold"><?= e($noticia['titulo']) ?></h1>
    </div>
</section>
<article class="py-16 bg-white">
    <div class="container mx-auto px-4 max-w-3xl animate-enter">
        <?php if ($noticia['imagem']): ?>
            <img src="<?= e(media_url($noticia['imagem'])) ?>" alt="<?= e($noticia['titulo']) ?>" class="w-full rounded-2xl mb-8 object-cover max-h-[420px]">
        <?php endif; ?>
        <?php if ($noticia['resumo']): ?><p class="text-xl text-gray-700 mb-6"><?= e($noticia['resumo']) ?></p><?php endif; ?>
        <div class="text-gray-700 leading-relaxed whitespace-pre-line"><?= nl2br(e($noticia['conteudo'])) ?></div>
        <div class="mt-10"><a href="<?= site_url('news') ?>" class="btn-ev">Todas as notícias</a></div>
    </div>
</article>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
