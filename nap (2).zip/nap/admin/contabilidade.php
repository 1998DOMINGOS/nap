<?php
require_once __DIR__ . '/../config/app.php';
redirect('/admin/contabilidade/dashboard.php');
