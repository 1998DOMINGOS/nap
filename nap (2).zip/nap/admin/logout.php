<?php
require_once __DIR__ . '/../config/app.php';
logout_user();
flash('success', 'Sessão terminada com sucesso.');
redirect('/admin/index.php');
