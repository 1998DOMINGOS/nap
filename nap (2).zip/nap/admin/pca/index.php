<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Mensagem do PCA';
$pageSubtitle = 'Actualizar a mensagem e a fotografia apresentada no site';
$current = 'pca';
$errors = [];
$stmt = db()->query('SELECT * FROM mensagem_pca ORDER BY id DESC LIMIT 1');
$item = $stmt->fetch() ?: ['id' => 0, 'nome' => '', 'cargo' => '', 'mensagem' => '', 'foto' => '', 'ativo' => 1];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $cargo = trim($_POST['cargo'] ?? '');
    $mensagem = trim($_POST['mensagem'] ?? '');
    $ativo = isset($_POST['ativo']) ? 1 : 0;
    $foto = $item['foto'] ?? null;
    if ($nome === '' || $cargo === '' || $mensagem === '') $errors[] = 'Nome, cargo e mensagem são obrigatórios.';
    if (!$errors && !empty($_FILES['foto']['name'])) {
        try { $foto = upload_image($_FILES['foto'], 'pca'); }
        catch (Throwable $e) { $errors[] = $e->getMessage(); }
    }
    if (!$errors) {
        if ((int)$item['id'] > 0) {
            db()->prepare('UPDATE mensagem_pca SET nome=?, cargo=?, mensagem=?, foto=?, ativo=? WHERE id=?')->execute([$nome, $cargo, $mensagem, $foto, $ativo, $item['id']]);
        } else {
            db()->prepare('INSERT INTO mensagem_pca (nome,cargo,mensagem,foto,ativo) VALUES (?,?,?,?,?)')->execute([$nome, $cargo, $mensagem, $foto, $ativo]);
        }
        flash('success', 'Mensagem do PCA actualizada.');
        redirect('/admin/pca/index.php');
    }
    $item = array_merge($item, compact('nome', 'cargo', 'mensagem', 'foto', 'ativo'));
}

require __DIR__ . '/../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data">
<?= csrf_field() ?>
<div class="form-grid"><div class="form-group"><label>Nome do PCA</label><input class="form-control" name="nome" required value="<?= e($item['nome']) ?>"></div><div class="form-group"><label>Cargo</label><input class="form-control" name="cargo" required value="<?= e($item['cargo']) ?>"></div></div>
<div class="form-group"><label>Mensagem</label><textarea name="mensagem" required style="min-height:220px"><?= e($item['mensagem']) ?></textarea></div>
<div class="form-grid"><div class="form-group"><label>Nova fotografia</label><input class="form-control" type="file" name="foto" accept="image/*"><small>JPG, PNG, WEBP ou GIF até 5 MB.</small></div><div class="form-group"><label>Estado</label><select name="ativo"><option value="1" <?= (int)$item['ativo'] === 1 ? 'selected' : '' ?>>Publicado</option><option value="0" <?= (int)$item['ativo'] !== 1 ? 'selected' : '' ?>>Oculto</option></select></div></div>
<?php if (!empty($item['foto'])): ?><p class="subtitle">Fotografia actual guardada: <?= e($item['foto']) ?></p><?php endif; ?>
<div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar mensagem</button></div>
</form>
</div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
