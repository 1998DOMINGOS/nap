<?php
require_once __DIR__ . '/../../config/app.php';
require_admin();

$pageTitle = 'Configurações';
$current = 'configuracoes';

$rows = db()->query('SELECT chave, valor FROM configuracoes')->fetchAll();
$cfg = [];
foreach ($rows as $row) {
    $cfg[$row['chave']] = $row['valor'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $fields = [
        'site_nome', 'site_email', 'site_telefone', 'site_telefone_secundario', 'site_morada',
        'site_whatsapp', 'site_facebook', 'site_instagram', 'site_linkedin',
    ];
    $stmt = db()->prepare('INSERT INTO configuracoes (chave, valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)');
    foreach ($fields as $field) {
        $stmt->execute([$field, trim($_POST[$field] ?? '')]);
        $cfg[$field] = trim($_POST[$field] ?? '');
    }
    flash('success', 'Configurações guardadas.');
    redirect('/admin/configuracoes/index.php');
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<form method="post">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome do site</label><input class="form-control" name="site_nome" value="<?= e($cfg['site_nome'] ?? '') ?>"></div>
        <div class="form-group"><label>Email de contacto</label><input class="form-control" name="site_email" value="<?= e($cfg['site_email'] ?? 'geralnacionalajudaopais@gmail.com') ?>"></div>
    </div>
    <div class="form-grid">
        <div class="form-group"><label>Telefone / WhatsApp (principal)</label><input class="form-control" name="site_telefone" value="<?= e($cfg['site_telefone'] ?? '935406556') ?>"></div>
        <div class="form-group"><label>WhatsApp (link wa.me)</label><input class="form-control" name="site_whatsapp" value="<?= e($cfg['site_whatsapp'] ?? '935406556') ?>" placeholder="935406556"></div>
    </div>
    <div class="form-group"><label>Telefone secundário</label><input class="form-control" name="site_telefone_secundario" value="<?= e($cfg['site_telefone_secundario'] ?? '') ?>"></div>
    <div class="form-group"><label>Morada e presença</label><input class="form-control" name="site_morada" value="<?= e($cfg['site_morada'] ?? 'Sede: Uíge | Luanda: Maianga, Edifício Unitel, 5.º andar | Huíla | Benguela | Mbanza Congo') ?>"></div>
    <div class="form-grid">
        <div class="form-group"><label>Facebook</label><input class="form-control" name="site_facebook" value="<?= e($cfg['site_facebook'] ?? '') ?>"></div>
        <div class="form-group"><label>Instagram</label><input class="form-control" name="site_instagram" value="<?= e($cfg['site_instagram'] ?? '') ?>"></div>
    </div>
    <div class="form-group"><label>LinkedIn</label><input class="form-control" name="site_linkedin" value="<?= e($cfg['site_linkedin'] ?? '') ?>"></div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar configurações</button>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
