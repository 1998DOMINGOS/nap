<?php
$pageTitle = 'Vagas';
$current = 'rh-vagas';
require_once __DIR__ . '/../../config/app.php';
ensure_rh_schema();

$errors = [];
$ok = null;
$editId = (int) ($_GET['editar'] ?? 0);
$editing = null;
if ($editId) {
    $st = db()->prepare('SELECT * FROM rh_vagas WHERE id=?');
    $st->execute([$editId]);
    $editing = $st->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'save';
    if ($action === 'delete') {
        db()->prepare('DELETE FROM rh_vagas WHERE id=?')->execute([(int) ($_POST['id'] ?? 0)]);
        flash('success', 'Vaga eliminada.');
        redirect('/admin/rh/vagas.php');
    }
    $titulo = trim($_POST['titulo'] ?? '');
    $dept = trim($_POST['departamento'] ?? '');
    $local = trim($_POST['local_trabalho'] ?? '');
    $tipo = in_array($_POST['tipo'] ?? '', ['tempo_inteiro', 'meio_periodo', 'estagio', 'freelance'], true) ? $_POST['tipo'] : 'tempo_inteiro';
    $status = in_array($_POST['status'] ?? '', ['aberta', 'pausada', 'fechada'], true) ? $_POST['status'] : 'aberta';
    $desc = trim($_POST['descricao'] ?? '');
    $req = trim($_POST['requisitos'] ?? '');
    if ($titulo === '') {
        $errors[] = 'Título obrigatório.';
    }
    if (!$errors) {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id) {
            db()->prepare('UPDATE rh_vagas SET titulo=?, departamento=?, local_trabalho=?, tipo=?, descricao=?, requisitos=?, status=? WHERE id=?')
                ->execute([$titulo, $dept ?: null, $local ?: null, $tipo, $desc ?: null, $req ?: null, $status, $id]);
            $ok = 'Vaga actualizada.';
        } else {
            db()->prepare('INSERT INTO rh_vagas (titulo, departamento, local_trabalho, tipo, descricao, requisitos, status) VALUES (?,?,?,?,?,?,?)')
                ->execute([$titulo, $dept ?: null, $local ?: null, $tipo, $desc ?: null, $req ?: null, $status]);
            $ok = 'Vaga criada.';
        }
    }
}

$vagas = db()->query('SELECT * FROM rh_vagas ORDER BY FIELD(status,"aberta","pausada","fechada"), titulo')->fetchAll();
$form = $editing ?: [];
require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>
<div class="grid-2">
<div class="card"><div class="card-body"><h3><?= $editing ? 'Editar vaga' : 'Nova vaga' ?></h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="save">
<?php if ($editing): ?><input type="hidden" name="id" value="<?= (int) $editing['id'] ?>"><?php endif; ?>
<div class="form-group"><label>Título *</label><input class="form-control" name="titulo" value="<?= e($form['titulo'] ?? '') ?>" required></div>
<div class="form-grid">
<div class="form-group"><label>Departamento</label><input class="form-control" name="departamento" value="<?= e($form['departamento'] ?? '') ?>"></div>
<div class="form-group"><label>Local</label><input class="form-control" name="local_trabalho" value="<?= e($form['local_trabalho'] ?? '') ?>"></div>
</div>
<div class="form-grid">
<div class="form-group"><label>Tipo</label><select name="tipo" class="form-control">
<?php foreach (['tempo_inteiro' => 'Tempo inteiro', 'meio_periodo' => 'Meio período', 'estagio' => 'Estágio', 'freelance' => 'Freelance'] as $k => $l): ?>
<option value="<?= $k ?>" <?= ($form['tipo'] ?? 'tempo_inteiro') === $k ? 'selected' : '' ?>><?= e($l) ?></option>
<?php endforeach; ?></select></div>
<div class="form-group"><label>Estado</label><select name="status" class="form-control">
<?php foreach (['aberta' => 'Aberta', 'pausada' => 'Pausada', 'fechada' => 'Fechada'] as $k => $l): ?>
<option value="<?= $k ?>" <?= ($form['status'] ?? 'aberta') === $k ? 'selected' : '' ?>><?= e($l) ?></option>
<?php endforeach; ?></select></div>
</div>
<div class="form-group"><label>Descrição</label><textarea class="form-control" name="descricao" rows="4"><?= e($form['descricao'] ?? '') ?></textarea></div>
<div class="form-group"><label>Requisitos</label><textarea class="form-control" name="requisitos" rows="3"><?= e($form['requisitos'] ?? '') ?></textarea></div>
<button class="btn btn-primary" type="submit">Guardar</button>
<?php if ($editing): ?><a class="btn btn-outline" href="<?= url('/admin/rh/vagas.php') ?>">Cancelar</a><?php endif; ?>
</form></div></div>
<div class="card"><div class="card-body"><h3>Vagas (<?= count($vagas) ?>)</h3>
<table><thead><tr><th>Título</th><th>Estado</th><th></th></tr></thead><tbody>
<?php foreach ($vagas as $v): ?><tr>
<td><strong><?= e($v['titulo']) ?></strong><br><span style="font-size:.8rem;color:var(--muted)"><?= e($v['departamento'] ?: '—') ?></span></td>
<td><?= e($v['status']) ?></td>
<td class="actions">
<a class="btn btn-sm btn-outline" href="<?= url('/admin/rh/vagas.php?editar=' . (int) $v['id']) ?>"><i class="fas fa-pen"></i></a>
<form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $v['id'] ?>">
<button class="btn btn-sm btn-danger" type="submit" data-confirm="Eliminar vaga?"><i class="fas fa-trash"></i></button></form>
</td></tr><?php endforeach; ?>
</tbody></table></div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
