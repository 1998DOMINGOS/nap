<?php
require_once __DIR__ . '/../../config/app.php';
require_rh();
$id = (int) ($_GET['id'] ?? 0);
if ($id > 0) {
    db()->prepare('DELETE FROM candidaturas WHERE id = ?')->execute([$id]);
    flash('success', 'Candidatura eliminada.');
}
redirect('/admin/rh/candidaturas.php');
