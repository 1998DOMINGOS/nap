<?php
$pageTitle = 'Candidaturas';
$current = 'rh-cand';
require_once __DIR__ . '/../../config/app.php';
ensure_rh_schema();

$items = db()->query('SELECT * FROM candidaturas ORDER BY FIELD(status,"pendente","aprovada","rejeitada"), id DESC')->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<div class="card"><div class="card-head"><h2>Candidaturas (<?= count($items) ?>)</h2>
    <a class="btn btn-outline btn-sm" href="<?= site_url('carreiras') ?>" target="_blank" rel="noopener">Ver página pública</a>
</div>
<div class="table-wrap"><table>
<thead><tr><th>Nome</th><th>Email</th><th>Vaga</th><th>Data</th><th>Estado</th><th></th></tr></thead>
<tbody>
<?php if (!$items): ?><tr><td colspan="6" class="empty">Nenhuma candidatura.</td></tr><?php endif; ?>
<?php foreach ($items as $item): ?>
<tr>
    <td><?= e($item['nome']) ?></td>
    <td><?= e($item['email']) ?></td>
    <td><?= e($item['vaga'] ?: 'Espontânea') ?></td>
    <td><?= e(format_date($item['criado_em'])) ?></td>
    <td><?= status_badge($item['status']) ?></td>
    <td class="actions">
        <a class="btn btn-sm btn-outline" href="<?= url('/admin/rh/candidatura.php?id=' . (int) $item['id']) ?>"><i class="fas fa-eye"></i></a>
        <a class="btn btn-sm btn-danger" data-confirm="Eliminar candidatura?" href="<?= url('/admin/rh/candidatura-excluir.php?id=' . (int) $item['id']) ?>"><i class="fas fa-trash"></i></a>
    </td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
