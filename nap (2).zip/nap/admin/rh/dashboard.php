<?php
$pageTitle = 'Dashboard RH';
$pageSubtitle = 'Recrutamento, colaboradores e folha';
$current = 'rh-dashboard';
require_once __DIR__ . '/../../config/app.php';
ensure_rh_schema();

$kpi = rh_dashboard_kpis();
$pipeline = rh_pipeline_candidaturas();
$candidaturas = rh_ultimas_candidaturas(8);
$ausencias = rh_ausencias_proximas(5);
$admissoes = rh_admissoes_mes();
$chartPayload = [
    'candidaturas' => rh_candidaturas_series(6),
    'folha' => rh_folha_series(6),
    'pipeline' => $pipeline,
];

require __DIR__ . '/includes/header.php';
?>
<style>
.rh-charts { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 16px; }
.rh-chart-wrap { position: relative; height: 280px; }
@media (max-width: 960px) { .rh-charts { grid-template-columns: 1fr; } }
</style>

<div class="stats-grid" style="margin-top:0">
    <article class="stat-card"><div class="stat-icon warn"><i class="fas fa-inbox"></i></div><div><span>Candidaturas pendentes</span><strong><?= (int) $kpi['candidaturas_pendentes'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon info"><i class="fas fa-calendar-plus"></i></div><div><span>Candidaturas (mês)</span><strong><?= (int) $kpi['candidaturas_mes'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon green"><i class="fas fa-id-badge"></i></div><div><span>Colaboradores activos</span><strong><?= (int) $kpi['funcionarios_ativos'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon dark"><i class="fas fa-briefcase"></i></div><div><span>Vagas abertas</span><strong><?= (int) $kpi['vagas_abertas'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon warn"><i class="fas fa-plane-departure"></i></div><div><span>Ausências pendentes</span><strong><?= (int) $kpi['ausencias_pendentes'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon green"><i class="fas fa-coins"></i></div><div><span>Massa salarial (bruta)</span><strong><?= e(fat_format_money((float) $kpi['massa_salarial_bruta'])) ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon info"><i class="fas fa-file-invoice-dollar"></i></div><div><span>Folha líquida (mês)</span><strong><?= e(fat_format_money((float) $kpi['folha_liquida_mes'])) ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon dark"><i class="fas fa-users"></i></div><div><span>Equipe no site</span><strong><?= (int) $kpi['equipe_site'] ?></strong></div></article>
</div>

<section class="rh-charts" aria-label="Gráficos RH">
    <div class="card"><div class="card-head"><h2>Candidaturas (6 meses)</h2></div>
        <div class="card-body"><div class="rh-chart-wrap"><canvas id="rhChartCand"></canvas></div></div></div>
    <div class="card"><div class="card-head"><h2>Pipeline de recrutamento</h2></div>
        <div class="card-body"><div class="rh-chart-wrap"><canvas id="rhChartPipe"></canvas></div></div></div>
    <div class="card" style="grid-column:1/-1"><div class="card-head"><h2>Folha salarial processada (6 meses)</h2><a class="link" href="<?= url('/admin/rh/folha.php') ?>">Ver folha</a></div>
        <div class="card-body"><div class="rh-chart-wrap"><canvas id="rhChartFolha"></canvas></div></div></div>
</section>

<div class="grid-2" style="margin-top:16px">
    <div class="card"><div class="card-head"><h2>Últimas candidaturas</h2><a class="link" href="<?= url('/admin/rh/candidaturas.php') ?>">Ver todas</a></div>
        <div class="card-body table-wrap"><table>
            <thead><tr><th>Nome</th><th>Vaga</th><th>Estado</th><th></th></tr></thead>
            <tbody>
            <?php if (!$candidaturas): ?><tr><td colspan="4" class="empty">Sem candidaturas.</td></tr><?php endif; ?>
            <?php foreach ($candidaturas as $c): ?>
                <tr>
                    <td><?= e($c['nome']) ?></td>
                    <td><?= e($c['vaga'] ?: '—') ?></td>
                    <td><?= status_badge($c['status']) ?></td>
                    <td><a class="btn btn-sm btn-outline" href="<?= url('/admin/rh/candidatura.php?id=' . (int) $c['id']) ?>">Abrir</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div></div>

    <div class="card"><div class="card-head"><h2>Próximas ausências</h2><a class="link" href="<?= url('/admin/rh/ausencias.php') ?>">Gerir</a></div>
        <div class="card-body table-wrap"><table>
            <thead><tr><th>Colaborador</th><th>Tipo</th><th>Período</th></tr></thead>
            <tbody>
            <?php if (!$ausencias): ?><tr><td colspan="3" class="empty">Nenhuma ausência agendada.</td></tr><?php endif; ?>
            <?php foreach ($ausencias as $a): ?>
                <tr>
                    <td><?= e($a['funcionario_nome']) ?></td>
                    <td><?= e(str_replace('_', ' ', $a['tipo'])) ?></td>
                    <td><?= e(format_date($a['data_inicio'], 'd/m/Y')) ?> – <?= e(format_date($a['data_fim'], 'd/m/Y')) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div></div>
</div>

<?php if ($admissoes): ?>
<?php
$mesesPt = ['', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
?>
<div class="card" style="margin-top:16px"><div class="card-head"><h2>Aniversários de admissão — <?= e($mesesPt[(int) date('n')] ?? '') ?></h2></div><div class="card-body">
    <ul><?php foreach ($admissoes as $a): ?>
        <li><strong><?= e($a['nome']) ?></strong> — <?= e($a['cargo'] ?? '') ?> · <?= e(format_date($a['data_admissao'], 'd/m/Y')) ?></li>
    <?php endforeach; ?></ul>
</div></div>
<?php endif; ?>

<div class="card" style="margin-top:16px"><div class="card-head"><h2>Atalhos</h2></div><div class="card-body" style="display:flex;flex-wrap:wrap;gap:8px">
    <a class="btn btn-primary" href="<?= url('/admin/rh/vagas.php') ?>"><i class="fas fa-plus"></i> Nova vaga</a>
    <a class="btn btn-outline" href="<?= url('/admin/rh/colaboradores.php') ?>"><i class="fas fa-user-plus"></i> Colaborador</a>
    <a class="btn btn-outline" href="<?= url('/admin/rh/ausencias.php') ?>"><i class="fas fa-calendar-check"></i> Registar ausência</a>
    <a class="btn btn-outline" href="<?= site_url('carreiras') ?>" target="_blank" rel="noopener"><i class="fas fa-external-link-alt"></i> Página Carreiras</a>
    <?php if (is_admin_user()): ?>
    <a class="btn btn-outline" href="<?= url('/admin/contabilidade/salarios.php') ?>"><i class="fas fa-calculator"></i> Folha (contabilidade)</a>
    <?php endif; ?>
</div></div>

<?php
$pageFootScripts = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>'
    . '<script>window.rhDashCharts = ' . json_encode($chartPayload, JSON_UNESCAPED_UNICODE) . ';</script>'
    . '<script src="' . e(url('/admin/rh/assets/dashboard-charts.js')) . '"></script>';
require __DIR__ . '/includes/footer.php';
