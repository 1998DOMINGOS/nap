<?php
$pageTitle = 'Folha salarial';
$current = 'rh-folha';
require_once __DIR__ . '/../../config/app.php';
ensure_contabilidade_schema();

$kpi = rh_dashboard_kpis();
$folhas = db()->query('SELECT * FROM cont_folhas ORDER BY ano DESC, mes DESC LIMIT 24')->fetchAll();
$funcs = db()->query('SELECT COUNT(*) FROM cont_funcionarios WHERE ativo=1')->fetchColumn();
require __DIR__ . '/includes/header.php';
?>
<div class="stats-grid" style="margin-top:0">
    <article class="stat-card"><div class="stat-icon green"><i class="fas fa-users"></i></div><div><span>Colaboradores</span><strong><?= (int) $funcs ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon info"><i class="fas fa-coins"></i></div><div><span>Massa bruta mensal (est.)</span><strong><?= e(fat_format_money((float) $kpi['massa_salarial_bruta'])) ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon dark"><i class="fas fa-wallet"></i></div><div><span>Última folha líquida</span><strong><?= e(fat_format_money((float) $kpi['folha_liquida_mes'])) ?></strong></div></article>
</div>
<div class="card" style="margin-top:16px"><div class="card-head"><h2>Folhas processadas</h2>
<?php if (is_admin_user()): ?><a class="btn btn-outline btn-sm" href="<?= url('/admin/contabilidade/salarios.php') ?>">Processar folha (contabilidade)</a><?php endif; ?>
</div><div class="table-wrap"><table>
<thead><tr><th>Período</th><th>Bruto</th><th>Líquido</th><th>Estado</th><th>Pagamento</th></tr></thead>
<tbody>
<?php if (!$folhas): ?><tr><td colspan="5" class="empty">Nenhuma folha. Use Contabilidade → Salários para processar.</td></tr><?php endif; ?>
<?php foreach ($folhas as $fo): ?>
<tr>
<td><?= sprintf('%02d/%04d', (int) $fo['mes'], (int) $fo['ano']) ?></td>
<td><?= e(fat_format_money((float) $fo['total_bruto'])) ?></td>
<td><?= e(fat_format_money((float) $fo['total_liquido'])) ?></td>
<td><?= e($fo['estado']) ?></td>
<td><?= e(format_date($fo['data_pagamento'], 'd/m/Y')) ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
<p class="subtitle">A folha gera lançamentos contabilísticos (631/632/25/24/12). O perfil RH consulta; o processamento é feito na contabilidade.</p>
<?php require __DIR__ . '/includes/footer.php'; ?>
