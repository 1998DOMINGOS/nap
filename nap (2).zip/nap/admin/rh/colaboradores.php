<?php
$pageTitle = 'Colaboradores';
$current = 'rh-colab';
require_once __DIR__ . '/../../config/app.php';
ensure_contabilidade_schema();
ensure_rh_schema();

$errors = [];
$ok = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'add';
    if ($action === 'toggle') {
        $id = (int) ($_POST['id'] ?? 0);
        db()->prepare('UPDATE cont_funcionarios SET ativo = 1 - ativo WHERE id=?')->execute([$id]);
        $ok = 'Estado actualizado.';
    } else {
        $nome = trim($_POST['nome'] ?? '');
        if ($nome === '') {
            $errors[] = 'Nome obrigatório.';
        }
        if (!$errors) {
            db()->prepare('INSERT INTO cont_funcionarios (nome, nif, cargo, salario_base, subsidio, data_admissao) VALUES (?,?,?,?,?,?)')
                ->execute([
                    $nome,
                    trim($_POST['nif'] ?? ''),
                    trim($_POST['cargo'] ?? ''),
                    (float) str_replace(',', '.', $_POST['salario_base'] ?? '0'),
                    (float) str_replace(',', '.', $_POST['subsidio'] ?? '0'),
                    $_POST['data_admissao'] ?? null,
                ]);
            $ok = 'Colaborador registado.';
        }
    }
}

$ativos = db()->query('SELECT * FROM cont_funcionarios WHERE ativo=1 ORDER BY nome')->fetchAll();
$inativos = db()->query('SELECT * FROM cont_funcionarios WHERE ativo=0 ORDER BY nome LIMIT 20')->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>
<div class="grid-2">
<div class="card"><div class="card-body"><h3>Novo colaborador</h3>
<form method="post"><?= csrf_field() ?>
<div class="form-group"><label>Nome *</label><input class="form-control" name="nome" required></div>
<div class="form-grid">
<div class="form-group"><label>NIF</label><input class="form-control" name="nif"></div>
<div class="form-group"><label>Cargo</label><input class="form-control" name="cargo"></div>
</div>
<div class="form-grid">
<div class="form-group"><label>Salário base</label><input class="form-control" name="salario_base"></div>
<div class="form-group"><label>Subsídio</label><input class="form-control" name="subsidio" value="0"></div>
</div>
<div class="form-group"><label>Data admissão</label><input class="form-control" type="date" name="data_admissao"></div>
<button class="btn btn-primary" type="submit">Registar</button>
</form></div></div>
<div class="card"><div class="card-body"><h3>Activos (<?= count($ativos) ?>)</h3>
<div class="table-wrap"><table><thead><tr><th>Nome</th><th>Cargo</th><th>Remuneração</th><th></th></tr></thead><tbody>
<?php foreach ($ativos as $f): ?>
<tr>
<td><?= e($f['nome']) ?></td>
<td><?= e($f['cargo'] ?? '—') ?></td>
<td><?= e(fat_format_money((float) $f['salario_base'] + (float) $f['subsidio'])) ?></td>
<td><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $f['id'] ?>">
<button class="btn btn-sm btn-outline" type="submit" data-confirm="Desactivar colaborador?">Desactivar</button></form></td>
</tr>
<?php endforeach; ?>
</tbody></table></div>
<?php if ($inativos): ?><h4 style="margin-top:16px">Inactivos</h4><ul><?php foreach ($inativos as $f): ?><li><?= e($f['nome']) ?></li><?php endforeach; ?></ul><?php endif; ?>
</div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
