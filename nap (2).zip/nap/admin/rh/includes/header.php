<?php
require_once __DIR__ . '/../../../config/app.php';
require_rh();

$user = current_user();
$pageTitle = $pageTitle ?? 'Recursos Humanos';
$current = $current ?? 'rh-dashboard';
$flash = get_flash();
$rhKpiNav = rh_dashboard_kpis();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> — RH · <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= url('/css/fonts.css') ?>">
    <link rel="stylesheet" href="<?= url('/vendor/fontawesome/css/all.min.css') ?>">
    <link rel="stylesheet" href="<?= url('/admin/assets/css/admin.css') ?>">
    <?php nap_swal_styles(); ?>
</head>
<body>
<script>
(function () {
    try {
        var stored = localStorage.getItem('informatiza-theme');
        if (stored === 'dark' || (!stored && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.body.classList.add('dark-mode');
        }
    } catch (e) {}
})();
</script>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <div class="brand-mark"><img src="<?= e(url('/imgs/logo-informatiza.svg?v=4')) ?>" alt=""></div>
            <div>
                <strong>Recursos Humanos</strong>
                <span><?= e(APP_NAME) ?></span>
            </div>
        </div>
        <nav class="nav">
            <a href="<?= url('/admin/rh/dashboard.php') ?>" class="<?= $current === 'rh-dashboard' ? 'active' : '' ?>"><i class="fas fa-gauge-high"></i> Dashboard</a>
            <a href="<?= url('/admin/rh/candidaturas.php') ?>" class="<?= $current === 'rh-cand' ? 'active' : '' ?>"><i class="fas fa-file-lines"></i> Candidaturas<?php if ($rhKpiNav['candidaturas_pendentes'] > 0): ?> <span class="nav-count"><?= (int) $rhKpiNav['candidaturas_pendentes'] ?></span><?php endif; ?></a>
            <a href="<?= url('/admin/rh/vagas.php') ?>" class="<?= $current === 'rh-vagas' ? 'active' : '' ?>"><i class="fas fa-briefcase"></i> Vagas</a>
            <a href="<?= url('/admin/rh/colaboradores.php') ?>" class="<?= $current === 'rh-colab' ? 'active' : '' ?>"><i class="fas fa-id-badge"></i> Colaboradores</a>
            <a href="<?= url('/admin/rh/ausencias.php') ?>" class="<?= $current === 'rh-aus' ? 'active' : '' ?>"><i class="fas fa-calendar-check"></i> Ausências<?php if ($rhKpiNav['ausencias_pendentes'] > 0): ?> <span class="nav-count"><?= (int) $rhKpiNav['ausencias_pendentes'] ?></span><?php endif; ?></a>
            <a href="<?= url('/admin/rh/folha.php') ?>" class="<?= $current === 'rh-folha' ? 'active' : '' ?>"><i class="fas fa-money-check-dollar"></i> Folha salarial</a>
            <a href="<?= url('/admin/equipe/index.php') ?>" class="<?= $current === 'rh-equipe' ? 'active' : '' ?>"><i class="fas fa-users"></i> Equipe (site)</a>
            <?php if (is_admin_user() || ($_SESSION['user_nivel'] ?? '') === 'editor'): ?>
                <a href="<?= url('/admin/dashboard.php') ?>" style="margin-top:12px;border-top:1px solid rgba(255,255,255,.1);padding-top:12px"><i class="fas fa-arrow-left"></i> Administração geral</a>
            <?php endif; ?>
        </nav>
        <div class="sidebar-foot">
            <a href="<?= url('/admin/logout.php') ?>" class="logout-link"><i class="fas fa-right-from-bracket"></i> Sair</a>
        </div>
    </aside>
    <div class="main">
        <header class="topbar">
            <button class="menu-toggle" id="menuToggle" type="button" aria-label="Menu"><i class="fas fa-bars"></i></button>
            <div class="topbar-title">
                <h1><?= e($pageTitle) ?></h1>
                <?php if (!empty($pageSubtitle)): ?><p><?= e($pageSubtitle) ?></p><?php endif; ?>
            </div>
            <div class="topbar-tools">
                <button id="theme-toggle" class="theme-toggle" type="button" aria-label="Modo escuro" title="Modo escuro"><i class="fas fa-moon"></i></button>
            </div>
            <div class="topbar-user">
                <div class="avatar"><?= e(user_initials($user['nome'] ?? '')) ?></div>
                <div>
                    <strong><?= e($user['nome'] ?? '') ?></strong>
                    <span>Recursos Humanos</span>
                </div>
            </div>
        </header>
        <main class="content">
        <?php if ($flash): ?><div class="alert alert-<?= e($flash['type'] === 'error' ? 'error' : 'success') ?>"><?= e($flash['message']) ?></div><?php endif; ?>
