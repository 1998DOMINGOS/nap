<?php
$pageTitle = 'Ausências';
$current = 'rh-aus';
require_once __DIR__ . '/../../config/app.php';
ensure_rh_schema();

$errors = [];
$ok = null;
$funcs = db()->query('SELECT id, nome FROM cont_funcionarios WHERE ativo=1 ORDER BY nome')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'create';
    if ($action === 'estado') {
        $est = in_array($_POST['estado'] ?? '', ['pendente', 'aprovada', 'rejeitada'], true) ? $_POST['estado'] : 'pendente';
        db()->prepare('UPDATE rh_ausencias SET estado=? WHERE id=?')->execute([$est, (int) ($_POST['id'] ?? 0)]);
        $ok = 'Estado actualizado.';
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM rh_ausencias WHERE id=?')->execute([(int) ($_POST['id'] ?? 0)]);
        $ok = 'Registo eliminado.';
    } else {
        $fid = (int) ($_POST['funcionario_id'] ?? 0);
        $ini = trim($_POST['data_inicio'] ?? '');
        $fim = trim($_POST['data_fim'] ?? '');
        $tipo = in_array($_POST['tipo'] ?? '', ['ferias', 'falta_justificada', 'falta_injustificada', 'licenca', 'outro'], true) ? $_POST['tipo'] : 'ferias';
        if (!$fid || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $ini) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fim)) {
            $errors[] = 'Colaborador e datas válidas são obrigatórios.';
        } elseif ($fim < $ini) {
            $errors[] = 'Data fim deve ser posterior à data início.';
        } else {
            db()->prepare('INSERT INTO rh_ausencias (funcionario_id, tipo, data_inicio, data_fim, observacoes, criado_por) VALUES (?,?,?,?,?,?)')
                ->execute([$fid, $tipo, $ini, $fim, trim($_POST['observacoes'] ?? '') ?: null, current_user()['id'] ?? null]);
            $ok = 'Ausência registada.';
        }
    }
}

$items = db()->query(
    'SELECT a.*, f.nome AS funcionario_nome FROM rh_ausencias a
     INNER JOIN cont_funcionarios f ON f.id=a.funcionario_id
     ORDER BY a.data_inicio DESC LIMIT 100'
)->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>
<div class="grid-2">
<div class="card"><div class="card-body"><h3>Registar ausência</h3>
<form method="post"><?= csrf_field() ?>
<div class="form-group"><label>Colaborador *</label><select name="funcionario_id" class="form-control" required>
<option value="">—</option><?php foreach ($funcs as $f): ?><option value="<?= (int) $f['id'] ?>"><?= e($f['nome']) ?></option><?php endforeach; ?>
</select></div>
<div class="form-group"><label>Tipo</label><select name="tipo" class="form-control">
<option value="ferias">Férias</option><option value="falta_justificada">Falta justificada</option>
<option value="falta_injustificada">Falta injustificada</option><option value="licenca">Licença</option><option value="outro">Outro</option>
</select></div>
<div class="form-grid">
<div class="form-group"><label>Início *</label><input class="form-control" type="date" name="data_inicio" required></div>
<div class="form-group"><label>Fim *</label><input class="form-control" type="date" name="data_fim" required></div>
</div>
<div class="form-group"><label>Observações</label><textarea class="form-control" name="observacoes" rows="2"></textarea></div>
<button class="btn btn-primary" type="submit">Registar</button>
</form></div></div>
<div class="card"><div class="card-body"><h3>Histórico</h3>
<table><thead><tr><th>Colaborador</th><th>Tipo</th><th>Período</th><th>Estado</th><th></th></tr></thead><tbody>
<?php foreach ($items as $a): ?>
<tr>
<td><?= e($a['funcionario_nome']) ?></td>
<td><?= e(str_replace('_', ' ', $a['tipo'])) ?></td>
<td><?= e(format_date($a['data_inicio'], 'd/m/Y')) ?> – <?= e(format_date($a['data_fim'], 'd/m/Y')) ?></td>
<td><?= status_badge($a['estado']) ?></td>
<td>
<form method="post" style="display:inline-flex;gap:4px"><?= csrf_field() ?><input type="hidden" name="action" value="estado"><input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
<select name="estado" class="form-control" style="padding:4px 8px;font-size:.8rem">
<option value="pendente" <?= $a['estado'] === 'pendente' ? 'selected' : '' ?>>Pendente</option>
<option value="aprovada" <?= $a['estado'] === 'aprovada' ? 'selected' : '' ?>>Aprovada</option>
<option value="rejeitada" <?= $a['estado'] === 'rejeitada' ? 'selected' : '' ?>>Rejeitada</option>
</select><button class="btn btn-sm btn-primary" type="submit">OK</button></form>
</td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
