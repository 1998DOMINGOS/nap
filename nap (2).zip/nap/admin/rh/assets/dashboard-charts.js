(function () {
  var data = window.rhDashCharts;
  if (!data || typeof Chart === 'undefined') {
    return;
  }

  var gridColor = 'rgba(148, 163, 184, 0.25)';
  var defaults = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, padding: 14 } } },
  };

  var fmtKz = function (v) {
    return (Number(v) || 0).toLocaleString('pt-PT', { maximumFractionDigits: 0 }) + ' Kz';
  };

  var c = data.candidaturas;
  var elCand = document.getElementById('rhChartCand');
  if (elCand) {
    new Chart(elCand, {
      type: 'line',
      data: {
        labels: c.labels,
        datasets: [
          { label: 'Total recebidas', data: c.total, borderColor: '#16b7e8', backgroundColor: 'rgba(22,183,232,.15)', fill: true, tension: 0.3 },
          { label: 'Aprovadas', data: c.aprovadas, borderColor: '#22c55e', backgroundColor: 'rgba(34,197,94,.1)', fill: false, tension: 0.3 },
        ],
      },
      options: Object.assign({}, defaults, {
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } }, x: { grid: { display: false } } },
      }),
    });
  }

  var p = data.pipeline;
  var elPipe = document.getElementById('rhChartPipe');
  if (elPipe) {
    new Chart(elPipe, {
      type: 'doughnut',
      data: {
        labels: ['Pendentes', 'Aprovadas', 'Rejeitadas'],
        datasets: [{
          data: [p.pendente, p.aprovada, p.rejeitada],
          backgroundColor: ['#f59e0b', '#22c55e', '#ef4444'],
        }],
      },
      options: defaults,
    });
  }

  var f = data.folha;
  var elFolha = document.getElementById('rhChartFolha');
  if (elFolha) {
    new Chart(elFolha, {
      type: 'bar',
      data: {
        labels: f.labels,
        datasets: [
          { label: 'Bruto', data: f.bruto, backgroundColor: 'rgba(99,102,241,.75)', borderRadius: 4 },
          { label: 'Líquido', data: f.liquido, backgroundColor: 'rgba(34,197,94,.75)', borderRadius: 4 },
        ],
      },
      options: Object.assign({}, defaults, {
        scales: {
          y: { beginAtZero: true, grid: { color: gridColor }, ticks: { callback: fmtKz } },
          x: { grid: { display: false } },
        },
        plugins: Object.assign({}, defaults.plugins, {
          tooltip: { callbacks: { label: function (ctx) { return (ctx.dataset.label || '') + ': ' + fmtKz(ctx.parsed.y); } } },
        }),
      }),
    });
  }
})();
