<?php

require_once __DIR__ . '/../config/app.php';

require_login();
if (is_contabilista()) {
    redirect('/admin/contabilidade/dashboard.php');
}
if (is_faturacao()) {
    redirect('/admin/facturacao/index.php');
}

$pageTitle = 'Dashboard';

$pageSubtitle = '';

$contentClass = 'content-dashboard';

$extraCss = url('/admin/assets/css/dashboard.css');

$current = 'dashboard';



$user = current_user();

$isAdmin = ($user['nivel'] ?? '') === 'admin';

$primeiroNome = explode(' ', trim($user['nome'] ?? 'Utilizador'))[0];



$hora = (int) date('G');

if ($hora < 12) {

    $saudacao = 'Bom dia';

} elseif ($hora < 18) {

    $saudacao = 'Boa tarde';

} else {

    $saudacao = 'Boa noite';

}



$meses = ['', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

$dataHoje = date('j') . ' de ' . $meses[(int) date('n')] . ' · ' . date('Y');



$stats = [

    'noticias'     => count_table('noticias'),

    'servicos'     => count_table('servicos', "status = 'ativo'"),

    'equipe'       => count_table('equipe', "status = 'ativo'"),

    'galeria'      => 0,

    'mensagens'    => count_table('mensagens', "status = 'nova'"),

    'candidaturas' => count_table('candidaturas', "status = 'pendente'"),

    'depoimentos'  => count_table('depoimentos', "status = 'pendente'"),

    'usuarios'     => count_table('usuarios', 'ativo = 1'),

];



try {

    $stats['galeria'] = count_table('galeria', "status = 'ativo'");

} catch (Throwable $e) {

    // tabela galeria pode ainda não existir

}



$caixa = null;

$fatStats = [

    'docs_mes' => 0,

    'vendas_mes' => 0.0,

    'rascunhos' => 0,

    'clientes' => 0,

    'produtos' => 0,

];

$ultimosDocs = [];



try {

    ensure_facturacao_schema();

    $caixa = fat_caixa_aberto();

    $mes = date('Y-m');



    $totMes = db()->prepare("SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS t FROM fat_documentos WHERE estado='emitido' AND DATE_FORMAT(data_documento,'%Y-%m')=? AND tipo IN ('FT','FR')");

    $totMes->execute([$mes]);

    $rowMes = $totMes->fetch() ?: [];



    $totNc = db()->prepare("SELECT COALESCE(SUM(total),0) FROM fat_documentos WHERE estado='emitido' AND DATE_FORMAT(data_documento,'%Y-%m')=? AND tipo='NC'");

    $totNc->execute([$mes]);

    $ncMes = (float) $totNc->fetchColumn();



    $fatStats['docs_mes'] = (int) ($rowMes['n'] ?? 0);

    $fatStats['vendas_mes'] = ((float) ($rowMes['t'] ?? 0)) - $ncMes;

    $fatStats['rascunhos'] = (int) db()->query("SELECT COUNT(*) FROM fat_documentos WHERE estado='rascunho'")->fetchColumn();

    $fatStats['clientes'] = (int) db()->query('SELECT COUNT(*) FROM fat_clientes WHERE ativo=1')->fetchColumn();

    $fatStats['produtos'] = (int) db()->query('SELECT COUNT(*) FROM fat_produtos WHERE ativo=1')->fetchColumn();



    $ultimosDocs = db()->query("SELECT id, tipo, numero_completo, cliente_nome, total, estado, data_documento FROM fat_documentos ORDER BY id DESC LIMIT 5")->fetchAll();

} catch (Throwable $e) {

    // módulo de facturação indisponível

}



$ultimasNoticias = db()->query('SELECT id, titulo, status, criado_em FROM noticias ORDER BY id DESC LIMIT 5')->fetchAll();

$ultimasMensagens = db()->query('SELECT id, nome, email, assunto, status, criado_em FROM mensagens ORDER BY id DESC LIMIT 5')->fetchAll();



function dash_status_pill(string $status): string

{

    return match ($status) {

        'ativo', 'publicado', 'emitido', 'lida', 'aprovado' => 'dash-pill-success',

        'pendente', 'nova', 'rascunho' => 'dash-pill-warning',

        'inativo', 'anulado', 'rejeitado' => 'dash-pill-danger',

        default => 'dash-pill-muted',

    };

}



require __DIR__ . '/includes/header.php';

?>



<div class="dash">



    <header class="dash-hero">

        <div class="dash-hero-text">

            <h2><?= e($saudacao) ?>, <?= e($primeiroNome) ?> 👋</h2>

            <p><?= e($dataHoje) ?> — visão geral do painel <?= e(APP_NAME) ?></p>

        </div>

        <div class="dash-hero-actions">

            <?php if ($caixa): ?>

                <a class="dash-btn dash-btn-primary" href="<?= url('/admin/facturacao/vender.php') ?>">

                    <i class="fas fa-cash-register"></i> Vender agora

                </a>

            <?php else: ?>

                <a class="dash-btn dash-btn-primary" href="<?= url('/admin/facturacao/caixa.php') ?>">

                    <i class="fas fa-lock-open"></i> Abrir caixa

                </a>

            <?php endif; ?>

            <a class="dash-btn dash-btn-ghost" href="<?= url('/') ?>" target="_blank" rel="noopener">

                <i class="fas fa-arrow-up-right-from-square"></i> Ver site

            </a>

        </div>

    </header>



    <section class="dash-kpis">

        <article class="dash-kpi dash-kpi-featured">

            <span class="dash-kpi-label">Vendas líquidas · <?= e($meses[(int) date('n')]) ?></span>

            <div class="dash-kpi-value"><?= e(fat_format_money($fatStats['vendas_mes'])) ?></div>

            <div class="dash-kpi-meta"><?= (int) $fatStats['docs_mes'] ?> documento(s) emitido(s)</div>

            <div class="dash-kpi-icon"><i class="fas fa-coins"></i></div>

        </article>

        <article class="dash-kpi">

            <span class="dash-kpi-label">Mensagens novas</span>

            <div class="dash-kpi-value"><?= (int) $stats['mensagens'] ?></div>

            <div class="dash-kpi-meta">Aguardam resposta</div>

            <div class="dash-kpi-icon blue"><i class="fas fa-envelope"></i></div>

        </article>

        <article class="dash-kpi">

            <span class="dash-kpi-label">Depoimentos pendentes</span>

            <div class="dash-kpi-value"><?= (int) $stats['depoimentos'] ?></div>

            <div class="dash-kpi-meta">Para validar no site</div>

            <div class="dash-kpi-icon amber"><i class="fas fa-quote-left"></i></div>

        </article>

        <article class="dash-kpi">

            <span class="dash-kpi-label">Candidaturas</span>

            <div class="dash-kpi-value"><?= (int) $stats['candidaturas'] ?></div>

            <div class="dash-kpi-meta">CVs por analisar</div>

            <div class="dash-kpi-icon green"><i class="fas fa-user-tie"></i></div>

        </article>

    </section>



    <div class="dash-chips">

        <span class="dash-chip"><i class="fas fa-newspaper"></i> Notícias <strong><?= (int) $stats['noticias'] ?></strong></span>

        <span class="dash-chip"><i class="fas fa-briefcase"></i> Serviços <strong><?= (int) $stats['servicos'] ?></strong></span>

        <span class="dash-chip"><i class="fas fa-users"></i> Equipe <strong><?= (int) $stats['equipe'] ?></strong></span>

        <span class="dash-chip"><i class="fas fa-images"></i> Galeria <strong><?= (int) $stats['galeria'] ?></strong></span>

        <span class="dash-chip"><i class="fas fa-users-gear"></i> Utilizadores <strong><?= (int) $stats['usuarios'] ?></strong></span>

        <span class="dash-chip"><i class="fas fa-pen"></i> Rascunhos <strong><?= (int) $fatStats['rascunhos'] ?></strong></span>

        <span class="dash-chip"><i class="fas fa-box"></i> Clientes <strong><?= (int) $fatStats['clientes'] ?></strong></span>

        <span class="dash-chip"><i class="fas fa-tag"></i> Produtos <strong><?= (int) $fatStats['produtos'] ?></strong></span>

    </div>



    <div class="dash-bento">



        <div class="dash-panel">

            <div class="dash-panel-head">

                <h3>Ações rápidas</h3>

            </div>

            <div class="dash-panel-body">

                <div class="dash-actions">

                    <a class="dash-action dash-action-highlight" href="<?= $caixa ? url('/admin/facturacao/vender.php') : url('/admin/facturacao/caixa.php') ?>">

                        <span class="dash-action-icon"><i class="fas fa-<?= $caixa ? 'cash-register' : 'lock-open' ?>"></i></span>

                        <span class="dash-action-label"><?= $caixa ? 'Vender' : 'Abrir caixa' ?></span>

                    </a>

                    <a class="dash-action" href="<?= url('/admin/noticias/criar.php') ?>">

                        <span class="dash-action-icon"><i class="fas fa-plus"></i></span>

                        <span class="dash-action-label">Nova notícia</span>

                    </a>

                    <a class="dash-action" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=FT') ?>">

                        <span class="dash-action-icon"><i class="fas fa-file-invoice"></i></span>

                        <span class="dash-action-label">Nova factura</span>

                    </a>

                    <a class="dash-action" href="<?= url('/admin/galeria/index.php') ?>">

                        <span class="dash-action-icon"><i class="fas fa-images"></i></span>

                        <span class="dash-action-label">Galeria</span>

                    </a>

                    <a class="dash-action" href="<?= url('/admin/mensagens/index.php') ?>">

                        <?php if ($stats['mensagens'] > 0): ?><span class="dash-badge"><?= (int) $stats['mensagens'] ?></span><?php endif; ?>

                        <span class="dash-action-icon"><i class="fas fa-envelope"></i></span>

                        <span class="dash-action-label">Mensagens</span>

                    </a>

                    <a class="dash-action" href="<?= url('/admin/depoimentos/index.php?filtro=pendente') ?>">

                        <?php if ($stats['depoimentos'] > 0): ?><span class="dash-badge"><?= (int) $stats['depoimentos'] ?></span><?php endif; ?>

                        <span class="dash-action-icon"><i class="fas fa-quote-left"></i></span>

                        <span class="dash-action-label">Depoimentos</span>

                    </a>

                    <a class="dash-action" href="<?= url('/admin/facturacao/index.php') ?>">

                        <span class="dash-action-icon"><i class="fas fa-file-invoice-dollar"></i></span>

                        <span class="dash-action-label">Facturação</span>

                    </a>

                    <a class="dash-action" href="<?= url('/admin/rh/dashboard.php') ?>">

                        <span class="dash-action-icon"><i class="fas fa-people-group"></i></span>

                        <span class="dash-action-label">Recursos Humanos</span>

                    </a>

                    <a class="dash-action" href="<?= url('/admin/tecnologia/dashboard.php') ?>">

                        <span class="dash-action-icon"><i class="fas fa-microchip"></i></span>

                        <span class="dash-action-label">Tecnologia</span>

                    </a>

                    <?php if ($isAdmin): ?>

                    <a class="dash-action" href="<?= url('/admin/configuracoes/index.php') ?>">

                        <span class="dash-action-icon"><i class="fas fa-gear"></i></span>

                        <span class="dash-action-label">Configurações</span>

                    </a>

                    <?php endif; ?>

                </div>

            </div>

        </div>



        <div class="dash-stack">

            <div class="dash-panel">

                <div class="dash-panel-head"><h3>Estado do caixa</h3></div>

                <div class="dash-panel-body">

                    <?php if ($caixa): ?>

                    <div class="dash-caixa dash-caixa-open">

                        <div class="dash-caixa-status"><span class="dash-caixa-dot"></span> Caixa aberto</div>

                        <div class="dash-caixa-meta">

                            Sessão #<?= (int) $caixa['id'] ?> · desde <?= e(format_date($caixa['aberto_em'], 'd/m/Y H:i')) ?><br>

                            Fundo inicial: <strong><?= e(fat_format_money($caixa['fundo_inicial'])) ?></strong>

                        </div>

                        <a class="dash-btn dash-btn-primary" href="<?= url('/admin/facturacao/vender.php') ?>" style="width:100%;justify-content:center">

                            <i class="fas fa-cash-register"></i> Iniciar venda

                        </a>

                    </div>

                    <?php else: ?>

                    <div class="dash-caixa dash-caixa-closed">

                        <div class="dash-caixa-status"><span class="dash-caixa-dot"></span> Caixa fechado</div>

                        <div class="dash-caixa-meta">Abra o caixa para registar vendas e emitir recibos.</div>

                        <a class="dash-btn dash-btn-primary" href="<?= url('/admin/facturacao/caixa.php') ?>" style="width:100%;justify-content:center">

                            <i class="fas fa-lock-open"></i> Abrir caixa

                        </a>

                    </div>

                    <?php endif; ?>

                </div>

            </div>



            <div class="dash-panel">

                <div class="dash-panel-head">

                    <h3>Últimas mensagens</h3>

                    <a class="dash-panel-link" href="<?= url('/admin/mensagens/index.php') ?>">Ver todas</a>

                </div>

                <div class="dash-panel-body">

                    <?php if (!$ultimasMensagens): ?>

                        <div class="dash-empty"><i class="fas fa-inbox"></i>Sem mensagens ainda</div>

                    <?php else: ?>

                    <ul class="dash-list">

                        <?php foreach ($ultimasMensagens as $m): ?>

                        <li class="dash-list-item">

                            <div class="dash-list-avatar msg"><?= e(mb_strtoupper(mb_substr($m['nome'], 0, 1))) ?></div>

                            <div class="dash-list-content">

                                <a class="dash-list-title" href="<?= url('/admin/mensagens/ver.php?id=' . $m['id']) ?>"><?= e($m['nome']) ?></a>

                                <span class="dash-list-sub"><?= e($m['assunto'] ?: 'Sem assunto') ?></span>

                            </div>

                            <div class="dash-list-end">

                                <span class="dash-list-date"><?= e(format_date($m['criado_em'], 'd/m')) ?></span>

                                <span class="dash-pill <?= dash_status_pill($m['status']) ?>"><?= e($m['status']) ?></span>

                            </div>

                        </li>

                        <?php endforeach; ?>

                    </ul>

                    <?php endif; ?>

                </div>

            </div>

        </div>



        <div class="dash-panel">

            <div class="dash-panel-head">

                <h3>Últimas notícias</h3>

                <a class="dash-panel-link" href="<?= url('/admin/noticias/index.php') ?>">Ver todas</a>

            </div>

            <div class="dash-panel-body">

                <?php if (!$ultimasNoticias): ?>

                    <div class="dash-empty"><i class="fas fa-newspaper"></i>Nenhuma notícia publicada</div>

                <?php else: ?>

                <ul class="dash-list">

                    <?php foreach ($ultimasNoticias as $n): ?>

                    <li class="dash-list-item">

                        <div class="dash-list-avatar news"><i class="fas fa-newspaper"></i></div>

                        <div class="dash-list-content">

                            <a class="dash-list-title" href="<?= url('/admin/noticias/editar.php?id=' . $n['id']) ?>"><?= e($n['titulo']) ?></a>

                            <span class="dash-list-sub"><?= e(format_date($n['criado_em'], 'd/m/Y')) ?></span>

                        </div>

                        <div class="dash-list-end">

                            <span class="dash-pill <?= dash_status_pill($n['status']) ?>"><?= e($n['status']) ?></span>

                        </div>

                    </li>

                    <?php endforeach; ?>

                </ul>

                <?php endif; ?>

            </div>

        </div>



        <?php if ($ultimosDocs): ?>

        <div class="dash-panel dash-span-2">

            <div class="dash-panel-head">

                <h3>Documentos fiscais recentes</h3>

                <a class="dash-panel-link" href="<?= url('/admin/facturacao/documentos/index.php') ?>">Ver todos</a>

            </div>

            <div class="dash-panel-body">

                <ul class="dash-list">

                    <?php foreach ($ultimosDocs as $d): ?>

                    <li class="dash-list-item">

                        <div class="dash-list-avatar doc"><i class="fas fa-receipt"></i></div>

                        <div class="dash-list-content">

                            <a class="dash-list-title" href="<?= url('/admin/facturacao/documentos/ver.php?id=' . $d['id']) ?>"><?= e($d['numero_completo']) ?></a>

                            <span class="dash-list-sub"><?= e(fat_tipo_label($d['tipo'])) ?> · <?= e($d['cliente_nome']) ?></span>

                        </div>

                        <div class="dash-list-end">

                            <span class="dash-list-date"><?= e(format_date($d['data_documento'], 'd/m/Y')) ?></span>

                            <strong style="font-size:.82rem;color:#09090b"><?= e(fat_format_money($d['total'])) ?></strong>

                            <span class="dash-pill <?= dash_status_pill($d['estado']) ?>" style="margin-left:6px"><?= e($d['estado']) ?></span>

                        </div>

                    </li>

                    <?php endforeach; ?>

                </ul>

            </div>

        </div>

        <?php endif; ?>



    </div>

</div>



<?php require __DIR__ . '/includes/footer.php'; ?>

