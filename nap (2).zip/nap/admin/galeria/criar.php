<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Nova foto';
$current = 'galeria';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $titulo = trim($_POST['titulo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $ordem = (int) ($_POST['ordem'] ?? 0);
    $status = $_POST['status'] === 'ativo' ? 'ativo' : 'inativo';
    $imagem = null;

    if ($titulo === '') {
        $errors[] = 'O título é obrigatório.';
    }
    if (empty($_FILES['imagem']['name'])) {
        $errors[] = 'Seleccione uma imagem.';
    }

    try {
        if (!empty($_FILES['imagem']['name'])) {
            $imagem = upload_image($_FILES['imagem'], 'galeria');
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }

    if (!$errors && $imagem) {
        db()->prepare('INSERT INTO galeria (titulo, descricao, imagem, ordem, status) VALUES (?,?,?,?,?)')
            ->execute([$titulo, $descricao, $imagem, $ordem, $status]);
        flash('success', 'Foto adicionada à galeria.');
        redirect('/admin/galeria/index.php');
    }
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="form-group"><label>Título</label><input class="form-control" name="titulo" required value="<?= e($_POST['titulo'] ?? '') ?>"></div>
    <div class="form-group"><label>Descrição (opcional)</label><input class="form-control" name="descricao" value="<?= e($_POST['descricao'] ?? '') ?>"></div>
    <div class="form-grid">
        <div class="form-group"><label>Imagem</label><input class="form-control" type="file" name="imagem" accept="image/*" required></div>
        <div class="form-group"><label>Ordem</label><input class="form-control" type="number" name="ordem" value="<?= e($_POST['ordem'] ?? '0') ?>"></div>
    </div>
    <div class="form-group">
        <label>Status</label>
        <select name="status"><option value="ativo">Activo</option><option value="inativo">Inactivo</option></select>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
        <a class="btn btn-outline" href="<?= url('/admin/galeria/index.php') ?>">Cancelar</a>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
