<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM galeria WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if ($item) {
    delete_upload($item['imagem']);
    db()->prepare('DELETE FROM galeria WHERE id = ?')->execute([$id]);
    flash('success', 'Foto eliminada.');
} else {
    flash('error', 'Foto não encontrada.');
}
redirect('/admin/galeria/index.php');
