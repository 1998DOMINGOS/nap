<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

// Garante a tabela (instalações antigas sem upgrade)
db()->exec("CREATE TABLE IF NOT EXISTS galeria (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(160) NOT NULL,
  descricao VARCHAR(255) NULL,
  imagem VARCHAR(255) NOT NULL,
  ordem INT NOT NULL DEFAULT 0,
  status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$pageTitle = 'Galeria';
$pageSubtitle = 'Fotos da empresa no site';
$current = 'galeria';
$items = db()->query('SELECT * FROM galeria ORDER BY ordem ASC, id DESC')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>

<div class="toolbar">
    <p class="subtitle" style="margin:0">Imagens publicadas na página Galeria</p>
    <a class="btn btn-primary" href="<?= url('/admin/galeria/criar.php') ?>"><i class="fas fa-plus"></i> Nova foto</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Foto</th><th>Título</th><th>Ordem</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
            <?php if (!$items): ?>
                <tr><td colspan="5" class="empty">Nenhuma foto na galeria.</td></tr>
            <?php else: foreach ($items as $item): ?>
                <tr>
                    <td>
                        <?php if ($item['imagem']): ?>
                            <img class="thumb" src="<?= e(media_url($item['imagem'])) ?>" alt="">
                        <?php else: ?>—<?php endif; ?>
                    </td>
                    <td>
                        <strong><?= e($item['titulo']) ?></strong>
                        <?php if ($item['descricao']): ?>
                            <div style="color:#6b7280;font-size:.82rem"><?= e(mb_strimwidth($item['descricao'], 0, 80, '...')) ?></div>
                        <?php endif; ?>
                    </td>
                    <td><?= (int) $item['ordem'] ?></td>
                    <td><?= status_badge($item['status']) ?></td>
                    <td class="actions">
                        <a class="btn btn-sm btn-outline" href="<?= url('/admin/galeria/editar.php?id=' . $item['id']) ?>"><i class="fas fa-pen"></i></a>
                        <a class="btn btn-sm btn-danger" data-confirm="Eliminar esta foto?" href="<?= url('/admin/galeria/excluir.php?id=' . $item['id']) ?>"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
