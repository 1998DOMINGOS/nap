<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Mensagens';
$current = 'mensagens';
$items = db()->query('SELECT * FROM mensagens ORDER BY FIELD(status,"nova","lida","respondida"), id DESC')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Nome</th><th>Email</th><th>Assunto</th><th>Status</th><th>Data</th><th>Ações</th></tr></thead>
            <tbody>
            <?php if (!$items): ?>
                <tr><td colspan="6" class="empty">Nenhuma mensagem recebida.</td></tr>
            <?php else: foreach ($items as $item): ?>
                <tr>
                    <td><strong><?= e($item['nome']) ?></strong></td>
                    <td><?= e($item['email']) ?></td>
                    <td><?= e($item['assunto'] ?: '—') ?></td>
                    <td><?= status_badge($item['status']) ?></td>
                    <td><?= e(format_date($item['criado_em'])) ?></td>
                    <td class="actions">
                        <a class="btn btn-sm btn-outline" href="<?= url('/admin/mensagens/ver.php?id=' . $item['id']) ?>"><i class="fas fa-eye"></i></a>
                        <a class="btn btn-sm btn-danger" data-confirm="Eliminar esta mensagem?" href="<?= url('/admin/mensagens/excluir.php?id=' . $item['id']) ?>"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
