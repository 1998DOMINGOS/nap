<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM mensagens WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    flash('error', 'Mensagem não encontrada.');
    redirect('/admin/mensagens/index.php');
}

if ($item['status'] === 'nova') {
    db()->prepare('UPDATE mensagens SET status = "lida" WHERE id = ?')->execute([$id]);
    $item['status'] = 'lida';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $status = in_array($_POST['status'] ?? '', ['nova', 'lida', 'respondida'], true) ? $_POST['status'] : 'lida';
    db()->prepare('UPDATE mensagens SET status = ? WHERE id = ?')->execute([$status, $id]);
    flash('success', 'Status atualizado.');
    redirect('/admin/mensagens/ver.php?id=' . $id);
}

$pageTitle = 'Ver mensagem';
$current = 'mensagens';
require __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-body">
        <div class="form-grid" style="margin-bottom:18px">
            <div>
                <p style="margin:0;color:#6b7280;font-size:.82rem">De</p>
                <strong><?= e($item['nome']) ?></strong><br>
                <a href="mailto:<?= e($item['email']) ?>"><?= e($item['email']) ?></a>
                <?php if ($item['telefone']): ?><br><?= e($item['telefone']) ?><?php endif; ?>
            </div>
            <div>
                <p style="margin:0;color:#6b7280;font-size:.82rem">Detalhes</p>
                Assunto: <strong><?= e($item['assunto'] ?: '—') ?></strong><br>
                Data: <?= e(format_date($item['criado_em'])) ?><br>
                Status: <?= status_badge($item['status']) ?>
            </div>
        </div>

        <div class="msg-box"><?= e($item['mensagem']) ?></div>

        <form method="post" style="margin-top:18px" class="form-actions">
            <?= csrf_field() ?>
            <select name="status" style="max-width:220px">
                <option value="nova" <?= $item['status'] === 'nova' ? 'selected' : '' ?>>Nova</option>
                <option value="lida" <?= $item['status'] === 'lida' ? 'selected' : '' ?>>Lida</option>
                <option value="respondida" <?= $item['status'] === 'respondida' ? 'selected' : '' ?>>Respondida</option>
            </select>
            <button class="btn btn-primary" type="submit">Atualizar status</button>
            <a class="btn btn-dark" href="mailto:<?= e($item['email']) ?>?subject=Re:%20<?= e(rawurlencode($item['assunto'] ?: 'Contacto')) ?>"><i class="fas fa-reply"></i> Responder por email</a>
            <a class="btn btn-outline" href="<?= url('/admin/mensagens/index.php') ?>">Voltar</a>
        </form>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
