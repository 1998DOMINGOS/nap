<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
db()->prepare('DELETE FROM mensagens WHERE id = ?')->execute([$id]);
flash('success', 'Mensagem eliminada.');
redirect('/admin/mensagens/index.php');
