<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM fat_compras WHERE id=?');
$stmt->execute([$id]);
$compra = $stmt->fetch();
if (!$compra) { http_response_code(404); exit('Compra não encontrada.'); }
$lines = db()->prepare('SELECT * FROM fat_compra_linhas WHERE compra_id=? ORDER BY linha');
$lines->execute([$id]);
$lines = $lines->fetchAll();
$pageTitle = 'Compra ' . $compra['referencia'];
$current = 'fat-compras';
require __DIR__ . '/../../includes/header.php';
?>
<div class="toolbar"><p class="subtitle" style="margin:0">Compra registada em <?= e(format_date($compra['data_compra'], 'd/m/Y')) ?></p><div style="display:flex;gap:8px"><a class="btn btn-outline" href="<?= url('/admin/facturacao/compras/index.php') ?>">Voltar</a><a class="btn btn-primary" href="<?= url('/admin/facturacao/compras/criar.php') ?>">Nova compra</a></div></div>
<div class="card"><div class="card-body">
<p><strong>Fornecedor:</strong> <?= e($compra['fornecedor_nome']) ?> (<?= e($compra['fornecedor_nif'] ?: 'NIF não indicado') ?>)</p>
<p><strong>Referência:</strong> <?= e($compra['referencia']) ?></p>
<div class="table-wrap"><table><thead><tr><th>Produto</th><th>Quantidade</th><th>Preço</th><th>IVA</th><th>Total</th></tr></thead><tbody><?php foreach ($lines as $line): ?><tr><td><?= e($line['codigo'] . ' — ' . $line['descricao']) ?></td><td><?= e($line['quantidade']) ?></td><td><?= e(fat_format_money($line['preco_unitario'])) ?></td><td><?= e($line['taxa_iva']) ?>%</td><td><?= e(fat_format_money($line['total_linha'])) ?></td></tr><?php endforeach; ?></tbody></table></div>
<p style="text-align:right"><strong>Subtotal:</strong> <?= e(fat_format_money($compra['subtotal'])) ?><br><strong>IVA:</strong> <?= e(fat_format_money($compra['total_iva'])) ?><br><strong>Total:</strong> <?= e(fat_format_money($compra['total'])) ?></p>
<?php if ($compra['observacoes']): ?><p><strong>Observações:</strong> <?= e($compra['observacoes']) ?></p><?php endif; ?>
</div></div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
