<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Registar compra';
$current = 'fat-compras';
$errors = [];
$fornecedores = db()->query('SELECT id, nome, nif FROM fat_fornecedores WHERE ativo=1 ORDER BY nome')->fetchAll();
$produtos = db()->query("SELECT id, codigo, descricao, unidade, preco, taxa_iva FROM fat_produtos WHERE ativo=1 AND tipo='produto' ORDER BY descricao")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $fornecedorId = (int) ($_POST['fornecedor_id'] ?? 0);
    $dataCompra = trim($_POST['data_compra'] ?? date('Y-m-d'));
    $observacoes = trim($_POST['observacoes'] ?? '');
    $aCredito = !empty($_POST['conta_a_pagar']);
    $vencimento = trim($_POST['data_vencimento'] ?? '') ?: null;
    if ($vencimento && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $vencimento)) {
        $vencimento = null;
    }
    $fornecedorStmt = db()->prepare('SELECT * FROM fat_fornecedores WHERE id=? AND ativo=1');
    $fornecedorStmt->execute([$fornecedorId]);
    $fornecedor = $fornecedorStmt->fetch();
    if (!$fornecedor) $errors[] = 'Seleccione um fornecedor.';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dataCompra)) $errors[] = 'Data da compra inválida.';

    $ids = $_POST['produto_id'] ?? [];
    $qtys = $_POST['quantidade'] ?? [];
    $precos = $_POST['preco'] ?? [];
    $ivas = $_POST['iva'] ?? [];
    $linhas = [];
    foreach ($ids as $i => $produtoId) {
        $produtoId = (int) $produtoId;
        if (!$produtoId) continue;
        $produtoStmt = db()->prepare("SELECT * FROM fat_produtos WHERE id=? AND ativo=1 AND tipo='produto'");
        $produtoStmt->execute([$produtoId]);
        $produto = $produtoStmt->fetch();
        $qty = (float) str_replace(',', '.', $qtys[$i] ?? '0');
        $preco = (float) str_replace(',', '.', $precos[$i] ?? '0');
        $iva = (float) str_replace(',', '.', $ivas[$i] ?? '14');
        if (!$produto || $qty <= 0 || $preco < 0 || !in_array($iva, [0.0, 5.0, 7.0, 14.0], true)) {
            $errors[] = 'Produto, quantidade, preço ou IVA inválido na linha ' . ((int) $i + 1) . '.';
            continue;
        }
        $liquido = round($qty * $preco, 2);
        $totalIva = round($liquido * $iva / 100, 2);
        $linhas[] = [$produto, $qty, $preco, $iva, $liquido, $totalIva, $liquido + $totalIva];
    }
    if (!$linhas) $errors[] = 'Adicione pelo menos um produto.';

    if (!$errors) {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $referencia = 'COMPRA-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(2)));
            $subtotal = array_sum(array_column($linhas, 4));
            $totalIva = array_sum(array_column($linhas, 5));
            $total = array_sum(array_column($linhas, 6));
            $pago = $aCredito ? 0 : 1;
            $dataPag = $aCredito ? null : $dataCompra;
            $pdo->prepare('INSERT INTO fat_compras (fornecedor_id, fornecedor_nome, fornecedor_nif, referencia, data_compra, subtotal, total_iva, total, observacoes, pago, data_vencimento, data_pagamento, criado_por) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
                ->execute([$fornecedor['id'], $fornecedor['nome'], $fornecedor['nif'], $referencia, $dataCompra, $subtotal, $totalIva, $total, $observacoes, $pago, $vencimento, $dataPag, current_user()['id']]);
            $compraId = (int) $pdo->lastInsertId();
            $insert = $pdo->prepare('INSERT INTO fat_compra_linhas (compra_id, produto_id, linha, codigo, descricao, quantidade, preco_unitario, taxa_iva, total_liquido, total_iva, total_linha) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
            foreach ($linhas as $pos => $linha) {
                [$produto, $qty, $preco, $iva, $liquido, $totalLinhaIva, $totalLinha] = $linha;
                $insert->execute([$compraId, $produto['id'], $pos + 1, $produto['codigo'], $produto['descricao'], $qty, $preco, $iva, $liquido, $totalLinhaIva, $totalLinha]);
                if ($produto['stock'] !== null) {
                    $pdo->prepare('UPDATE fat_produtos SET stock=stock+? WHERE id=?')->execute([$qty, $produto['id']]);
                }
            }
            $pdo->commit();
            if (function_exists('cont_post_compra')) {
                try {
                    cont_post_compra($compraId, (int) (current_user()['id'] ?? 0));
                } catch (Throwable $e) {
                    // compra guardada; lançamento pode ser sincronizado depois
                }
            }
            flash('success', 'Compra registada e stock actualizado.');
            redirect('/admin/facturacao/compras/ver.php?id=' . $compraId);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $errors[] = 'Erro ao guardar: ' . $e->getMessage();
        }
    }
}
require __DIR__ . '/../../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endforeach; ?>
<form method="post"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Fornecedor *</label><select name="fornecedor_id" required><option value="">Seleccione</option><?php foreach ($fornecedores as $f): ?><option value="<?= (int) $f['id'] ?>" <?= ((int) ($_POST['fornecedor_id'] ?? 0) === (int) $f['id']) ? 'selected' : '' ?>><?= e($f['nome']) ?> — <?= e($f['nif']) ?></option><?php endforeach; ?></select></div>
        <div class="form-group"><label>Referência da factura</label><input class="form-control" value="Gerada automaticamente ao guardar" disabled></div>
        <div class="form-group"><label>Data *</label><input class="form-control" type="date" name="data_compra" required value="<?= e($_POST['data_compra'] ?? date('Y-m-d')) ?>"></div>
    </div>
    <h3>Produtos comprados</h3>
    <p class="subtitle" style="margin:0 0 12px">As prestações de serviços não entram em compras nem em stock.</p>
    <div class="table-wrap"><table><thead><tr><th>Produto</th><th>Quantidade</th><th>Preço unitário</th><th>IVA %</th></tr></thead><tbody>
    <?php for ($i = 0; $i < 5; $i++): ?><tr><td><select name="produto_id[]"><option value="">Seleccione</option><?php foreach ($produtos as $p): ?><option value="<?= (int) $p['id'] ?>"><?= e($p['codigo'] . ' — ' . $p['descricao']) ?></option><?php endforeach; ?></select></td><td><input class="form-control" type="number" step="0.001" min="0" name="quantidade[]"></td><td><input class="form-control" type="number" step="0.01" min="0" name="preco[]"></td><td><select name="iva[]"><option>14</option><option>7</option><option>5</option><option>0</option></select></td></tr><?php endfor; ?>
    </tbody></table></div>
    <div class="form-group"><label>Observações</label><textarea class="form-control" name="observacoes" rows="3"><?= e($_POST['observacoes'] ?? '') ?></textarea></div>
    <div class="form-grid">
        <div class="form-group"><label>Vencimento</label><input class="form-control" type="date" name="data_vencimento" value="<?= e($_POST['data_vencimento'] ?? '') ?>"></div>
        <div class="form-group" style="display:flex;align-items:flex-end"><label style="display:flex;gap:8px;align-items:center;margin:0"><input type="checkbox" name="conta_a_pagar" value="1" <?= !empty($_POST['conta_a_pagar']) ? 'checked' : '' ?>> Compra a crédito (conta a pagar)</label></div>
    </div>
    <div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Registar compra</button><a class="btn btn-outline" href="<?= url('/admin/facturacao/compras/index.php') ?>">Cancelar</a></div>
</form>
</div></div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
