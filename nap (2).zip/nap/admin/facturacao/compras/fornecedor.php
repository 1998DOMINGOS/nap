<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $nif = preg_replace('/\s+/', '', trim($_POST['nif'] ?? ''));
    if ($nome === '') $errors[] = 'Nome do fornecedor obrigatório.';
    if (!$errors) {
        db()->prepare('INSERT INTO fat_fornecedores (nome, nif, morada, telefone, email) VALUES (?,?,?,?,?)')->execute([$nome, $nif, trim($_POST['morada'] ?? ''), trim($_POST['telefone'] ?? ''), trim($_POST['email'] ?? '')]);
        flash('success', 'Fornecedor criado.');
        redirect('/admin/facturacao/compras/criar.php');
    }
}
$pageTitle = 'Novo fornecedor';
$current = 'fat-compras';
require __DIR__ . '/../../includes/header.php';
?><div class="card"><div class="card-body">
<?php foreach ($errors as $error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endforeach; ?>
<form method="post"><?= csrf_field() ?><div class="form-grid"><div class="form-group"><label>Nome *</label><input class="form-control" name="nome" required></div><div class="form-group"><label>NIF</label><input class="form-control" name="nif"></div><div class="form-group"><label>Morada</label><input class="form-control" name="morada"></div><div class="form-group"><label>Telefone</label><input class="form-control" name="telefone"></div><div class="form-group"><label>Email</label><input class="form-control" type="email" name="email"></div></div><div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button><a class="btn btn-outline" href="<?= url('/admin/facturacao/compras/index.php') ?>">Cancelar</a></div></form>
</div></div><?php require __DIR__ . '/../../includes/footer.php'; ?>
