<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Compras';
$pageSubtitle = 'Registo de compras e entrada em stock';
$current = 'fat-compras';
$items = db()->query('SELECT * FROM fat_compras ORDER BY data_compra DESC, id DESC')->fetchAll();

require __DIR__ . '/../../includes/header.php';
?>
<div class="toolbar">
    <p class="subtitle" style="margin:0">Facturas de compra registadas</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-primary" href="<?= url('/admin/facturacao/compras/criar.php') ?>"><i class="fas fa-cart-plus"></i> Registar compra</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/compras/fornecedor.php') ?>"><i class="fas fa-truck"></i> Novo fornecedor</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Voltar</a>
    </div>
</div>
<div class="card"><div class="table-wrap">
<table>
    <thead><tr><th>Data</th><th>Referência</th><th>Fornecedor</th><th>NIF</th><th>Total</th><th></th></tr></thead>
    <tbody>
    <?php if (!$items): ?>
        <tr><td colspan="6" class="empty">Ainda não existem compras registadas.</td></tr>
    <?php else: foreach ($items as $item): ?>
        <tr>
            <td><?= e(format_date($item['data_compra'], 'd/m/Y')) ?></td>
            <td><strong><?= e($item['referencia']) ?></strong></td>
            <td><?= e($item['fornecedor_nome']) ?></td>
            <td><?= e($item['fornecedor_nif'] ?: '—') ?></td>
            <td><?= e(fat_format_money($item['total'])) ?></td>
            <td class="actions"><a class="btn btn-sm btn-outline" href="<?= url('/admin/facturacao/compras/ver.php?id=' . $item['id']) ?>">Abrir</a></td>
        </tr>
    <?php endforeach; endif; ?>
    </tbody>
</table>
</div></div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
