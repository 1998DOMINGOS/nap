<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
fat_agt_compliance_migrate();

$pageTitle = 'Integração (SourceBilling I)';
$current = 'fat-empresa';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $tipo = strtoupper(trim($_POST['tipo'] ?? 'FT'));
    $clienteId = (int) ($_POST['cliente_id'] ?? 0);
    $dataDoc = trim($_POST['data_documento'] ?? date('Y-m-d'));
    $total = (float) str_replace(',', '.', $_POST['total'] ?? '0');
    $desc = trim($_POST['descricao'] ?? 'Documento integrado');
    $hashExt = trim($_POST['hash_externo'] ?? '');
    $hashCtrl = trim($_POST['hash_control_custom'] ?? '');

    $cli = null;
    if ($clienteId) {
        $s = db()->prepare('SELECT * FROM fat_clientes WHERE id=?');
        $s->execute([$clienteId]);
        $cli = $s->fetch();
    }
    if (!$cli) {
        $errors[] = 'Seleccione um cliente.';
    }
    if (!in_array($tipo, ['FT', 'FR', 'NC', 'ND'], true)) {
        $errors[] = 'Tipo inválido.';
    }
    if ($hashExt === '') {
        $errors[] = 'Hash externo obrigatório para integração.';
    }
    if ($total <= 0) {
        $errors[] = 'Total inválido.';
    }

    if (!$errors) {
        try {
            $pdo = db();
            $pdo->beginTransaction();
            $pdo->prepare("INSERT INTO fat_documentos
                (tipo, serie, numero, numero_completo, cliente_id, cliente_nome, cliente_nif, cliente_morada,
                 data_documento, data_sistema, estado, source_billing, hash_externo, hash_control_custom,
                 subtotal, total_iva, total, observacoes, criado_por)
                 VALUES (?,?,NULL,'RASCUNHO',?,?,?,?,?,NOW(),'rascunho','I',?,?, ?,0,?,?,?)")
                ->execute([
                    $tipo, 'INT', $cli['id'], $cli['nome'], $cli['nif'], $cli['morada'], $dataDoc,
                    $hashExt, $hashCtrl !== '' ? $hashCtrl : null,
                    $total, $total, 'Integração AGT (SourceBilling I)', current_user()['id'],
                ]);
            $docId = (int) $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO fat_linhas (documento_id, linha, codigo, descricao, quantidade, unidade, preco_unitario, desconto_pct, taxa_iva, total_liquido, total_iva, total_linha)
                VALUES (?,1,?,?,1,?, ?,0,14, ?,?,?,?)')
                ->execute([$docId, 'INT', $desc, 'UN', $total, round($total / 1.14, 2), round($total - $total / 1.14, 2), $total]);
            $pdo->commit();
            $emitido = fat_emitir_documento($docId, (int) current_user()['id'], '1');
            flash('success', 'Documento integrado emitido: ' . $emitido['numero_completo']);
            redirect('/admin/facturacao/documentos/ver.php?id=' . $docId);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = $e->getMessage();
        }
    }
}

$clientes = db()->query('SELECT id, nome, nif FROM fat_clientes WHERE ativo=1 ORDER BY nome')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<p style="font-size:.9rem;color:#6b7280">Registo de documentos emitidos noutro sistema certificado (<strong>SourceBilling I</strong>) com hash RSA já calculado.</p>
<form method="post"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Tipo</label><select name="tipo"><option value="FT">FT</option><option value="FR">FR</option><option value="NC">NC</option><option value="ND">ND</option></select></div>
        <div class="form-group"><label>Data</label><input class="form-control" type="date" name="data_documento" value="<?= e(date('Y-m-d')) ?>" required></div>
        <div class="form-group"><label>Cliente *</label><select name="cliente_id" required><option value="">—</option>
            <?php foreach ($clientes as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['nome']) ?></option><?php endforeach; ?>
        </select></div>
        <div class="form-group"><label>Total c/ IVA</label><input class="form-control" name="total" required></div>
        <div class="form-group"><label>Descrição</label><input class="form-control" name="descricao" value="Documento integrado"></div>
        <div class="form-group" style="grid-column:1/-1"><label>Hash externo (Base64 RSA) *</label><textarea name="hash_externo" rows="3" required placeholder="Assinatura Base64 do sistema origem"></textarea></div>
        <div class="form-group" style="grid-column:1/-1"><label>HashControl custom (opcional)</label><input class="form-control" name="hash_control_custom" placeholder="N.º certificação sistema origem"></div>
    </div>
    <div class="form-actions"><button class="btn btn-primary" type="submit">Emitir integrado</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Voltar</a></div>
</form>
</div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
