<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
if (function_exists('fat_agt_compliance_migrate')) {
    fat_agt_compliance_migrate();
}

$pageTitle = 'Facturação';
$pageSubtitle = 'Gestão de vendas';
$current = 'fat';

$caixa = fat_caixa_aberto();

$mes = date('Y-m');
$totMes = db()->prepare("SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS t FROM fat_documentos WHERE estado='emitido' AND DATE_FORMAT(data_documento,'%Y-%m')=? AND tipo IN ('FT','FR')");
$totMes->execute([$mes]);
$statsMes = $totMes->fetch();

$totNc = db()->prepare("SELECT COALESCE(SUM(total),0) FROM fat_documentos WHERE estado='emitido' AND DATE_FORMAT(data_documento,'%Y-%m')=? AND tipo='NC'");
$totNc->execute([$mes]);
$ncMes = (float) $totNc->fetchColumn();

$rascunhos = (int) db()->query("SELECT COUNT(*) FROM fat_documentos WHERE estado='rascunho'")->fetchColumn();
$clientes = (int) db()->query('SELECT COUNT(*) FROM fat_clientes WHERE ativo=1')->fetchColumn();
$produtos = (int) db()->query('SELECT COUNT(*) FROM fat_produtos WHERE ativo=1')->fetchColumn();

$ultimos = db()->query("SELECT id, tipo, numero_completo, cliente_nome, total, estado, data_documento FROM fat_documentos ORDER BY id DESC LIMIT 8")->fetchAll();

$agtPendentes = (int) db()->query("SELECT COUNT(*) FROM fat_agt_envios WHERE estado IN ('pendente','submetido','processando','erro')")->fetchColumn();
$backupAtraso = function_exists('fat_agt_backup_em_atraso') && fat_agt_backup_em_atraso();

$dashFrom = date('Y-m-01');
$dashTo = date('Y-m-d');
$resumoMes = fat_relatorio_resumo($dashFrom, $dashTo);
$porTipoRows = fat_dashboard_por_tipo($dashFrom, $dashTo);
$tiposChart = ['labels' => [], 'totais' => []];
foreach ($porTipoRows as $row) {
    $tiposChart['labels'][] = fat_tipo_label((string) $row['tipo']) . ' (' . (int) $row['n'] . ')';
    $tiposChart['totais'][] = (float) $row['total'];
}
$topCliRows = fat_dashboard_top_clientes($dashFrom, $dashTo, 6);
$cliChart = ['labels' => [], 'totais' => []];
foreach ($topCliRows as $row) {
    $nome = trim((string) $row['cliente_nome']);
    $cliChart['labels'][] = $nome !== '' ? (mb_strlen($nome) > 28 ? mb_substr($nome, 0, 26) . '…' : $nome) : '—';
    $cliChart['totais'][] = (float) $row['total'];
}
$pagRows = fat_dashboard_pagamentos($dashFrom, $dashTo);
$pagLabels = ['numerario' => 'Numerário', 'multicaixa' => 'Multicaixa', 'transferencia' => 'Transferência', 'cartao' => 'Cartão', 'outro' => 'Outro'];
$pagChart = ['labels' => [], 'totais' => []];
foreach ($pagRows as $row) {
    $m = (string) $row['metodo'];
    $pagChart['labels'][] = $pagLabels[$m] ?? ucfirst($m);
    $pagChart['totais'][] = (float) $row['total'];
}

$chartPayload = [
    'series' => fat_dashboard_series(6),
    'diario' => fat_dashboard_vendas_diarias(30),
    'tipos' => $tiposChart,
    'topClientes' => $cliChart,
    'pagamentos' => $pagChart,
];

require __DIR__ . '/../includes/header.php';
?>
<style>
.fat-charts { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 16px; }
.fat-charts .chart-card .card-body { padding: 12px 16px 20px; }
.fat-chart-wrap { position: relative; height: 280px; max-width: 100%; }
.fat-charts .chart-card-wide { grid-column: 1 / -1; }
@media (max-width: 960px) {
    .fat-charts { grid-template-columns: 1fr; }
    .fat-charts .chart-card-wide { grid-column: auto; }
}
</style>

<?php if ($caixa): ?>
<div class="alert alert-success alert-persist" style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between">
    <div>
        <strong><i class="fas fa-lock-open"></i> Caixa #<?= (int)$caixa['id'] ?> aberto</strong>
        desde <?= e(format_date($caixa['aberto_em'], 'd/m/Y H:i')) ?>
        · Fundo <?= e(fat_format_money($caixa['fundo_inicial'])) ?>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-primary" href="<?= url('/admin/facturacao/vender.php') ?>"><i class="fas fa-cash-register"></i> Vender</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/caixa.php') ?>">Fechar / gerir caixa</a>
    </div>
</div>
<?php else: ?>
<div class="alert alert-error alert-persist" style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between">
    <div><strong><i class="fas fa-lock"></i> Caixa fechado</strong> — abra o caixa para realizar vendas.</div>
    <a class="btn btn-primary" href="<?= url('/admin/facturacao/caixa.php') ?>"><i class="fas fa-lock-open"></i> Abrir caixa</a>
</div>
<?php endif; ?>

<section class="stats-grid">
    <article class="stat-card">
        <div class="stat-icon green"><i class="fas fa-file-invoice"></i></div>
        <div><span>Docs emitidos (mês)</span><strong><?= (int) ($statsMes['n'] ?? 0) ?></strong></div>
    </article>
    <article class="stat-card">
        <div class="stat-icon dark"><i class="fas fa-coins"></i></div>
        <div><span>Vendas líquidas (mês)</span><strong><?= e(fat_format_money(((float)($statsMes['t'] ?? 0)) - $ncMes)) ?></strong></div>
    </article>
    <article class="stat-card">
        <div class="stat-icon warn"><i class="fas fa-pen"></i></div>
        <div><span>Rascunhos</span><strong><?= $rascunhos ?></strong></div>
    </article>
    <article class="stat-card">
        <div class="stat-icon info"><i class="fas fa-users"></i></div>
        <div><span>Clientes / Produtos</span><strong><?= $clientes ?> / <?= $produtos ?></strong></div>
    </article>
    <article class="stat-card">
        <div class="stat-icon green"><i class="fas fa-percent"></i></div>
        <div><span>IVA liquidado (mês)</span><strong><?= e(fat_format_money($resumoMes['iva_liquidado'])) ?></strong></div>
    </article>
    <article class="stat-card">
        <div class="stat-icon dark"><i class="fas fa-hand-holding-dollar"></i></div>
        <div><span>Recebimentos (mês)</span><strong><?= e(fat_format_money($resumoMes['recebimentos'])) ?></strong></div>
    </article>
</section>

<section class="fat-charts" aria-label="Gráficos de facturação">
    <div class="card chart-card">
        <div class="card-head"><h2>Vendas e notas de crédito (6 meses)</h2><a class="link" href="<?= url('/admin/facturacao/relatorios.php?tipo=resumo') ?>">Relatórios</a></div>
        <div class="card-body"><div class="fat-chart-wrap"><canvas id="fatChartVendasMes"></canvas></div></div>
    </div>
    <div class="card chart-card">
        <div class="card-head"><h2>Vendas líquidas — últimos 30 dias</h2></div>
        <div class="card-body"><div class="fat-chart-wrap"><canvas id="fatChartDiario"></canvas></div></div>
    </div>
    <div class="card chart-card">
        <div class="card-head"><h2>IVA liquidado (6 meses)</h2></div>
        <div class="card-body"><div class="fat-chart-wrap"><canvas id="fatChartIva"></canvas></div></div>
    </div>
    <div class="card chart-card">
        <div class="card-head"><h2>Documentos por tipo (mês)</h2></div>
        <div class="card-body"><div class="fat-chart-wrap"><canvas id="fatChartTipos"></canvas></div></div>
    </div>
    <div class="card chart-card">
        <div class="card-head"><h2>Top clientes (mês)</h2></div>
        <div class="card-body"><div class="fat-chart-wrap"><canvas id="fatChartClientes"></canvas></div></div>
    </div>
    <div class="card chart-card">
        <div class="card-head"><h2>Recebimentos por meio (mês)</h2></div>
        <div class="card-body"><div class="fat-chart-wrap"><canvas id="fatChartPagamentos"></canvas></div></div>
    </div>
</section>

<?php if ($backupAtraso): ?>
<div class="alert alert-error alert-persist" style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between">
    <div><strong><i class="fas fa-database"></i> Cópias de segurança AGT:</strong> período sem backup superior ao configurado.</div>
    <a class="btn btn-outline" href="<?= url('/admin/facturacao/backups.php') ?>">Gerir backups</a>
</div>
<?php endif; ?>
<?php if ($agtPendentes > 0): ?>
<div class="alert alert-error alert-persist" style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between">
    <div><strong><i class="fas fa-satellite-dish"></i> Facturação electrónica AGT:</strong> <?= $agtPendentes ?> envio(s) pendente(s) ou a processar.</div>
    <a class="btn btn-outline" href="<?= url('/admin/facturacao/agt.php') ?>">Abrir fila AGT</a>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-head"><h2>Últimos documentos</h2><a class="link" href="<?= url('/admin/facturacao/documentos/index.php') ?>">Ver todos</a></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Documento</th><th>Cliente</th><th>Data</th><th>Total</th><th>Estado</th><th></th></tr></thead>
            <tbody>
            <?php if (!$ultimos): ?>
                <tr><td colspan="6" class="empty">Ainda sem documentos. Abra o caixa e venda.</td></tr>
            <?php else: foreach ($ultimos as $d): ?>
                <tr>
                    <td><strong><?= e($d['numero_completo']) ?></strong><div style="font-size:.8rem;color:#6b7280"><?= e(fat_tipo_label($d['tipo'])) ?></div></td>
                    <td><?= e($d['cliente_nome']) ?></td>
                    <td><?= e(format_date($d['data_documento'], 'd/m/Y')) ?></td>
                    <td><?= e(fat_format_money($d['total'])) ?></td>
                    <td><?= e($d['estado']) ?></td>
                    <td class="actions"><a class="btn btn-sm btn-outline" href="<?= url('/admin/facturacao/documentos/ver.php?id=' . $d['id']) ?>">Abrir</a></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$pageFootScripts = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>'
    . '<script>window.fatDashCharts = ' . json_encode($chartPayload, JSON_UNESCAPED_UNICODE) . ';</script>'
    . '<script src="' . e(url('/admin/facturacao/assets/dashboard-charts.js')) . '"></script>';
require __DIR__ . '/../includes/footer.php';
?>
