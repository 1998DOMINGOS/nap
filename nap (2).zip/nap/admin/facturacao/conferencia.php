<?php
/**
 * Documentos 4.3 — WorkingDocuments (consultas de mesa, encomendas, etc.)
 */
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
fat_agt_compliance_migrate();

$pageTitle = 'Conferência / mesa (4.3)';
$current = 'fat-conferencia';
$errors = [];
$workTypes = function_exists('fat_agt_work_types') ? fat_agt_work_types() : ['PF', 'CM', 'NE', 'DC', 'OU'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $clienteId = (int) ($_POST['cliente_id'] ?? 0);
    $dataDoc = trim($_POST['data_documento'] ?? date('Y-m-d'));
    $workType = strtoupper(trim($_POST['work_type'] ?? 'CM'));
    $obs = trim($_POST['observacoes'] ?? '');
    $deviceId = (int) ($_POST['dispositivo_movel_id'] ?? 0) ?: null;
    $emissaoMovel = !empty($_POST['emissao_movel']) ? 1 : 0;

    $cli = null;
    if ($clienteId) {
        $s = db()->prepare('SELECT * FROM fat_clientes WHERE id=?');
        $s->execute([$clienteId]);
        $cli = $s->fetch();
    }
    if (!$cli) {
        $errors[] = 'Seleccione um cliente.';
    }
    if (!in_array($workType, $workTypes, true)) {
        $errors[] = 'WorkType inválido.';
    }

    $descs = $_POST['linha_desc'] ?? [];
    $qtys = $_POST['linha_qty'] ?? [];
    $precos = $_POST['linha_preco'] ?? [];
    $linhas = [];
    for ($i = 0; $i < count($descs); $i++) {
        $desc = trim($descs[$i] ?? '');
        if ($desc === '') {
            continue;
        }
        $qty = (float) str_replace(',', '.', $qtys[$i] ?? '1');
        $preco = (float) str_replace(',', '.', $precos[$i] ?? '0');
        $calc = fat_calc_linha($qty, $preco, 0, 14);
        $linhas[] = ['descricao' => $desc, 'qty' => $qty, 'preco' => $preco, 'calc' => $calc];
    }
    if (!$linhas) {
        $errors[] = 'Adicione pelo menos uma linha.';
    }

    if (!$errors) {
        try {
            $sub = array_sum(array_column(array_column($linhas, 'calc'), 'total_liquido'));
            $iva = array_sum(array_column(array_column($linhas, 'calc'), 'total_iva'));
            $tot = array_sum(array_column(array_column($linhas, 'calc'), 'total_linha'));
            db()->prepare("INSERT INTO fat_documentos (tipo, serie, numero, numero_completo, cliente_id, cliente_nome, cliente_nif, cliente_morada,
                data_documento, data_sistema, estado, work_type, subtotal, total_iva, total, observacoes, emissao_movel, dispositivo_movel_id, criado_por)
                VALUES ('OR','A',NULL,'RASCUNHO',?,?,?,?,?,NOW(),'rascunho',?,?,?,?,?,?,?,?)")
                ->execute([
                    $cli['id'], $cli['nome'], $cli['nif'], $cli['morada'], $dataDoc, $workType,
                    $sub, $iva, $tot, $obs, $emissaoMovel, $deviceId, current_user()['id'],
                ]);
            $docId = (int) db()->lastInsertId();
            $ins = db()->prepare('INSERT INTO fat_linhas (documento_id, linha, descricao, quantidade, unidade, preco_unitario, taxa_iva, total_liquido, total_iva, total_linha) VALUES (?,?,?,?,?,?,?,?,?,?)');
            $n = 1;
            foreach ($linhas as $l) {
                $c = $l['calc'];
                $ins->execute([$docId, $n++, $l['descricao'], $l['qty'], 'UN', $l['preco'], 14, $c['total_liquido'], $c['total_iva'], $c['total_linha']]);
            }
            $emitido = fat_emitir_documento($docId, (int) current_user()['id'], '1');
            flash('success', 'Documento 4.3 emitido: ' . $emitido['numero_completo'] . ' (' . $workType . ')');
            redirect('/admin/facturacao/documentos/ver.php?id=' . $docId);
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
}

$clientes = db()->query('SELECT id, nome, nif FROM fat_clientes WHERE ativo=1 ORDER BY nome')->fetchAll();
$devices = db()->query('SELECT id, nome FROM fat_dispositivos_movel WHERE ativo=1 ORDER BY nome')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post"><?= csrf_field() ?>
<div class="form-grid">
<div class="form-group"><label>Cliente *</label><select name="cliente_id" required><option value="">—</option><?php foreach ($clientes as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['nome']) ?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Data</label><input type="date" class="form-control" name="data_documento" value="<?= e(date('Y-m-d')) ?>"></div>
<div class="form-group"><label>WorkType (SAF-T 4.3) *</label><select name="work_type"><?php foreach ($workTypes as $wt): ?><option value="<?= e($wt) ?>" <?= $wt === 'CM' ? 'selected' : '' ?>><?= e($wt) ?></option><?php endforeach; ?></select></div>
</div>
<div id="linhas">
<div class="form-grid"><div class="form-group"><label>Descrição</label><input class="form-control" name="linha_desc[]"></div><div class="form-group"><label>Qtd</label><input class="form-control" name="linha_qty[]" value="1"></div><div class="form-group"><label>Preço</label><input class="form-control" name="linha_preco[]" value="0"></div></div>
</div>
<button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('linhas').insertAdjacentHTML('beforeend', document.querySelector('#linhas .form-grid').outerHTML)">+ Linha</button>
<?php if ($devices): ?>
<div class="form-group" style="margin-top:12px"><label><input type="checkbox" name="emissao_movel" value="1"> Emissão móvel</label>
<select name="dispositivo_movel_id"><option value="">— terminal —</option><?php foreach ($devices as $d): ?><option value="<?= (int)$d['id'] ?>"><?= e($d['nome']) ?></option><?php endforeach; ?></select></div>
<?php endif; ?>
<div class="form-group"><label>Observações</label><textarea name="observacoes"></textarea></div>
<button class="btn btn-primary" type="submit">Emitir documento 4.3</button>
</form></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
