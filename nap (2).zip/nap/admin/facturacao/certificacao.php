<?php
/**
 * Anexos para certificação AGT: Chave Pública + Ficheiro SAF-T.
 */
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
fat_agt_ensure_schema();

$pageTitle = 'Certificação AGT — anexos';
$current = 'fat-cert';
$emp = fat_empresa();
$errors = [];
$ok = null;

if (($_GET['download'] ?? '') === 'chave') {
    $path = fat_agt_cert_public_path();
    if (!is_file($path)) {
        try {
            fat_agt_preparar_anexo_chave_publica();
        } catch (Throwable $e) {
            http_response_code(404);
            exit($e->getMessage());
        }
        $path = fat_agt_cert_public_path();
    }
    header('Content-Type: application/x-pem-file; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . fat_agt_cert_public_filename() . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
}

if (($_GET['download'] ?? '') === 'saft') {
    $path = fat_agt_cert_saft_path();
    if (!is_file($path)) {
        http_response_code(404);
        exit('Gere ou carregue primeiro o SAF-T de certificação.');
    }
    header('Content-Type: application/xml; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . fat_agt_cert_saft_filename() . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'preparar_chave') {
            fat_agt_preparar_anexo_chave_publica();
            $ok = 'Chave pública preparada. Descarregue e anexe no portal AGT.';
        }
        if ($action === 'upload_chave' && !empty($_FILES['chave_publica']['tmp_name'])) {
            $tmp = $_FILES['chave_publica']['tmp_name'];
            $name = strtolower((string) ($_FILES['chave_publica']['name'] ?? ''));
            if (!preg_match('/\.(pem|txt|cer|pub)$/i', $name)) {
                throw new RuntimeException('Formato accepto: .pem, .txt, .cer ou .pub');
            }
            $content = (string) file_get_contents($tmp);
            if (!str_contains($content, 'BEGIN PUBLIC KEY') && !str_contains($content, 'BEGIN RSA PUBLIC KEY')) {
                throw new RuntimeException('O ficheiro não contém uma chave pública PEM válida.');
            }
            file_put_contents(fat_agt_cert_public_path(), $content);
            $pubSystem = fat_keys_dir() . '/public.pem';
            file_put_contents($pubSystem, $content);
            db()->prepare('UPDATE fat_empresa SET chave_publica_path=?, agt_anexo_chave_path=? WHERE id=?')
                ->execute(['storage/fat_keys/public.pem', 'storage/agt_cert/' . fat_agt_cert_public_filename(), $emp['id']]);
            $ok = 'Chave pública carregada e definida como anexo de certificação.';
        }
        if ($action === 'gerar_saft') {
            $from = trim($_POST['from'] ?? date('Y-01-01'));
            $to = trim($_POST['to'] ?? date('Y-m-d'));
            if (trim((string) ($emp['nif'] ?? '')) === '') {
                throw new RuntimeException('Configure o NIF da empresa antes de gerar o SAF-T.');
            }
            fat_validar_configuracao_eletronica();
            fat_fix_fr_invoice_dates_sequential(2, 'A', '2026-08-22');
            fat_portal_cert_align_system_entry_dates(2, 8, 'A');
            fat_rebuild_portal_cert_fr_chain(2, 8, 'A');
            $xml = fat_export_saft_ao_portal_cert($from, $to);
            fat_agt_guardar_anexo_saft($xml);
            $ok = 'SAF-T de certificação (FR A/2–A/8) gerado e guardado como anexo.';
        }
        if ($action === 'upload_saft' && !empty($_FILES['saft']['tmp_name'])) {
            $name = (string) ($_FILES['saft']['name'] ?? '');
            if (!preg_match('/\.xml$/i', $name)) {
                throw new RuntimeException('O SAF-T deve ser um ficheiro .xml');
            }
            $xml = (string) file_get_contents($_FILES['saft']['tmp_name']);
            fat_agt_guardar_anexo_saft($xml);
            $ok = 'Ficheiro SAF-T carregado como anexo de certificação.';
        }
        if ($action === 'regenerar_anexo') {
            fat_fix_fr_invoice_dates_sequential(2, 'A', '2026-08-22');
            fat_portal_cert_align_system_entry_dates(2, 8, 'A');
            fat_rebuild_portal_cert_fr_chain(2, 8, 'A');
            $xml = fat_export_saft_ao_portal_cert(date('Y-01-01'), date('Y-m-d'));
            fat_agt_guardar_anexo_saft($xml);
            fat_agt_preparar_anexo_chave_publica();
            $ok = 'FR A/2–A/8 reassinados (cadeia portal) e anexos actualizados.';
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
    $emp = fat_empresa();
}

$dlToken = substr(hash_hmac('sha256', trim((string) ($emp['nif'] ?? '')) !== '' ? (string) $emp['nif'] : APP_NAME, APP_NAME), 0, 20);
$chaveOk = is_file(fat_agt_cert_public_path()) || is_file(fat_keys_dir() . '/public.pem');
$saftOk = is_file(fat_agt_cert_saft_path()) || (glob(__DIR__ . '/../../storage/saft/SAFT_AO_*.xml') ?: []);
$chaveSize = $chaveOk ? filesize(fat_agt_cert_public_path()) : 0;
$saftSize = $saftOk ? filesize(fat_agt_cert_saft_path()) : 0;

require __DIR__ . '/../includes/header.php';
?>
<div class="toolbar">
    <p class="subtitle" style="margin:0">Documentos para o formulário AGT: <strong>Anexar Chave Pública</strong> e <strong>Ficheiro SAF-T</strong>.</p>
    <div class="actions">
        <a class="btn btn-primary" href="<?= url('/admin/facturacao/exportar-anexos-desktop.php') ?>"><i class="fas fa-desktop"></i> Copiar para Ambiente de Trabalho</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/empresa.php') ?>">Empresa fiscal</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/saft.php') ?>">Exportar SAF-T</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Voltar</a>
    </div>
</div>

<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>

<div class="grid-2" style="margin-top:16px">
    <div class="card"><div class="card-body">
        <h3><span style="color:#dc2626">*</span> Anexar Chave Pública</h3>
        <p style="font-size:.82rem;margin-bottom:8px"><strong>Nome do ficheiro no portal:</strong> <code>Chave Publica.pem</code></p>
        <p style="font-size:.88rem;color:#6b7280">RSA <strong>1024</strong> bits em PEM (hash SAF-T ≤172 caracteres). Deve corresponder à chave privada actual em <code>storage/fat_keys/</code> — volte a anexar após <code>php scripts/fat_migrate_keys_1024.php</code>.</p>
        <p><strong>Estado:</strong> <?= $chaveOk ? '<span style="color:#059669">Pronto (' . (int) $chaveSize . ' bytes)</span>' : '<span style="color:#dc2626">Em falta</span>' ?></p>
        <?php if ($chaveOk): ?>
            <p style="font-size:.85rem"><code><?= e(fat_agt_cert_public_filename()) ?></code></p>
        <?php endif; ?>
        <form method="post" style="margin-top:12px"><?= csrf_field() ?>
            <input type="hidden" name="action" value="preparar_chave">
            <button class="btn btn-primary" type="submit"><i class="fas fa-key"></i> Usar chave do sistema</button>
        </form>
        <form method="post" enctype="multipart/form-data" style="margin-top:12px"><?= csrf_field() ?>
            <input type="hidden" name="action" value="upload_chave">
            <div class="form-group"><label>Carregar ficheiro (.pem / .txt)</label><input type="file" name="chave_publica" accept=".pem,.txt,.cer,.pub" required></div>
            <button class="btn btn-outline" type="submit">Substituir / carregar chave</button>
        </form>
        <?php if ($chaveOk): ?>
        <div class="form-actions" style="margin-top:12px">
            <a class="btn btn-outline" href="<?= url('/admin/facturacao/certificacao.php?download=chave') ?>"><i class="fas fa-download"></i> Descarregar para portal AGT</a>
        </div>
        <?php endif; ?>
    </div></div>

    <div class="card"><div class="card-body">
        <h3><span style="color:#dc2626">*</span> Ficheiro SAF-T</h3>
        <p style="font-size:.82rem;margin-bottom:8px"><strong>Nome do ficheiro no portal:</strong> <code>Ficheiro SAF-T.xml</code></p>
        <?php $empCert = fat_empresa(); ?>
        <p style="font-size:.88rem;color:#6b7280">Configure software, Product ID, validação AGT e SAF-T em <a href="<?= url('/admin/facturacao/empresa.php') ?>"><strong>Empresa fiscal</strong></a> (fonte única — sem ficheiros duplicados).</p>
        <p style="font-size:.82rem;color:#374151"><strong>ProductID:</strong> <code><?= e(fat_saft_product_id($empCert)) ?></code> · <strong>Validação:</strong> <code><?= e(fat_saft_validation_number($empCert)) ?></code> · <strong>HashControl:</strong> <code><?= e(fat_saft_hash_control_value($empCert)) ?></code> · <strong>Basis:</strong> <code><?= e(fat_saft_tax_accounting_basis($empCert)) ?></code> · <strong>Produtor NIF:</strong> <code><?= e($empCert['produtor_nif'] ?? '') ?></code></p>
        <p style="font-size:.82rem;color:#92400e">Chave pública do portal = <code>Chave Publica.pem</code> (RSA 1024).</p>
        <form method="post" style="margin-top:12px"><?= csrf_field() ?>
            <input type="hidden" name="action" value="regenerar_anexo">
            <button class="btn btn-primary" type="submit"><i class="fas fa-sync"></i> Reassinar e regenerar anexo SAF-T</button>
        </form>
        <p><strong>Estado:</strong> <?= $saftOk ? '<span style="color:#059669">Pronto (' . number_format($saftSize / 1024, 1) . ' KB)</span>' : '<span style="color:#dc2626">Em falta</span>' ?></p>
        <?php if ($saftOk): ?>
            <p style="font-size:.85rem"><code><?= e(fat_agt_cert_saft_filename()) ?></code></p>
        <?php endif; ?>
        <form method="post" style="margin-top:12px"><?= csrf_field() ?>
            <input type="hidden" name="action" value="gerar_saft">
            <div class="form-grid">
                <div class="form-group"><label>Data início</label><input class="form-control" type="date" name="from" value="<?= e(date('Y-01-01')) ?>" required></div>
                <div class="form-group"><label>Data fim</label><input class="form-control" type="date" name="to" value="<?= e(date('Y-m-d')) ?>" required></div>
            </div>
            <button class="btn btn-primary" type="submit"><i class="fas fa-file-code"></i> Gerar SAF-T (anexo)</button>
        </form>
        <form method="post" enctype="multipart/form-data" style="margin-top:12px"><?= csrf_field() ?>
            <input type="hidden" name="action" value="upload_saft">
            <div class="form-group"><label>Carregar XML SAF-T</label><input type="file" name="saft" accept=".xml,application/xml,text/xml" required></div>
            <button class="btn btn-outline" type="submit">Carregar ficheiro existente</button>
        </form>
        <?php if ($saftOk): ?>
        <div class="form-actions" style="margin-top:12px">
            <a class="btn btn-outline" href="<?= url('/admin/facturacao/certificacao.php?download=saft') ?>"><i class="fas fa-download"></i> Descarregar para portal AGT</a>
        </div>
        <?php endif; ?>
    </div></div>
</div>

<div class="card" style="margin-top:16px"><div class="card-body">
    <h3>Links directos (partilhar / descarregar)</h3>
    <p style="font-size:.88rem;color:#6b7280">Use estes links no browser (ou envie ao consultor). Token ligado ao NIF da empresa.</p>
    <ul style="font-size:.85rem;word-break:break-all">
        <li><strong>Chave pública:</strong> <a href="<?= e(url('/download-anexos-agt.php?f=chave&t=' . $dlToken)) ?>"><?= e(url('/download-anexos-agt.php?f=chave&t=' . $dlToken)) ?></a></li>
        <li><strong>SAF-T:</strong> <a href="<?= e(url('/download-anexos-agt.php?f=saft&t=' . $dlToken)) ?>"><?= e(url('/download-anexos-agt.php?f=saft&t=' . $dlToken)) ?></a></li>
    </ul>
    <p style="font-size:.8rem;color:#6b7280">Ficheiros locais: <code>C:\xampp\htdocs\nap\storage\agt_cert\</code> e <code>storage\fat_keys\public.pem</code></p>
</div></div>

<div class="card" style="margin-top:16px"><div class="card-body">
    <h3>Checklist portal AGT</h3>
    <ol style="font-size:.9rem;line-height:1.8;color:#374151">
        <li>Empresa fiscal: NIF, produtor, n.º certificação e validação software preenchidos.</li>
        <li>Emitir pelo menos uma factura de teste (FT/FR) antes de gerar o SAF-T.</li>
        <li>Preparar chave pública → descarregar <code><?= e(fat_agt_cert_public_filename()) ?></code> → anexar no portal.</li>
        <li>Gerar SAF-T do período → descarregar <code><?= e(fat_agt_cert_saft_filename()) ?></code> → anexar no portal.</li>
        <li>A chave privada <strong>nunca</strong> é enviada à AGT — apenas a pública.</li>
    </ol>
</div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
