<?php

require_once __DIR__ . '/../../config/app.php';

require_facturacao();

ensure_facturacao_schema();

fat_agt_compliance_migrate();



$pageTitle = 'Cópias de segurança';

$current = 'fat-empresa';

$ok = null;

$err = null;

$backupDir = __DIR__ . '/../../storage/backups';



if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verify_csrf();

    $action = $_POST['action'] ?? '';

    try {

        if ($action === 'backup') {

            $name = fat_agt_executar_backup_sql((int) (current_user()['id'] ?? 0), 'manual');

            $ok = 'Cópia criada: ' . $name;

        }

        if ($action === 'restauracao_registo') {

            $ficheiro = trim($_POST['ficheiro'] ?? '');

            $notas = trim($_POST['notas'] ?? '');

            if ($ficheiro === '') {

                throw new RuntimeException('Indique o ficheiro restaurado.');

            }

            fat_agt_registar_restauracao($ficheiro . ($notas !== '' ? ' — ' . $notas : ''), (int) current_user()['id']);

            $ok = 'Restauração registada no histórico AGT.';

        }

    } catch (Throwable $e) {

        $err = $e->getMessage();

    }

}



$logs = [];

try {

    $logs = db()->query('SELECT * FROM fat_system_backups ORDER BY id DESC LIMIT 40')->fetchAll();

} catch (Throwable $e) {

}



$diasSem = function_exists('fat_agt_dias_sem_backup') ? fat_agt_dias_sem_backup() : null;

$emp = fat_empresa();

$limite = max(1, (int) ($emp['agt_backup_dias'] ?? 7));



require __DIR__ . '/../includes/header.php';

?>

<?php if ($diasSem !== null && $diasSem > $limite): ?>

<div class="alert alert-error"><strong>Alerta AGT:</strong> há <?= (int) $diasSem ?> dias sem cópia de segurança (limite configurado: <?= $limite ?> dias).</div>

<?php endif; ?>

<div class="card"><div class="card-body">

<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>

<?php if ($err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endif; ?>

<p style="font-size:.9rem;color:#6b7280">Requisito AGT: política de cópias e registo de restaurações. Automático: <code>php scripts/fat_backup_automatico.php</code> (Task Scheduler).</p>

<form method="post" style="margin-bottom:16px"><?= csrf_field() ?><input type="hidden" name="action" value="backup"><button class="btn btn-primary" type="submit"><i class="fas fa-database"></i> Criar cópia SQL agora</button></form>

<form method="post" class="form-grid">

    <?= csrf_field() ?><input type="hidden" name="action" value="restauracao_registo">

    <div class="form-group"><label>Registar restauração (ficheiro)</label><input class="form-control" name="ficheiro" placeholder="nap_20260101_120000.sql"></div>

    <div class="form-group"><label>Notas</label><input class="form-control" name="notas" placeholder="Motivo / operador"></div>

    <div class="form-group" style="align-self:end"><button class="btn btn-outline" type="submit">Registar restauração</button></div>

</form>

</div></div>

<div class="card" style="margin-top:16px"><div class="card-head"><h2>Histórico</h2></div><div class="card-body">

<table><thead><tr><th>Data</th><th>Ficheiro</th><th>Tamanho</th><th>Tipo</th><th>Restauração</th></tr></thead><tbody>

<?php foreach ($logs as $l): ?><tr><td><?= e($l['criado_em']) ?></td><td><?= e($l['ficheiro']) ?></td><td><?= e(number_format((int) $l['tamanho'] / 1024, 1)) ?> KB</td><td><?= e($l['tipo']) ?></td><td><?= !empty($l['restauracao']) ? 'Sim' : '—' ?></td></tr><?php endforeach; ?>

<?php if (!$logs): ?><tr><td colspan="5">Nenhuma cópia registada.</td></tr><?php endif; ?>

</tbody></table>

</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>

