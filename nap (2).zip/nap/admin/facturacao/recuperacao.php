<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
fat_agt_compliance_migrate();

$pageTitle = 'Recuperação manual / duplicado';
$current = 'fat-empresa';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $modo = $_POST['modo'] ?? 'manual';
    $tipo = strtoupper(trim($_POST['tipo'] ?? 'FT'));
    $clienteId = (int) ($_POST['cliente_id'] ?? 0);
    $dataDoc = trim($_POST['data_documento'] ?? date('Y-m-d'));
    $total = (float) str_replace(',', '.', $_POST['total'] ?? '0');
    $desc = trim($_POST['descricao'] ?? 'Documento de recuperação');
    $dupRef = trim($_POST['doc_duplicado_ref'] ?? '');
    $refSerie = trim($_POST['ref_manual_serie'] ?? '');
    $refNum = trim($_POST['ref_manual_numero'] ?? '');

    $cli = null;
    if ($clienteId) {
        $s = db()->prepare('SELECT * FROM fat_clientes WHERE id=?');
        $s->execute([$clienteId]);
        $cli = $s->fetch();
    }
    if (!$cli) {
        $errors[] = 'Seleccione um cliente.';
    }
    if (!in_array($tipo, ['FT', 'FR', 'NC', 'ND'], true)) {
        $errors[] = 'Tipo inválido para recuperação.';
    }
    if ($modo === 'manual' && ($refSerie === '' || $refNum === '')) {
        $errors[] = 'Indique série e número manual (SourceBilling M).';
    }
    if ($modo === 'duplicado' && $dupRef === '') {
        $errors[] = 'Indique a referência do documento original (duplicado).';
    }
    if ($total <= 0) {
        $errors[] = 'Total inválido.';
    }

    if (!$errors) {
        try {
            $pdo = db();
            $pdo->beginTransaction();
            $copiaOrig = $modo === 'duplicado' ? 1 : 0;
            $pdo->prepare("INSERT INTO fat_documentos
                (tipo, serie, numero, numero_completo, cliente_id, cliente_nome, cliente_nif, cliente_morada,
                 data_documento, data_sistema, estado, source_billing, ref_manual_serie, ref_manual_numero, doc_duplicado_ref, copia_original,
                 subtotal, total_iva, total, observacoes, criado_por)
                 VALUES (?,?,NULL,'RASCUNHO',?,?,?,?,?,NOW(),'rascunho','M',?,?,?,?, ?,0,?,?,?)")
                ->execute([
                    $tipo, 'A', $cli['id'], $cli['nome'], $cli['nif'], $cli['morada'], $dataDoc,
                    $modo === 'manual' ? $refSerie : null,
                    $modo === 'manual' ? $refNum : null,
                    $modo === 'duplicado' ? $dupRef : null,
                    $copiaOrig,
                    $total, $total,
                    'Recuperação AGT (' . $modo . ')',
                    (int) current_user()['id'],
                ]);
            $docId = (int) $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO fat_linhas (documento_id, linha, codigo, descricao, quantidade, unidade, preco_unitario, desconto_pct, taxa_iva, total_liquido, total_iva, total_linha)
                VALUES (?,1,?,?,1,?, ?,0,0, ?,0,?)')
                ->execute([$docId, 'REC', $desc, 'UN', $total, $total, $total]);
            $pdo->commit();
            $emitido = fat_emitir_documento($docId, (int) current_user()['id'], '1');
            flash('success', 'Documento emitido: ' . $emitido['numero_completo']);
            redirect('/admin/facturacao/documentos/ver.php?id=' . $docId);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = $e->getMessage();
        }
    }
}

$clientes = db()->query('SELECT id, nome, nif FROM fat_clientes WHERE ativo=1 ORDER BY nome')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<p style="font-size:.9rem;color:#6b7280">Emissão com <strong>SourceBilling M</strong> (manual) ou segunda via (<strong>HashControl duplicado</strong>), conforme requisitos AGT.</p>
<form method="post"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Modo</label>
            <select name="modo" id="modoRec">
                <option value="manual">Manual (série/número externos)</option>
                <option value="duplicado">Duplicado (2.ª via)</option>
            </select>
        </div>
        <div class="form-group"><label>Tipo</label>
            <select name="tipo"><option value="FT">FT</option><option value="FR">FR</option><option value="NC">NC</option><option value="ND">ND</option></select>
        </div>
        <div class="form-group"><label>Data documento</label><input class="form-control" type="date" name="data_documento" value="<?= e(date('Y-m-d')) ?>" required></div>
        <div class="form-group"><label>Cliente *</label>
            <select name="cliente_id" required><option value="">—</option>
            <?php foreach ($clientes as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['nome']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><label>Total (Kz)</label><input class="form-control" name="total" required value="0"></div>
        <div class="form-group"><label>Descrição linha</label><input class="form-control" name="descricao" value="Documento de recuperação"></div>
    </div>
    <div id="blocoManual" class="form-grid">
        <div class="form-group"><label>Série manual</label><input class="form-control" name="ref_manual_serie" placeholder="ex.: A"></div>
        <div class="form-group"><label>Número manual</label><input class="form-control" name="ref_manual_numero" placeholder="ex.: 123"></div>
    </div>
    <div id="blocoDup" class="form-group" style="display:none"><label>Factura original (duplicado)</label><input class="form-control" name="doc_duplicado_ref" placeholder="FT A/100"></div>
    <div class="form-actions"><button class="btn btn-primary" type="submit">Emitir</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Voltar</a></div>
</form>
</div></div>
<script>
document.getElementById('modoRec').addEventListener('change', function() {
  const m = this.value === 'manual';
  document.getElementById('blocoManual').style.display = m ? '' : 'none';
  document.getElementById('blocoDup').style.display = m ? 'none' : '';
});
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
