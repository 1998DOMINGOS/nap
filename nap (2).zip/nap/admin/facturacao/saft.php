<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Exportar SAF-T AO';
$current = 'fat-saft';
$errors = [];
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$emp = fat_empresa();
$agtPendente = fat_agt_normalize_validation_number($emp['software_validation_number'] ?? '') === null;

if (isset($_GET['download'])) {
    $file = basename((string) $_GET['download']);
    if (!preg_match('/^SAFT_AO_[0-9]+_[0-9]+_[0-9]+\.xml$/', $file)) {
        http_response_code(400);
        exit('Ficheiro SAF-T inválido.');
    }
    $path = __DIR__ . '/../../storage/saft/' . $file;
    if (!is_file($path)) {
        http_response_code(404);
        exit('Ficheiro SAF-T não encontrado.');
    }
    header('Content-Type: application/xml; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $file . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $from = trim($_POST['from'] ?? $from);
    $to = trim($_POST['to'] ?? $to);
    try {
        $xml = fat_export_saft_ao($from, $to);
        $dir = __DIR__ . '/../../storage/saft';
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $name = 'SAFT_AO_' . preg_replace('/\D/', '', $from) . '_' . preg_replace('/\D/', '', $to) . '_' . date('YmdHis') . '.xml';
        $path = $dir . '/' . $name;
        file_put_contents($path, $xml);

        header('Content-Type: application/xml; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        echo $xml;
        exit;
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

require __DIR__ . '/../includes/header.php';
$saftFiles = glob(__DIR__ . '/../../storage/saft/SAFT_AO_*.xml') ?: [];
usort($saftFiles, static fn($a, $b) => filemtime($b) <=> filemtime($a));
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Data início</label><input class="form-control" type="date" name="from" value="<?= e($from) ?>" required></div>
        <div class="form-group"><label>Data fim</label><input class="form-control" type="date" name="to" value="<?= e($to) ?>" required></div>
    </div>
    <?php if ($agtPendente): ?><div class="alert alert-error">Pré-validação técnica: faltam o número de certificação e o número de validação AGT. Este XML não deve ser submetido como ficheiro final.</div><?php else: ?><div class="alert alert-success">Dados AGT configurados. Valide o XML no ambiente oficial antes de o submeter.</div><?php endif; ?>
    <p style="font-size:.9rem;color:#6b7280">Empresa NIF: <strong><?= e($emp['nif'] ?: '(configure em Empresa fiscal)') ?></strong></p>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-file-code"></i> Gerar e descarregar XML</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/empresa.php') ?>">Empresa fiscal</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Voltar</a>
    </div>
</form>
</div></div>
<div class="card"><div class="card-body">
    <h3>Ficheiros SAF-T guardados</h3>
    <?php if (!$saftFiles): ?>
        <p style="font-size:.9rem;color:#6b7280">Ainda não foi gerado nenhum ficheiro SAF-T.</p>
    <?php else: ?>
        <div class="table-responsive"><table class="table">
            <thead><tr><th>Ficheiro</th><th>Gerado em</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($saftFiles as $filePath): $file = basename($filePath); ?>
                <tr>
                    <td><?= e($file) ?></td>
                    <td><?= e(date('d/m/Y H:i', filemtime($filePath))) ?></td>
                    <td><a class="btn btn-sm btn-outline" href="<?= url('/admin/facturacao/saft.php?download=' . rawurlencode($file)) ?>"><i class="fas fa-download"></i> Descarregar</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    <?php endif; ?>
</div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
