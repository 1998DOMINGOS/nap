<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
fat_agt_compliance_migrate();

$pageTitle = 'Mobilidade (terminais)';
$current = 'fat-empresa';
$ok = null;
$err = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'toggle_empresa') {
            $on = !empty($_POST['agt_mobilidade_ativa']) ? 1 : 0;
            db()->exec('UPDATE fat_empresa SET agt_mobilidade_ativa=' . (int) $on . ' ORDER BY id ASC LIMIT 1');
            $ok = 'Mobilidade ' . ($on ? 'activada' : 'desactivada') . '.';
        }
        if ($action === 'add_device') {
            $nome = trim($_POST['nome'] ?? '');
            $id = trim($_POST['identificador'] ?? '');
            if ($nome === '' || $id === '') {
                throw new RuntimeException('Nome e identificador obrigatórios.');
            }
            db()->prepare('INSERT INTO fat_dispositivos_movel (nome, identificador) VALUES (?,?)')->execute([$nome, $id]);
            $ok = 'Dispositivo registado.';
        }
        if ($action === 'toggle_device') {
            $did = (int) ($_POST['device_id'] ?? 0);
            $ativo = !empty($_POST['ativo']) ? 1 : 0;
            db()->prepare('UPDATE fat_dispositivos_movel SET ativo=? WHERE id=?')->execute([$ativo, $did]);
            $ok = 'Dispositivo actualizado.';
        }
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

$emp = fat_empresa();
$devices = db()->query('SELECT * FROM fat_dispositivos_movel ORDER BY id DESC')->fetchAll();

require __DIR__ . '/../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endif; ?>
<p style="font-size:.9rem;color:#6b7280">Requisito AGT n.º 18: registo de terminais móveis. Na emissão, seleccione o dispositivo em documentos de conferência/venda móvel (<code>emissao_movel</code>).</p>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_empresa">
<label><input type="checkbox" name="agt_mobilidade_ativa" value="1" <?= !empty($emp['agt_mobilidade_ativa']) ? 'checked' : '' ?>> Activar emissão móvel certificada</label>
<button class="btn btn-outline btn-sm" type="submit" style="margin-left:12px">Guardar</button>
</form>
<hr style="margin:20px 0;border:0;border-top:1px solid #e5e7eb">
<form method="post" class="form-grid"><?= csrf_field() ?><input type="hidden" name="action" value="add_device">
<div class="form-group"><label>Nome terminal</label><input class="form-control" name="nome" required></div>
<div class="form-group"><label>Identificador único</label><input class="form-control" name="identificador" required placeholder="UUID ou n.º série"></div>
<div class="form-group" style="align-self:end"><button class="btn btn-primary" type="submit">Adicionar</button></div>
</form>
</div></div>
<div class="card" style="margin-top:16px"><div class="card-body table-wrap">
<table><thead><tr><th>Nome</th><th>ID</th><th>Activo</th><th></th></tr></thead><tbody>
<?php foreach ($devices as $d): ?>
<tr><td><?= e($d['nome']) ?></td><td><code><?= e($d['identificador']) ?></code></td><td><?= (int)$d['ativo'] ? 'Sim' : 'Não' ?></td>
<td><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_device"><input type="hidden" name="device_id" value="<?= (int)$d['id'] ?>">
<input type="hidden" name="ativo" value="<?= (int)$d['ativo'] ? '0' : '1' ?>"><button class="btn btn-sm btn-outline" type="submit"><?= (int)$d['ativo'] ? 'Desactivar' : 'Activar' ?></button></form></td></tr>
<?php endforeach; ?>
</tbody></table>
</div></div>
<div class="form-actions" style="margin-top:16px"><a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Voltar</a></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
