<?php
/**
 * Copia anexos AGT para a Área de Trabalho (Windows).
 */
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Exportar anexos para Ambiente de Trabalho';
$current = 'fat-cert';
$msg = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    try {
        $desktop = null;
        if (PHP_OS_FAMILY === 'Windows') {
            $desktop = getenv('USERPROFILE') . '\\Desktop';
            if (!is_dir($desktop)) {
                $desktop = getenv('OneDrive') . '\\Desktop';
            }
        }
        if (!$desktop || !is_dir($desktop)) {
            throw new RuntimeException('Área de Trabalho não encontrada neste sistema.');
        }
        $folder = $desktop . '\\Anexos_AGT_INFORMATIZA';
        if (!is_dir($folder)) {
            mkdir($folder, 0755, true);
        }

        if (!is_file(fat_agt_cert_public_path())) {
            fat_agt_preparar_anexo_chave_publica();
        }
        if (!is_file(fat_agt_cert_saft_path())) {
            $latest = glob(__DIR__ . '/../../storage/saft/SAFT_AO_*.xml') ?: [];
            if ($latest) {
                usort($latest, static fn($a, $b) => filemtime($b) <=> filemtime($a));
                copy($latest[0], fat_agt_cert_saft_path());
            } else {
                throw new RuntimeException('Gere primeiro o SAF-T em Certificação AGT.');
            }
        }

        $chaveSrc = fat_agt_cert_public_path();
        if (!is_file($chaveSrc)) {
            $chaveSrc = fat_keys_dir() . '/public.pem';
        }
        $saftSrc = fat_agt_cert_saft_path();

        $chaveDst = $folder . '\\' . fat_agt_cert_public_filename();
        $saftDst = $folder . '\\' . fat_agt_cert_saft_filename();

        if (!copy($chaveSrc, $chaveDst)) {
            throw new RuntimeException('Falha ao copiar a chave pública.');
        }
        if (!copy($saftSrc, $saftDst)) {
            throw new RuntimeException('Falha ao copiar o SAF-T.');
        }

        $msg = $folder;
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

require __DIR__ . '/../includes/header.php';
?>
<div class="card"><div class="card-body">
    <h2>Exportar para Ambiente de Trabalho</h2>
    <p style="font-size:.9rem;color:#6b7280">Cria a pasta <strong>Anexos_AGT_INFORMATIZA</strong> no Ambiente de Trabalho com:</p>
    <ul><li><code>Chave Publica.pem</code></li><li><code>Ficheiro SAF-T.xml</code></li></ul>
    <?php if ($msg): ?>
        <div class="alert alert-success">Ficheiros copiados para:<br><strong><?= e($msg) ?></strong></div>
        <?php if (PHP_OS_FAMILY === 'Windows'): ?>
        <p style="font-size:.85rem">Abra o Explorador de Ficheiros → Ambiente de Trabalho → pasta <strong>Anexos_AGT_INFORMATIZA</strong>.</p>
        <?php endif; ?>
    <?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
    <form method="post"><?= csrf_field() ?>
        <button class="btn btn-primary" type="submit"><i class="fas fa-desktop"></i> Copiar para Ambiente de Trabalho</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/certificacao.php') ?>">Voltar</a>
    </form>
</div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
