<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$tipo = strtoupper(trim($_GET['tipo'] ?? 'FT'));
$modoServico = ($_GET['modo'] ?? $_POST['modo'] ?? '') === 'servico';
$tiposPermitidos = ['FT', 'FR', 'NC', 'ND', 'FA', 'OR', 'GT', 'GR', 'GD', 'GA'];
if (!in_array($tipo, $tiposPermitidos, true)) {
    $tipo = 'FT';
}
$isMovimento = function_exists('fat_agt_is_movement_type') && fat_agt_is_movement_type($tipo);

$pageTitle = $modoServico ? 'Prestar serviço' : 'Novo ' . fat_tipo_label($tipo);
$current = $modoServico && $tipo === 'FT' ? 'fat-servico' : 'fat-docs';
$errors = [];
$origem = null;
$origemLinhas = [];
if ($tipo === 'NC' && (int) ($_GET['origem'] ?? 0) > 0) {
    $origemStmt = db()->prepare("SELECT * FROM fat_documentos WHERE id=? AND tipo IN ('FT','FR') AND estado IN ('emitido','anulado')");
    $origemStmt->execute([(int) $_GET['origem']]);
    $origem = $origemStmt->fetch() ?: null;
    if ($origem) {
        $origemLinesStmt = db()->prepare('SELECT * FROM fat_linhas WHERE documento_id=? ORDER BY linha');
        $origemLinesStmt->execute([$origem['id']]);
        $origemLinhas = $origemLinesStmt->fetchAll();
    }
}
$clientes = db()->query('SELECT id, nome, nif FROM fat_clientes WHERE ativo=1 ORDER BY nome')->fetchAll();
$produtos = db()->query($modoServico
    ? "SELECT * FROM fat_produtos WHERE ativo=1 AND tipo='servico' ORDER BY descricao"
    : 'SELECT * FROM fat_produtos WHERE ativo=1 ORDER BY descricao')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $tipo = strtoupper(trim($_POST['tipo'] ?? $tipo));
    $modoServico = ($_POST['modo'] ?? '') === 'servico';
    $clienteId = (int) ($_POST['cliente_id'] ?? ($origem['cliente_id'] ?? 0));
    $dataDoc = trim($_POST['data_documento'] ?? date('Y-m-d'));
    $localPrestacao = trim($_POST['local_prestacao'] ?? '');
    $obs = trim($_POST['observacoes'] ?? '');
    $origemId = (int) ($_POST['documento_origem_id'] ?? ($origem['id'] ?? 0)) ?: null;

    $codigos = $_POST['linha_codigo'] ?? [];
    $descs = $_POST['linha_desc'] ?? [];
    $qtys = $_POST['linha_qty'] ?? [];
    $precos = $_POST['linha_preco'] ?? [];
    $unidades = $_POST['linha_unidade'] ?? [];
    $descontos = $_POST['linha_desconto'] ?? [];
    $ivas = $_POST['linha_iva'] ?? [];
    $prodIds = $_POST['linha_produto_id'] ?? [];

    $cli = null;
    if ($clienteId) {
        $s = db()->prepare('SELECT * FROM fat_clientes WHERE id=?');
        $s->execute([$clienteId]);
        $cli = $s->fetch();
    }
    if (!$cli) {
        $errors[] = 'Seleccione um cliente.';
    }
    if (!in_array($tipo, $tiposPermitidos, true)) {
        $errors[] = 'Tipo inválido.';
    }
    $isMovimento = function_exists('fat_agt_is_movement_type') && fat_agt_is_movement_type($tipo);
    $shipFrom = trim($_POST['ship_from_morada'] ?? '');
    $shipTo = trim($_POST['ship_to_morada'] ?? '');
    $whFrom = trim($_POST['warehouse_from'] ?? '');
    $whTo = trim($_POST['warehouse_to'] ?? '');
    $movStart = trim($_POST['movement_start'] ?? '') ?: null;
    $movEnd = trim($_POST['movement_end'] ?? '') ?: null;
    if ($tipo === 'NC' && !$origemId) {
        $errors[] = 'Indique a factura de origem da nota de crédito.';
    }
    if ($origemId) {
        $origemStmt = db()->prepare("SELECT * FROM fat_documentos WHERE id=? AND tipo IN ('FT','FR') AND estado IN ('emitido','anulado')");
        $origemStmt->execute([$origemId]);
        $origem = $origemStmt->fetch();
        if (!$origem || (int) $origem['cliente_id'] !== (int) $clienteId) {
            $errors[] = 'A factura de origem não existe, não é válida ou pertence a outro cliente.';
        }
    }

    $linhas = [];
    $n = max(count($descs), count($codigos));
    for ($i = 0; $i < $n; $i++) {
        $desc = trim($descs[$i] ?? '');
        if ($desc === '') {
            continue;
        }
        $qty = (float) str_replace(',', '.', $qtys[$i] ?? '1');
        $preco = (float) str_replace(',', '.', $precos[$i] ?? '0');
        $unidade = strtoupper(trim($unidades[$i] ?? 'UN')) ?: 'UN';
        $desconto = (float) str_replace(',', '.', $descontos[$i] ?? '0');
        $taxa = (float) str_replace(',', '.', $ivas[$i] ?? '14');
        if ($qty <= 0 || $preco < 0 || $desconto < 0 || $desconto > 100 || !in_array($taxa, [0.0, 5.0, 7.0, 14.0], true)) {
            $errors[] = 'Quantidade, preço, desconto ou taxa de IVA inválidos na linha ' . ($i + 1) . '.';
            continue;
        }
        $calc = fat_calc_linha($qty, $preco, $desconto, $taxa);
        $pid = (int) ($prodIds[$i] ?? 0) ?: null;
        $isencao = null;
        if ($pid) {
            $ps = db()->prepare('SELECT codigo_isencao FROM fat_produtos WHERE id=?');
            $ps->execute([$pid]);
            $isencao = $ps->fetchColumn() ?: null;
        }
        if (!$isMovimento && $taxa == 0.0 && !$isencao) {
            $errors[] = 'Linha ' . ($i + 1) . ': IVA 0% exige código de isenção no produto/serviço (Anexo 6.4 AGT).';
            continue;
        }
        $linhas[] = [
            'produto_id' => $pid,
            'codigo' => trim($codigos[$i] ?? '') ?: null,
            'descricao' => $desc,
            'quantidade' => $qty,
            'unidade' => $unidade,
            'preco_unitario' => $preco,
            'desconto_pct' => $desconto,
            'taxa_iva' => $taxa,
            'codigo_isencao' => $isencao,
            'total_liquido' => $calc['total_liquido'],
            'total_iva' => $calc['total_iva'],
            'total_linha' => $calc['total_linha'],
        ];
    }
    if (!$linhas) {
        $errors[] = 'Adicione pelo menos uma linha.';
    }

    if (!$errors) {
        $pdo = db();
        $docId = 0;
        $pdo->beginTransaction();
        try {
            $sub = array_sum(array_column($linhas, 'total_liquido'));
            $iva = array_sum(array_column($linhas, 'total_iva'));
            $tot = array_sum(array_column($linhas, 'total_linha'));
            $pdo->prepare("INSERT INTO fat_documentos
                (tipo, serie, numero, numero_completo, cliente_id, cliente_nome, cliente_nif, cliente_morada, local_prestacao,
                 data_documento, data_sistema, estado, documento_origem_id, subtotal, total_iva, total, observacoes,
                 ship_from_morada, ship_to_morada, warehouse_from, warehouse_to, movement_start, movement_end, criado_por)
                VALUES (?,?,NULL,'RASCUNHO',?,?,?,?,?,?,?, 'rascunho', ?,?,?,?,?, ?,?,?, ?,?,?,?)")
                ->execute([
                    $tipo, 'A', $cli['id'], $cli['nome'], $cli['nif'], $cli['morada'],
                    $localPrestacao ?: null, $dataDoc, date('Y-m-d H:i:s'), $origemId, $sub, $iva, $tot, $obs,
                    $shipFrom ?: null, $shipTo ?: null, $whFrom ?: null, $whTo ?: null, $movStart, $movEnd,
                    current_user()['id'],
                ]);
            $docId = (int) $pdo->lastInsertId();
            $ins = $pdo->prepare('INSERT INTO fat_linhas
                (documento_id, produto_id, linha, codigo, descricao, quantidade, unidade, preco_unitario, desconto_pct, taxa_iva, codigo_isencao, total_liquido, total_iva, total_linha)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $linhaN = 1;
            foreach ($linhas as $l) {
                $ins->execute([
                    $docId, $l['produto_id'], $linhaN++, $l['codigo'], $l['descricao'],
                    $l['quantidade'], $l['unidade'], $l['preco_unitario'], $l['desconto_pct'], $l['taxa_iva'], $l['codigo_isencao'] ?? null,
                    $l['total_liquido'], $l['total_iva'], $l['total_linha'],
                ]);
            }
            $pdo->commit();
            $emitido = fat_emitir_documento($docId, (int) current_user()['id']);
            flash('success', 'Documento emitido com sucesso: ' . $emitido['numero_completo']);
            redirect('/admin/facturacao/documentos/ver.php?id=' . $docId);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($docId > 0) {
                db()->prepare("DELETE FROM fat_documentos WHERE id=? AND estado='rascunho'")->execute([$docId]);
            }
            $errors[] = 'Erro ao guardar: ' . $e->getMessage();
        }
    }
}

    $produtosJson = array_map(static fn($p) => [
    'id' => (int) $p['id'],
    'codigo' => $p['codigo'],
    'tipo' => $p['tipo'] ?? 'produto',
    'descricao' => $p['descricao'],
    'unidade' => $p['unidade'],
    'preco' => (float) $p['preco'],
    'taxa_iva' => (float) $p['taxa_iva'],
], $produtos);
$origemLinhasJson = array_map(static fn($l) => [
    'codigo' => $l['codigo'], 'descricao' => $l['descricao'], 'qty' => $l['quantidade'],
    'preco' => $l['preco_unitario'], 'unidade' => $l['unidade'] ?? 'UN', 'desconto' => $l['desconto_pct'] ?? 0, 'iva' => $l['taxa_iva'],
], $origemLinhas);

require __DIR__ . '/../../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" id="fatForm"><?= csrf_field() ?>
    <input type="hidden" name="tipo" value="<?= e($tipo) ?>"><input type="hidden" name="modo" value="<?= $modoServico ? 'servico' : '' ?>">
    <div class="form-grid">
        <div class="form-group"><label>Tipo</label><input class="form-control" value="<?= e($modoServico ? 'Prestação de serviço' : fat_tipo_label($tipo)) ?>" disabled></div>
        <div class="form-group"><label>Data</label><input class="form-control" type="date" name="data_documento" value="<?= e($_POST['data_documento'] ?? date('Y-m-d')) ?>" required></div>
        <div class="form-group"><label>Cliente *</label>
            <select name="cliente_id" required>
                <option value="">— seleccionar —</option>
                <?php foreach ($clientes as $c): ?>
                    <option value="<?= (int)$c['id'] ?>" <?= ((int)($_POST['cliente_id'] ?? ($origem['cliente_id'] ?? 0)) === (int)$c['id']) ? 'selected' : '' ?>><?= e($c['nome']) ?> (<?= e($c['nif']) ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><label>Local de prestação do serviço</label><input class="form-control" name="local_prestacao" value="<?= e($_POST['local_prestacao'] ?? '') ?>" placeholder="Morada ou local onde o serviço será realizado"></div>
        <?php if ($isMovimento): ?>
        <div class="form-group"><label>Morada carga (ShipFrom)</label><input class="form-control" name="ship_from_morada" value="<?= e($_POST['ship_from_morada'] ?? '') ?>"></div>
        <div class="form-group"><label>Morada descarga (ShipTo)</label><input class="form-control" name="ship_to_morada" value="<?= e($_POST['ship_to_morada'] ?? '') ?>"></div>
        <div class="form-group"><label>Armazém origem (WarehouseID)</label><input class="form-control" name="warehouse_from" value="<?= e($_POST['warehouse_from'] ?? '') ?>"></div>
        <div class="form-group"><label>Armazém destino</label><input class="form-control" name="warehouse_to" value="<?= e($_POST['warehouse_to'] ?? '') ?>"></div>
        <div class="form-group"><label>Início transporte</label><input class="form-control" type="datetime-local" name="movement_start" value="<?= e($_POST['movement_start'] ?? '') ?>"></div>
        <div class="form-group"><label>Fim transporte</label><input class="form-control" type="datetime-local" name="movement_end" value="<?= e($_POST['movement_end'] ?? '') ?>"></div>
        <?php endif; ?>
        <?php if ($tipo === 'NC'): ?>
        <div class="form-group"><label>Documento origem</label><input class="form-control" name="documento_origem_id" value="<?= e($_POST['documento_origem_id'] ?? ($origem['id'] ?? '')) ?>" placeholder="ID da factura a rectificar" required></div>
        <?php endif; ?>
    </div>
    <div class="form-group"><label>Observações</label><textarea name="observacoes"><?= e($_POST['observacoes'] ?? '') ?></textarea></div>

    <h3 style="margin:18px 0 10px"><?= $modoServico ? 'Serviço prestado' : 'Linhas' ?></h3>
    <div class="table-wrap">
        <table id="linhasTable">
            <thead><tr><th>Item / serviço</th><th>Código</th><th>Descrição</th><th>Unid.</th><th>Qtd</th><th>Preço unit.</th><th>Desc. %</th><th>IVA %</th><th></th></tr></thead>
            <tbody id="linhasBody"></tbody>
        </table>
    </div>
    <button type="button" class="btn btn-outline" id="addLine" style="margin-top:10px"><i class="fas fa-plus"></i> Linha</button>

    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-file-circle-check"></i> Emitir documento</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/index.php') ?>">Cancelar</a>
    </div>
</form>
</div></div>
<script>
const PRODUTOS = <?= json_encode($produtosJson, JSON_UNESCAPED_UNICODE) ?>;
const body = document.getElementById('linhasBody');
const ORIGEM_LINHAS = <?= json_encode($origemLinhasJson, JSON_UNESCAPED_UNICODE) ?>;
function addRow(prefill) {
  const tr = document.createElement('tr');
    const opts = PRODUTOS.map(p => `<option value="${p.id}" data-codigo="${p.codigo}" data-desc="${p.descricao.replace(/"/g,'&quot;')}" data-unidade="${p.unidade}" data-preco="${p.preco}" data-iva="${p.taxa_iva}">${p.tipo === 'servico' ? 'Serviço' : 'Produto'} · ${p.codigo} — ${p.descricao}</option>`).join('');
  tr.innerHTML = `
    <td><select name="linha_produto_id[]" class="prod-sel"><option value="">Manual</option>${opts}</select></td>
    <td><input class="form-control" name="linha_codigo[]" value="${prefill?.codigo||''}"></td>
    <td><input class="form-control" name="linha_desc[]" required value="${prefill?.descricao||''}"></td>
    <td><input class="form-control" name="linha_unidade[]" value="${prefill?.unidade||'UN'}" style="width:70px"></td>
    <td><input class="form-control" name="linha_qty[]" value="${prefill?.qty||'1'}" style="width:80px"></td>
    <td><input class="form-control" name="linha_preco[]" value="${prefill?.preco||'0'}" style="width:110px"></td>
    <td><input class="form-control" name="linha_desconto[]" value="${prefill?.desconto||'0'}" style="width:75px"></td>
    <td><input class="form-control" name="linha_iva[]" value="${prefill?.iva||'14'}" style="width:70px"></td>
    <td><button type="button" class="btn btn-sm btn-danger rm">×</button></td>`;
  body.appendChild(tr);
  tr.querySelector('.prod-sel').addEventListener('change', function() {
    const o = this.selectedOptions[0];
    if (!o || !o.value) return;
    tr.querySelector('[name="linha_codigo[]"]').value = o.dataset.codigo;
    tr.querySelector('[name="linha_desc[]"]').value = o.dataset.desc;
    tr.querySelector('[name="linha_unidade[]"]').value = o.dataset.unidade;
    tr.querySelector('[name="linha_preco[]"]').value = o.dataset.preco;
    tr.querySelector('[name="linha_iva[]"]').value = o.dataset.iva;
  });
  tr.querySelector('.rm').addEventListener('click', () => tr.remove());
}
document.getElementById('addLine').addEventListener('click', () => addRow());
if (ORIGEM_LINHAS.length) ORIGEM_LINHAS.forEach(line => addRow(line));
else addRow();
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
