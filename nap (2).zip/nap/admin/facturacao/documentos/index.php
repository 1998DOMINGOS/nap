<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Documentos';
$current = 'fat-docs';
$filtro = $_GET['estado'] ?? '';
$sql = 'SELECT * FROM fat_documentos WHERE 1=1';
$params = [];
if (in_array($filtro, ['rascunho', 'emitido', 'anulado'], true)) {
    $sql .= ' AND estado=?';
    $params[] = $filtro;
}
$sql .= ' ORDER BY id DESC LIMIT 200';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

require __DIR__ . '/../../includes/header.php';
?>
<div class="toolbar">
    <p class="subtitle" style="margin:0"><a href="<?= url('/admin/facturacao/index.php') ?>">Facturação</a> / Documentos</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-primary" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=FT') ?>"><i class="fas fa-plus"></i> Factura</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=FR') ?>">FR</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=NC') ?>">NC</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=ND') ?>">ND</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=FA') ?>">Adiantamento</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=OR') ?>">Proposta orçamental (OR)</a>
    </div>
</div>
<div style="margin-bottom:12px;display:flex;gap:8px">
    <a class="btn btn-sm <?= $filtro===''?'btn-primary':'btn-outline' ?>" href="<?= url('/admin/facturacao/documentos/index.php') ?>">Todos</a>
    <a class="btn btn-sm <?= $filtro==='rascunho'?'btn-primary':'btn-outline' ?>" href="?estado=rascunho">Rascunhos</a>
    <a class="btn btn-sm <?= $filtro==='emitido'?'btn-primary':'btn-outline' ?>" href="?estado=emitido">Emitidos</a>
    <a class="btn btn-sm <?= $filtro==='anulado'?'btn-primary':'btn-outline' ?>" href="?estado=anulado">Anulados</a>
</div>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>Documento</th><th>Cliente</th><th>Data</th><th>Total</th><th>Estado</th><th></th></tr></thead>
<tbody>
<?php if (!$items): ?><tr><td colspan="6" class="empty">Sem documentos.</td></tr>
<?php else: foreach ($items as $d): ?>
<tr>
    <td><strong><?= e($d['numero_completo']) ?></strong><div style="font-size:.8rem;color:#6b7280"><?= e(fat_tipo_label($d['tipo'])) ?></div></td>
    <td><?= e($d['cliente_nome']) ?><div style="font-size:.8rem">NIF <?= e($d['cliente_nif']) ?></div></td>
    <td><?= e(format_date($d['data_documento'], 'd/m/Y')) ?></td>
    <td><?= e(fat_format_money($d['total'])) ?></td>
    <td><?= e($d['estado']) ?><?php if ($d['hash_control']): ?> · <code><?= e($d['hash_control']) ?></code><?php endif; ?></td>
    <td class="actions"><a class="btn btn-sm btn-outline" href="<?= url('/admin/facturacao/documentos/ver.php?id='.$d['id']) ?>">Abrir</a></td>
</tr>
<?php endforeach; endif; ?>
</tbody></table></div></div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
