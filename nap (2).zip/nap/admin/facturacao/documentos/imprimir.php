<?php
/**
 * Impressão térmica 80mm / PDF via browser.
 */
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM fat_documentos WHERE id=?');
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc || $doc['estado'] === 'rascunho') {
    http_response_code(404);
    echo 'Documento não disponível para impressão.';
    exit;
}

$linhas = db()->prepare('SELECT * FROM fat_linhas WHERE documento_id=? ORDER BY linha');
$linhas->execute([$id]);
$linhas = $linhas->fetchAll();
$descontoTotal = 0.0;
foreach ($linhas as $linha) {
    $descontoTotal += max(0, ((float) $linha['quantidade'] * (float) $linha['preco_unitario']) - (float) $linha['total_liquido']);
}
$pagamentoStmt = db()->prepare('SELECT COALESCE(SUM(valor), 0), GROUP_CONCAT(DISTINCT metodo ORDER BY metodo SEPARATOR ", ") FROM fat_pagamentos WHERE documento_id=?');
$pagamentoStmt->execute([$id]);
[$valorPago, $metodosPagamento] = $pagamentoStmt->fetch(PDO::FETCH_NUM) ?: [0, ''];
$emp = fat_empresa();
$user = current_user();

$logoFs = realpath(__DIR__ . '/../../../imgs/logo-informatiza.svg');
$logoUrl = url('/imgs/logo-informatiza.svg');

$hora = $doc['data_sistema']
    ? date('H:i:s', strtotime($doc['data_sistema']))
    : date('H:i:s');

$ivaPct = 0.0;
if ((float) $doc['subtotal'] > 0) {
    $ivaPct = round(((float) $doc['total_iva'] / (float) $doc['subtotal']) * 100, 2);
}

$legendaAgt = fat_legenda_programa_validado_agt($doc['hash'] ?? '', (string) ($doc['tipo'] ?? 'FT'), $emp ?: []);
$avisoNaoFactura = function_exists('fat_agt_aviso_nao_factura') ? fat_agt_aviso_nao_factura((string) ($doc['tipo'] ?? '')) : '';
$formacaoDoc = !empty($doc['modo_formacao']) || (function_exists('fat_agt_modo_formacao_ativo') && fat_agt_modo_formacao_ativo());
$bannerDuplicado = !empty($doc['doc_duplicado_ref']) || !empty($doc['copia_original']);
$refDup = trim((string) ($doc['doc_duplicado_ref'] ?? ''));
$integracaoExterna = function_exists('fat_agt_source_billing_for_doc') && fat_agt_source_billing_for_doc($doc) === 'I';
$avisoIntegracao = $integracaoExterna && trim((string) ($doc['hash_externo'] ?? '')) !== '';
$formato = ($_GET['formato'] ?? 'termico') === 'a4' ? 'a4' : 'termico';
$isA4 = $formato === 'a4';
$qrDataUri = '';
if (is_file(__DIR__ . '/../../../vendor/autoload.php')) {
    require_once __DIR__ . '/../../../vendor/autoload.php';
    $qrData = fat_fatura_qr_content($doc, $emp ?: []);
    $qrSize = $isA4 ? 240 : 180;
    $qrDataUri = (new \Endroid\QrCode\Builder\Builder(writer: new \Endroid\QrCode\Writer\SvgWriter(), data: $qrData, size: $qrSize, margin: 8))->build()->getDataUri();
}
$formatQuantity = static function (float $quantity): string {
    return rtrim(rtrim(number_format($quantity, 3, ',', '.'), '0'), ',');
};
$numberWords = static function (int $number) use (&$numberWords): string {
    $ones = ['', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez', 'onze', 'doze', 'treze', 'catorze', 'quinze', 'dezasseis', 'dezassete', 'dezoito', 'dezanove'];
    $tens = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
    $hundreds = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
    if ($number < 20) return $ones[$number];
    if ($number < 100) return $tens[intdiv($number, 10)] . ($number % 10 ? ' e ' . $ones[$number % 10] : '');
    if ($number === 100) return 'cem';
    if ($number < 1000) return $hundreds[intdiv($number, 100)] . ($number % 100 ? ' e ' . $numberWords($number % 100) : '');
    if ($number < 1000000) return $numberWords(intdiv($number, 1000)) . ' mil' . ($number % 1000 ? ' e ' . $numberWords($number % 1000) : '');
    if ($number < 1000000000) return $numberWords(intdiv($number, 1000000)) . ' milhão' . (intdiv($number, 1000000) > 1 ? 'ões' : '') . ($number % 1000000 ? ' e ' . $numberWords($number % 1000000) : '');
    return (string) $number;
};
$totalCents = (int) round((float) $doc['total'] * 100);
$totalWords = $numberWords(intdiv($totalCents, 100)) . ' kwanzas';
if ($totalCents % 100) $totalWords .= ' e ' . $numberWords($totalCents % 100) . ' cêntimos';
$goodsTotal = 0.0;
$servicesTotal = 0.0;
foreach ($linhas as $invoiceLine) {
    if (!empty($invoiceLine['produto_id'])) $goodsTotal += (float) $invoiceLine['total_liquido'];
    else $servicesTotal += (float) $invoiceLine['total_liquido'];
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title><?= e(fat_tipo_label($doc['tipo'])) ?> <?= e($doc['numero_completo']) ?> — <?= $isA4 ? 'A4' : 'Térmico' ?></title>
<style>
    @page {
        size: <?= $isA4 ? 'A4' : '80mm auto' ?>;
        margin: <?= $isA4 ? '12mm' : '0' ?>;
    }
    body {
        font-family: <?= $isA4 ? "Arial, Helvetica, sans-serif" : "'Courier New', Courier, monospace" ?>;
        font-size: <?= $isA4 ? '12px' : '14px' ?>;
        color: #000;
        margin: 0 auto;
        padding: <?= $isA4 ? '0' : '5px' ?>;
        width: <?= $isA4 ? '190mm' : '80mm' ?>;
        min-height: <?= $isA4 ? '267mm' : '250mm' ?>;
        background: #fff;
    }
    <?php if ($isA4): ?>
    body { background: #f2f2f2; padding: 30px; font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
    .invoice { width: 210mm; min-height: 297mm; margin: auto; background: #fff; padding: 18mm; box-shadow: 0 0 10px rgba(0,0,0,.12); }
    <?php endif; ?>
    .center { text-align: center; }
    .right { text-align: right; }
    .bold { font-weight: bold; }
    .a4-header { display: <?= $isA4 ? 'flex' : 'none' ?>; }
    .a4-header { justify-content: space-between; align-items: flex-start; gap: 0; border-bottom: 2px solid #222; padding: 0 0 18px; }
    .a4-header .company { flex: 1; text-align: left; padding: 0 9px 0 0; }
    .a4-header .document-meta { min-width: 68mm; text-align: right; padding: 6px 0 0 14px; }
    .invoice-title-a4 { font-size: 30px; letter-spacing: 1px; }
    .invoice-number-a4 { margin-top: 10px; font-size: 14px; font-weight: bold; }
    .a4-parties { display: grid; grid-template-columns: 1fr 1fr; border: 1px solid #222; border-radius: 4px; padding: 0; gap: 0; margin-top: 25px; }
    .a4-parties > div { padding: 14px; min-height: 35mm; }
    .a4-parties > div + div { border-left: 1px solid #222; text-align: right; }
    .a4-party-inline { line-height: 1.8; font-size: 11px; overflow-wrap: anywhere; }
    .a4-client-meta { display: none; }
    .a4-label { color: #1d4ed8; font-weight: bold; }
    .a4-summary { justify-content: space-between; align-items: flex-start; gap: 25px; margin-top: 20px; }
    .a4-fiscal-tables { display: flex; gap: 25px; margin-top: 22px; }
    .a4-fiscal-tables > div { flex: 1; }
    .a4-fiscal-tables h3 { font-size: 13px; margin: 0 0 8px; }
    .a4-fiscal-tables table { margin-top: 0; }
    .a4-fiscal-tables th, .a4-fiscal-tables td { padding: 7px 8px; }
    .a4-placement { margin-top: 22px; font-size: 11px; line-height: 1.7; }
    .a4-tax-summary { flex: 1; }
    .a4-total-box { min-width: 70mm; }
    .a4-total-box div { display: flex; justify-content: space-between; border-bottom: 1px solid #aaa; padding: 4px 0; }
    .a4-total-box .grand-total { font-size: 16px; font-weight: bold; border-top: 2px solid #111; }
    .a4-footer { border-top: 1px solid #999; margin-top: 22px; padding-top: 12px; font-size: 10px; }
    .a4-bottom { display: <?= $isA4 ? 'flex' : 'none' ?>; justify-content: space-between; align-items: flex-end; gap: 20px; margin-top: 18px; }
    .a4-qr { width: 38mm; text-align: center; font-size: 9px; }
    .a4-qr img { display: block; width: 34mm; height: 34mm; margin: 0 auto 4px; }
    .page-number { margin-top: 10px; text-align: left; color: #555; }
    .a4-payment, .a4-notes { margin-top: 22px; }
    .a4-compliance { margin-top: 18px; padding: 9px 0; font-size: 10px; line-height: 1.6; border-top: 1px solid #ddd; }
    .a4-payment h3, .a4-notes h3 { font-size: 13px; border-bottom: 1px solid #222; padding-bottom: 6px; margin-bottom: 8px; }
    .a4-signatures { display: grid; grid-template-columns: 1fr 1fr; gap: 80px; margin-top: 48px; }
    .a4-signature { text-align: center; border-top: 1px solid #222; padding-top: 8px; }
    .a4-only table th { color: #111; font-weight: bold; background: #d9d9d9; }
    .a4-only table { border: 1px solid #999; }
    .a4-only table th, .a4-only table td { border: 1px solid #bbb; }
    .a4-items { table-layout: fixed; }
    .a4-items th:nth-child(1), .a4-items td:nth-child(1) { width: 46%; }
    .a4-items th:nth-child(2), .a4-items td:nth-child(2) { width: 10%; }
    .a4-items th:nth-child(3), .a4-items td:nth-child(3) { width: 9%; }
    .a4-items th:nth-child(4), .a4-items td:nth-child(4) { width: 15%; }
    .a4-items th:nth-child(5), .a4-items td:nth-child(5) { width: 8%; }
    .a4-items th:nth-child(6), .a4-items td:nth-child(6) { width: 16%; }
    .a4-items th, .a4-items td { border: 1px solid #bbb; }
    .a4-items thead th { color: #1d4ed8; background: #f7f7f7; }
    .a4-items tbody tr:nth-child(even) { background: #fafafa; }
    .a4-items-grid { margin-top: 25px; }
    .a4-items-grid .items-head, .a4-items-grid .item-row { display: grid; grid-template-columns: 8% 40% 8% 18% 12% 14%; align-items: center; }
    .a4-items-grid .items-head { color: #222; background: #222; font-weight: bold; border-bottom: 0; padding: 10px 8px; }
    .a4-items-grid .items-head > div { color: #fff; font-size: 11px; }
    .a4-items-grid .item-row { min-height: 42px; border-bottom: 1px solid #ddd; }
    .a4-items-grid .item-row > div { padding: 10px 8px; }
    .a4-company-logo { max-width: 62mm; max-height: 26mm; object-fit: contain; margin-bottom: 6px; }
    .invoice .line { display: none; }
    .a4-only { display: <?= $isA4 ? 'block' : 'none' ?>; }
    .a4-parties.a4-only { display: <?= $isA4 ? 'grid' : 'none' ?>; }
    .a4-summary.a4-only { display: <?= $isA4 ? 'flex' : 'none' ?>; }
    .a4-bottom.a4-only { display: <?= $isA4 ? 'flex' : 'none' ?>; justify-content: flex-end; }
    .thermal-only { display: <?= $isA4 ? 'none' : 'block' ?>; }
    .big { font-size: <?= $isA4 ? '22px' : '16px' ?>; font-weight: bold; }
    .line { text-align: center; margin: <?= $isA4 ? '12px' : '6px' ?> 0; overflow: hidden; }
    .line::after { content: "<?= $isA4 ? '________________________________________________________________________________' : '--------------------------------' ?>"; display: block; letter-spacing: -1px; }
    table { width: 100%; border-collapse: collapse; margin-top: 6px; }
    th, td { padding: <?= $isA4 ? '7px 5px' : '3px 0' ?>; vertical-align: top; font-size: <?= $isA4 ? '12px' : '13px' ?>; }
    th { text-align: left; }
    img.logo { max-width: <?= $isA4 ? '70mm' : '50mm' ?>; height: auto; margin-bottom: 6px; }
    .cert {
        font-size: 11px;
        text-align: center;
        margin: 4px 0 8px;
        border: 1px solid #000;
        padding: 4px;
        font-weight: bold;
    }
    .hash { word-break: break-all; font-size: 9px; margin-top: 4px; }
    .no-print { margin: 12px auto; width: <?= $isA4 ? '190mm' : '80mm' ?>; font-family: Arial, sans-serif; }
    .no-print button {
        background: #FF6200; color: #fff; border: 0;
        padding: 10px 16px; border-radius: 8px; font-weight: 700; cursor: pointer;
    }
    @media print {
        .no-print { display: none !important; }
        body { margin: 0; width: <?= $isA4 ? '190mm' : '80mm' ?>; }
    }
</style>
</head>
<body>

<div class="no-print">
    <button type="button" onclick="window.print()">Imprimir / Guardar PDF (<?= $isA4 ? 'A4' : 'Térmico' ?>)</button>
    <?php if ($isA4): ?>
        <a href="<?= e(url('/admin/facturacao/documentos/imprimir.php?id=' . $id)) ?>" style="margin-left:10px">Formato térmico</a>
    <?php else: ?>
        <a href="<?= e(url('/admin/facturacao/documentos/imprimir.php?id=' . $id . '&formato=a4')) ?>" style="margin-left:10px">Formato A4</a>
    <?php endif; ?>
    <a href="<?= e(url('/admin/facturacao/documentos/ver.php?id=' . $id)) ?>" style="margin-left:10px">Voltar</a>
</div>

<div class="<?= $isA4 ? 'invoice' : '' ?>">

<?php if ($formacaoDoc): ?><div class="cert" style="background:#fef3c7;border-color:#d97706">Documento emitido para fins de Formação<?php if ($emp): ?> · <?= e($emp['produtor_nome'] ?? '') ?> (<?= e($emp['produtor_nif'] ?? '') ?>)<?php endif; ?></div><?php endif; ?>
<?php if ($avisoNaoFactura !== ''): ?><div class="cert" style="font-size:12px"><?= e($avisoNaoFactura) ?></div><?php endif; ?>
<?php if ($bannerDuplicado): ?><div class="cert" style="background:#fee2e2;border-color:#b91c1c">DUPLICADO / 2.ª via<?= $refDup !== '' ? ' — ref. ' . e($refDup) : '' ?></div><?php endif; ?>
<?php if ($avisoIntegracao): ?><div class="cert" style="font-size:11px">Documento integrado (SourceBilling I) — hash emitido por sistema externo certificado.</div><?php endif; ?>
<?php if (!empty($doc['emissao_movel'])): ?><div class="cert" style="font-size:11px">Emissão em terminal móvel registado.</div><?php endif; ?>

<div class="center thermal-only">
    <?php if ($logoFs): ?>
        <img src="<?= e($logoUrl) ?>" alt="Logo" class="logo">
    <?php endif; ?>
</div>

<div class="a4-header">
    <div class="company">
        <?php if ($logoFs): ?><img src="<?= e($logoUrl) ?>" alt="Logo" class="a4-company-logo a4-only"><?php endif; ?>
        <div class="bold big"><?= e(mb_strtoupper($emp['nome'] ?? APP_NAME)) ?></div>
        <div><?= e($emp['morada'] ?? '—') ?><?= !empty($emp['cidade']) ? ' · ' . e($emp['cidade']) . ' — Angola' : '' ?></div>
        <div>Tel.: <?= e($emp['telefone'] ?? '—') ?><?= !empty($emp['email']) ? ' · ' . e($emp['email']) : '' ?></div>
        <div>NIF: <?= e($emp['nif'] ?: '—') ?></div>
    </div>
    <div class="document-meta">
        <div class="bold invoice-title-a4"><?= e(fat_tipo_label($doc['tipo'])) ?></div>
        <div class="invoice-number-a4">Factura nº <?= e($doc['numero_completo']) ?></div>
        <div>Data de emissão: <?= e(format_date($doc['data_documento'], 'd-m-Y')) ?> <?= e($hora) ?></div>
    </div>
</div>
<div class="a4-parties a4-only">
    <div class="a4-party-inline"><strong><?= e($emp['nome'] ?? '—') ?></strong> · Nº de Contribuinte: <?= e($emp['nif'] ?: '—') ?> · <?= e($emp['morada'] ?: $emp['cidade'] ?: '—') ?> · <?= e($emp['telefone'] ?: '') ?></div>
    <div class="a4-party-inline"><strong><?= e($doc['cliente_nome']) ?></strong> · NIF: <?= e($doc['cliente_nif'] && $doc['cliente_nif'] !== '999999999' ? $doc['cliente_nif'] : 'Consumidor final') ?> · <?= e($doc['cliente_morada'] ?: '—') ?><?= !empty($doc['cliente_telefone']) ? ' · Contacto: ' . e($doc['cliente_telefone']) : '' ?><?php if (!empty($doc['local_prestacao'])): ?><br><strong>Local do serviço:</strong> <?= e($doc['local_prestacao']) ?><?php endif; ?></div>
</div>
<div class="thermal-only center">
    <div class="bold big"><?= e(mb_strtoupper($emp['nome'] ?? APP_NAME)) ?></div>
    Tecnologia que ajuda o país<br>
    NIF: <?= e($emp['nif'] ?: '—') ?><br>
    <?= e($emp['morada'] ?? '—') ?><br>
    <?php if (!empty($emp['cidade'])): ?><?= e($emp['cidade']) ?><br><?php endif; ?>
    Tel: <?= e($emp['telefone'] ?? '—') ?>
    <?php if (!empty($doc['local_prestacao'])): ?><br><strong>Local do serviço:</strong> <?= e($doc['local_prestacao']) ?><?php endif; ?>
</div>

<div class="cert thermal-only">
    <?= e($legendaAgt) ?>
</div>

<div class="line thermal-only"></div>

<div class="thermal-only">
    <span class="bold"><?= e(fat_tipo_label($doc['tipo'])) ?>:</span> <?= e($doc['numero_completo']) ?><br>
    <span class="bold">Data:</span> <?= e(format_date($doc['data_documento'], 'd/m/Y')) ?><br>
    <span class="bold">Hora:</span> <?= e($hora) ?><br>
    <span class="bold"><?= e($doc['cliente_nome']) ?></span><br>
    <span class="bold">NIF:</span> <?= e($doc['cliente_nif'] ?: 'Consumidor Final') ?><br>
    <span class="bold">Endereço:</span> <?= e($doc['cliente_morada'] ?: '—') ?>
</div>

<div class="line"></div>

<div class="bold">Artigos / Serviços:</div>
<?php if ($isA4): ?>
<div class="a4-items-grid a4-only">
    <div class="items-head"><div>Código</div><div>Descrição</div><div class="right">Qtd.</div><div class="right">Preço Unitário</div><div class="right">IVA</div><div class="right">Total</div></div>
    <?php if (!$linhas): ?><div class="item-row"><div>Nenhum artigo</div></div>
    <?php else: foreach ($linhas as $l): ?><div class="item-row"><div><?= e($l['codigo'] ?: '—') ?></div><div><?= e($l['descricao']) ?><?php if ((float) ($l['desconto_pct'] ?? 0) > 0): ?><small> (desc. <?= e(number_format((float) $l['desconto_pct'], 2, ',', '.')) ?>%)</small><?php endif; ?></div><div class="right"><?= e($formatQuantity((float) $l['quantidade'])) ?> <?= e($l['unidade']) ?></div><div class="right"><?= e(number_format((float) $l['preco_unitario'], 2, ',', '.')) ?></div><div class="right"><?= e(number_format((float) $l['taxa_iva'], 0)) ?>%</div><div class="right"><?= e(number_format((float) $l['total_linha'], 2, ',', '.')) ?></div></div><?php endforeach; endif; ?>
</div>
<?php else: ?>
<table>
    <thead>
        <tr>
            <th>Descrição</th>
            <th class="right">Kz</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!$linhas): ?>
        <tr>
            <td colspan="6" class="center">Nenhum artigo</td>
        </tr>
        <?php else: foreach ($linhas as $l): ?>
        <tr>
            <td><?= e($l['descricao']) ?><br><?= e($formatQuantity((float) $l['quantidade'])) ?> x <?= e(number_format((float) $l['preco_unitario'], 2, ',', '.')) ?><?php if ((float) ($l['desconto_pct'] ?? 0) > 0): ?> - desc. <?= e(number_format((float) $l['desconto_pct'], 2, ',', '.')) ?>%<?php endif; ?><?php if ((float) $l['taxa_iva'] > 0): ?> (IVA <?= e(number_format((float) $l['taxa_iva'], 0)) ?>%)<?php endif; ?></td>
            <td class="right"><?= e(number_format((float)$l['total_linha'], 2, ',', '.')) ?></td>
        </tr>
        <?php endforeach; endif; ?>
    </tbody>
</table>
<?php endif; ?>

<div class="a4-fiscal-tables a4-only">
    <div>
        <h3>Totais retidos na fonte ou cativados pelo adquirente</h3>
        <p>(Valores informativos não integrados no total do documento)</p>
        <table><thead><tr><th>Tipo</th><th>Imposto</th><th>Taxa</th><th class="right">Valor</th></tr></thead><tbody><tr><td>—</td><td>—</td><td>0%</td><td class="right">0,00</td></tr></tbody></table>
        <div style="font-weight:bold;margin-top:8px">Totais do documento (valores em Kwanzas)</div>
    </div>
    <div>
        <h3>Totais do documento (Valores em Kwanzas)</h3>
        <table><thead><tr><th>Descrição</th><th class="right">Valor</th></tr></thead><tbody>
            <tr><td>Mercadorias e Bens</td><td class="right"><?= e(number_format($goodsTotal, 2, ',', '.')) ?></td></tr>
            <tr><td>Prestação de Serviços</td><td class="right"><?= e(number_format($servicesTotal, 2, ',', '.')) ?></td></tr>
            <tr><td>IVA</td><td class="right"><?= e(number_format((float) $doc['total_iva'], 2, ',', '.')) ?></td></tr>
            <tr><td>Imposto de Selo (IS)</td><td class="right">0,00</td></tr>
            <tr><td>Imposto Especial ao Consumo (IEC)</td><td class="right">0,00</td></tr>
            <tr><td>Descontos</td><td class="right">0,00</td></tr>
        </tbody></table>
    </div>
</div>

<div class="line"></div>

<div class="right thermal-only">
    <span class="bold">Subtotal:</span> <?= e(number_format((float)$doc['subtotal'], 2, ',', '.')) ?> Kz<br>
    <span class="bold">IVA<?= $ivaPct > 0 ? ' (' . number_format($ivaPct, 0) . '%)' : '' ?>:</span> <?= e(number_format((float)$doc['total_iva'], 2, ',', '.')) ?> Kz<br>
    <span class="bold">TOTAL:</span> <?= e(number_format((float)$doc['total'], 2, ',', '.')) ?> Kz
</div>

<div class="a4-summary a4-only">
    <div class="a4-tax-summary">
        <div class="a4-label">Resumo de impostos</div>
        <table><thead><tr><th>Taxa</th><th>Base de incidência</th><th>Valor IVA</th></tr></thead><tbody><tr><td><?= e(number_format($ivaPct, 0)) ?>%</td><td><?= e(number_format((float) $doc['subtotal'], 2, ',', '.')) ?> Kz</td><td><?= e(number_format((float) $doc['total_iva'], 2, ',', '.')) ?> Kz</td></tr></tbody></table>
    </div>
    <div class="a4-total-box"><table><tbody><tr><td>Total sem impostos</td><td class="right"><?= e(number_format((float)$doc['subtotal'], 2, ',', '.')) ?> Kz</td></tr><tr><td>Valor de impostos</td><td class="right"><?= e(number_format((float)$doc['total_iva'], 2, ',', '.')) ?> Kz</td></tr><tr><td>Valor de descontos</td><td class="right"><?= e(number_format($descontoTotal, 2, ',', '.')) ?> Kz</td></tr><tr class="grand-total"><th>Valor Total do Documento</th><th class="right"><?= e(number_format((float)$doc['total'], 2, ',', '.')) ?> Kz</th></tr></tbody></table></div>
</div>

<div class="a4-compliance a4-only">
    <div><strong>Moeda:</strong> Kz (AOA) · <strong>Local de disponibilização:</strong> <?= e($emp['cidade'] ?: $emp['morada'] ?: 'Angola') ?></div>
    <div><strong>Pagamento antecipado:</strong> <?= (float) $valorPago > 0 ? e(fat_format_money($valorPago) . ($metodosPagamento ? ' · ' . $metodosPagamento : '')) : 'Não registado' ?></div>
    <div><strong>Total por extenso:</strong> <?= e(ucfirst($totalWords)) ?></div>
    <div><strong><?= e($legendaAgt) ?></strong></div>
    <div><strong>Software:</strong> <?= e($emp['software_nome'] ?? 'Sistema de facturação') ?> v<?= e($emp['software_versao'] ?? '1.0.0') ?></div>
    <?php if (!empty($doc['hash'])): ?><div class="hash"><strong>Código hash:</strong> <?= e($doc['hash']) ?></div><?php endif; ?>
</div>

<div class="a4-placement a4-only">
    <div>Os bens/serviços foram colocados à disposição do adquirente em <?= e(format_date($doc['data_documento'], 'd/m/Y')) ?></div>
    <div>Local de prestação de bens/serviços: <?= e($emp['cidade'] ?: $emp['morada'] ?: 'Angola') ?></div>
    <div style="margin-top:14px"><strong>Legendas de Tipos de Serviços e Códigos de Isenção:</strong><br>Sem código de isenção registado</div>
</div>

<?php if (!empty($doc['observacoes'])): ?>
<div class="line thermal-only"></div>
<div class="thermal-only"><span class="bold">Obs.:</span> <?= e($doc['observacoes']) ?></div>
<?php endif; ?>

<div class="line"></div>

<div class="right thermal-only" style="margin-top: 30px;">
    ___________________________<br>
    <span class="bold">Responsável</span>
</div>

<div class="a4-payment a4-only">
    <h3>DADOS PARA PAGAMENTO</h3>
    <div><strong>Banco:</strong> <?= e($emp['banco'] ?: 'Dados bancários não configurados') ?></div>
    <div><strong>Titular:</strong> <?= e($emp['titular_pagamento'] ?: APP_NAME) ?></div>
    <div><strong>IBAN:</strong> <?= e($emp['iban'] ?: 'Dados bancários não configurados') ?></div>
    <?php if (!empty($emp['numero_conta'])): ?><div><strong>Nº de conta:</strong> <?= e($emp['numero_conta']) ?></div><?php endif; ?>
</div>

<?php if (!empty($doc['observacoes'])): ?>
<div class="a4-notes a4-only"><h3>OBSERVAÇÕES</h3><p><?= nl2br(e($doc['observacoes'])) ?></p></div>
<?php endif; ?>

<div class="a4-footer a4-only">
    <div><?= e($emp['morada'] ?: 'Morada não configurada') ?><?= !empty($emp['cidade']) ? ' · ' . e($emp['cidade']) . ' — Angola' : '' ?></div>
    <div>Tel.: <?= e($emp['telefone'] ?: 'Contacto não configurado') ?><?= !empty($emp['email']) ? ' · E-mail: ' . e($emp['email']) : '' ?></div>
    <div><?= e($legendaAgt) ?></div>
    <div><?= e($emp['software_nome'] ?? 'Sistema de facturação') ?> v<?= e($emp['software_versao'] ?? '1.0.0') ?></div>
    <div>Documento emitido electronicamente · Processado por: <?= e($user['nome'] ?? '—') ?></div>
    <div class="page-number">Página: 1</div>
</div>

<?php if ($isA4 && $qrDataUri): ?>
<div class="a4-bottom a4-only"><div></div><div class="a4-qr"><img src="<?= e($qrDataUri) ?>" alt="QR Code da factura"><div>Validar factura</div></div></div>
<?php endif; ?>

<div class="line"></div>

<?php if (!$isA4 && $qrDataUri): ?>
<div class="center thermal-only" style="margin-top:8px">
    <img src="<?= e($qrDataUri) ?>" alt="QR" style="width:42mm;height:42mm">
    <div style="font-size:10px">Validar factura</div>
</div>
<?php endif; ?>

<div class="center thermal-only">
    <span class="bold">Cód. Único:</span> <?= e($doc['numero_completo']) ?><br>
    <div><?= e($legendaAgt) ?></div>
    <div>Gerado por: <?= e($user['nome'] ?? '—') ?></div>
    <div><?= e($emp['software_nome'] ?? 'INFORMATIZA Facturação') ?> v<?= e($emp['software_versao'] ?? '1.0.0') ?></div>
    <div><em><?= e(site_tagline()) ?></em></div>
    <div><?= e($emp['morada'] ?: 'Morada não configurada') ?><?= !empty($emp['cidade']) ? ' · ' . e($emp['cidade']) . ' — Angola' : '' ?></div>
    <div>Tel.: <?= e($emp['telefone'] ?: 'Contacto não configurado') ?><?= !empty($emp['email']) ? ' · E-mail: ' . e($emp['email']) : '' ?></div>
    <div class="page-number">Página: 1</div>
</div>

</body>
</html>
