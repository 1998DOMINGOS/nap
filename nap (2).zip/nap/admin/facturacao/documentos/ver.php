<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM fat_documentos WHERE id=?');
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc) {
    flash('error', 'Documento não encontrado.');
    redirect('/admin/facturacao/documentos/index.php');
}

$linhas = db()->prepare('SELECT * FROM fat_linhas WHERE documento_id=? ORDER BY linha');
$linhas->execute([$id]);
$linhas = $linhas->fetchAll();
$clienteEmail = '';
if (!empty($doc['cliente_id'])) {
    $ce = db()->prepare('SELECT email FROM fat_clientes WHERE id=?');
    $ce->execute([(int) $doc['cliente_id']]);
    $clienteEmail = trim((string) ($ce->fetchColumn() ?: ''));
}
$emp = fat_empresa();
$envioStmt = db()->prepare('SELECT estado, tentativas, resposta, enviado_em, request_id FROM fat_agt_envios WHERE documento_id=?');
$envioStmt->execute([$id]);
$agtEnvio = $envioStmt->fetch() ?: null;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'emitir') {
            fat_emitir_documento($id, (int) current_user()['id'], trim((string) ($_POST['confirm_clock_ok'] ?? '')) ?: null);
            flash('success', 'Documento emitido com hash de segurança.');
            redirect('/admin/facturacao/documentos/ver.php?id=' . $id);
        }
        if ($action === 'eliminar_rascunho') {
            fat_assert_rascunho($doc);
            db()->prepare('DELETE FROM fat_documentos WHERE id=? AND estado=\'rascunho\'')->execute([$id]);
            flash('success', 'Rascunho eliminado.');
            redirect('/admin/facturacao/documentos/index.php');
        }
        if ($action === 'enviar_agt') {
            fat_agt_registar_documento($id, (int) current_user()['id']);
            flash('success', 'Documento submetido à AGT. Consulte o estado na fila AGT.');
            redirect('/admin/facturacao/documentos/ver.php?id=' . $id);
        }
        if ($action === 'reenviar_correcao') {
            fat_agt_registar_documento($id, (int) current_user()['id'], true);
            flash('success', 'Correcção (documentStatus C) submetida à AGT.');
            redirect('/admin/facturacao/documentos/ver.php?id=' . $id);
        }
        if ($action === 'consultar_agt') {
            fat_agt_obter_estado($id, (int) current_user()['id']);
            flash('success', 'Estado AGT actualizado.');
            redirect('/admin/facturacao/documentos/ver.php?id=' . $id);
        }
        if ($action === 'consultar_factura_agt') {
            fat_agt_consultar_factura($id, (int) current_user()['id']);
            flash('success', 'Consulta consultarFactura actualizada.');
            redirect('/admin/facturacao/documentos/ver.php?id=' . $id);
        }
        if ($action === 'enviar_email') {
            if ($doc['estado'] !== 'emitido') {
                throw new RuntimeException('Emita o documento antes de enviar por email.');
            }
            $email = trim($_POST['email'] ?? '');
            $msg = trim($_POST['mensagem'] ?? '');
            fat_enviar_documento_email($id, $email, $msg, (int) current_user()['id']);
            flash('success', 'Documento enviado por email para ' . $email);
            redirect('/admin/facturacao/documentos/ver.php?id=' . $id);
        }
        if ($action === 'converter_ft' || $action === 'converter_fr') {
            $dest = $action === 'converter_fr' ? 'FR' : 'FT';
            $novoId = fat_copiar_or_para_factura($id, $dest, (int) current_user()['id']);
            flash('success', 'Rascunho de ' . fat_tipo_label($dest) . ' criado a partir da proposta. Revise e emita.');
            redirect('/admin/facturacao/documentos/ver.php?id=' . $novoId);
        }
        if ($action === 'anular') {
            if ($doc['estado'] !== 'emitido') {
                throw new RuntimeException('Só documentos emitidos podem ser anulados.');
            }
            if (function_exists('fat_agt_validar_anulacao')) {
                fat_agt_validar_anulacao($doc);
            }
            $motivo = trim($_POST['motivo'] ?? '');
            if ($motivo === '') {
                throw new RuntimeException('Indique o motivo da anulação.');
            }
            $agtValidado = ($doc['fe_agt_estado'] ?? '') === 'validado' || ($doc['fe_validation_status'] ?? '') === 'V';
            if ($agtValidado && (fat_agt_api_configured() || fat_agt_simular())) {
                fat_agt_anular_factura($id, $motivo, (int) current_user()['id']);
                flash('success', 'Documento anulado na AGT (anularFactura) e localmente.');
            } else {
                db()->prepare("UPDATE fat_documentos SET estado='anulado', motivo_anulacao=? WHERE id=? AND estado='emitido'")
                    ->execute([$motivo, $id]);
                fat_auditar_documento($id, 'anulacao', (int) current_user()['id'], 'emitido', 'anulado', $doc['hash']);
                if (function_exists('cont_reverter_venda')) {
                    cont_reverter_venda($id, (int) current_user()['id']);
                }
                flash('success', 'Documento marcado como anulado localmente. Se já estava na AGT, use anulação após validação ou emita NC.');
            }
            redirect('/admin/facturacao/documentos/ver.php?id=' . $id);
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
        $stmt->execute([$id]);
        $doc = $stmt->fetch();
    }
}

$pageTitle = $doc['numero_completo'];
$current = 'fat-docs';
require __DIR__ . '/../../includes/header.php';
?>
<div class="toolbar">
    <p class="subtitle" style="margin:0"><a href="<?= url('/admin/facturacao/documentos/index.php') ?>">Documentos</a> / <?= e($doc['numero_completo']) ?></p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <?php if ($doc['estado'] === 'emitido' || $doc['estado'] === 'anulado'): ?>
            <a class="btn btn-primary" target="_blank" href="<?= url('/admin/facturacao/documentos/imprimir.php?id='.$id) ?>"><i class="fas fa-print"></i> Imprimir / PDF</a>
            <a class="btn btn-outline" target="_blank" href="<?= url('/admin/facturacao/documentos/imprimir.php?id='.$id.'&formato=a4') ?>"><i class="fas fa-file-invoice"></i> Factura A4</a>
        <?php endif; ?>
        <?php if ($doc['estado'] === 'emitido' && in_array($doc['tipo'], ['FT', 'FR', 'NC', 'ND', 'FA'], true)): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="enviar_agt"><button class="btn btn-outline" type="submit"><i class="fas fa-paper-plane"></i> Enviar à AGT</button></form>
            <?php if ($agtEnvio && !empty($agtEnvio['request_id'])): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="consultar_agt"><button class="btn btn-outline" type="submit"><i class="fas fa-sync"></i> obterEstado</button></form>
            <?php endif; ?>
            <?php if ($agtEnvio): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="consultar_factura_agt"><button class="btn btn-outline" type="submit">consultarFactura</button></form>
            <?php endif; ?>
            <?php if ($agtEnvio && ($agtEnvio['estado'] ?? '') === 'rejeitado'): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="reenviar_correcao"><button class="btn btn-outline" type="submit">Reenviar correcção (C)</button></form>
            <?php endif; ?>
        <?php endif; ?>
        <?php if ($doc['estado'] === 'emitido' && in_array($doc['tipo'], ['FT','FR'], true)): ?>
            <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=NC&origem=' . $id) ?>">Emitir NC</a>
        <?php endif; ?>
        <?php if ($doc['estado'] === 'emitido' && ($doc['tipo'] ?? '') === 'OR'): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="converter_ft"><button class="btn btn-outline" type="submit">Converter em Factura (FT)</button></form>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="converter_fr"><button class="btn btn-outline" type="submit">Converter em Factura-Recibo (FR)</button></form>
        <?php endif; ?>
    </div>
</div>

<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<?php if ($agtEnvio): ?><div class="alert alert-persist <?= in_array($agtEnvio['estado'], ['validado', 'submetido', 'processando'], true) ? 'alert-success' : 'alert-error' ?>"><strong>Estado AGT:</strong> <?= e(fat_agt_estado_label($agtEnvio['estado'])) ?><?php if (!empty($doc['fe_request_id'])): ?> · Request <?= e($doc['fe_request_id']) ?><?php endif; ?><?php if ($agtEnvio['resposta']): ?><div style="font-size:.8rem;margin-top:6px;word-break:break-word"><?php $r = (string) $agtEnvio['resposta']; echo e(mb_strlen($r) > 200 ? mb_substr($r, 0, 200) . '…' : $r); ?></div><?php endif; ?></div><?php endif; ?>

<div class="grid-2">
    <div class="card"><div class="card-body">
        <h2><?= e(fat_tipo_label($doc['tipo'])) ?></h2>
        <p><strong>Nº:</strong> <?= e($doc['numero_completo']) ?></p>
        <p><strong>Estado:</strong> <?= e($doc['estado']) ?></p>
        <?php if (!empty($doc['fe_validation_status'])): ?><p><strong>Validação AGT:</strong> <?= e($doc['fe_validation_status']) ?></p><?php endif; ?>
        <?php if (!empty($doc['fe_customer_status'])): ?><p><strong>Confirmação adquirente:</strong> <?= e($doc['fe_customer_status']) ?></p><?php endif; ?>
        <p><strong>Data:</strong> <?= e(format_date($doc['data_documento'], 'd/m/Y')) ?></p>
        <?php if ($doc['data_sistema']): ?><p><strong>Registo sistema:</strong> <?= e(format_date($doc['data_sistema'], 'd/m/Y H:i:s')) ?></p><?php endif; ?>
        <?php if ($doc['hash_control']): ?>
            <p><strong>Hash control:</strong> <code><?= e($doc['hash_control']) ?></code></p>
            <p style="font-size:.75rem;word-break:break-all;color:#6b7280"><strong>Hash:</strong> <?= e(mb_substr((string)$doc['hash'], 0, 80)) ?>…</p>
        <?php endif; ?>
        <?php if ($doc['estado'] === 'emitido'): ?>
            <p style="margin-top:10px"><a class="link" target="_blank" rel="noopener" href="<?= e(fat_fatura_validar_url($id)) ?>">Link público de validação</a></p>
        <?php endif; ?>
        <?php if ($doc['motivo_anulacao']): ?><p class="alert alert-error"><?= e($doc['motivo_anulacao']) ?></p><?php endif; ?>
    </div></div>
    <div class="card"><div class="card-body">
        <h2>Cliente</h2>
        <p><strong><?= e($doc['cliente_nome']) ?></strong></p>
        <p>NIF: <?= e($doc['cliente_nif']) ?></p>
        <?php if ($clienteEmail): ?><p>Email: <?= e($clienteEmail) ?></p><?php endif; ?>
        <p><?= e($doc['cliente_morada'] ?? '') ?></p>
        <?php if (!empty($doc['local_prestacao'])): ?><p><strong>Local do serviço:</strong> <?= e($doc['local_prestacao']) ?></p><?php endif; ?>
        <hr style="margin:16px 0;border:0;border-top:1px solid #e5e7eb">
        <p>Subtotal: <?= e(fat_format_money($doc['subtotal'])) ?></p>
        <p>IVA: <?= e(fat_format_money($doc['total_iva'])) ?></p>
        <p><strong>Total: <?= e(fat_format_money($doc['total'])) ?></strong></p>
    </div></div>
</div>

<div class="card" style="margin-top:16px"><div class="table-wrap"><table>
<thead><tr><th>#</th><th>Código</th><th>Descrição</th><th>Qtd</th><th>Preço</th><th>IVA</th><th>Total</th></tr></thead>
<tbody>
<?php foreach ($linhas as $l): ?>
<tr>
    <td><?= (int)$l['linha'] ?></td>
    <td><?= e($l['codigo']) ?></td>
    <td><?= e($l['descricao']) ?></td>
    <td><?= e($l['quantidade']) ?></td>
    <td><?= e(fat_format_money($l['preco_unitario'])) ?></td>
    <td><?= e(number_format((float)$l['taxa_iva'], 2)) ?>%</td>
    <td><?= e(fat_format_money($l['total_linha'])) ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>

<?php if ($doc['estado'] === 'rascunho'): ?>
<div class="card" style="margin-top:16px"><div class="card-body" style="display:flex;gap:12px;flex-wrap:wrap">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="emitir"><input type="hidden" name="confirm_clock_ok" value="<?= e($_GET['confirm_clock_ok'] ?? '') ?>">
        <button class="btn btn-primary" type="submit" onclick="return confirm('Emitir documento? A numeração e o hash ficam definitivos.')"><i class="fas fa-check"></i> Emitir documento</button>
    </form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="eliminar_rascunho">
        <button class="btn btn-danger" type="submit" onclick="return confirm('Eliminar este rascunho?')">Eliminar rascunho</button>
    </form>
</div></div>
<?php endif; ?>

<?php if ($doc['estado'] === 'emitido'): ?>
<div class="card" style="margin-top:16px"><div class="card-body">
    <h3 style="margin-top:0"><?= ($doc['tipo'] ?? '') === 'OR' ? 'Enviar proposta orçamental' : 'Enviar documento ao cliente' ?></h3>
    <form method="post" class="form-grid" style="grid-template-columns:1fr 1fr auto;gap:12px;align-items:end">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="enviar_email">
        <div class="form-group" style="margin:0"><label>Email do cliente *</label><input class="form-control" type="email" name="email" value="<?= e($clienteEmail) ?>" required placeholder="cliente@empresa.ao"></div>
        <div class="form-group" style="margin:0"><label>Mensagem (opcional)</label><input class="form-control" name="mensagem" placeholder="Prazo de validade, condições…"></div>
        <button class="btn btn-primary" type="submit"><i class="fas fa-envelope"></i> Enviar por email</button>
    </form>
    <p style="font-size:.85rem;color:var(--muted);margin:10px 0 0">Inclui link para imprimir/PDF<?= ($doc['tipo'] ?? '') !== 'OR' ? ' e validação AGT' : '' ?>.</p>
</div></div>
<div class="card" style="margin-top:16px"><div class="card-body">
    <p style="font-size:.9rem;color:#6b7280;margin-bottom:10px">Documentos emitidos <strong>não podem ser apagados</strong>. Pode marcar como anulado e/ou emitir Nota de Crédito.</p>
    <form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end"><?= csrf_field() ?>
        <input type="hidden" name="action" value="anular">
        <div class="form-group" style="flex:1;min-width:220px;margin:0"><label>Motivo anulação</label><input class="form-control" name="motivo" required></div>
        <button class="btn btn-danger" type="submit" onclick="return confirm('Marcar como anulado?')">Anular</button>
    </form>
</div></div>
<?php endif; ?>

<?php require __DIR__ . '/../../includes/footer.php'; ?>
