<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Facturação electrónica AGT';
$current = 'fat-agt';
$msg = null;
$errors = [];
$listResult = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'processar') {
            $n = fat_agt_processar_pendentes(30);
            $msg = "Processados {$n} registo(s) AGT.";
        }
        if ($action === 'consultar' && !empty($_POST['documento_id'])) {
            fat_agt_obter_estado((int) $_POST['documento_id'], (int) current_user()['id']);
            $msg = 'Estado AGT actualizado (obterEstado).';
        }
        if ($action === 'listar') {
            $from = trim($_POST['from'] ?? date('Y-m-01'));
            $to = trim($_POST['to'] ?? date('Y-m-d'));
            $tipo = trim($_POST['document_type'] ?? '') ?: null;
            $listResult = fat_agt_listar_facturas($from, $to, $tipo);
            $msg = 'listarFacturas concluído.';
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

$emp = fat_empresa();
$pendentes = db()->query("SELECT e.*, d.numero_completo, d.tipo, d.total, d.fe_agt_estado
    FROM fat_agt_envios e
    INNER JOIN fat_documentos d ON d.id=e.documento_id
    ORDER BY e.id DESC LIMIT 40")->fetchAll();

require __DIR__ . '/../includes/header.php';
?>
<div class="toolbar">
    <p class="subtitle" style="margin:0">API AGT schema 2.0: registarFactura, obterEstado, consultarFactura, listarFacturas, anularFactura.</p>
    <div class="actions">
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/empresa.php') ?>">Empresa fiscal</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Voltar</a>
    </div>
</div>

<?php if ($msg): ?><div class="alert alert-success"><?= e($msg) ?></div><?php endif; ?>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>

<div class="card"><div class="card-body">
    <h3>Estado da ligação</h3>
    <ul style="font-size:.9rem;color:#374151;line-height:1.7">
        <li>Base URL: <code><?= e(fat_agt_api_base()) ?></code></li>
        <li>Ambiente: <strong><?= e(fat_agt_ambiente() === 'producao' ? 'Produção' : 'Homologação') ?></strong></li>
        <li>API configurada: <strong><?= fat_agt_api_configured() ? 'Sim' : 'Não' ?></strong></li>
        <li>Simulação: <strong><?= fat_agt_simular() ? 'Activa' : 'Inactiva' ?></strong></li>
        <li>Chave produtor (JWS software): <strong><?= is_file(fat_agt_key_path('produtor')) ? 'OK' : 'Em falta' ?></strong></li>
        <li>Chave emitente (JWS documento): <strong><?= is_file(fat_agt_key_path('emitente')) ? 'OK' : 'Em falta' ?></strong></li>
    </ul>
    <form method="post" style="margin-top:12px"><?= csrf_field() ?>
        <input type="hidden" name="action" value="processar">
        <button class="btn btn-primary" type="submit"><i class="fas fa-sync"></i> Processar fila / obterEstado</button>
    </form>
</div></div>

<div class="card" style="margin-top:16px"><div class="card-body">
    <h3>listarFacturas (AGT)</h3>
    <form method="post" class="form-grid"><?= csrf_field() ?>
        <input type="hidden" name="action" value="listar">
        <div class="form-group"><label>De</label><input class="form-control" type="date" name="from" value="<?= e(date('Y-m-01')) ?>" required></div>
        <div class="form-group"><label>Até</label><input class="form-control" type="date" name="to" value="<?= e(date('Y-m-d')) ?>" required></div>
        <div class="form-group"><label>Tipo (opcional)</label>
            <select name="document_type">
                <option value="">Todos</option>
                <?php foreach (['FT', 'FR', 'NC', 'ND', 'FA'] as $t): ?>
                    <option value="<?= $t ?>"><?= $t ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group" style="align-self:end"><button class="btn btn-outline" type="submit">Listar na AGT</button></div>
    </form>
    <?php if ($listResult !== null): ?>
        <pre style="margin-top:12px;font-size:.75rem;max-height:240px;overflow:auto;background:#f9fafb;padding:12px;border-radius:8px"><?= e(json_encode($listResult, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?></pre>
    <?php endif; ?>
</div></div>

<div class="card" style="margin-top:16px"><div class="card-head"><h2>Últimos envios AGT</h2></div><div class="table-wrap"><table>
<thead><tr><th>Documento</th><th>Estado</th><th>Request ID</th><th>Tentativas</th><th>Resposta</th><th></th></tr></thead>
<tbody>
<?php if (!$pendentes): ?>
<tr><td colspan="6" class="empty">Ainda não há envios registados.</td></tr>
<?php else: foreach ($pendentes as $p): ?>
<tr>
    <td><strong><?= e($p['numero_completo']) ?></strong><div style="font-size:.8rem;color:#6b7280"><?= e(fat_tipo_label($p['tipo'])) ?></div></td>
    <td><?= e(fat_agt_estado_label($p['estado'])) ?><?php if ($p['fe_agt_estado']): ?><div style="font-size:.75rem"><?= e($p['fe_agt_estado']) ?></div><?php endif; ?></td>
    <td><?= e($p['request_id'] ?: '—') ?></td>
    <td><?= (int) $p['tentativas'] ?></td>
    <td style="max-width:280px;font-size:.78rem;word-break:break-word"><?= e(mb_substr((string) $p['resposta'], 0, 120)) ?><?= mb_strlen((string) $p['resposta']) > 120 ? '…' : '' ?></td>
    <td class="actions">
        <a class="btn btn-sm btn-outline" href="<?= url('/admin/facturacao/documentos/ver.php?id=' . (int) $p['documento_id']) ?>">Abrir</a>
        <?php if ($p['request_id'] && in_array($p['estado'], ['submetido', 'processando'], true)): ?>
        <form method="post" style="display:inline"><?= csrf_field() ?>
            <input type="hidden" name="action" value="consultar">
            <input type="hidden" name="documento_id" value="<?= (int) $p['documento_id'] ?>">
            <button class="btn btn-sm btn-outline" type="submit">obterEstado</button>
        </form>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; endif; ?>
</tbody></table></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
