<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Caixa';
$current = 'fat-caixa';
$errors = [];
$userId = (int) current_user()['id'];
$caixa = fat_caixa_aberto();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'abrir') {
            $fundo = (float) str_replace(',', '.', $_POST['fundo_inicial'] ?? '0');
            $obs = trim($_POST['observacoes'] ?? '');
            fat_abrir_caixa($userId, $fundo, $obs);
            flash('success', 'Caixa aberto. Já pode vender.');
            redirect('/admin/facturacao/vender.php');
        }
        if ($action === 'fechar') {
            if (!$caixa) {
                throw new RuntimeException('Não há caixa aberto.');
            }
            $contado = (float) str_replace(',', '.', $_POST['valor_contado'] ?? '0');
            $obs = trim($_POST['observacoes'] ?? '');
            $fechado = fat_fechar_caixa((int) $caixa['id'], $userId, $contado, $obs);
            flash('success', 'Caixa fechado. Diferença: ' . fat_format_money($fechado['diferenca'] ?? 0));
            redirect('/admin/facturacao/caixa.php');
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
        $caixa = fat_caixa_aberto();
    }
}

$historico = db()->query("SELECT c.*, u.nome AS operador
    FROM fat_caixa c
    LEFT JOIN usuarios u ON u.id = c.aberto_por
    ORDER BY c.id DESC LIMIT 15")->fetchAll();

$vendasCaixa = [];
$totCaixa = 0.0;
if ($caixa) {
    $vs = db()->prepare("SELECT id, numero_completo, cliente_nome, total, data_sistema
        FROM fat_documentos WHERE caixa_id=? AND estado='emitido' ORDER BY id DESC");
    $vs->execute([$caixa['id']]);
    $vendasCaixa = $vs->fetchAll();
    foreach ($vendasCaixa as $v) {
        $totCaixa += (float) $v['total'];
    }
}

require __DIR__ . '/../includes/header.php';
?>

<div class="toolbar">
    <p class="subtitle" style="margin:0"><a href="<?= url('/admin/facturacao/index.php') ?>">Facturação</a> / Caixa</p>
    <?php if ($caixa): ?>
        <a class="btn btn-primary" href="<?= url('/admin/facturacao/vender.php') ?>"><i class="fas fa-cash-register"></i> Vender</a>
    <?php endif; ?>
</div>

<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>

<?php if (!$caixa): ?>
<div class="card"><div class="card-body">
    <h2 style="margin-top:0">Abrir caixa</h2>
    <p style="color:#6b7280">É obrigatório abrir o caixa antes de realizar vendas.</p>
    <form method="post"><?= csrf_field() ?>
        <input type="hidden" name="action" value="abrir">
        <div class="form-grid">
            <div class="form-group"><label>Fundo inicial (Kz)</label><input class="form-control" name="fundo_inicial" value="0" required></div>
            <div class="form-group"><label>Observações</label><input class="form-control" name="observacoes" placeholder="Opcional"></div>
        </div>
        <button class="btn btn-primary" type="submit"><i class="fas fa-lock-open"></i> Abrir caixa</button>
    </form>
</div></div>
<?php else: ?>
<div class="alert alert-success">
    <strong>Caixa #<?= (int)$caixa['id'] ?> aberto</strong> desde <?= e(format_date($caixa['aberto_em'], 'd/m/Y H:i')) ?>
    · Fundo: <?= e(fat_format_money($caixa['fundo_inicial'])) ?>
    · Vendas nesta sessão: <?= e(fat_format_money($totCaixa)) ?>
</div>

<div class="grid-2">
    <div class="card"><div class="card-body">
        <h2 style="margin-top:0">Fechar caixa</h2>
        <p style="color:#6b7280;font-size:.9rem">Esperado em numerário ≈ fundo + pagamentos em dinheiro das vendas.</p>
        <form method="post"><?= csrf_field() ?>
            <input type="hidden" name="action" value="fechar">
            <div class="form-group"><label>Valor contado no caixa (Kz)</label><input class="form-control" name="valor_contado" required value="<?= e(number_format((float)$caixa['fundo_inicial'] + $totCaixa, 2, '.', '')) ?>"></div>
            <div class="form-group"><label>Observações</label><input class="form-control" name="observacoes"></div>
            <button class="btn btn-danger" type="submit" onclick="return confirm('Fechar o caixa? Não poderá vender até abrir novamente.')"><i class="fas fa-lock"></i> Fechar caixa</button>
        </form>
    </div></div>
    <div class="card">
        <div class="card-head"><h2>Vendas deste caixa</h2></div>
        <div class="table-wrap"><table>
            <thead><tr><th>Documento</th><th>Cliente</th><th>Total</th></tr></thead>
            <tbody>
            <?php if (!$vendasCaixa): ?>
                <tr><td colspan="3" class="empty">Ainda sem vendas neste caixa.</td></tr>
            <?php else: foreach ($vendasCaixa as $v): ?>
                <tr>
                    <td><a href="<?= url('/admin/facturacao/documentos/ver.php?id='.$v['id']) ?>"><?= e($v['numero_completo']) ?></a></td>
                    <td><?= e($v['cliente_nome']) ?></td>
                    <td><?= e(fat_format_money($v['total'])) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table></div>
    </div>
</div>
<?php endif; ?>

<div class="card" style="margin-top:16px">
    <div class="card-head"><h2>Histórico de caixas</h2></div>
    <div class="table-wrap"><table>
        <thead><tr><th>#</th><th>Aberto</th><th>Operador</th><th>Fundo</th><th>Vendas</th><th>Estado</th><th>Diferença</th></tr></thead>
        <tbody>
        <?php if (!$historico): ?>
            <tr><td colspan="7" class="empty">Sem histórico.</td></tr>
        <?php else: foreach ($historico as $h): ?>
            <tr>
                <td><?= (int)$h['id'] ?></td>
                <td><?= e(format_date($h['aberto_em'], 'd/m/Y H:i')) ?></td>
                <td><?= e($h['operador'] ?? '—') ?></td>
                <td><?= e(fat_format_money($h['fundo_inicial'])) ?></td>
                <td><?= e(fat_format_money($h['total_vendas'])) ?></td>
                <td><?= e($h['estado']) ?></td>
                <td><?= $h['diferenca'] !== null ? e(fat_format_money($h['diferenca'])) : '—' ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table></div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
