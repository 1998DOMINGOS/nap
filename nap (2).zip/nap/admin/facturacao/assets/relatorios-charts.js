(function () {
  var data = window.fatRelCharts;
  if (!data || typeof Chart === 'undefined') {
    return;
  }

  var fmtKwanza = function (value) {
    var n = Number(value) || 0;
    return n.toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + ' Kz';
  };

  var gridColor = 'rgba(148, 163, 184, 0.25)';
  var baseOpts = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'bottom', labels: { boxWidth: 12, padding: 10 } },
      tooltip: {
        callbacks: {
          label: function (ctx) {
            var label = ctx.dataset.label || '';
            if (label) {
              label += ': ';
            }
            var val = ctx.parsed.y !== undefined && ctx.parsed.y !== null ? ctx.parsed.y : ctx.parsed;
            return label + fmtKwanza(val);
          },
        },
      },
    },
  };

  var s = data.series;
  var elFluxo = document.getElementById('relChartFluxo');
  if (elFluxo && s) {
    new Chart(elFluxo, {
      type: 'bar',
      data: {
        labels: s.labels,
        datasets: [
          { label: 'Vendas', data: s.vendas, backgroundColor: 'rgba(34, 197, 94, 0.8)', borderRadius: 4 },
          { label: 'Compras', data: s.compras, backgroundColor: 'rgba(249, 115, 22, 0.75)', borderRadius: 4 },
          { label: 'Notas crédito', data: s.nc, backgroundColor: 'rgba(239, 68, 68, 0.6)', borderRadius: 4 },
        ],
      },
      options: Object.assign({}, baseOpts, {
        scales: {
          x: { grid: { display: false } },
          y: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: { callback: function (v) { return fmtKwanza(v); } },
          },
        },
      }),
    });
  }

  var elIva = document.getElementById('relChartIva');
  if (elIva && s) {
    new Chart(elIva, {
      type: 'line',
      data: {
        labels: s.labels,
        datasets: [{
          label: 'IVA liquidado',
          data: s.iva,
          borderColor: 'rgb(59, 130, 246)',
          backgroundColor: 'rgba(59, 130, 246, 0.12)',
          fill: true,
          tension: 0.25,
        }],
      },
      options: Object.assign({}, baseOpts, {
        scales: {
          x: { grid: { display: false } },
          y: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: { callback: function (v) { return fmtKwanza(v); } },
          },
        },
      }),
    });
  }

  var tipos = data.tipos;
  var elTipo = document.getElementById('relChartTipos');
  if (elTipo && tipos && tipos.labels && tipos.labels.length) {
    new Chart(elTipo, {
      type: 'doughnut',
      data: {
        labels: tipos.labels,
        datasets: [{ data: tipos.totais, backgroundColor: ['#22c55e', '#3b82f6', '#f97316', '#a855f7', '#eab308', '#64748b'] }],
      },
      options: Object.assign({}, baseOpts, {
        plugins: Object.assign({}, baseOpts.plugins, {
          tooltip: {
            callbacks: {
              label: function (ctx) {
                return ctx.label + ': ' + fmtKwanza(ctx.parsed);
              },
            },
          },
        }),
      }),
    });
  }

  var cli = data.topClientes;
  var elCli = document.getElementById('relChartClientes');
  if (elCli && cli && cli.labels && cli.labels.length) {
    new Chart(elCli, {
      type: 'bar',
      data: {
        labels: cli.labels,
        datasets: [{ label: 'Total', data: cli.totais, backgroundColor: 'rgba(99, 102, 241, 0.75)', borderRadius: 4 }],
      },
      options: Object.assign({}, baseOpts, {
        indexAxis: 'y',
        scales: {
          x: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: { callback: function (v) { return fmtKwanza(v); } },
          },
          y: { grid: { display: false } },
        },
      }),
    });
  }

  var pag = data.pagamentos;
  var elPag = document.getElementById('relChartPagamentos');
  if (elPag && pag && pag.labels && pag.labels.length) {
    new Chart(elPag, {
      type: 'pie',
      data: {
        labels: pag.labels,
        datasets: [{ data: pag.totais, backgroundColor: ['#22c55e', '#3b82f6', '#f97316', '#a855f7', '#64748b'] }],
      },
      options: baseOpts,
    });
  }
})();
