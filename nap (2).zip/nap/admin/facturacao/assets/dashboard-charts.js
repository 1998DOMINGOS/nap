(function () {
  var data = window.fatDashCharts;
  if (!data || typeof Chart === 'undefined') {
    return;
  }

  var fmtKwanza = function (value) {
    var n = Number(value) || 0;
    return n.toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + ' Kz';
  };

  var gridColor = 'rgba(148, 163, 184, 0.25)';
  var baseOpts = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'bottom', labels: { boxWidth: 12, padding: 12 } },
      tooltip: {
        callbacks: {
          label: function (ctx) {
            var label = ctx.dataset.label || '';
            if (label) {
              label += ': ';
            }
            var val = ctx.parsed.y !== undefined && ctx.parsed.y !== null ? ctx.parsed.y : ctx.parsed;
            return label + fmtKwanza(val);
          },
        },
      },
    },
  };

  var s = data.series;
  var elMes = document.getElementById('fatChartVendasMes');
  if (elMes && s) {
    new Chart(elMes, {
      type: 'bar',
      data: {
        labels: s.labels,
        datasets: [
          { label: 'Vendas', data: s.vendas, backgroundColor: 'rgba(34, 197, 94, 0.8)', borderRadius: 4 },
          { label: 'Notas crédito', data: s.nc, backgroundColor: 'rgba(239, 68, 68, 0.65)', borderRadius: 4 },
        ],
      },
      options: Object.assign({}, baseOpts, {
        scales: {
          x: { grid: { display: false } },
          y: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: { callback: function (v) { return fmtKwanza(v); } },
          },
        },
      }),
    });
  }

  var elIva = document.getElementById('fatChartIva');
  if (elIva && s) {
    new Chart(elIva, {
      type: 'line',
      data: {
        labels: s.labels,
        datasets: [
          {
            label: 'IVA liquidado',
            data: s.iva,
            borderColor: 'rgb(59, 130, 246)',
            backgroundColor: 'rgba(59, 130, 246, 0.15)',
            fill: true,
            tension: 0.25,
          },
        ],
      },
      options: Object.assign({}, baseOpts, {
        scales: {
          x: { grid: { display: false } },
          y: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: { callback: function (v) { return fmtKwanza(v); } },
          },
        },
      }),
    });
  }

  var d = data.diario;
  var elDia = document.getElementById('fatChartDiario');
  if (elDia && d) {
    new Chart(elDia, {
      type: 'line',
      data: {
        labels: d.labels,
        datasets: [
          {
            label: 'Vendas líquidas',
            data: d.totais,
            borderColor: 'rgb(16, 185, 129)',
            backgroundColor: 'rgba(16, 185, 129, 0.12)',
            fill: true,
            tension: 0.2,
            pointRadius: 2,
          },
        ],
      },
      options: Object.assign({}, baseOpts, {
        scales: {
          x: { grid: { display: false }, ticks: { maxTicksLimit: 10 } },
          y: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: { callback: function (v) { return fmtKwanza(v); } },
          },
        },
      }),
    });
  }

  var tipos = data.tipos;
  var elTipo = document.getElementById('fatChartTipos');
  if (elTipo && tipos && tipos.labels) {
    new Chart(elTipo, {
      type: 'doughnut',
      data: {
        labels: tipos.labels,
        datasets: [{
          data: tipos.totais,
          backgroundColor: [
            'rgba(34, 197, 94, 0.85)',
            'rgba(59, 130, 246, 0.85)',
            'rgba(249, 115, 22, 0.85)',
            'rgba(168, 85, 247, 0.85)',
            'rgba(234, 179, 8, 0.85)',
            'rgba(107, 114, 128, 0.85)',
          ],
        }],
      },
      options: Object.assign({}, baseOpts, {
        plugins: Object.assign({}, baseOpts.plugins, {
          tooltip: {
            callbacks: {
              label: function (ctx) {
                return ctx.label + ': ' + fmtKwanza(ctx.parsed);
              },
            },
          },
        }),
      }),
    });
  }

  var pag = data.pagamentos;
  var elPag = document.getElementById('fatChartPagamentos');
  if (elPag && pag && pag.labels) {
    new Chart(elPag, {
      type: 'pie',
      data: {
        labels: pag.labels,
        datasets: [{ data: pag.totais, backgroundColor: ['#22c55e', '#3b82f6', '#f97316', '#a855f7', '#64748b'] }],
      },
      options: baseOpts,
    });
  }

  var cli = data.topClientes;
  var elCli = document.getElementById('fatChartClientes');
  if (elCli && cli && cli.labels) {
    new Chart(elCli, {
      type: 'bar',
      data: {
        labels: cli.labels,
        datasets: [{ label: 'Total', data: cli.totais, backgroundColor: 'rgba(99, 102, 241, 0.75)', borderRadius: 4 }],
      },
      options: Object.assign({}, baseOpts, {
        indexAxis: 'y',
        scales: {
          x: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: { callback: function (v) { return fmtKwanza(v); } },
          },
          y: { grid: { display: false } },
        },
      }),
    });
  }
})();
