<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
ensure_contabilidade_schema();

$pageTitle = 'Cobranças';
$pageSubtitle = 'Contas a receber e envio de documentos';
$current = 'fat-cobrancas';
$errors = [];
$ok = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $docId = (int) ($_POST['documento_id'] ?? 0);
    try {
        if ($action === 'enviar_email' && $docId > 0) {
            $email = trim($_POST['email'] ?? '');
            $msg = trim($_POST['mensagem'] ?? '');
            fat_enviar_documento_email($docId, $email, $msg, (int) (current_user()['id'] ?? 0));
            $ok = 'Documento enviado por email.';
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

$receber = cont_listar_contas_receber();
$totalReceber = array_sum(array_column($receber, 'saldo'));

require __DIR__ . '/../includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>

<div class="toolbar">
    <p class="subtitle" style="margin:0">Total em dívida: <strong><?= e(fat_format_money((float) $totalReceber)) ?></strong></p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=OR') ?>"><i class="fas fa-file-signature"></i> Nova proposta (OR)</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=FT') ?>"><i class="fas fa-file-invoice"></i> Nova factura (venda)</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/criar.php?tipo=FT&modo=servico') ?>"><i class="fas fa-hand-holding-hand"></i> Factura de serviço</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/recibos.php') ?>"><i class="fas fa-receipt"></i> Registar recebimento</a>
    </div>
</div>

<div class="card"><div class="card-body">
<?php if (!$receber): ?>
    <p>Não há documentos com saldo em aberto.</p>
<?php else: ?>
<div class="table-wrap"><table>
<thead><tr><th>Documento</th><th>Cliente</th><th>Data</th><th class="right">Em dívida</th><th>Enviar factura</th></tr></thead>
<tbody>
<?php foreach ($receber as $r):
    $docId = (int) $r['id'];
    $emailDefault = fat_documento_cliente_email($docId);
?>
<tr>
    <td><a href="<?= url('/admin/facturacao/documentos/ver.php?id=' . $docId) ?>"><?= e($r['tipo'] . ' ' . $r['numero_completo']) ?></a></td>
    <td><?= e($r['cliente_nome']) ?></td>
    <td><?= e(format_date($r['data_documento'], 'd/m/Y')) ?></td>
    <td class="right"><?= e(fat_format_money((float) $r['saldo'])) ?></td>
    <td>
        <form method="post" class="form-grid" style="grid-template-columns:1fr auto;gap:8px;align-items:end;margin:0">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="enviar_email">
            <input type="hidden" name="documento_id" value="<?= $docId ?>">
            <div class="form-group" style="margin:0"><label style="font-size:.75rem">Email</label><input class="form-control" type="email" name="email" value="<?= e($emailDefault) ?>" required placeholder="cliente@email.ao"></div>
            <button class="btn btn-primary btn-sm" type="submit"><i class="fas fa-envelope"></i> Enviar</button>
        </form>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table></div>
<?php endif; ?>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
