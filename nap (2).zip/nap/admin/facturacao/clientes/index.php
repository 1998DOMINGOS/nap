<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Clientes';
$current = 'fat-clientes';
$items = db()->query('SELECT * FROM fat_clientes ORDER BY nome')->fetchAll();
require __DIR__ . '/../../includes/header.php';
?>
<div class="toolbar">
    <p class="subtitle" style="margin:0"><a href="<?= url('/admin/facturacao/index.php') ?>">Facturação</a> / Clientes</p>
    <a class="btn btn-primary" href="<?= url('/admin/facturacao/clientes/criar.php') ?>"><i class="fas fa-plus"></i> Novo cliente</a>
</div>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>Código</th><th>Nome</th><th>NIF</th><th>Contacto</th><th>Estado</th><th></th></tr></thead>
<tbody>
<?php if (!$items): ?><tr><td colspan="6" class="empty">Sem clientes.</td></tr>
<?php else: foreach ($items as $c): ?>
<tr>
    <td><?= e($c['codigo'] ?: '—') ?></td>
    <td><strong><?= e($c['nome']) ?></strong><div style="font-size:.8rem;color:#6b7280"><?= e($c['morada']) ?></div></td>
    <td><?= e($c['nif']) ?></td>
    <td><?= e($c['telefone']) ?><?= $c['email'] ? '<br>'.e($c['email']) : '' ?></td>
    <td><?= (int)$c['ativo'] ? 'Activo' : 'Inactivo' ?></td>
    <td class="actions">
        <a class="btn btn-sm btn-outline" href="<?= url('/admin/facturacao/clientes/editar.php?id='.$c['id']) ?>"><i class="fas fa-pen"></i></a>
    </td>
</tr>
<?php endforeach; endif; ?>
</tbody></table></div></div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
