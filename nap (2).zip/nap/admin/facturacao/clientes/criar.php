<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Novo cliente';
$current = 'fat-clientes';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $nif = preg_replace('/\s+/', '', trim($_POST['nif'] ?? '999999999')) ?: '999999999';
    $codigo = trim($_POST['codigo'] ?? '');
    $morada = trim($_POST['morada'] ?? '');
    $cidade = trim($_POST['cidade'] ?? 'Luanda');
    $telefone = trim($_POST['telefone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $ativo = isset($_POST['ativo']) ? 1 : 0;

    if ($nome === '') {
        $errors[] = 'Nome obrigatório.';
    }
    if (!$errors) {
        db()->prepare('INSERT INTO fat_clientes (codigo,nome,nif,morada,cidade,telefone,email,ativo) VALUES (?,?,?,?,?,?,?,?)')
            ->execute([$codigo ?: null, $nome, $nif, $morada, $cidade, $telefone, $email, $ativo]);
        flash('success', 'Cliente criado.');
        redirect('/admin/facturacao/clientes/index.php');
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome *</label><input class="form-control" name="nome" required value="<?= e($_POST['nome'] ?? '') ?>"></div>
        <div class="form-group"><label>NIF</label><input class="form-control" name="nif" value="<?= e($_POST['nif'] ?? '999999999') ?>"></div>
    </div>
    <div class="form-grid">
        <div class="form-group"><label>Código</label><input class="form-control" name="codigo" value="<?= e($_POST['codigo'] ?? '') ?>"></div>
        <div class="form-group"><label>Cidade</label><input class="form-control" name="cidade" value="<?= e($_POST['cidade'] ?? 'Luanda') ?>"></div>
    </div>
    <div class="form-group"><label>Morada</label><input class="form-control" name="morada" value="<?= e($_POST['morada'] ?? '') ?>"></div>
    <div class="form-grid">
        <div class="form-group"><label>Telefone</label><input class="form-control" name="telefone" value="<?= e($_POST['telefone'] ?? '') ?>"></div>
        <div class="form-group"><label>Email</label><input class="form-control" type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>"></div>
    </div>
    <label><input type="checkbox" name="ativo" checked> Activo</label>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit">Guardar</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/clientes/index.php') ?>">Cancelar</a>
    </div>
</form>
</div></div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
