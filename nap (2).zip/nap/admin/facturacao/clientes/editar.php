<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM fat_clientes WHERE id=?');
$stmt->execute([$id]);
$c = $stmt->fetch();
if (!$c) {
    flash('error', 'Cliente não encontrado.');
    redirect('/admin/facturacao/clientes/index.php');
}

$pageTitle = 'Editar cliente';
$current = 'fat-clientes';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $nif = preg_replace('/\s+/', '', trim($_POST['nif'] ?? '')) ?: '999999999';
    $codigo = trim($_POST['codigo'] ?? '');
    $morada = trim($_POST['morada'] ?? '');
    $cidade = trim($_POST['cidade'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $ativo = isset($_POST['ativo']) ? 1 : 0;
    if ($nome === '') {
        $errors[] = 'Nome obrigatório.';
    }
    if (!$errors) {
        try {
            if (function_exists('fat_agt_validar_alteracao_cliente')) {
                fat_agt_validar_alteracao_cliente($id, $nif, $nome, $c);
            }
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
    if (!$errors) {
        db()->prepare('UPDATE fat_clientes SET codigo=?,nome=?,nif=?,morada=?,cidade=?,telefone=?,email=?,ativo=? WHERE id=?')
            ->execute([$codigo ?: null, $nome, $nif, $morada, $cidade, $telefone, $email, $ativo, $id]);
        flash('success', 'Cliente actualizado.');
        redirect('/admin/facturacao/clientes/index.php');
    }
    $c = array_merge($c, $_POST);
    $c['ativo'] = $ativo;
}

require __DIR__ . '/../../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome *</label><input class="form-control" name="nome" required value="<?= e($c['nome']) ?>"></div>
        <div class="form-group"><label>NIF</label><input class="form-control" name="nif" value="<?= e($c['nif']) ?>"></div>
    </div>
    <div class="form-grid">
        <div class="form-group"><label>Código</label><input class="form-control" name="codigo" value="<?= e($c['codigo'] ?? '') ?>"></div>
        <div class="form-group"><label>Cidade</label><input class="form-control" name="cidade" value="<?= e($c['cidade'] ?? '') ?>"></div>
    </div>
    <div class="form-group"><label>Morada</label><input class="form-control" name="morada" value="<?= e($c['morada'] ?? '') ?>"></div>
    <div class="form-grid">
        <div class="form-group"><label>Telefone</label><input class="form-control" name="telefone" value="<?= e($c['telefone'] ?? '') ?>"></div>
        <div class="form-group"><label>Email</label><input class="form-control" type="email" name="email" value="<?= e($c['email'] ?? '') ?>"></div>
    </div>
    <label><input type="checkbox" name="ativo" <?= (int)$c['ativo'] ? 'checked' : '' ?>> Activo</label>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit">Guardar</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/clientes/index.php') ?>">Cancelar</a>
    </div>
</form>
</div></div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
