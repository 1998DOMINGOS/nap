<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Relatórios';
$pageSubtitle = 'Vendas, compras, IVA e análise';
$current = 'fat-relatorios';
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$tiposValidos = ['resumo', 'vendas', 'compras', 'clientes', 'pagamentos', 'iva', 'stock'];
$tipo = in_array($_GET['tipo'] ?? 'resumo', $tiposValidos, true) ? $_GET['tipo'] : 'resumo';
$format = $_GET['format'] ?? '';
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
    $from = date('Y-m-01');
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
    $to = date('Y-m-d');
}
if ($from > $to) {
    [$from, $to] = [$to, $from];
}

$empresa = fat_empresa();
$pagLabels = ['numerario' => 'Numerário', 'multicaixa' => 'Multicaixa', 'transferencia' => 'Transferência', 'cartao' => 'Cartão', 'outro' => 'Outro'];

$resumo = fat_relatorio_resumo($from, $to);
$vendas = [];
$compras = [];
$produtos = [];
$clientesRel = [];
$pagamentosRel = [];
$ivaPorTaxa = [];

if ($tipo === 'vendas') {
    $stmt = db()->prepare("SELECT tipo, numero_completo, cliente_nome, cliente_nif, data_documento, subtotal, total_iva, total, estado FROM fat_documentos WHERE data_documento BETWEEN ? AND ? AND tipo IN ('FT','FR','NC','ND','FA') ORDER BY data_documento, numero");
    $stmt->execute([$from, $to]);
    $vendas = $stmt->fetchAll();
} elseif ($tipo === 'compras') {
    $stmt = db()->prepare('SELECT referencia, fornecedor_nome, fornecedor_nif, data_compra, subtotal, total_iva, total FROM fat_compras WHERE data_compra BETWEEN ? AND ? ORDER BY data_compra, id');
    $stmt->execute([$from, $to]);
    $compras = $stmt->fetchAll();
} elseif ($tipo === 'clientes') {
    $clientesRel = fat_dashboard_top_clientes($from, $to, 50);
} elseif ($tipo === 'pagamentos') {
    $pagamentosRel = fat_dashboard_pagamentos($from, $to);
} elseif ($tipo === 'iva') {
    $stmt = db()->prepare(
        "SELECT l.taxa_iva,
            COALESCE(SUM(CASE WHEN d.tipo='NC' THEN -l.total_liquido ELSE l.total_liquido END),0) AS base,
            COALESCE(SUM(CASE WHEN d.tipo='NC' THEN -l.total_iva ELSE l.total_iva END),0) AS iva
         FROM fat_linhas l
         INNER JOIN fat_documentos d ON d.id=l.documento_id
         WHERE d.estado='emitido' AND d.data_documento BETWEEN ? AND ?
           AND d.tipo IN ('FT','FR','NC','ND','FA')
         GROUP BY l.taxa_iva ORDER BY l.taxa_iva DESC"
    );
    $stmt->execute([$from, $to]);
    $ivaPorTaxa = $stmt->fetchAll();
} elseif ($tipo === 'stock') {
    $produtos = db()->query('SELECT codigo, descricao, unidade, stock, preco, preco_compra, preco_venda, taxa_iva, data_validade, ativo FROM fat_produtos ORDER BY descricao')->fetchAll();
}

$titleMap = [
    'resumo' => 'Resumo executivo',
    'vendas' => 'Relatório de vendas e recibos',
    'compras' => 'Relatório de compras',
    'clientes' => 'Clientes por facturação',
    'pagamentos' => 'Recebimentos por meio de pagamento',
    'iva' => 'Mapa de IVA (vendas)',
    'stock' => 'Relatório de stock',
];
$title = $titleMap[$tipo] ?? 'Relatório';

$buildChartPayload = static function (string $from, string $to) use ($pagLabels): array {
    $porTipoRows = fat_dashboard_por_tipo($from, $to);
    $tiposChart = ['labels' => [], 'totais' => []];
    foreach ($porTipoRows as $row) {
        $tiposChart['labels'][] = fat_tipo_label((string) $row['tipo']);
        $tiposChart['totais'][] = (float) $row['total'];
    }
    $topCliRows = fat_dashboard_top_clientes($from, $to, 8);
    $cliChart = ['labels' => [], 'totais' => []];
    foreach ($topCliRows as $row) {
        $nome = trim((string) $row['cliente_nome']);
        $cliChart['labels'][] = $nome !== '' ? (mb_strlen($nome) > 24 ? mb_substr($nome, 0, 22) . '…' : $nome) : '—';
        $cliChart['totais'][] = (float) $row['total'];
    }
    $pagRows = fat_dashboard_pagamentos($from, $to);
    $pagChart = ['labels' => [], 'totais' => []];
    foreach ($pagRows as $row) {
        $m = (string) $row['metodo'];
        $pagChart['labels'][] = $pagLabels[$m] ?? ucfirst($m);
        $pagChart['totais'][] = (float) $row['total'];
    }

    return [
        'series' => fat_dashboard_series(6),
        'tipos' => $tiposChart,
        'topClientes' => $cliChart,
        'pagamentos' => $pagChart,
    ];
};

if ($format === 'csv' && in_array($tipo, ['vendas', 'compras', 'clientes', 'pagamentos', 'iva', 'resumo'], true)) {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="relatorio-' . $tipo . '-' . date('Ymd') . '.csv"');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'w');
    if ($tipo === 'resumo') {
        fputcsv($out, ['Indicador', 'Valor'], ';');
        fputcsv($out, ['Vendas líquidas', $resumo['vendas_liquidas']], ';');
        fputcsv($out, ['IVA liquidado', $resumo['iva_liquidado']], ';');
        fputcsv($out, ['Documentos', $resumo['documentos']], ';');
        fputcsv($out, ['Compras', $resumo['compras']], ';');
        fputcsv($out, ['IVA compras', $resumo['iva_compras']], ';');
        fputcsv($out, ['Recebimentos', $resumo['recebimentos']], ';');
    } elseif ($tipo === 'vendas') {
        fputcsv($out, ['Tipo', 'Número', 'Cliente', 'NIF', 'Data', 'Subtotal', 'IVA', 'Total', 'Estado'], ';');
        foreach ($vendas as $item) {
            fputcsv($out, [$item['tipo'], $item['numero_completo'], $item['cliente_nome'], $item['cliente_nif'], $item['data_documento'], $item['subtotal'], $item['total_iva'], $item['total'], $item['estado']], ';');
        }
    } elseif ($tipo === 'compras') {
        fputcsv($out, ['Referência', 'Fornecedor', 'NIF', 'Data', 'Subtotal', 'IVA', 'Total'], ';');
        foreach ($compras as $item) {
            fputcsv($out, [$item['referencia'], $item['fornecedor_nome'], $item['fornecedor_nif'], $item['data_compra'], $item['subtotal'], $item['total_iva'], $item['total']], ';');
        }
    } elseif ($tipo === 'clientes') {
        fputcsv($out, ['Cliente', 'NIF', 'Documentos', 'Total'], ';');
        foreach ($clientesRel as $item) {
            fputcsv($out, [$item['cliente_nome'], $item['cliente_nif'], $item['docs'], $item['total']], ';');
        }
    } elseif ($tipo === 'pagamentos') {
        fputcsv($out, ['Meio', 'Operações', 'Total'], ';');
        foreach ($pagamentosRel as $item) {
            $m = (string) $item['metodo'];
            fputcsv($out, [$pagLabels[$m] ?? $m, $item['n'], $item['total']], ';');
        }
    } else {
        fputcsv($out, ['Taxa IVA', 'Base', 'IVA'], ';');
        foreach ($ivaPorTaxa as $item) {
            fputcsv($out, [$item['taxa_iva'], $item['base'], $item['iva']], ';');
        }
    }
    fclose($out);
    exit;
}

$download = $format === 'word';
$chartPayload = null;
if (!$download && in_array($tipo, ['resumo', 'clientes', 'pagamentos', 'iva'], true)) {
    $chartPayload = $buildChartPayload($from, $to);
}

if ($download) {
    header('Content-Type: application/msword; charset=UTF-8');
    header('Content-Disposition: attachment; filename="relatorio-' . $tipo . '-' . date('Ymd-His') . '.doc"');
} else {
    require __DIR__ . '/../includes/header.php';
}
?>
<?php if (!$download): ?>
<style>
.fat-rel-charts { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
.fat-rel-charts .chart-card .card-body { padding: 12px 16px 20px; }
.fat-rel-chart-wrap { position: relative; height: 260px; }
.fat-rel-charts .chart-wide { grid-column: 1 / -1; }
@media (max-width: 960px) { .fat-rel-charts { grid-template-columns: 1fr; } .fat-rel-charts .chart-wide { grid-column: auto; } }
</style>
<div class="toolbar no-print">
    <p class="subtitle" style="margin:0">Relatórios e gráficos</p>
    <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Dashboard</a>
</div>
<div class="card no-print"><div class="card-body">
<form method="get"><div class="form-grid">
    <div class="form-group"><label>Tipo de relatório</label>
        <select name="tipo">
            <?php foreach ($titleMap as $k => $lbl): ?>
                <option value="<?= e($k) ?>" <?= $tipo === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group"><label>Data início</label><input class="form-control" type="date" name="from" value="<?= e($from) ?>"></div>
    <div class="form-group"><label>Data fim</label><input class="form-control" type="date" name="to" value="<?= e($to) ?>"></div>
</div>
<div class="form-actions">
    <button class="btn btn-primary" type="submit"><i class="fas fa-eye"></i> Ver relatório</button>
    <?php if ($tipo !== 'stock'): ?>
    <a class="btn btn-outline" href="<?= url('/admin/facturacao/relatorios.php?tipo=' . rawurlencode($tipo) . '&from=' . rawurlencode($from) . '&to=' . rawurlencode($to) . '&format=csv') ?>"><i class="fas fa-file-csv"></i> Exportar CSV</a>
    <?php endif; ?>
    <a class="btn btn-outline" target="_blank" href="<?= url('/admin/facturacao/relatorios.php?tipo=' . rawurlencode($tipo) . '&from=' . rawurlencode($from) . '&to=' . rawurlencode($to) . '&format=word') ?>"><i class="fas fa-file-word"></i> Word</a>
    <button class="btn btn-outline" type="button" onclick="window.print()"><i class="fas fa-print"></i> Imprimir / PDF</button>
</div></form>
</div></div>

<?php if ($chartPayload): ?>
<section class="fat-rel-charts no-print" aria-label="Gráficos do período">
    <div class="card chart-card chart-wide">
        <div class="card-head"><h2>Fluxo mensal (6 meses)</h2></div>
        <div class="card-body"><div class="fat-rel-chart-wrap"><canvas id="relChartFluxo"></canvas></div></div>
    </div>
    <?php if ($tipo === 'resumo' || $tipo === 'iva'): ?>
    <div class="card chart-card">
        <div class="card-head"><h2>IVA liquidado</h2></div>
        <div class="card-body"><div class="fat-rel-chart-wrap"><canvas id="relChartIva"></canvas></div></div>
    </div>
    <div class="card chart-card">
        <div class="card-head"><h2>Documentos por tipo</h2></div>
        <div class="card-body"><div class="fat-rel-chart-wrap"><canvas id="relChartTipos"></canvas></div></div>
    </div>
    <?php endif; ?>
    <?php if ($tipo === 'resumo' || $tipo === 'clientes'): ?>
    <div class="card chart-card">
        <div class="card-head"><h2>Top clientes</h2></div>
        <div class="card-body"><div class="fat-rel-chart-wrap"><canvas id="relChartClientes"></canvas></div></div>
    </div>
    <?php endif; ?>
    <?php if ($tipo === 'resumo' || $tipo === 'pagamentos'): ?>
    <div class="card chart-card">
        <div class="card-head"><h2>Recebimentos</h2></div>
        <div class="card-body"><div class="fat-rel-chart-wrap"><canvas id="relChartPagamentos"></canvas></div></div>
    </div>
    <?php endif; ?>
</section>
<?php endif; ?>
<?php endif; ?>

<div class="report-sheet">
    <div class="report-header"><div><h1><?= e($title) ?></h1><p><?= e($empresa['nome'] ?? '') ?> · NIF <?= e($empresa['nif'] ?? '') ?></p></div><div><strong>Período</strong><br><?= e(format_date($from, 'd/m/Y')) ?> a <?= e(format_date($to, 'd/m/Y')) ?></div></div>

    <?php if ($tipo === 'resumo'): ?>
    <table><thead><tr><th>Indicador</th><th>Valor</th></tr></thead><tbody>
        <tr><td>Vendas líquidas (FT, FR, FA − NC)</td><td><?= e(fat_format_money($resumo['vendas_liquidas'])) ?></td></tr>
        <tr><td>IVA liquidado</td><td><?= e(fat_format_money($resumo['iva_liquidado'])) ?></td></tr>
        <tr><td>N.º documentos de venda</td><td><?= (int) $resumo['documentos'] ?></td></tr>
        <tr><td>Total compras</td><td><?= e(fat_format_money($resumo['compras'])) ?></td></tr>
        <tr><td>IVA dedutível (compras)</td><td><?= e(fat_format_money($resumo['iva_compras'])) ?></td></tr>
        <tr><td>Recebimentos registados</td><td><?= e(fat_format_money($resumo['recebimentos'])) ?></td></tr>
        <tr class="total-row"><td>IVA estimado a pagar (liquidado − compras)</td><td><?= e(fat_format_money(max(0, $resumo['iva_liquidado'] - $resumo['iva_compras']))) ?></td></tr>
    </tbody></table>
    <?php elseif ($tipo === 'vendas'): ?>
    <table><thead><tr><th>Documento</th><th>Cliente</th><th>NIF</th><th>Data</th><th>Estado</th><th>Total</th></tr></thead><tbody><?php $total = 0; foreach ($vendas as $item): $total += $item['tipo'] === 'NC' ? -(float) $item['total'] : (float) $item['total']; ?><tr><td><?= e($item['tipo'] . ' ' . $item['numero_completo']) ?></td><td><?= e($item['cliente_nome']) ?></td><td><?= e($item['cliente_nif']) ?></td><td><?= e(format_date($item['data_documento'], 'd/m/Y')) ?></td><td><?= e($item['estado']) ?></td><td><?= e(fat_format_money($item['total'])) ?></td></tr><?php endforeach; ?><tr class="total-row"><td colspan="5">Total líquido</td><td><?= e(fat_format_money($total)) ?></td></tr></tbody></table>
    <?php elseif ($tipo === 'compras'): ?>
    <table><thead><tr><th>Referência</th><th>Fornecedor</th><th>NIF</th><th>Data</th><th>Subtotal</th><th>IVA</th><th>Total</th></tr></thead><tbody><?php $total = 0; foreach ($compras as $item): $total += (float) $item['total']; ?><tr><td><?= e($item['referencia']) ?></td><td><?= e($item['fornecedor_nome']) ?></td><td><?= e($item['fornecedor_nif']) ?></td><td><?= e(format_date($item['data_compra'], 'd/m/Y')) ?></td><td><?= e(fat_format_money($item['subtotal'])) ?></td><td><?= e(fat_format_money($item['total_iva'])) ?></td><td><?= e(fat_format_money($item['total'])) ?></td></tr><?php endforeach; ?><tr class="total-row"><td colspan="6">Total compras</td><td><?= e(fat_format_money($total)) ?></td></tr></tbody></table>
    <?php elseif ($tipo === 'clientes'): ?>
    <table><thead><tr><th>Cliente</th><th>NIF</th><th>Documentos</th><th>Total facturado</th></tr></thead><tbody><?php $total = 0; foreach ($clientesRel as $item): $total += (float) $item['total']; ?><tr><td><?= e($item['cliente_nome']) ?></td><td><?= e($item['cliente_nif']) ?></td><td><?= (int) $item['docs'] ?></td><td><?= e(fat_format_money($item['total'])) ?></td></tr><?php endforeach; ?><?php if (!$clientesRel): ?><tr><td colspan="4">Sem vendas a clientes registados no período.</td></tr><?php endif; ?><tr class="total-row"><td colspan="3">Total</td><td><?= e(fat_format_money($total)) ?></td></tr></tbody></table>
    <?php elseif ($tipo === 'pagamentos'): ?>
    <table><thead><tr><th>Meio de pagamento</th><th>Operações</th><th>Total recebido</th></tr></thead><tbody><?php $total = 0; foreach ($pagamentosRel as $item): $total += (float) $item['total']; $m = (string) $item['metodo']; ?><tr><td><?= e($pagLabels[$m] ?? ucfirst($m)) ?></td><td><?= (int) $item['n'] ?></td><td><?= e(fat_format_money($item['total'])) ?></td></tr><?php endforeach; ?><?php if (!$pagamentosRel): ?><tr><td colspan="3">Sem pagamentos registados no período.</td></tr><?php endif; ?><tr class="total-row"><td colspan="2">Total</td><td><?= e(fat_format_money($total)) ?></td></tr></tbody></table>
    <?php elseif ($tipo === 'iva'): ?>
    <table><thead><tr><th>Taxa IVA</th><th>Base tributável</th><th>IVA</th></tr></thead><tbody><?php $b = 0; $i = 0; foreach ($ivaPorTaxa as $item): $b += (float) $item['base']; $i += (float) $item['iva']; ?><tr><td><?= e($item['taxa_iva']) ?>%</td><td><?= e(fat_format_money($item['base'])) ?></td><td><?= e(fat_format_money($item['iva'])) ?></td></tr><?php endforeach; ?><?php if (!$ivaPorTaxa): ?><tr><td colspan="3">Sem documentos emitidos no período.</td></tr><?php endif; ?><tr class="total-row"><td>Total</td><td><?= e(fat_format_money($b)) ?></td><td><?= e(fat_format_money($i)) ?></td></tr></tbody></table>
    <?php else: ?>
    <table><thead><tr><th>Código</th><th>Produto</th><th>Stock</th><th>Custo stock</th><th>Venda stock</th><th>Lucro unit.</th><th>Lucro potencial</th><th>Validade</th></tr></thead><tbody><?php $stockCost = 0; $stockSales = 0; $stockProfit = 0; foreach ($produtos as $item): $sale = (float) ($item['preco_venda'] ?: $item['preco']); $cost = (float) $item['preco_compra']; $qty = $item['stock'] === null ? 0 : (float) $item['stock']; $stockCost += $qty * $cost; $stockSales += $qty * $sale; $stockProfit += $qty * ($sale - $cost); ?><tr><td><?= e($item['codigo']) ?></td><td><?= e($item['descricao']) ?></td><td><?= e($item['stock'] === null ? 'Não controlado' : $item['stock']) ?></td><td><?= e(fat_format_money($qty * $cost)) ?></td><td><?= e(fat_format_money($qty * $sale)) ?></td><td><?= e(fat_format_money($sale - $cost)) ?></td><td><?= e(fat_format_money($qty * ($sale - $cost))) ?></td><td><?= e($item['data_validade'] ?: '—') ?></td></tr><?php endforeach; ?><tr class="total-row"><td colspan="3">Totais</td><td><?= e(fat_format_money($stockCost)) ?></td><td><?= e(fat_format_money($stockSales)) ?></td><td></td><td><?= e(fat_format_money($stockProfit)) ?></td><td></td></tr></tbody></table>
    <?php endif; ?>
    <p class="report-footer">Gerado em <?= e(date('d/m/Y H:i')) ?> · <?= e($empresa['software_nome'] ?? 'Sistema de facturação') ?></p>
</div>
<?php if ($download): ?>
<style>body{font-family:Arial,sans-serif;color:#111}.report-sheet{max-width:1100px;margin:20px auto}.report-header{display:flex;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:12px;margin-bottom:20px}h1{font-size:22px;margin:0 0 5px}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #999;padding:7px;text-align:left}th{background:#eee}.total-row{font-weight:bold}.report-footer{margin-top:20px;font-size:11px;color:#555}</style>
<?php elseif (!$download): ?>
<style>@media print{.no-print{display:none!important}body{background:#fff}.report-sheet{margin:0;max-width:none}.report-header{margin-top:0}}.report-sheet{background:#fff;padding:24px;max-width:1100px;margin:20px auto}.report-header{display:flex;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:12px;margin-bottom:20px}.report-header h1{font-size:24px}.report-sheet table{width:100%;border-collapse:collapse}.report-sheet th,.report-sheet td{border:1px solid #ddd;padding:8px;text-align:left}.report-sheet th{background:#f3f4f6}.total-row{font-weight:bold}.report-footer{margin-top:20px;font-size:.8rem;color:#6b7280}</style>
<?php
if ($chartPayload) {
    $pageFootScripts = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>'
        . '<script>window.fatRelCharts = ' . json_encode($chartPayload, JSON_UNESCAPED_UNICODE) . ';</script>'
        . '<script src="' . e(url('/admin/facturacao/assets/relatorios-charts.js')) . '"></script>';
}
require __DIR__ . '/../includes/footer.php';
endif; ?>
