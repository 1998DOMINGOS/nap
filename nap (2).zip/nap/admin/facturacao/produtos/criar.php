<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$tipo = ($_GET['tipo'] ?? $_POST['tipo'] ?? 'produto') === 'servico' ? 'servico' : 'produto';
$pageTitle = $tipo === 'servico' ? 'Nova prestação de serviço' : 'Novo produto';
$current = 'fat-produtos';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $tipo = ($_POST['tipo'] ?? $tipo) === 'servico' ? 'servico' : 'produto';
    $codigo = fat_proximo_codigo_item($tipo);
    $descricao = trim($_POST['descricao'] ?? '');
    $unidade = trim($_POST['unidade'] ?? 'UN') ?: 'UN';
    $precoCompra = (float) str_replace(',', '.', $_POST['preco_compra'] ?? '0');
    $precoVenda = (float) str_replace(',', '.', $_POST['preco_venda'] ?? '0');
    $taxa = (float) str_replace(',', '.', $_POST['taxa_iva'] ?? '14');
    $isencao = strtoupper(trim($_POST['codigo_isencao'] ?? '')) ?: null;
    $stock = $_POST['stock'] === '' ? null : (float) str_replace(',', '.', $_POST['stock']);
    $validade = trim($_POST['data_validade'] ?? '') ?: null;
    $ativo = isset($_POST['ativo']) ? 1 : 0;

    if ($descricao === '') {
        $errors[] = 'A descrição é obrigatória.';
    }
    if ($precoCompra < 0 || $precoVenda < 0 || ($stock !== null && $stock < 0)) $errors[] = 'Preços e stock não podem ser negativos.';
    if ($taxa == 0.0 && (!$isencao || !isset(fat_agt_isencao_codigos()[$isencao]))) {
        $errors[] = 'Para IVA 0% seleccione o código de isenção AGT (Anexo 6.4).';
    }
    if ($taxa > 0) {
        $isencao = null;
    }
    if (!$errors) {
        try {
            db()->prepare('INSERT INTO fat_produtos (codigo,tipo,descricao,unidade,preco,preco_compra,preco_venda,taxa_iva,codigo_isencao,stock,data_validade,ativo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
                ->execute([$codigo, $tipo, $descricao, $unidade, $precoVenda, $precoCompra, $precoVenda, $taxa, $isencao, $tipo === 'servico' ? null : $stock, $tipo === 'servico' ? null : $validade, $ativo]);
            flash('success', $tipo === 'servico' ? 'Serviço criado.' : 'Produto criado.');
            redirect('/admin/facturacao/produtos/index.php?tipo=' . $tipo);
        } catch (Throwable $e) {
            $errors[] = 'Código já existe ou erro ao guardar.';
        }
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post"><?= csrf_field() ?><input type="hidden" name="tipo" value="<?= e($tipo) ?>">
    <div class="form-grid">
        <div class="form-group"><label>Código</label><input class="form-control" value="Gerado automaticamente ao guardar" disabled></div>
        <div class="form-group"><label>Unidade</label><input class="form-control" name="unidade" value="<?= e($_POST['unidade'] ?? 'UN') ?>"></div>
    </div>
    <div class="form-group"><label>Descrição *</label><input class="form-control" name="descricao" required value="<?= e($_POST['descricao'] ?? '') ?>"></div>
    <div class="form-grid">
        <?php if ($tipo === 'produto'): ?><div class="form-group"><label>Preço de compra (Kz)</label><input class="form-control" name="preco_compra" value="<?= e($_POST['preco_compra'] ?? '0') ?>"></div><?php endif; ?>
        <div class="form-group"><label>Preço de venda (Kz)</label><input class="form-control" name="preco_venda" value="<?= e($_POST['preco_venda'] ?? '0') ?>"></div>
        <div class="form-group"><label>Taxa IVA %</label>
            <select name="taxa_iva">
                <?php foreach ([14, 7, 5, 0] as $t): ?>
                    <option value="<?= $t ?>" <?= ((string)($_POST['taxa_iva'] ?? '14') === (string)$t) ? 'selected' : '' ?>><?= $t ?>%</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><label>Cód. isenção IVA (se 0%)</label>
            <select name="codigo_isencao">
                <option value="">—</option>
                <?php foreach (fat_agt_isencao_codigos() as $code => $label): ?>
                    <option value="<?= e($code) ?>" <?= (($_POST['codigo_isencao'] ?? '') === $code) ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if ($tipo === 'produto'): ?><div class="form-group"><label>Stock (opcional)</label><input class="form-control" name="stock" value="<?= e($_POST['stock'] ?? '') ?>"></div><div class="form-group"><label>Data de validade</label><input class="form-control" type="date" name="data_validade" value="<?= e($_POST['data_validade'] ?? '') ?>"></div><?php endif; ?>
    </div>
    <label><input type="checkbox" name="ativo" checked> Activo</label>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit">Guardar</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/produtos/index.php?tipo=' . $tipo) ?>">Cancelar</a>
    </div>
</form>
</div></div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
