<?php
require_once __DIR__ . '/../../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$tipo = ($_GET['tipo'] ?? 'produto') === 'servico' ? 'servico' : 'produto';
$pageTitle = $tipo === 'servico' ? 'Prestação de serviços' : 'Produtos';
$current = 'fat-produtos';
$stmtItems = db()->prepare('SELECT * FROM fat_produtos WHERE tipo=? ORDER BY descricao');
$stmtItems->execute([$tipo]);
$items = $stmtItems->fetchAll();
$today = new DateTimeImmutable('today');
$validityAlerts = [];
$stockPurchaseTotal = 0.0;
$stockSaleTotal = 0.0;
$potentialProfit = 0.0;
foreach ($items as &$item) {
    $item['preco_venda'] = (float) ($item['preco_venda'] ?: $item['preco']);
    $item['preco_compra'] = (float) $item['preco_compra'];
    $item['lucro_unitario'] = $item['preco_venda'] - $item['preco_compra'];
    $item['margem'] = $item['preco_venda'] > 0 ? ($item['lucro_unitario'] / $item['preco_venda']) * 100 : 0;
    if ($item['stock'] !== null) {
        $stockPurchaseTotal += $item['stock'] * $item['preco_compra'];
        $stockSaleTotal += $item['stock'] * $item['preco_venda'];
        $potentialProfit += $item['stock'] * $item['lucro_unitario'];
    }
    if (!empty($item['data_validade'])) {
        $expiry = new DateTimeImmutable($item['data_validade']);
        $days = (int) $today->diff($expiry)->format('%r%a');
        if ($days < 0 || $days <= 30) $validityAlerts[] = [$item['descricao'], $item['data_validade'], $days];
    }
}
unset($item);
require __DIR__ . '/../../includes/header.php';
?>
<div class="toolbar">
    <p class="subtitle" style="margin:0"><a href="<?= url('/admin/facturacao/index.php') ?>">Facturação</a> / <?= e($pageTitle) ?></p>
    <div class="actions"><a class="btn <?= $tipo === 'produto' ? 'btn-primary' : 'btn-outline' ?>" href="<?= url('/admin/facturacao/produtos/index.php?tipo=produto') ?>"><i class="fas fa-box"></i> Produtos</a><a class="btn <?= $tipo === 'servico' ? 'btn-primary' : 'btn-outline' ?>" href="<?= url('/admin/facturacao/produtos/index.php?tipo=servico') ?>"><i class="fas fa-handshake"></i> Serviços</a><a class="btn btn-primary" href="<?= url('/admin/facturacao/produtos/criar.php?tipo=' . $tipo) ?>"><i class="fas fa-plus"></i> Novo <?= $tipo === 'servico' ? 'serviço' : 'produto' ?></a></div>
</div>
<?php if ($validityAlerts): ?><div class="alert alert-error"><strong>Alertas de validade:</strong><?php foreach ($validityAlerts as $alert): ?> <span><?= e($alert[0]) ?> — <?= e(format_date($alert[1], 'd/m/Y')) ?> (<?= $alert[2] < 0 ? 'vencido' : 'vence em ' . $alert[2] . ' dias' ?>)</span><?php endforeach; ?></div><?php endif; ?>
<div class="stats-grid"><article class="stat-card"><div><span>Stock a custo</span><strong><?= e(fat_format_money($stockPurchaseTotal)) ?></strong></div></article><article class="stat-card"><div><span>Stock a venda</span><strong><?= e(fat_format_money($stockSaleTotal)) ?></strong></div></article><article class="stat-card"><div><span>Lucro potencial</span><strong><?= e(fat_format_money($potentialProfit)) ?></strong></div></article></div>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>Código</th><th>Descrição</th><th>Compra</th><th>Venda</th><th>Lucro</th><?php if ($tipo === 'produto'): ?><th>Stock</th><th>Validade</th><?php endif; ?><th>IVA</th><th>Estado</th><th></th></tr></thead>
<tbody>
<?php if (!$items): ?><tr><td colspan="<?= $tipo === 'produto' ? 10 : 8 ?>" class="empty">Sem <?= $tipo === 'servico' ? 'serviços' : 'produtos' ?> cadastrados.</td></tr>
<?php else: foreach ($items as $p): ?>
<tr>
    <td><?= e($p['codigo']) ?></td>
    <td><strong><?= e($p['descricao']) ?></strong></td>
    <td><?= e(fat_format_money($p['preco_compra'])) ?></td>
    <td><?= e(fat_format_money($p['preco_venda'])) ?></td>
    <td><?= e(fat_format_money($p['lucro_unitario'])) ?><div style="font-size:.8rem"><?= e(number_format($p['margem'], 1, ',', '.')) ?>%</div></td>
    <?php if ($tipo === 'produto'): ?><td><?= e(rtrim(rtrim(number_format((float) $p['stock'], 3, ',', '.'), '0'), ',')) ?></td><td><?= $p['data_validade'] ? e(format_date($p['data_validade'], 'd/m/Y')) : '—' ?></td><?php endif; ?>
    <td><?= e(number_format((float)$p['taxa_iva'], 2, ',', '.')) ?>%</td>
    <td><?= (int)$p['ativo'] ? 'Activo' : 'Inactivo' ?></td>
    <td class="actions"><a class="btn btn-sm btn-outline" href="<?= url('/admin/facturacao/produtos/editar.php?id='.$p['id']) ?>"><i class="fas fa-pen"></i></a></td>
</tr>
<?php endforeach; endif; ?>
</tbody></table></div></div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
