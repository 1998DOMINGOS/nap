<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$caixa = fat_require_caixa_aberto();
$pageTitle = 'Vender';
$current = 'fat-vender';
$errors = [];
$userId = (int) current_user()['id'];

$clientes = db()->query('SELECT id, nome, nif FROM fat_clientes WHERE ativo=1 ORDER BY nome')->fetchAll();
$produtos = db()->query('SELECT * FROM fat_produtos WHERE ativo=1 ORDER BY descricao')->fetchAll();
$cfId = (int) (db()->query("SELECT id FROM fat_clientes WHERE nif='999999999' LIMIT 1")->fetchColumn() ?: 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $clienteId = (int) ($_POST['cliente_id'] ?? $cfId);
    $metodo = $_POST['metodo'] ?? 'numerario';
    $referencia = trim($_POST['referencia'] ?? '');
    $prodIds = $_POST['produto_id'] ?? [];
    $qtys = $_POST['quantidade'] ?? [];

    $linhas = [];
    foreach ($prodIds as $i => $pid) {
        $pid = (int) $pid;
        $qty = (float) str_replace(',', '.', $qtys[$i] ?? '0');
        if ($pid < 1 || $qty <= 0) {
            continue;
        }
        $ps = db()->prepare('SELECT * FROM fat_produtos WHERE id=? AND ativo=1');
        $ps->execute([$pid]);
        $p = $ps->fetch();
        if (!$p) {
            continue;
        }
        $linhas[] = [
            'produto_id' => $pid,
            'codigo' => $p['codigo'],
            'descricao' => $p['descricao'],
            'quantidade' => $qty,
            'unidade' => $p['unidade'],
            'preco_unitario' => (float) ($p['preco_venda'] ?: $p['preco']),
            'taxa_iva' => (float) $p['taxa_iva'],
        ];
    }

    try {
        $doc = fat_vender_no_caixa($caixa, $userId, $clienteId, $linhas, $metodo, $referencia);
        flash('success', 'Venda concluída: ' . $doc['numero_completo'] . ' — ' . fat_format_money($doc['total']));
        redirect('/admin/facturacao/documentos/imprimir.php?id=' . $doc['id']);
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

$produtosJson = array_map(static fn($p) => [
    'id' => (int) $p['id'],
    'codigo' => $p['codigo'],
    'tipo' => $p['tipo'] ?? 'produto',
    'descricao' => $p['descricao'],
    'preco' => (float) ($p['preco_venda'] ?: $p['preco']),
    'taxa_iva' => (float) $p['taxa_iva'],
    'stock' => $p['stock'],
], $produtos);

require __DIR__ . '/../includes/header.php';
?>

<div class="toolbar">
    <p class="subtitle" style="margin:0">
        <a href="<?= url('/admin/facturacao/index.php') ?>">Facturação</a> /
        <a href="<?= url('/admin/facturacao/caixa.php') ?>">Caixa #<?= (int)$caixa['id'] ?></a> / Vender
    </p>
    <a class="btn btn-outline" href="<?= url('/admin/facturacao/caixa.php') ?>"><i class="fas fa-lock"></i> Gerir caixa</a>
</div>

<div class="alert alert-success">
    Caixa aberto desde <?= e(format_date($caixa['aberto_em'], 'd/m/Y H:i')) ?> · Fundo <?= e(fat_format_money($caixa['fundo_inicial'])) ?>
</div>

<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>

<div class="card"><div class="card-body">
<form method="post" id="vendaForm"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Cliente</label>
            <select name="cliente_id" required>
                <?php foreach ($clientes as $c): ?>
                    <option value="<?= (int)$c['id'] ?>" <?= $cfId === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['nome']) ?> (<?= e($c['nif']) ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><label>Pagamento</label>
            <select name="metodo">
                <option value="numerario">Numerário</option>
                <option value="multicaixa">Multicaixa</option>
                <option value="transferencia">Transferência</option>
                <option value="outro">Outro</option>
            </select>
        </div>
        <div class="form-group"><label>Referência</label><input class="form-control" name="referencia" placeholder="Opcional"></div>
    </div>

    <h3 style="margin:16px 0 8px">Produtos e serviços</h3>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Produto</th><th>Qtd</th><th>Preço</th><th>IVA</th><th>Subtotal</th><th></th></tr></thead>
            <tbody id="vendaBody"></tbody>
            <tfoot>
                <tr><td colspan="4" class="right"><strong>Total</strong></td><td colspan="2"><strong id="vendaTotal">0,00 Kz</strong></td></tr>
            </tfoot>
        </table>
    </div>
    <button type="button" class="btn btn-outline" id="addProd" style="margin-top:10px"><i class="fas fa-plus"></i> Adicionar produto</button>

    <div class="form-actions">
        <button class="btn btn-primary" type="submit" style="font-size:1.05rem;padding:14px 28px">
            <i class="fas fa-cash-register"></i> Confirmar venda
        </button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Cancelar</a>
    </div>
</form>
</div></div>

<script>
const PRODUTOS = <?= json_encode($produtosJson, JSON_UNESCAPED_UNICODE) ?>;
const body = document.getElementById('vendaBody');
const totalEl = document.getElementById('vendaTotal');

function money(n) {
  return n.toLocaleString('pt-AO', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' Kz';
}

function recalc() {
  let total = 0;
  body.querySelectorAll('tr').forEach(tr => {
    const sel = tr.querySelector('.prod');
    const qty = parseFloat(String(tr.querySelector('.qty').value).replace(',','.')) || 0;
    const opt = sel.selectedOptions[0];
    const preco = opt && opt.value ? parseFloat(opt.dataset.preco) : 0;
    const iva = opt && opt.value ? parseFloat(opt.dataset.iva) : 0;
    const line = qty * preco * (1 + iva/100);
    tr.querySelector('.preco').textContent = money(preco);
    tr.querySelector('.iva').textContent = iva.toFixed(2) + '%';
    tr.querySelector('.sub').textContent = money(line);
    total += line;
  });
  totalEl.textContent = money(total);
}

function addRow() {
  const tr = document.createElement('tr');
  const opts = PRODUTOS.map(p =>
    `<option value="${p.id}" data-preco="${p.preco}" data-iva="${p.taxa_iva}">${p.tipo === 'servico' ? 'Serviço' : 'Produto'} · ${p.codigo} — ${p.descricao}</option>`
  ).join('');
  tr.innerHTML = `
    <td><select name="produto_id[]" class="prod formrequired"><option value="">— escolher —</option>${opts}</select></td>
    <td><input class="form-control qty" name="quantidade[]" value="1" style="width:90px" required></td>
    <td class="preco">—</td>
    <td class="iva">—</td>
    <td class="sub">—</td>
    <td><button type="button" class="btn btn-sm btn-danger rm">×</button></td>`;
  body.appendChild(tr);
  tr.querySelector('.prod').addEventListener('change', recalc);
  tr.querySelector('.qty').addEventListener('input', recalc);
  tr.querySelector('.rm').addEventListener('click', () => { tr.remove(); recalc(); });
  recalc();
}

document.getElementById('addProd').addEventListener('click', addRow);
document.getElementById('vendaForm').addEventListener('submit', function(e) {
  if (!body.querySelector('tr')) {
    e.preventDefault();
    alert('Adicione pelo menos um produto.');
  }
});
addRow();
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>
