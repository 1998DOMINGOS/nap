<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
fat_agt_compliance_migrate();

$pageTitle = 'Recibos RC / AR';
$current = 'fat-recibos';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $facturaId = (int) ($_POST['factura_id'] ?? 0);
    $valor = (float) str_replace(',', '.', $_POST['valor'] ?? '0');
    $metodo = trim($_POST['metodo'] ?? 'numerario');
    $tipoRec = strtoupper(trim($_POST['tipo_recibo'] ?? 'RC')) === 'AR' ? 'AR' : 'RC';
    try {
        $docId = fat_agt_criar_rascunho_recibo($facturaId, $valor, $metodo, (int) current_user()['id'], $tipoRec);
        $emitido = fat_emitir_documento($docId, (int) current_user()['id'], '1');
        flash('success', 'Recibo emitido: ' . $emitido['numero_completo']);
        redirect('/admin/facturacao/documentos/ver.php?id=' . $docId);
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

$facturas = db()->query("SELECT id, numero_completo, cliente_nome, total, data_documento FROM fat_documentos
    WHERE estado='emitido' AND tipo IN ('FT','FR') ORDER BY id DESC LIMIT 80")->fetchAll();

require __DIR__ . '/../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<p style="font-size:.9rem;color:#6b7280">Emissão de <strong>RC</strong> ou <strong>AR</strong> ligado a factura FT/FR (SAF-T 4.4 Payments).</p>
<form method="post"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Tipo</label><select name="tipo_recibo"><option value="RC">RC — Recibo</option><option value="AR">AR — Aviso de cobrança</option></select></div>
        <div class="form-group"><label>Factura *</label>
            <select name="factura_id" required>
                <option value="">— seleccionar —</option>
                <?php foreach ($facturas as $f): ?>
                    <option value="<?= (int)$f['id'] ?>"><?= e($f['numero_completo']) ?> — <?= e($f['cliente_nome']) ?> (<?= e(fat_format_money($f['total'])) ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><label>Valor recebido</label><input class="form-control" name="valor" required placeholder="0,00"></div>
        <div class="form-group"><label>Meio</label>
            <select name="metodo"><option value="numerario">Numerário</option><option value="multicaixa">Multicaixa</option><option value="transferencia">Transferência</option></select>
        </div>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-receipt"></i> Emitir RC</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/documentos/index.php') ?>">Documentos</a>
    </div>
</form>
</div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
