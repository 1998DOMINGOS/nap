<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();
fat_agt_compliance_migrate();

$pageTitle = 'Séries documentais';
$current = 'fat-empresa';
$ok = null;
$err = null;
$ano = max(2000, (int) ($_GET['ano'] ?? date('Y')));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $id = (int) ($_POST['id'] ?? 0);
    $des = !empty($_POST['descontinuada']) ? 1 : 0;
    $form = !empty($_POST['modo_formacao']) ? 1 : 0;
    $integ = !empty($_POST['serie_integrada']) ? 1 : 0;
    try {
        db()->prepare('UPDATE fat_series SET descontinuada=?, modo_formacao=?, serie_integrada=? WHERE id=?')
            ->execute([$des, $form, $integ, $id]);
        $ok = 'Série actualizada.';
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

$rows = db()->prepare('SELECT * FROM fat_series WHERE ano=? ORDER BY tipo, serie');
$rows->execute([$ano]);
$series = $rows->fetchAll();

require __DIR__ . '/../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endif; ?>
<p style="font-size:.9rem;color:#6b7280">Requisitos AGT §8–9: séries descontinuadas, formação e integração. Em modo formação (empresa) só pode emitir em séries marcadas para formação.</p>
<form method="get" class="form-grid" style="margin-bottom:16px;max-width:320px">
    <div class="form-group"><label>Ano</label><input class="form-control" type="number" name="ano" value="<?= (int) $ano ?>"></div>
    <div class="form-group" style="align-self:end"><button class="btn btn-outline" type="submit">Filtrar</button></div>
</form>
<div class="table-wrap">
<table>
<thead><tr><th>Tipo</th><th>Série</th><th>Próximo n.º</th><th>Activa</th><th>Descontinuada</th><th>Formação</th><th>Integrada</th><th></th></tr></thead>
<tbody>
<?php foreach ($series as $s): ?>
<tr>
    <td><?= e(fat_tipo_label($s['tipo'])) ?> (<?= e($s['tipo']) ?>)</td>
    <td><?= e($s['serie']) ?></td>
    <td><?= (int) $s['proximo_numero'] ?></td>
    <td><?= (int) $s['ativo'] ? 'Sim' : 'Não' ?></td>
    <td colspan="3">
        <form method="post" style="display:flex;flex-wrap:wrap;gap:12px;align-items:center">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
            <label><input type="checkbox" name="descontinuada" value="1" <?= !empty($s['descontinuada']) ? 'checked' : '' ?>> Descontinuada</label>
            <label><input type="checkbox" name="modo_formacao" value="1" <?= !empty($s['modo_formacao']) ? 'checked' : '' ?>> Formação</label>
            <label><input type="checkbox" name="serie_integrada" value="1" <?= !empty($s['serie_integrada']) ? 'checked' : '' ?>> Integrada</label>
            <button class="btn btn-sm btn-primary" type="submit">Guardar</button>
        </form>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<div class="form-actions" style="margin-top:16px">
    <a class="btn btn-outline" href="<?= url('/admin/facturacao/empresa.php') ?>">Empresa fiscal</a>
    <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Voltar</a>
</div>
</div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
