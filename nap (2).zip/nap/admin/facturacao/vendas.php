<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Vendas';
$pageSubtitle = is_admin_user() ? 'Todas as vendas da empresa' : 'As suas vendas registadas';
$current = 'fat-vendas';

$userId = (int) ($_SESSION['user_id'] ?? 0);
$verTodas = is_admin_user();

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
    $from = date('Y-m-01');
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
    $to = date('Y-m-d');
}
if ($from > $to) {
    [$from, $to] = [$to, $from];
}

$operadorFiltro = $verTodas ? (int) ($_GET['operador'] ?? 0) : 0;

$sql = "SELECT d.id, d.tipo, d.numero_completo, d.cliente_nome, d.cliente_nif, d.total, d.data_documento, d.data_sistema,
               d.caixa_id, d.criado_por, u.nome AS operador_nome,
               (SELECT p.metodo FROM fat_pagamentos p WHERE p.documento_id = d.id ORDER BY p.id LIMIT 1) AS metodo_pag
        FROM fat_documentos d
        LEFT JOIN usuarios u ON u.id = d.criado_por
        WHERE d.estado = 'emitido' AND d.tipo IN ('FR','FT')
          AND d.data_documento BETWEEN ? AND ?";
$params = [$from, $to];

if (!$verTodas) {
    $sql .= ' AND d.criado_por = ?';
    $params[] = $userId;
} elseif ($operadorFiltro > 0) {
    $sql .= ' AND d.criado_por = ?';
    $params[] = $operadorFiltro;
}

$sql .= ' ORDER BY d.id DESC LIMIT 500';

$stmt = db()->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

$totalVendas = 0.0;
foreach ($items as $row) {
    $totalVendas += (float) $row['total'];
}

$operadores = [];
if ($verTodas) {
    $operadores = db()->query(
        "SELECT DISTINCT u.id, u.nome FROM usuarios u
         INNER JOIN fat_documentos d ON d.criado_por = u.id
         WHERE d.estado = 'emitido' AND d.tipo IN ('FR','FT')
         ORDER BY u.nome"
    )->fetchAll();
}

$pagLabels = ['numerario' => 'Numerário', 'multicaixa' => 'Multicaixa', 'transferencia' => 'Transferência', 'cartao' => 'Cartão', 'outro' => 'Outro'];

require __DIR__ . '/../includes/header.php';
?>

<div class="toolbar">
    <p class="subtitle" style="margin:0"><a href="<?= url('/admin/facturacao/index.php') ?>">Facturação</a> / Vendas</p>
    <?php if (fat_caixa_aberto()): ?>
        <a class="btn btn-primary" href="<?= url('/admin/facturacao/vender.php') ?>"><i class="fas fa-cash-register"></i> Nova venda</a>
    <?php endif; ?>
</div>

<div class="card no-print"><div class="card-body">
<form method="get"><div class="form-grid">
    <div class="form-group"><label>Data início</label><input class="form-control" type="date" name="from" value="<?= e($from) ?>"></div>
    <div class="form-group"><label>Data fim</label><input class="form-control" type="date" name="to" value="<?= e($to) ?>"></div>
    <?php if ($verTodas): ?>
    <div class="form-group"><label>Operador</label>
        <select name="operador">
            <option value="0">Todos</option>
            <?php foreach ($operadores as $op): ?>
                <option value="<?= (int) $op['id'] ?>" <?= $operadorFiltro === (int) $op['id'] ? 'selected' : '' ?>><?= e($op['nome']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php endif; ?>
</div>
<div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-filter"></i> Filtrar</button></div>
</form>
</div></div>

<section class="stats-grid" style="margin-top:16px">
    <article class="stat-card">
        <div class="stat-icon green"><i class="fas fa-receipt"></i></div>
        <div><span>Vendas no período</span><strong><?= count($items) ?></strong></div>
    </article>
    <article class="stat-card">
        <div class="stat-icon dark"><i class="fas fa-coins"></i></div>
        <div><span>Total (FR + FT)</span><strong><?= e(fat_format_money($totalVendas)) ?></strong></div>
    </article>
</section>

<div class="card" style="margin-top:16px">
    <div class="card-head">
        <h2><?= $verTodas ? 'Vendas realizadas' : 'As minhas vendas' ?></h2>
        <span style="font-size:.85rem;color:#6b7280"><?= e(format_date($from, 'd/m/Y')) ?> — <?= e(format_date($to, 'd/m/Y')) ?></span>
    </div>
    <div class="table-wrap"><table>
        <thead><tr>
            <th>Documento</th>
            <th>Cliente</th>
            <th>Data</th>
            <?php if ($verTodas): ?><th>Operador</th><?php endif; ?>
            <th>Pagamento</th>
            <th>Total</th>
            <th></th>
        </tr></thead>
        <tbody>
        <?php if (!$items): ?>
            <tr><td colspan="<?= $verTodas ? 7 : 6 ?>" class="empty">Nenhuma venda emitida neste período<?= $verTodas ? '' : ' por si' ?>.</td></tr>
        <?php else: foreach ($items as $d):
            $mp = (string) ($d['metodo_pag'] ?? '');
            ?>
            <tr>
                <td>
                    <strong><?= e($d['numero_completo']) ?></strong>
                    <div style="font-size:.8rem;color:#6b7280"><?= e(fat_tipo_label($d['tipo'])) ?><?php if ($d['caixa_id']): ?> · Caixa #<?= (int) $d['caixa_id'] ?><?php endif; ?></div>
                </td>
                <td><?= e($d['cliente_nome']) ?><div style="font-size:.8rem">NIF <?= e($d['cliente_nif']) ?></div></td>
                <td><?= e(format_date($d['data_documento'], 'd/m/Y')) ?><div style="font-size:.75rem;color:#9ca3af"><?= e(format_date($d['data_sistema'], 'H:i')) ?></div></td>
                <?php if ($verTodas): ?>
                <td><?= e($d['operador_nome'] ?: '—') ?></td>
                <?php endif; ?>
                <td><?= $mp !== '' ? e($pagLabels[$mp] ?? ucfirst($mp)) : '—' ?></td>
                <td><?= e(fat_format_money($d['total'])) ?></td>
                <td class="actions"><a class="btn btn-sm btn-outline" href="<?= url('/admin/facturacao/documentos/ver.php?id=' . (int) $d['id']) ?>">Ver</a></td>
            </tr>
        <?php endforeach; endif; ?>
        <?php if ($items): ?>
            <tr class="total-row"><td colspan="<?= $verTodas ? 5 : 4 ?>">Total</td><td><?= e(fat_format_money($totalVendas)) ?></td><td></td></tr>
        <?php endif; ?>
        </tbody>
    </table></div>
    <?php if (count($items) >= 500): ?>
    <p style="padding:12px 16px;font-size:.85rem;color:#6b7280;margin:0">Mostrando as últimas 500 vendas do período. Ajuste as datas para ver mais.</p>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
