<?php
require_once __DIR__ . '/../../config/app.php';
require_facturacao();
ensure_facturacao_schema();

$pageTitle = 'Empresa fiscal';
$current = 'fat-empresa';
$emp = fat_empresa();
$errors = [];
$ok = null;

if (($_GET['download'] ?? '') === 'public-key') {
    redirect('/admin/facturacao/certificacao.php?download=chave');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $nif = preg_replace('/\s+/', '', trim($_POST['nif'] ?? ''));
    $morada = trim($_POST['morada'] ?? '');
    $cidade = trim($_POST['cidade'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $banco = trim($_POST['banco'] ?? '');
    $titularPagamento = trim($_POST['titular_pagamento'] ?? APP_NAME);
    $iban = trim($_POST['iban'] ?? '');
    $numeroConta = trim($_POST['numero_conta'] ?? '');
    $regime = in_array($_POST['regime_iva'] ?? '', ['geral', 'simplificado', 'isento'], true) ? $_POST['regime_iva'] : 'geral';
    $agtAmbiente = ($_POST['agt_ambiente'] ?? '') === 'producao' ? 'producao' : 'homologacao';
    $agtUser = trim($_POST['agt_api_user'] ?? '');
    $agtPass = trim($_POST['agt_api_pass'] ?? '');
    $agtAuto = !empty($_POST['agt_auto_envio']) ? 1 : 0;
    $agtSimular = !empty($_POST['agt_simular']) ? 1 : 0;
    $agtEac = trim($_POST['agt_eac_code'] ?? '');
    $agtSigVer = max(1, (int) ($_POST['agt_signature_version'] ?? 1));
    $agtKeyProd = trim($_POST['agt_chave_produtor_path'] ?? '');
    $agtKeyEmit = trim($_POST['agt_chave_emitente_path'] ?? '');

    if ($nome === '') {
        $errors[] = 'Nome da empresa obrigatório.';
    }
    if (!$errors) {
        try {
            $saftBasis = $_POST['saft_tax_accounting_basis'] ?? 'F';
            if (!in_array($saftBasis, ['F', 'I', 'C'], true)) {
                $saftBasis = 'F';
            }
            fat_agt_save_software_config((int) $emp['id'], [
                'software_nome' => trim($_POST['software_nome'] ?? ''),
                'software_versao' => trim($_POST['software_versao'] ?? ''),
                'produtor_nome' => trim($_POST['produtor_nome'] ?? ''),
                'produtor_nif' => trim($_POST['produtor_nif'] ?? ''),
                'agt_software_product_id' => trim($_POST['agt_software_product_id'] ?? ''),
                'software_validation_number' => trim($_POST['software_validation_number'] ?? ''),
                'saft_tax_accounting_basis' => $saftBasis,
                'agt_saft_integrated' => ($saftBasis !== 'F' && !empty($_POST['agt_saft_integrated'])) ? 1 : 0,
                'agt_signature_version' => max(1, (int) ($_POST['agt_signature_version'] ?? 1)),
            ], !empty($_POST['regenerar_saft_cert']));
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
    if (!$errors) {
        $passSql = '';
        $params = [$nome, $nif, $morada, $cidade, $telefone, $email, $banco ?: null, $titularPagamento ?: APP_NAME, $iban ?: null, $numeroConta ?: null, $regime, $agtAmbiente, $agtUser ?: null, $agtAuto, $agtSimular, $agtEac ?: null, $agtKeyProd ?: null, $agtKeyEmit ?: null];
        if ($agtPass !== '') {
            $passSql = ', agt_api_pass=?';
            $params[] = $agtPass;
        }
        $modoFormacao = !empty($_POST['modo_formacao']) ? 1 : 0;
        $backupDias = max(1, (int) ($_POST['agt_backup_dias'] ?? 7));
        $pwdMax = max(30, (int) ($_POST['agt_password_max_days'] ?? 90));
        $estCod = trim($_POST['estabelecimento_codigo'] ?? '') ?: null;
        $estNome = trim($_POST['estabelecimento_nome'] ?? '') ?: null;
        $params[] = $modoFormacao;
        $params[] = $backupDias;
        $params[] = $pwdMax;
        $params[] = $estCod;
        $params[] = $estNome;
        $params[] = $emp['id'];
        db()->prepare('UPDATE fat_empresa SET nome=?,nif=?,morada=?,cidade=?,telefone=?,email=?,banco=?,titular_pagamento=?,iban=?,numero_conta=?,regime_iva=?,agt_ambiente=?,agt_api_user=?,agt_auto_envio=?,agt_simular=?,agt_eac_code=?,agt_chave_produtor_path=?,agt_chave_emitente_path=?,modo_formacao=?,agt_backup_dias=?,agt_password_max_days=?,estabelecimento_codigo=?,estabelecimento_nome=?' . $passSql . ' WHERE id=?')
            ->execute($params);
        $ok = 'Dados guardados.';
        if (!empty($_POST['regenerar_saft_cert'])) {
            $ok .= ' Documentos reassinados e anexo SAF-T actualizado.';
        }
        $emp = fat_empresa();
    }
}

$emp = fat_empresa();
$pidSugestao = ($emp && trim((string) ($emp['software_nome'] ?? '')) !== '' && trim((string) ($emp['produtor_nome'] ?? '')) !== '')
    ? fat_saft_product_id_from_empresa($emp) : '';

require __DIR__ . '/../includes/header.php';
?>
<div class="card"><div class="card-body">
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post"><?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome comercial emitente *</label><input class="form-control" name="nome" required value="<?= e($emp['nome']) ?>"></div>
        <div class="form-group"><label>NIF emitente</label><input class="form-control" name="nif" value="<?= e($emp['nif']) ?>" placeholder="NIF angolano"></div>
    </div>
    <div class="form-group"><label>Morada</label><input class="form-control" name="morada" value="<?= e($emp['morada'] ?? '') ?>"></div>
    <div class="form-grid">
        <div class="form-group"><label>Cidade</label><input class="form-control" name="cidade" value="<?= e($emp['cidade'] ?? '') ?>"></div>
        <div class="form-group"><label>Telefone</label><input class="form-control" name="telefone" value="<?= e($emp['telefone'] ?? '') ?>"></div>
        <div class="form-group"><label>Email</label><input class="form-control" type="email" name="email" value="<?= e($emp['email'] ?? '') ?>"></div>
    </div>
    <h3>Dados para pagamento</h3>
    <div class="form-grid">
        <div class="form-group"><label>Banco</label><input class="form-control" name="banco" value="<?= e($emp['banco'] ?? '') ?>"></div>
        <div class="form-group"><label>Titular</label><input class="form-control" name="titular_pagamento" value="<?= e($emp['titular_pagamento'] ?? APP_NAME) ?>"></div>
        <div class="form-group"><label>IBAN</label><input class="form-control" name="iban" value="<?= e($emp['iban'] ?? '') ?>"></div>
        <div class="form-group"><label>Número de conta</label><input class="form-control" name="numero_conta" value="<?= e($emp['numero_conta'] ?? '') ?>"></div>
    </div>
    <div class="form-group"><label>Regime IVA</label>
        <select name="regime_iva">
            <?php foreach (['geral' => 'Geral', 'simplificado' => 'Simplificado', 'isento' => 'Isento'] as $k => $lab): ?>
                <option value="<?= $k ?>" <?= ($emp['regime_iva'] ?? '') === $k ? 'selected' : '' ?>><?= $lab ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <h3>Software, SAF-T e certificação AGT (Modelo 08)</h3>
    <p style="font-size:.85rem;color:#6b7280;margin-bottom:12px">Uma única configuração alimenta facturas, SAF-T, API FE e portal fornecedor. <a href="<?= url('/admin/facturacao/certificacao.php') ?>">Anexos de certificação</a></p>
    <div class="form-grid">
        <div class="form-group"><label>Nome do programa (portal)</label><input class="form-control" name="software_nome" value="<?= e($emp['software_nome'] ?? '') ?>" required></div>
        <div class="form-group"><label>Versão</label><input class="form-control" name="software_versao" value="<?= e($emp['software_versao'] ?? '1.0.0') ?>" required></div>
        <div class="form-group"><label>Nome do produtor</label><input class="form-control" name="produtor_nome" value="<?= e($emp['produtor_nome'] ?? '') ?>" required></div>
        <div class="form-group"><label>NIF do produtor</label><input class="form-control" name="produtor_nif" value="<?= e($emp['produtor_nif'] ?? '') ?>" required></div>
        <div class="form-group"><label>Product ID (SAF-T + API)</label><input class="form-control" name="agt_software_product_id" value="<?= e($emp['agt_software_product_id'] ?? '') ?>" placeholder="<?= e($pidSugestao ?: 'Programa/Produtor') ?>"><p style="font-size:.8rem;color:#6b7280;margin:4px 0 0">Sugestão: <code><?= e($pidSugestao) ?></code> — deixe vazio para usar automaticamente.</p></div>
        <div class="form-group"><label>Número de validação AGT</label><input class="form-control" name="software_validation_number" value="<?= e($emp['software_validation_number'] ?? '') ?>" placeholder="000/AGT/<?= (int) date('Y') ?> ou NNN/AGT/AAAA" required pattern="\d+/AGT/\d{4}"><p style="font-size:.8rem;color:#6b7280;margin:4px 0 0">Único número para SAF-T, HashControl e impressão (substitui o antigo campo duplicado «certificação»).</p></div>
        <div class="form-group"><label>Tipo de ficheiro SAF-T</label>
            <select name="saft_tax_accounting_basis">
                <?php
                $basis = fat_saft_tax_accounting_basis($emp);
                foreach (['F' => 'F — Facturação (recomendado)', 'I' => 'I — Integrado (exige contabilidade completa)', 'C' => 'C — Contabilidade'] as $k => $lab):
                ?>
                <option value="<?= $k ?>" <?= $basis === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><label>Versão chave pública (HashControl)</label><input class="form-control" type="number" min="1" name="agt_signature_version" value="<?= e((string) ($emp['agt_signature_version'] ?? 1)) ?>"></div>
    </div>
    <h3>Conformidade AGT (decreto)</h3>
    <div class="form-grid">
        <div class="form-group"><label>Código estabelecimento (TaxEntity SAF-T)</label><input class="form-control" name="estabelecimento_codigo" value="<?= e($emp['estabelecimento_codigo'] ?? '') ?>" placeholder="Opcional — multi-estabelecimento"></div>
        <div class="form-group"><label>Nome estabelecimento</label><input class="form-control" name="estabelecimento_nome" value="<?= e($emp['estabelecimento_nome'] ?? '') ?>"></div>
        <div class="form-group"><label>Rotação palavra-passe (dias)</label><input class="form-control" type="number" min="30" name="agt_password_max_days" value="<?= e((string) ($emp['agt_password_max_days'] ?? 90)) ?>"></div>
        <div class="form-group"><label>Alerta cópias segurança (dias)</label><input class="form-control" type="number" min="1" name="agt_backup_dias" value="<?= e((string) ($emp['agt_backup_dias'] ?? 7)) ?>"></div>
    </div>
    <div class="form-group">
        <label><input type="checkbox" name="modo_formacao" value="1" <?= !empty($emp['modo_formacao']) ? 'checked' : '' ?>> Modo formação (documentos com aviso legal; use séries de formação)</label>
    </div>
    <p style="font-size:.85rem"><a href="<?= url('/admin/facturacao/backups.php') ?>">Cópias de segurança</a> · <a href="<?= url('/admin/facturacao/mobilidade.php') ?>">Mobilidade</a> · <a href="<?= url('/admin/facturacao/conferencia.php') ?>">Conferência 4.3</a> · <a href="<?= url('/docs/AGT_REQUISITOS_SAFT.md') ?>" target="_blank" rel="noopener">Checklist AGT</a></p>
    <div class="form-group">
        <label><input type="checkbox" name="agt_saft_integrated" value="1" <?= !empty($emp['agt_saft_integrated']) || in_array($basis, ['I', 'C'], true) ? 'checked' : '' ?>> Software integrado com contabilidade (TransactionID + razão no SAF-T)</label>
    </div>
    <div class="form-group">
        <label><input type="checkbox" name="regenerar_saft_cert" value="1"> Reassinar documentos e regenerar <code>Ficheiro SAF-T.xml</code> após guardar</label>
    </div>
    <p style="font-size:.82rem;color:#374151"><strong>Export actual:</strong> ProductID <code><?= e(fat_saft_product_id($emp)) ?></code> · Validação <code><?= e(fat_saft_validation_number($emp)) ?></code> · HashControl <code><?= e(fat_saft_hash_control_value($emp)) ?></code> · Basis <code><?= e(fat_saft_tax_accounting_basis($emp)) ?></code></p>

    <h3>Facturação electrónica (API AGT)</h3>
    <p style="font-size:.85rem;color:#6b7280;margin-bottom:12px">Homologação: <code>sifphml.minfin.gov.ao</code> · Produção: <code>sifp.minfin.gov.ao</code>. Chaves JWS por defeito: <code>storage/fat_keys/</code> (mesma do hash SAF-T).</p>
    <div class="form-grid">
        <div class="form-group"><label>Ambiente</label>
            <select name="agt_ambiente">
                <option value="homologacao" <?= ($emp['agt_ambiente'] ?? 'homologacao') === 'homologacao' ? 'selected' : '' ?>>Homologação</option>
                <option value="producao" <?= ($emp['agt_ambiente'] ?? '') === 'producao' ? 'selected' : '' ?>>Produção</option>
            </select>
        </div>
        <div class="form-group"><label>Utilizador API</label><input class="form-control" name="agt_api_user" value="<?= e($emp['agt_api_user'] ?? '') ?>" autocomplete="off"></div>
        <div class="form-group"><label>Senha API</label><input class="form-control" type="password" name="agt_api_pass" value="" placeholder="<?= !empty($emp['agt_api_pass']) ? '•••••••• (deixe vazio para manter)' : '' ?>" autocomplete="new-password"></div>
        <div class="form-group"><label>Código actividade (EAC)</label><input class="form-control" name="agt_eac_code" maxlength="5" value="<?= e($emp['agt_eac_code'] ?? '') ?>" placeholder="Opcional"></div>
        <div class="form-group"><label>Chave produtor (opcional)</label><input class="form-control" name="agt_chave_produtor_path" value="<?= e($emp['agt_chave_produtor_path'] ?? '') ?>" placeholder="storage/fat_keys/private.pem"></div>
        <div class="form-group"><label>Chave emitente (opcional)</label><input class="form-control" name="agt_chave_emitente_path" value="<?= e($emp['agt_chave_emitente_path'] ?? '') ?>" placeholder="Registada na AGT"></div>
    </div>
    <div class="form-group">
        <label><input type="checkbox" name="agt_auto_envio" value="1" <?= !empty($emp['agt_auto_envio']) ? 'checked' : '' ?>> Enviar automaticamente à AGT após emitir</label>
    </div>
    <div class="form-group">
        <label><input type="checkbox" name="agt_simular" value="1" <?= !empty($emp['agt_simular']) ? 'checked' : '' ?>> Modo simulação (sem HTTP)</label>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/certificacao.php') ?>"><i class="fas fa-certificate"></i> Anexos certificação</a>
        <a class="btn btn-outline" href="<?= url('/admin/contabilidade/index.php') ?>">Contabilidade</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/agt.php') ?>">Fila AGT</a>
        <a class="btn btn-outline" href="<?= url('/admin/facturacao/index.php') ?>">Voltar</a>
    </div>
</form>
</div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
