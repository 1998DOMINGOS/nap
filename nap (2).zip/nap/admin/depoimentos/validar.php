<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$acao = $_GET['acao'] ?? '';

$stmt = db()->prepare('SELECT id, status FROM depoimentos WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) {
    flash('error', 'Depoimento não encontrado.');
    redirect('/admin/depoimentos/index.php');
}

if ($acao === 'aprovar') {
    db()->prepare("UPDATE depoimentos SET status = 'ativo' WHERE id = ?")->execute([$id]);
    flash('success', 'Depoimento aprovado. Já aparece no site.');
} elseif ($acao === 'rejeitar') {
    db()->prepare("UPDATE depoimentos SET status = 'rejeitado' WHERE id = ?")->execute([$id]);
    flash('success', 'Depoimento rejeitado. Não será publicado.');
} elseif ($acao === 'ocultar') {
    db()->prepare("UPDATE depoimentos SET status = 'inativo' WHERE id = ?")->execute([$id]);
    flash('success', 'Depoimento ocultado do site.');
} else {
    flash('error', 'Acção inválida.');
}

redirect('/admin/depoimentos/index.php');
