<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Depoimentos';
$current = 'depoimentos';

$filtro = $_GET['filtro'] ?? 'todos';
$allowed = ['todos', 'pendente', 'ativo', 'rejeitado', 'inativo'];
if (!in_array($filtro, $allowed, true)) {
    $filtro = 'todos';
}

if ($filtro === 'todos') {
    $items = db()->query('SELECT * FROM depoimentos ORDER BY FIELD(status,"pendente","ativo","inativo","rejeitado"), id DESC')->fetchAll();
} else {
    $stmt = db()->prepare('SELECT * FROM depoimentos WHERE status = ? ORDER BY id DESC');
    $stmt->execute([$filtro]);
    $items = $stmt->fetchAll();
}

$contagens = [
    'todos'     => count_table('depoimentos'),
    'pendente'  => count_table('depoimentos', "status = 'pendente'"),
    'ativo'     => count_table('depoimentos', "status = 'ativo'"),
    'rejeitado' => count_table('depoimentos', "status = 'rejeitado'"),
    'inativo'   => count_table('depoimentos', "status = 'inativo'"),
];

require __DIR__ . '/../includes/header.php';
?>

<div class="toolbar">
    <p class="subtitle" style="margin:0">Testemunhos enviados pelos clientes — só aparecem no site depois de aprovados.</p>
    <a class="btn btn-primary" href="<?= url('/admin/depoimentos/criar.php') ?>"><i class="fas fa-plus"></i> Novo depoimento</a>
</div>

<div class="toolbar" style="margin-top:-8px">
    <div class="actions">
        <?php
        $filtros = [
            'todos'     => 'Todos',
            'pendente'  => 'Pendentes',
            'ativo'     => 'Publicados',
            'rejeitado' => 'Rejeitados',
            'inativo'   => 'Inativos',
        ];
        foreach ($filtros as $key => $label):
            $active = $filtro === $key;
        ?>
            <a class="btn btn-sm <?= $active ? 'btn-primary' : 'btn-outline' ?>" href="<?= url('/admin/depoimentos/index.php?filtro=' . $key) ?>">
                <?= e($label) ?> (<?= (int) $contagens[$key] ?>)
            </a>
        <?php endforeach; ?>
    </div>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Nome</th><th>Origem</th><th>Nota</th><th>Status</th><th>Data</th><th>Ações</th></tr></thead>
            <tbody>
            <?php if (!$items): ?>
                <tr><td colspan="6" class="empty">Nenhum depoimento neste filtro.</td></tr>
            <?php else: foreach ($items as $item): ?>
                <tr>
                    <td>
                        <strong><?= e($item['nome']) ?></strong>
                        <?php if (!empty($item['email'])): ?>
                            <div style="color:#6b7280;font-size:.82rem"><?= e($item['email']) ?></div>
                        <?php endif; ?>
                        <div style="color:#6b7280;font-size:.82rem;max-width:360px"><?= e(mb_strimwidth($item['texto'], 0, 90, '...')) ?></div>
                    </td>
                    <td><?= ($item['origem'] ?? 'admin') === 'cliente' ? 'Cliente' : 'Admin' ?></td>
                    <td><?= str_repeat('★', (int) $item['nota']) ?></td>
                    <td><?= status_badge($item['status']) ?></td>
                    <td><?= e(format_date($item['criado_em'] ?? null, 'd/m/Y')) ?></td>
                    <td class="actions">
                        <?php if ($item['status'] === 'pendente'): ?>
                            <a class="btn btn-sm btn-primary" data-confirm="Aprovar e publicar este depoimento no site?" href="<?= url('/admin/depoimentos/validar.php?id=' . $item['id'] . '&acao=aprovar') ?>"><i class="fas fa-check"></i> Aprovar</a>
                            <a class="btn btn-sm btn-danger" data-confirm="Rejeitar este depoimento?" href="<?= url('/admin/depoimentos/validar.php?id=' . $item['id'] . '&acao=rejeitar') ?>"><i class="fas fa-times"></i></a>
                        <?php elseif ($item['status'] === 'ativo'): ?>
                            <a class="btn btn-sm btn-outline" data-confirm="Ocultar este depoimento do site?" href="<?= url('/admin/depoimentos/validar.php?id=' . $item['id'] . '&acao=ocultar') ?>"><i class="fas fa-eye-slash"></i></a>
                        <?php elseif (in_array($item['status'], ['rejeitado', 'inativo'], true)): ?>
                            <a class="btn btn-sm btn-primary" data-confirm="Publicar este depoimento no site?" href="<?= url('/admin/depoimentos/validar.php?id=' . $item['id'] . '&acao=aprovar') ?>"><i class="fas fa-check"></i></a>
                        <?php endif; ?>
                        <a class="btn btn-sm btn-outline" href="<?= url('/admin/depoimentos/editar.php?id=' . $item['id']) ?>"><i class="fas fa-pen"></i></a>
                        <a class="btn btn-sm btn-danger" data-confirm="Eliminar este depoimento?" href="<?= url('/admin/depoimentos/excluir.php?id=' . $item['id']) ?>"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
