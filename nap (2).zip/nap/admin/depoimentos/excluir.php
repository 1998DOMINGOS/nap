<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
db()->prepare('DELETE FROM depoimentos WHERE id = ?')->execute([$id]);
flash('success', 'Depoimento eliminado.');
redirect('/admin/depoimentos/index.php');
