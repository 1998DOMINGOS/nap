<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM depoimentos WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    flash('error', 'Depoimento não encontrado.');
    redirect('/admin/depoimentos/index.php');
}

$pageTitle = 'Editar depoimento';
$current = 'depoimentos';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $cargo = trim($_POST['cargo'] ?? '');
    $texto = trim($_POST['texto'] ?? '');
    $nota = max(1, min(5, (int) ($_POST['nota'] ?? 5)));
    $ordem = (int) ($_POST['ordem'] ?? 0);
    $status = in_array($_POST['status'] ?? '', ['pendente', 'ativo', 'inativo', 'rejeitado'], true)
        ? $_POST['status']
        : 'pendente';

    if ($nome === '' || $texto === '') {
        $errors[] = 'Nome e texto são obrigatórios.';
    }

    if (!$errors) {
        db()->prepare('UPDATE depoimentos SET nome=?, email=?, cargo=?, texto=?, nota=?, status=?, ordem=? WHERE id=?')
            ->execute([$nome, $email !== '' ? $email : null, $cargo, $texto, $nota, $status, $ordem, $id]);
        flash('success', 'Depoimento atualizado.');
        redirect('/admin/depoimentos/index.php');
    }
    $item = array_merge($item, compact('nome', 'email', 'cargo', 'texto', 'nota', 'ordem', 'status'));
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome</label><input class="form-control" name="nome" required value="<?= e($item['nome']) ?>"></div>
        <div class="form-group"><label>Email</label><input class="form-control" type="email" name="email" value="<?= e($item['email'] ?? '') ?>"></div>
    </div>
    <div class="form-group"><label>Cargo / Empresa</label><input class="form-control" name="cargo" value="<?= e($item['cargo']) ?>"></div>
    <div class="form-group"><label>Depoimento</label><textarea name="texto" required><?= e($item['texto']) ?></textarea></div>
    <div class="form-grid">
        <div class="form-group">
            <label>Nota</label>
            <select name="nota">
                <?php for ($i = 5; $i >= 1; $i--): ?>
                    <option value="<?= $i ?>" <?= (int)$item['nota'] === $i ? 'selected' : '' ?>><?= $i ?> estrela<?= $i > 1 ? 's' : '' ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="form-group"><label>Ordem</label><input class="form-control" type="number" name="ordem" value="<?= e((string) $item['ordem']) ?>"></div>
    </div>
    <div class="form-group">
        <label>Status</label>
        <select name="status">
            <option value="pendente" <?= $item['status'] === 'pendente' ? 'selected' : '' ?>>Pendente (aguarda validação)</option>
            <option value="ativo" <?= $item['status'] === 'ativo' ? 'selected' : '' ?>>Ativo (publicado no site)</option>
            <option value="inativo" <?= $item['status'] === 'inativo' ? 'selected' : '' ?>>Inativo</option>
            <option value="rejeitado" <?= $item['status'] === 'rejeitado' ? 'selected' : '' ?>>Rejeitado</option>
        </select>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Atualizar</button>
        <a class="btn btn-outline" href="<?= url('/admin/depoimentos/index.php') ?>">Voltar</a>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
