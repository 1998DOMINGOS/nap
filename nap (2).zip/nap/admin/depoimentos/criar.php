<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Novo depoimento';
$current = 'depoimentos';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $cargo = trim($_POST['cargo'] ?? '');
    $texto = trim($_POST['texto'] ?? '');
    $nota = max(1, min(5, (int) ($_POST['nota'] ?? 5)));
    $ordem = (int) ($_POST['ordem'] ?? 0);
    $status = $_POST['status'] === 'ativo' ? 'ativo' : 'inativo';

    if ($nome === '' || $texto === '') {
        $errors[] = 'Nome e texto são obrigatórios.';
    }

    if (!$errors) {
        db()->prepare('INSERT INTO depoimentos (nome, email, cargo, texto, nota, status, ordem, origem) VALUES (?,?,?,?,?,?,?,"admin")')
            ->execute([$nome, $email !== '' ? $email : null, $cargo, $texto, $nota, $status, $ordem]);
        flash('success', 'Depoimento criado.');
        redirect('/admin/depoimentos/index.php');
    }
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome</label><input class="form-control" name="nome" required value="<?= e($_POST['nome'] ?? '') ?>"></div>
        <div class="form-group"><label>Email</label><input class="form-control" type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>"></div>
    </div>
    <div class="form-group"><label>Cargo / Empresa</label><input class="form-control" name="cargo" value="<?= e($_POST['cargo'] ?? '') ?>"></div>
    <div class="form-group"><label>Depoimento</label><textarea name="texto" required><?= e($_POST['texto'] ?? '') ?></textarea></div>
    <div class="form-grid">
        <div class="form-group">
            <label>Nota</label>
            <select name="nota">
                <?php for ($i = 5; $i >= 1; $i--): ?>
                    <option value="<?= $i ?>"><?= $i ?> estrela<?= $i > 1 ? 's' : '' ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="form-group"><label>Ordem</label><input class="form-control" type="number" name="ordem" value="0"></div>
    </div>
    <div class="form-group">
        <label>Status</label>
        <select name="status"><option value="ativo">Ativo (publicado no site)</option><option value="inativo">Inativo</option></select>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
        <a class="btn btn-outline" href="<?= url('/admin/depoimentos/index.php') ?>">Cancelar</a>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
