<?php
require_once __DIR__ . '/../config/app.php';
require_contabilidade();
ensure_facturacao_schema();
ensure_contabilidade_schema();

$pageTitle = 'Balancetes';
$pageSubtitle = 'Balancete analítico (razão)';
$current = is_contabilista() ? 'cont-bal' : 'balancetes';
$useContLayout = is_contabilista();
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
    $from = date('Y-m-01');
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
    $to = date('Y-m-d');
}

$ledgerRows = cont_balancete($from, $to);
$fromLedger = $ledgerRows !== [];
$accounts = [];
if ($fromLedger) {
    foreach ($ledgerRows as $r) {
        $accounts[] = [$r['codigo'], $r['nome'], $r['debito'], $r['credito']];
    }
} else {
    $salesStmt = db()->prepare("SELECT COALESCE(SUM(CASE WHEN tipo='NC' THEN -subtotal ELSE subtotal END),0), COALESCE(SUM(CASE WHEN tipo='NC' THEN -total_iva ELSE total_iva END),0), COALESCE(SUM(CASE WHEN tipo='NC' THEN -total ELSE total END),0) FROM fat_documentos WHERE estado='emitido' AND data_documento BETWEEN ? AND ? AND tipo IN ('FT','FR','NC','ND','FA')");
    $salesStmt->execute([$from, $to]);
    [$salesNet, $salesVat, $salesGross] = array_map('floatval', $salesStmt->fetch(PDO::FETCH_NUM));
    $paymentsStmt = db()->prepare("SELECT COALESCE(SUM(CASE WHEN p.metodo='numerario' THEN p.valor ELSE 0 END),0), COALESCE(SUM(CASE WHEN p.metodo<>'numerario' THEN p.valor ELSE 0 END),0), COALESCE(SUM(p.valor),0) FROM fat_pagamentos p INNER JOIN fat_documentos d ON d.id=p.documento_id WHERE d.estado='emitido' AND d.data_documento BETWEEN ? AND ?");
    $paymentsStmt->execute([$from, $to]);
    [$cashReceived, $bankReceived, $received] = array_map('floatval', $paymentsStmt->fetch(PDO::FETCH_NUM));
    $purchaseStmt = db()->prepare('SELECT COALESCE(SUM(subtotal),0), COALESCE(SUM(total_iva),0), COALESCE(SUM(total),0) FROM fat_compras WHERE data_compra BETWEEN ? AND ?');
    $purchaseStmt->execute([$from, $to]);
    [$purchaseNet, $purchaseVat, $purchaseGross] = array_map('floatval', $purchaseStmt->fetch(PDO::FETCH_NUM));
    $accountsReceivable = max(0, $salesGross - $received);
    $accounts = [
        ['11', 'Caixa', $cashReceived, 0],
        ['12', 'Bancos', $bankReceived, 0],
        ['2111', 'Clientes', $accountsReceivable, 0],
        ['2453', 'IVA dedutível', $purchaseVat, 0],
        ['31', 'Compras', $purchaseNet, 0],
        ['2211', 'Fornecedores', 0, $purchaseGross],
        ['711', 'Vendas', 0, max(0, $salesNet)],
        ['2432', 'IVA liquidado', 0, max(0, $salesVat)],
    ];
}

$debitTotal = array_sum(array_column($accounts, 2));
$creditTotal = array_sum(array_column($accounts, 3));
$balanceDifference = $debitTotal - $creditTotal;
$empresa = fat_empresa();
$mapa = cont_mapa_iva($from, $to);

if ($useContLayout) {
    require __DIR__ . '/contabilidade/includes/header.php';
} else {
    require __DIR__ . '/includes/header.php';
}
?>
<div class="toolbar no-print"><p class="subtitle" style="margin:0"><?= $fromLedger ? 'Balancete do razão (lançamentos)' : 'Balancete estimado — sincronize lançamentos na Contabilidade' ?></p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-primary" type="button" onclick="window.print()"><i class="fas fa-print"></i> Imprimir / PDF</button><a class="btn btn-outline" href="<?= url('/admin/contabilidade/dashboard.php') ?>">Dashboard</a></div></div>
<div class="card no-print"><div class="card-body"><form method="get"><div class="form-grid"><div class="form-group"><label>Data início</label><input class="form-control" type="date" name="from" value="<?= e($from) ?>"></div><div class="form-group"><label>Data fim</label><input class="form-control" type="date" name="to" value="<?= e($to) ?>"></div></div><div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-filter"></i> Actualizar</button></div></form></div></div>
<div class="report-sheet">
    <div class="report-header"><div><h1>Balancete</h1><p><?= e($empresa['nome'] ?? '') ?> · NIF <?= e($empresa['nif'] ?? '') ?></p></div><div><strong>Período</strong><br><?= e(format_date($from, 'd/m/Y')) ?> a <?= e(format_date($to, 'd/m/Y')) ?></div></div>
    <table><thead><tr><th>Código</th><th>Conta</th><th class="right">Débito</th><th class="right">Crédito</th><th class="right">Saldo</th></tr></thead><tbody><?php foreach ($accounts as $account): $balance = (float) $account[2] - (float) $account[3]; ?><tr><td><?= e($account[0]) ?></td><td><?= e($account[1]) ?></td><td class="right"><?= e(fat_format_money($account[2])) ?></td><td class="right"><?= e(fat_format_money($account[3])) ?></td><td class="right"><?= e(fat_format_money($balance)) ?></td></tr><?php endforeach; ?><tr class="total-row"><th colspan="2">Totais</th><th class="right"><?= e(fat_format_money($debitTotal)) ?></th><th class="right"><?= e(fat_format_money($creditTotal)) ?></th><th class="right"><?= e(fat_format_money($balanceDifference)) ?></th></tr></tbody></table>
    <div class="balance-check <?= abs($balanceDifference) < 0.01 ? 'balanced' : 'unbalanced' ?>"><strong><?= abs($balanceDifference) < 0.01 ? 'Débito = Crédito' : 'Desequilíbrio — rever lançamentos' ?></strong> · Diferença: <?= e(fat_format_money($balanceDifference)) ?></div>
    <div class="report-notes"><p>IVA liquidado: <?= e(fat_format_money($mapa['iva_liquidado'])) ?> · IVA dedutível: <?= e(fat_format_money($mapa['iva_dedutivel_total'])) ?> · IVA a pagar (est.): <?= e(fat_format_money($mapa['iva_a_pagar'])) ?></p><p>Documento para apoio ao contabilista certificado (OCC).</p></div>
</div>
<?php require $useContLayout ? __DIR__ . '/contabilidade/includes/footer.php' : __DIR__ . '/includes/footer.php'; ?>
