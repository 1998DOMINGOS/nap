<?php
require_once __DIR__ . '/../../config/app.php';
require_admin();

$pageTitle = 'Utilizadores';
$current = 'usuarios';
$items = db()->query('SELECT id, nome, email, nivel, ativo, ultimo_acesso, criado_em FROM usuarios ORDER BY id ASC')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>

<div class="toolbar">
    <p class="subtitle" style="margin:0">Contas de acesso ao painel</p>
    <a class="btn btn-primary" href="<?= url('/admin/usuarios/criar.php') ?>"><i class="fas fa-plus"></i> Novo utilizador</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Nome</th><th>Email</th><th>Nível</th><th>Estado</th><th>Último acesso</th><th>Ações</th></tr></thead>
            <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><strong><?= e($item['nome']) ?></strong></td>
                    <td><?= e($item['email']) ?></td>
                    <td><?= e(ucfirst($item['nivel'])) ?></td>
                    <td><?= status_badge($item['ativo'] ? 'ativo' : 'inativo') ?></td>
                    <td><?= e(format_date($item['ultimo_acesso'])) ?></td>
                    <td class="actions">
                        <a class="btn btn-sm btn-outline" href="<?= url('/admin/usuarios/editar.php?id=' . $item['id']) ?>"><i class="fas fa-pen"></i></a>
                        <?php if ((int)$item['id'] !== (int)$_SESSION['user_id']): ?>
                            <a class="btn btn-sm btn-danger" data-confirm="Eliminar este utilizador?" href="<?= url('/admin/usuarios/excluir.php?id=' . $item['id']) ?>"><i class="fas fa-trash"></i></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
