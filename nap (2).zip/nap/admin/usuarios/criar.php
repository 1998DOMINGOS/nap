<?php
require_once __DIR__ . '/../../config/app.php';
require_admin();

$pageTitle = 'Novo utilizador';
$current = 'usuarios';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $senha = (string) ($_POST['senha'] ?? '');
    $nivel = $_POST['nivel'] ?? 'editor';
    if (!in_array($nivel, ['admin', 'editor', 'contabilista', 'faturacao', 'rh', 'ti'], true)) {
        $nivel = 'editor';
    }
    $ativo = isset($_POST['ativo']) ? 1 : 0;

    if ($nome === '' || $email === '' || strlen($senha) < 6) {
        $errors[] = 'Preencha nome, email e senha (mín. 6 caracteres).';
    }

    $exists = db()->prepare('SELECT id FROM usuarios WHERE email = ?');
    $exists->execute([$email]);
    if ($exists->fetch()) {
        $errors[] = 'Já existe um utilizador com este email.';
    }

    if (!$errors) {
        db()->prepare('INSERT INTO usuarios (nome, email, senha, nivel, ativo) VALUES (?,?,?,?,?)')
            ->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), $nivel, $ativo]);
        $newId = (int) db()->lastInsertId();
        if ($newId > 0 && function_exists('fat_agt_marcar_senha_alterada')) {
            fat_agt_marcar_senha_alterada($newId);
        }
        flash('success', 'Utilizador criado.');
        redirect('/admin/usuarios/index.php');
    }
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome</label><input class="form-control" name="nome" required value="<?= e($_POST['nome'] ?? '') ?>"></div>
        <div class="form-group"><label>Email</label><input class="form-control" type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></div>
    </div>
    <div class="form-grid">
        <div class="form-group"><label>Senha</label><input class="form-control" type="password" name="senha" required minlength="6"></div>
        <div class="form-group">
            <label>Nível</label>
            <select name="nivel">
                <option value="editor">Editor</option>
                <option value="faturacao">Facturação (só módulo fiscal)</option>
                <option value="contabilista">Contabilista (só módulo contabilidade)</option>
                <option value="rh">Recursos Humanos (só módulo RH)</option>
                <option value="ti">Tecnologia (só módulo TI)</option>
                <option value="admin">Admin</option>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label><input type="checkbox" name="ativo" checked> Conta ativa</label>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
        <a class="btn btn-outline" href="<?= url('/admin/usuarios/index.php') ?>">Cancelar</a>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
