<?php
require_once __DIR__ . '/../../config/app.php';
require_login();
ensure_usuario_niveis();

$id = (int) ($_GET['id'] ?? 0);
$perfilProprioFaturacao = is_faturacao() && $id === (int) ($_SESSION['user_id'] ?? 0);
if (!$perfilProprioFaturacao) {
    require_admin();
}
$stmt = db()->prepare('SELECT * FROM usuarios WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    flash('error', 'Utilizador não encontrado.');
    redirect('/admin/usuarios/index.php');
}

$pageTitle = 'Editar utilizador';
$current = 'usuarios';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $nivel = $_POST['nivel'] ?? 'editor';
    if ($perfilProprioFaturacao) {
        $nivel = 'faturacao';
    } elseif (!in_array($nivel, ['admin', 'editor', 'contabilista', 'faturacao', 'rh', 'ti'], true)) {
        $nivel = 'editor';
    }
    $ativo = $perfilProprioFaturacao ? (int) $item['ativo'] : (isset($_POST['ativo']) ? 1 : 0);
    $senha = (string) ($_POST['senha'] ?? '');

    if ($nome === '' || $email === '') {
        $errors[] = 'Nome e email são obrigatórios.';
    }

    $exists = db()->prepare('SELECT id FROM usuarios WHERE email = ? AND id <> ?');
    $exists->execute([$email, $id]);
    if ($exists->fetch()) {
        $errors[] = 'Já existe um utilizador com este email.';
    }

    if (!$errors) {
        if ($senha !== '') {
            if (strlen($senha) < 6) {
                $errors[] = 'A nova senha deve ter pelo menos 6 caracteres.';
            } else {
                db()->prepare('UPDATE usuarios SET nome=?, email=?, senha=?, nivel=?, ativo=? WHERE id=?')
                    ->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), $nivel, $ativo, $id]);
                if (function_exists('fat_agt_marcar_senha_alterada')) {
                    fat_agt_marcar_senha_alterada($id);
                }
            }
        } else {
            db()->prepare('UPDATE usuarios SET nome=?, email=?, nivel=?, ativo=? WHERE id=?')
                ->execute([$nome, $email, $nivel, $ativo, $id]);
        }
    }

    if (!$errors) {
        if ((int)$id === (int)$_SESSION['user_id']) {
            $_SESSION['user_nome'] = $nome;
            $_SESSION['user_email'] = $email;
            $_SESSION['user_nivel'] = $nivel;
        }
        flash('success', 'Utilizador actualizado.');
        redirect($perfilProprioFaturacao ? '/admin/facturacao/index.php' : '/admin/usuarios/index.php');
    }
    $item = array_merge($item, compact('nome', 'email', 'nivel', 'ativo'));
}

$pwdExpirada = (int) $id === (int) ($_SESSION['user_id'] ?? 0)
    && function_exists('fat_agt_password_expirada')
    && fat_agt_password_expirada(['id' => $id]);

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<?php if ($pwdExpirada): ?>
<div class="alert alert-error"><strong>Palavra-passe expirada (requisito AGT).</strong> Defina uma <em>nova senha</em> abaixo (mín. 6 caracteres) e guarde.</div>
<?php endif; ?>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome</label><input class="form-control" name="nome" required value="<?= e($item['nome']) ?>"></div>
        <div class="form-group"><label>Email</label><input class="form-control" type="email" name="email" required value="<?= e($item['email']) ?>"></div>
    </div>
    <div class="form-grid">
        <div class="form-group"><label>Nova senha <?= $pwdExpirada ? '(obrigatória)' : '(opcional)' ?></label><input class="form-control" type="password" name="senha" minlength="6" <?= $pwdExpirada ? 'required' : '' ?> placeholder="<?= $pwdExpirada ? 'Nova palavra-passe' : 'Deixe em branco para manter' ?>"></div>
        <?php if (!$perfilProprioFaturacao): ?>
        <div class="form-group">
            <label>Nível</label>
            <select name="nivel">
                <option value="editor" <?= $item['nivel'] === 'editor' ? 'selected' : '' ?>>Editor</option>
                <option value="faturacao" <?= $item['nivel'] === 'faturacao' ? 'selected' : '' ?>>Facturação (só módulo fiscal)</option>
                <option value="contabilista" <?= $item['nivel'] === 'contabilista' ? 'selected' : '' ?>>Contabilista (só contabilidade)</option>
                <option value="rh" <?= $item['nivel'] === 'rh' ? 'selected' : '' ?>>Recursos Humanos (só módulo RH)</option>
                <option value="ti" <?= $item['nivel'] === 'ti' ? 'selected' : '' ?>>Tecnologia (só módulo TI)</option>
                <option value="admin" <?= $item['nivel'] === 'admin' ? 'selected' : '' ?>>Admin</option>
            </select>
        </div>
        <?php endif; ?>
    </div>
    <?php if (!$perfilProprioFaturacao): ?>
    <div class="form-group">
        <label><input type="checkbox" name="ativo" <?= $item['ativo'] ? 'checked' : '' ?>> Conta ativa</label>
    </div>
    <?php endif; ?>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Atualizar</button>
        <a class="btn btn-outline" href="<?= url($perfilProprioFaturacao ? '/admin/facturacao/index.php' : '/admin/usuarios/index.php') ?>">Voltar</a>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
