<?php
require_once __DIR__ . '/../../config/app.php';
require_admin();

$id = (int) ($_GET['id'] ?? 0);
if ($id === (int) $_SESSION['user_id']) {
    flash('error', 'Não pode eliminar a sua própria conta.');
    redirect('/admin/usuarios/index.php');
}

db()->prepare('DELETE FROM usuarios WHERE id = ?')->execute([$id]);
flash('success', 'Utilizador eliminado.');
redirect('/admin/usuarios/index.php');
