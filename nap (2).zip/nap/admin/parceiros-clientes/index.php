<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Parceiros e Clientes';
$current = 'parceiros-clientes';
$errors = [];
$editing = null;
$type = ($_GET['tipo'] ?? $_POST['tipo'] ?? 'parceiro') === 'cliente' ? 'cliente' : 'parceiro';
$table = $type === 'cliente' ? 'clientes' : 'parceiros';
$label = $type === 'cliente' ? 'cliente' : 'parceiro';
$uploadSubdir = $type === 'cliente' ? 'clientes' : 'parceiros';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'save';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'delete' && $id > 0) {
        $stmt = db()->prepare("SELECT imagem FROM {$table} WHERE id = ?");
        $stmt->execute([$id]);
        $img = $stmt->fetchColumn();
        if (is_upload_path($img)) {
            delete_upload((string) $img);
        }
        db()->prepare("DELETE FROM {$table} WHERE id = ?")->execute([$id]);
        flash('success', ucfirst($label) . ' eliminado.');
        redirect('/admin/parceiros-clientes/index.php?tipo=' . $type);
    }

    $nome = trim($_POST['nome'] ?? '');
    $imagemUrl = trim($_POST['imagem_url'] ?? '');
    $link = trim($_POST['link'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $icone = trim($_POST['icone'] ?? ($type === 'cliente' ? 'fa-building' : 'fa-handshake'));
    $ordem = (int) ($_POST['ordem'] ?? 0);
    $status = ($_POST['status'] ?? 'ativo') === 'ativo' ? 'ativo' : 'inativo';
    $removerLogo = !empty($_POST['remover_logo']);

    $existingImagem = null;
    if ($id > 0) {
        $stmt = db()->prepare("SELECT imagem FROM {$table} WHERE id = ?");
        $stmt->execute([$id]);
        $existingImagem = $stmt->fetchColumn() ?: null;
    }

    if ($nome === '') {
        $errors[] = 'O nome é obrigatório.';
    }
    if ($link !== '' && !filter_var($link, FILTER_VALIDATE_URL)) {
        $errors[] = 'O link da entidade não é válido.';
    }
    if ($imagemUrl !== '' && !filter_var($imagemUrl, FILTER_VALIDATE_URL)) {
        $errors[] = 'O link da imagem não é válido.';
    }

    $imagem = $existingImagem;

    if (!$errors) {
        try {
            if ($removerLogo) {
                if (is_upload_path($imagem)) {
                    delete_upload($imagem);
                }
                $imagem = null;
            } elseif (!empty($_FILES['logo']['name'])) {
                $nova = upload_brand_logo($_FILES['logo'], $uploadSubdir);
                if ($nova) {
                    if (is_upload_path($imagem)) {
                        delete_upload($imagem);
                    }
                    $imagem = $nova;
                }
            } elseif ($imagemUrl !== '') {
                if (is_upload_path($imagem)) {
                    delete_upload($imagem);
                }
                $imagem = $imagemUrl;
            }
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }

    if (!$errors) {
        if ($id > 0) {
            db()->prepare("UPDATE {$table} SET nome=?, imagem=?, link=?, descricao=?, icone=?, ordem=?, status=? WHERE id=?")
                ->execute([$nome, $imagem ?: null, $link ?: null, $descricao, $icone, $ordem, $status, $id]);
            flash('success', ucfirst($label) . ' actualizado.');
        } else {
            db()->prepare("INSERT INTO {$table} (nome, imagem, link, descricao, icone, ordem, status) VALUES (?,?,?,?,?,?,?)")
                ->execute([$nome, $imagem ?: null, $link ?: null, $descricao, $icone, $ordem, $status]);
            flash('success', ucfirst($label) . ' criado.');
        }
        redirect('/admin/parceiros-clientes/index.php?tipo=' . $type);
    }
    $editing = $_POST;
    $editing['imagem'] = $imagem;
} elseif (!empty($_GET['editar'])) {
    $stmt = db()->prepare("SELECT * FROM {$table} WHERE id = ?");
    $stmt->execute([(int) $_GET['editar']]);
    $editing = $stmt->fetch() ?: null;
}

$partners = db()->query('SELECT * FROM parceiros ORDER BY ordem, nome')->fetchAll();
$clients = db()->query('SELECT * FROM clientes ORDER BY ordem, nome')->fetchAll();
$editLogoUrl = !empty($editing['imagem']) ? partner_logo_url($editing['imagem']) : '';
$editLogoIsUrl = !empty($editing['imagem']) && !is_upload_path($editing['imagem']);

require __DIR__ . '/../includes/header.php';
?>
<div class="toolbar">
    <p class="subtitle" style="margin:0">Gerir nomes, logótipos e links apresentados no site.</p>
    <div class="actions">
        <a class="btn <?= $type === 'parceiro' ? 'btn-primary' : 'btn-outline' ?>" href="?tipo=parceiro">Parceiros</a>
        <a class="btn <?= $type === 'cliente' ? 'btn-primary' : 'btn-outline' ?>" href="?tipo=cliente">Clientes</a>
    </div>
</div>
<?php foreach ($errors as $error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endforeach; ?>
<div class="card"><div class="card-body">
<form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="tipo" value="<?= e($type) ?>"><input type="hidden" name="id" value="<?= e((string)($editing['id'] ?? '0')) ?>">
    <h2 style="margin-bottom:16px"><?= $editing ? 'Editar' : 'Novo' ?> <?= e($label) ?></h2>
    <div class="form-grid">
        <div class="form-group"><label>Nome</label><input class="form-control" name="nome" required value="<?= e($editing['nome'] ?? '') ?>"></div>
        <div class="form-group"><label>Ícone Font Awesome (fallback se não houver logótipo)</label><input class="form-control" name="icone" value="<?= e($editing['icone'] ?? ($type === 'cliente' ? 'fa-building' : 'fa-handshake')) ?>" placeholder="fa-building"></div>
    </div>
    <div class="form-group">
        <label>Logótipo</label>
        <?php if ($editLogoUrl): ?>
            <div style="margin-bottom:10px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
                <img class="thumb" src="<?= e($editLogoUrl) ?>" alt="" style="width:88px;height:88px;object-fit:contain;background:#f5f9fc;border:1px solid #e5e7eb;padding:6px">
                <label style="font-weight:500;margin:0"><input type="checkbox" name="remover_logo" value="1"> Remover logótipo actual</label>
            </div>
        <?php endif; ?>
        <input class="form-control" type="file" name="logo" accept="image/jpeg,image/png,image/webp,image/gif,image/svg+xml,.svg">
        <p style="margin:6px 0 0;font-size:.82rem;color:#6b7280">JPG, PNG, WEBP, GIF ou SVG — máx. 3MB. Recomendado: fundo transparente ou branco.</p>
    </div>
    <div class="form-grid">
        <div class="form-group">
            <label>Ou link externo do logótipo (opcional)</label>
            <input class="form-control" type="url" name="imagem_url" value="<?= e($editLogoIsUrl ? ($editing['imagem'] ?? '') : '') ?>" placeholder="https://.../logo.png">
            <p style="margin:6px 0 0;font-size:.82rem;color:#6b7280">Substitui o ficheiro enviado se preencher ao guardar.</p>
        </div>
        <div class="form-group"><label>Link da entidade (site)</label><input class="form-control" type="url" name="link" value="<?= e($editing['link'] ?? '') ?>" placeholder="https://.../"></div>
    </div>
    <div class="form-grid">
        <div class="form-group"><label>Descrição</label><input class="form-control" name="descricao" value="<?= e($editing['descricao'] ?? '') ?>"></div>
        <div class="form-group"><label>Ordem</label><input class="form-control" type="number" name="ordem" value="<?= e((string)($editing['ordem'] ?? 0)) ?>"></div>
    </div>
    <div class="form-group"><label>Status</label><select name="status"><option value="ativo" <?= ($editing['status'] ?? 'ativo') === 'ativo' ? 'selected' : '' ?>>Ativo</option><option value="inativo" <?= ($editing['status'] ?? '') === 'inativo' ? 'selected' : '' ?>>Inativo</option></select></div>
    <div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button><?php if ($editing): ?><a class="btn btn-outline" href="?tipo=<?= e($type) ?>">Cancelar</a><?php endif; ?></div>
</form>
</div></div>
<?php foreach ([['parceiro', 'Parceiros', $partners], ['cliente', 'Clientes', $clients]] as [$kind, $title, $items]): ?>
<div class="card" style="margin-top:18px"><div class="card-head"><h2><?= e($title) ?> (<?= count($items) ?>)</h2></div><div class="table-wrap"><table><thead><tr><th>Logótipo</th><th>Nome</th><th>Ordem</th><th>Status</th><th>Ações</th></tr></thead><tbody>
<?php foreach ($items as $item):
    $logo = partner_logo_url($item['imagem'] ?? '');
?><tr>
    <td><?php if ($logo): ?><img src="<?= e($logo) ?>" alt="" style="width:52px;height:52px;object-fit:contain;background:#f5f9fc;border-radius:8px;padding:4px;border:1px solid #e5e7eb"><?php else: ?>—<?php endif; ?></td>
    <td><strong><?= e($item['nome']) ?></strong><div style="color:#6b7280;font-size:.82rem"><?= e($item['descricao']) ?></div></td>
    <td><?= (int)$item['ordem'] ?></td>
    <td><?= status_badge($item['status']) ?></td>
    <td class="actions"><a class="btn btn-sm btn-outline" href="?tipo=<?= e($kind) ?>&editar=<?= (int)$item['id'] ?>"><i class="fas fa-pen"></i></a><form method="post" style="display:inline" onsubmit="return confirm('Eliminar este registo?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="tipo" value="<?= e($kind) ?>"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><button class="btn btn-sm btn-danger" type="submit"><i class="fas fa-trash"></i></button></form></td>
</tr><?php endforeach; ?></tbody></table></div></div>
<?php endforeach; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
