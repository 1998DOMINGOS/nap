<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM equipe WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if ($item) {
    delete_upload($item['foto']);
    db()->prepare('DELETE FROM equipe WHERE id = ?')->execute([$id]);
    flash('success', 'Membro eliminado.');
} else {
    flash('error', 'Membro não encontrado.');
}
redirect('/admin/equipe/index.php');
