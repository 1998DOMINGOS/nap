<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM equipe WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    flash('error', 'Membro não encontrado.');
    redirect('/admin/equipe/index.php');
}

$pageTitle = 'Editar membro';
$current = 'equipe';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $cargo = trim($_POST['cargo'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    $ordem = (int) ($_POST['ordem'] ?? 0);
    $status = $_POST['status'] === 'ativo' ? 'ativo' : 'inativo';
    $foto = $item['foto'];

    if ($nome === '' || $cargo === '') {
        $errors[] = 'Nome e cargo são obrigatórios.';
    }

    try {
        if (!empty($_FILES['foto']['name'])) {
            $nova = upload_image($_FILES['foto'], 'equipe');
            if ($nova) {
                delete_upload($foto);
                $foto = $nova;
            }
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }

    if (!$errors) {
        db()->prepare('UPDATE equipe SET nome=?, cargo=?, bio=?, foto=?, ordem=?, status=? WHERE id=?')
            ->execute([$nome, $cargo, $bio, $foto, $ordem, $status, $id]);
        flash('success', 'Membro atualizado.');
        redirect('/admin/equipe/index.php');
    }
    $item = array_merge($item, compact('nome', 'cargo', 'bio', 'ordem', 'status', 'foto'));
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome</label><input class="form-control" name="nome" required value="<?= e($item['nome']) ?>"></div>
        <div class="form-group"><label>Cargo</label><input class="form-control" name="cargo" required value="<?= e($item['cargo']) ?>"></div>
    </div>
    <div class="form-group"><label>Biografia</label><textarea name="bio"><?= e($item['bio']) ?></textarea></div>
    <div class="form-grid">
        <div class="form-group">
            <label>Foto</label>
            <?php if ($item['foto']): ?><div style="margin-bottom:8px"><img class="thumb" src="<?= e(UPLOAD_URL . $item['foto']) ?>" alt=""></div><?php endif; ?>
            <input class="form-control" type="file" name="foto" accept="image/*">
        </div>
        <div class="form-group"><label>Ordem</label><input class="form-control" type="number" name="ordem" value="<?= e((string) $item['ordem']) ?>"></div>
    </div>
    <div class="form-group">
        <label>Status</label>
        <select name="status">
            <option value="ativo" <?= $item['status'] === 'ativo' ? 'selected' : '' ?>>Ativo</option>
            <option value="inativo" <?= $item['status'] === 'inativo' ? 'selected' : '' ?>>Inativo</option>
        </select>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Atualizar</button>
        <a class="btn btn-outline" href="<?= url('/admin/equipe/index.php') ?>">Voltar</a>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
