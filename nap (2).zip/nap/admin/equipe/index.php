<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Equipe';
$current = 'equipe';
$items = db()->query('SELECT * FROM equipe ORDER BY ordem ASC, id DESC')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>

<div class="toolbar">
    <p class="subtitle" style="margin:0">Membros da equipa</p>
    <a class="btn btn-primary" href="<?= url('/admin/equipe/criar.php') ?>"><i class="fas fa-plus"></i> Novo membro</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Foto</th><th>Nome</th><th>Cargo</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
            <?php if (!$items): ?>
                <tr><td colspan="5" class="empty">Nenhum membro cadastrado.</td></tr>
            <?php else: foreach ($items as $item): ?>
                <tr>
                    <td>
                        <?php if ($item['foto']): ?>
                            <img class="thumb" src="<?= e(UPLOAD_URL . $item['foto']) ?>" alt="">
                        <?php else: ?>
                            <div class="thumb" style="display:grid;place-items:center;background:#111111;color:#FF6200;font-weight:700"><?= e(user_initials($item['nome'])) ?></div>
                        <?php endif; ?>
                    </td>
                    <td><strong><?= e($item['nome']) ?></strong></td>
                    <td><?= e($item['cargo']) ?></td>
                    <td><?= status_badge($item['status']) ?></td>
                    <td class="actions">
                        <a class="btn btn-sm btn-outline" href="<?= url('/admin/equipe/editar.php?id=' . $item['id']) ?>"><i class="fas fa-pen"></i></a>
                        <a class="btn btn-sm btn-danger" data-confirm="Eliminar este membro?" href="<?= url('/admin/equipe/excluir.php?id=' . $item['id']) ?>"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
