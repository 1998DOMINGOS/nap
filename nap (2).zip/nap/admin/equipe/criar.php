<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Novo membro';
$current = 'equipe';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim($_POST['nome'] ?? '');
    $cargo = trim($_POST['cargo'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    $ordem = (int) ($_POST['ordem'] ?? 0);
    $status = $_POST['status'] === 'ativo' ? 'ativo' : 'inativo';
    $foto = null;

    if ($nome === '' || $cargo === '') {
        $errors[] = 'Nome e cargo são obrigatórios.';
    }

    try {
        if (!empty($_FILES['foto']['name'])) {
            $foto = upload_image($_FILES['foto'], 'equipe');
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }

    if (!$errors) {
        db()->prepare('INSERT INTO equipe (nome, cargo, bio, foto, ordem, status) VALUES (?,?,?,?,?,?)')
            ->execute([$nome, $cargo, $bio, $foto, $ordem, $status]);
        flash('success', 'Membro adicionado.');
        redirect('/admin/equipe/index.php');
    }
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Nome</label><input class="form-control" name="nome" required value="<?= e($_POST['nome'] ?? '') ?>"></div>
        <div class="form-group"><label>Cargo</label><input class="form-control" name="cargo" required value="<?= e($_POST['cargo'] ?? '') ?>"></div>
    </div>
    <div class="form-group"><label>Biografia</label><textarea name="bio"><?= e($_POST['bio'] ?? '') ?></textarea></div>
    <div class="form-grid">
        <div class="form-group"><label>Foto</label><input class="form-control" type="file" name="foto" accept="image/*"></div>
        <div class="form-group"><label>Ordem</label><input class="form-control" type="number" name="ordem" value="<?= e($_POST['ordem'] ?? '0') ?>"></div>
    </div>
    <div class="form-group">
        <label>Status</label>
        <select name="status"><option value="ativo">Ativo</option><option value="inativo">Inativo</option></select>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
        <a class="btn btn-outline" href="<?= url('/admin/equipe/index.php') ?>">Cancelar</a>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
