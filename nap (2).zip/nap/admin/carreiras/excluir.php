<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM candidaturas WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if ($item) {
    delete_upload($item['cv_arquivo']);
    db()->prepare('DELETE FROM candidaturas WHERE id = ?')->execute([$id]);
    flash('success', 'Candidatura eliminada.');
}
redirect('/admin/carreiras/index.php');
