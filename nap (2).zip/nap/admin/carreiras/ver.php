<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM candidaturas WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    flash('error', 'Candidatura não encontrada.');
    redirect('/admin/carreiras/index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $status = in_array($_POST['status'] ?? '', ['pendente', 'aprovada', 'rejeitada'], true) ? $_POST['status'] : 'pendente';
    db()->prepare('UPDATE candidaturas SET status = ? WHERE id = ?')->execute([$status, $id]);
    flash('success', 'Status da candidatura atualizado.');
    redirect('/admin/carreiras/ver.php?id=' . $id);
}

$pageTitle = 'Ver candidatura';
$current = 'carreiras';
require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
    <div class="form-grid" style="margin-bottom:16px">
        <div>
            <strong><?= e($item['nome']) ?></strong><br>
            <?= e($item['email']) ?><br>
            <?= e($item['telefone'] ?: 'Sem telefone') ?>
        </div>
        <div>
            Vaga: <strong><?= e($item['vaga'] ?: '—') ?></strong><br>
            Data: <?= e(format_date($item['criado_em'])) ?><br>
            Status: <?= status_badge($item['status']) ?>
        </div>
    </div>

    <?php if ($item['mensagem']): ?>
        <div class="msg-box" style="margin-bottom:16px"><?= e($item['mensagem']) ?></div>
    <?php endif; ?>

    <?php if ($item['cv_arquivo']): ?>
        <p><a class="btn btn-outline" href="<?= e(media_url($item['cv_arquivo'])) ?>" target="_blank"><i class="fas fa-file-pdf"></i> Abrir CV</a></p>
    <?php endif; ?>

    <form method="post" class="form-actions">
        <?= csrf_field() ?>
        <select name="status" style="max-width:220px">
            <option value="pendente" <?= $item['status'] === 'pendente' ? 'selected' : '' ?>>Pendente</option>
            <option value="aprovada" <?= $item['status'] === 'aprovada' ? 'selected' : '' ?>>Aprovada</option>
            <option value="rejeitada" <?= $item['status'] === 'rejeitada' ? 'selected' : '' ?>>Rejeitada</option>
        </select>
        <button class="btn btn-primary" type="submit">Atualizar</button>
        <a class="btn btn-outline" href="<?= url('/admin/carreiras/index.php') ?>">Voltar</a>
    </form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
