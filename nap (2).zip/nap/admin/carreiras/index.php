<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Candidaturas';
$current = 'carreiras';
$items = db()->query('SELECT * FROM candidaturas ORDER BY FIELD(status,"pendente","aprovada","rejeitada"), id DESC')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>Candidato</th><th>Vaga</th><th>Contacto</th><th>Status</th><th>Data</th><th>Ações</th></tr></thead>
            <tbody>
            <?php if (!$items): ?>
                <tr><td colspan="6" class="empty">Nenhuma candidatura.</td></tr>
            <?php else: foreach ($items as $item): ?>
                <tr>
                    <td><strong><?= e($item['nome']) ?></strong></td>
                    <td><?= e($item['vaga'] ?: '—') ?></td>
                    <td><?= e($item['email']) ?><?php if ($item['telefone']): ?><br><?= e($item['telefone']) ?><?php endif; ?></td>
                    <td><?= status_badge($item['status']) ?></td>
                    <td><?= e(format_date($item['criado_em'], 'd/m/Y')) ?></td>
                    <td class="actions">
                        <a class="btn btn-sm btn-outline" href="<?= url('/admin/carreiras/ver.php?id=' . $item['id']) ?>"><i class="fas fa-eye"></i></a>
                        <a class="btn btn-sm btn-danger" data-confirm="Eliminar candidatura?" href="<?= url('/admin/carreiras/excluir.php?id=' . $item['id']) ?>"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
