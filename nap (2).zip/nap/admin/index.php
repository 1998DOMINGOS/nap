<?php
/**
 * Tela de login — entrada do painel administrativo
 */
require_once __DIR__ . '/../config/app.php';

if (is_logged_in()) {
    redirect(auth_home_path());
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Preencha o email e a senha.';
    } else {
        try {
            if (attempt_login($email, $password)) {
                $welcome = is_contabilista()
                    ? 'Bem-vindo ao painel de contabilidade.'
                    : (is_faturacao() ? 'Bem-vindo ao painel de facturação.'
                    : (is_rh() ? 'Bem-vindo ao painel de Recursos Humanos.'
                    : (is_ti() ? 'Bem-vindo ao Departamento de Tecnologia.' : 'Bem-vindo ao painel administrativo.')));
                flash('success', $welcome);
                redirect(auth_home_path());
            }
            $error = 'Credenciais inválidas ou conta inativa.';
        } catch (Throwable $e) {
            $error = 'Erro de ligação à base de dados. Execute o install.php ou verifique config/database.php.';
        }
    }
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= url('/css/fonts.css') ?>">
    <link rel="stylesheet" href="<?= url('/vendor/fontawesome/css/all.min.css') ?>">
    <link rel="stylesheet" href="<?= url('/admin/assets/css/admin.css') ?>">
    <?php nap_swal_styles(); ?>
</head>
<body class="login-page">
    <div class="login-shell">
        <div class="login-panel">
            <div class="login-brand">
                <div class="login-logo login-logo-img">
                    <img src="<?= e(url('/imgs/logo-informatiza.svg?v=4')) ?>" alt="<?= e(APP_NAME) ?>">
                </div>
                <h1><?= e(APP_NAME) ?></h1>
                <p data-i18n="restricted_area">Área administrativa restrita</p>
            </div>
            <div class="login-preferences">
                <select id="language-selector" class="language-selector" aria-label="Idioma">
                    <option value="pt">PT</option>
                    <option value="en">EN</option>
                    <option value="fr">FR</option>
                </select>
                <button id="theme-toggle" class="theme-toggle" type="button" aria-label="Modo escuro" title="Modo escuro"><i class="fas fa-moon"></i></button>
            </div>

            <?php if ($flash): ?>
                <div class="alert alert-<?= e($flash['type'] === 'error' ? 'error' : 'success') ?>"><?= e($flash['message']) ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-error"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="post" class="login-form" autocomplete="off">
                <label for="email" data-i18n="email">Email</label>
                <div class="input-icon">
                    <i class="fas fa-envelope"></i>
                    <input type="email" id="email" name="email" required placeholder="admin@emifatijr.ao" value="<?= e($_POST['email'] ?? '') ?>">
                </div>

                <label for="password" data-i18n="password">Senha</label>
                <div class="input-icon">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" name="password" required placeholder="••••••••">
                </div>

                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-right-to-bracket"></i> <span data-i18n="sign_in">Entrar</span>
                </button>
            </form>

            <a href="<?= url('/') ?>" class="login-back">
                <i class="fas fa-arrow-left"></i> <span data-i18n="back_to_site">Voltar ao site</span>
            </a>
        </div>
        <div class="login-aside">
            <video class="login-video" autoplay muted loop playsinline poster="<?= e(url('/imgs/hero-1.jpg')) ?>" aria-hidden="true">
                <source src="https://cdn.coverr.co/videos/coverr-a-programmer-working-on-a-laptop-1573/1080p.mp4" type="video/mp4">
            </video>
            <div class="login-video-overlay"></div>
            <div class="login-aside-inner">
                <span class="pill"><i class="fas fa-lock"></i> <span data-i18n="secure_access">Acesso seguro</span></span>
                <h2><?= e(site_tagline()) ?></h2>
                <p>Gerencie conteúdos, serviços, mensagens e operações da <?= e(APP_NAME) ?> num único painel.</p>
            </div>
        </div>
    </div>
    <script src="<?= url('/js/site.js') ?>"></script>
    <?php nap_swal_scripts(); ?>
</body>
</html>
