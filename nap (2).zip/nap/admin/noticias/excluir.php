<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM noticias WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();

if ($item) {
    delete_upload($item['imagem']);
    db()->prepare('DELETE FROM noticias WHERE id = ?')->execute([$id]);
    flash('success', 'Notícia eliminada.');
} else {
    flash('error', 'Notícia não encontrada.');
}

redirect('/admin/noticias/index.php');
