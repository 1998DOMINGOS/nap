<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Nova notícia';
$current = 'noticias';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $titulo = trim($_POST['titulo'] ?? '');
    $resumo = trim($_POST['resumo'] ?? '');
    $conteudo = trim($_POST['conteudo'] ?? '');
    $status = $_POST['status'] === 'publicado' ? 'publicado' : 'rascunho';
    $slug = slugify($titulo);

    if ($titulo === '' || $conteudo === '') {
        $errors[] = 'Título e conteúdo são obrigatórios.';
    }

    $imagem = null;
    try {
        if (!empty($_FILES['imagem']['name'])) {
            $imagem = upload_image($_FILES['imagem'], 'noticias');
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }

    if (!$errors) {
        $stmt = db()->prepare('INSERT INTO noticias (titulo, slug, resumo, conteudo, imagem, status, autor_id, publicado_em) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $titulo,
            $slug . '-' . time(),
            $resumo,
            $conteudo,
            $imagem,
            $status,
            $_SESSION['user_id'],
            $status === 'publicado' ? date('Y-m-d H:i:s') : null,
        ]);
        flash('success', 'Notícia criada com sucesso.');
        redirect('/admin/noticias/index.php');
    }
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-body">
        <?php foreach ($errors as $err): ?>
            <div class="alert alert-error"><?= e($err) ?></div>
        <?php endforeach; ?>

        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="form-group">
                <label>Título</label>
                <input class="form-control" name="titulo" required value="<?= e($_POST['titulo'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Resumo</label>
                <textarea name="resumo"><?= e($_POST['resumo'] ?? '') ?></textarea>
            </div>
            <div class="form-group">
                <label>Conteúdo</label>
                <textarea name="conteudo" required style="min-height:220px"><?= e($_POST['conteudo'] ?? '') ?></textarea>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>Imagem de capa</label>
                    <input class="form-control" type="file" name="imagem" accept="image/*">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="rascunho">Rascunho</option>
                        <option value="publicado" <?= (($_POST['status'] ?? '') === 'publicado') ? 'selected' : '' ?>>Publicado</option>
                    </select>
                </div>
            </div>
            <div class="form-actions">
                <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
                <a class="btn btn-outline" href="<?= url('/admin/noticias/index.php') ?>">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
