<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM noticias WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    flash('error', 'Notícia não encontrada.');
    redirect('/admin/noticias/index.php');
}

$pageTitle = 'Editar notícia';
$current = 'noticias';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $titulo = trim($_POST['titulo'] ?? '');
    $resumo = trim($_POST['resumo'] ?? '');
    $conteudo = trim($_POST['conteudo'] ?? '');
    $status = $_POST['status'] === 'publicado' ? 'publicado' : 'rascunho';
    $imagem = $item['imagem'];

    if ($titulo === '' || $conteudo === '') {
        $errors[] = 'Título e conteúdo são obrigatórios.';
    }

    try {
        if (!empty($_FILES['imagem']['name'])) {
            $nova = upload_image($_FILES['imagem'], 'noticias');
            if ($nova) {
                delete_upload($imagem);
                $imagem = $nova;
            }
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }

    if (!$errors) {
        $publicado = $item['publicado_em'];
        if ($status === 'publicado' && !$publicado) {
            $publicado = date('Y-m-d H:i:s');
        }
        $upd = db()->prepare('UPDATE noticias SET titulo=?, resumo=?, conteudo=?, imagem=?, status=?, publicado_em=? WHERE id=?');
        $upd->execute([$titulo, $resumo, $conteudo, $imagem, $status, $publicado, $id]);
        flash('success', 'Notícia atualizada.');
        redirect('/admin/noticias/index.php');
    }
    $item = array_merge($item, compact('titulo', 'resumo', 'conteudo', 'status', 'imagem'));
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-body">
        <?php foreach ($errors as $err): ?>
            <div class="alert alert-error"><?= e($err) ?></div>
        <?php endforeach; ?>

        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="form-group">
                <label>Título</label>
                <input class="form-control" name="titulo" required value="<?= e($item['titulo']) ?>">
            </div>
            <div class="form-group">
                <label>Resumo</label>
                <textarea name="resumo"><?= e($item['resumo']) ?></textarea>
            </div>
            <div class="form-group">
                <label>Conteúdo</label>
                <textarea name="conteudo" required style="min-height:220px"><?= e($item['conteudo']) ?></textarea>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>Imagem de capa</label>
                    <?php if ($item['imagem']): ?>
                        <div style="margin-bottom:8px"><img class="thumb" src="<?= e(UPLOAD_URL . $item['imagem']) ?>" alt=""></div>
                    <?php endif; ?>
                    <input class="form-control" type="file" name="imagem" accept="image/*">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="rascunho" <?= $item['status'] === 'rascunho' ? 'selected' : '' ?>>Rascunho</option>
                        <option value="publicado" <?= $item['status'] === 'publicado' ? 'selected' : '' ?>>Publicado</option>
                    </select>
                </div>
            </div>
            <div class="form-actions">
                <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Atualizar</button>
                <a class="btn btn-outline" href="<?= url('/admin/noticias/index.php') ?>">Voltar</a>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
