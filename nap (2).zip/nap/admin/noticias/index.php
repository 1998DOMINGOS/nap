<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Notícias';
$pageSubtitle = 'Gerir publicações do site';
$current = 'noticias';

$q = trim($_GET['q'] ?? '');
$sql = 'SELECT n.*, u.nome AS autor FROM noticias n LEFT JOIN usuarios u ON u.id = n.autor_id';
$params = [];
if ($q !== '') {
    $sql .= ' WHERE n.titulo LIKE ? OR n.resumo LIKE ?';
    $params = ["%{$q}%", "%{$q}%"];
}
$sql .= ' ORDER BY n.id DESC';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

require __DIR__ . '/../includes/header.php';
?>

<div class="toolbar">
    <form class="search-form" method="get">
        <input type="search" name="q" value="<?= e($q) ?>" placeholder="Pesquisar notícias...">
        <button class="btn btn-outline" type="submit"><i class="fas fa-search"></i></button>
    </form>
    <a class="btn btn-primary" href="<?= url('/admin/noticias/criar.php') ?>"><i class="fas fa-plus"></i> Nova notícia</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Imagem</th>
                    <th>Título</th>
                    <th>Autor</th>
                    <th>Status</th>
                    <th>Data</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$items): ?>
                <tr><td colspan="6" class="empty">Nenhuma notícia encontrada.</td></tr>
            <?php else: foreach ($items as $item): ?>
                <tr>
                    <td>
                        <?php if ($item['imagem']): ?>
                            <img class="thumb" src="<?= e(UPLOAD_URL . $item['imagem']) ?>" alt="">
                        <?php else: ?>
                            <div class="thumb" style="display:grid;place-items:center;color:#9ca3af"><i class="fas fa-image"></i></div>
                        <?php endif; ?>
                    </td>
                    <td><strong><?= e($item['titulo']) ?></strong></td>
                    <td><?= e($item['autor'] ?: '—') ?></td>
                    <td><?= status_badge($item['status']) ?></td>
                    <td><?= e(format_date($item['criado_em'], 'd/m/Y')) ?></td>
                    <td class="actions">
                        <a class="btn btn-sm btn-outline" href="<?= url('/admin/noticias/editar.php?id=' . $item['id']) ?>"><i class="fas fa-pen"></i></a>
                        <a class="btn btn-sm btn-danger" data-confirm="Eliminar esta notícia?" href="<?= url('/admin/noticias/excluir.php?id=' . $item['id']) ?>"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
