<?php
$pageTitle = 'Dashboard TI';
$pageSubtitle = 'Suporte, projectos, activos e conteúdos digitais';
$current = 'ti-dashboard';
require_once __DIR__ . '/../../config/app.php';
ensure_ti_schema();

$kpi = ti_dashboard_kpis();
$chamados = ti_ultimos_chamados(8);
$projetos = ti_projetos_destaque(6);
$alertas = ti_ativos_alerta(5);
$chartPayload = [
    'chamados' => ti_chamados_series(6),
    'pipeline' => ti_chamados_pipeline(),
    'projetos' => ti_projetos_series(),
];

require __DIR__ . '/includes/header.php';
?>
<style>
.ti-charts { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 16px; }
.ti-chart-wrap { position: relative; height: 280px; }
@media (max-width: 960px) { .ti-charts { grid-template-columns: 1fr; } }
</style>

<div class="stats-grid" style="margin-top:0">
    <article class="stat-card"><div class="stat-icon warn"><i class="fas fa-headset"></i></div><div><span>Chamados em aberto</span><strong><?= (int) $kpi['chamados_abertos'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon error"><i class="fas fa-triangle-exclamation"></i></div><div><span>Críticos activos</span><strong><?= (int) $kpi['chamados_criticos'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon info"><i class="fas fa-diagram-project"></i></div><div><span>Projectos activos</span><strong><?= (int) $kpi['projetos_ativos'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon green"><i class="fas fa-server"></i></div><div><span>Activos operacionais</span><strong><?= (int) $kpi['ativos_operacionais'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon warn"><i class="fas fa-screwdriver-wrench"></i></div><div><span>Em manutenção</span><strong><?= (int) $kpi['ativos_manutencao'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon info"><i class="fas fa-envelope"></i></div><div><span>Mensagens novas</span><strong><?= (int) $kpi['mensagens_novas'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon dark"><i class="fas fa-briefcase"></i></div><div><span>Serviços no site</span><strong><?= (int) $kpi['servicos_site'] ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon green"><i class="fas fa-certificate"></i></div><div><span>Certificações activas</span><strong><?= (int) $kpi['certificacoes'] ?></strong></div></article>
</div>

<section class="ti-charts" aria-label="Gráficos TI">
    <div class="card"><div class="card-head"><h2>Chamados (6 meses)</h2></div>
        <div class="card-body"><div class="ti-chart-wrap"><canvas id="tiChartChamados"></canvas></div></div></div>
    <div class="card"><div class="card-head"><h2>Estado dos chamados</h2></div>
        <div class="card-body"><div class="ti-chart-wrap"><canvas id="tiChartPipeline"></canvas></div></div></div>
    <div class="card" style="grid-column:1/-1"><div class="card-head"><h2>Projectos por estado</h2><a class="link" href="<?= url('/admin/tecnologia/projetos.php') ?>">Gerir</a></div>
        <div class="card-body"><div class="ti-chart-wrap"><canvas id="tiChartProjetos"></canvas></div></div></div>
</section>

<div class="grid-2" style="margin-top:16px">
    <div class="card"><div class="card-head"><h2>Últimos chamados</h2><a class="link" href="<?= url('/admin/tecnologia/chamados.php') ?>">Ver todos</a></div>
        <div class="card-body table-wrap"><table>
            <thead><tr><th>Assunto</th><th>Prioridade</th><th>Estado</th><th></th></tr></thead>
            <tbody>
            <?php if (!$chamados): ?><tr><td colspan="4" class="empty">Sem chamados registados.</td></tr><?php endif; ?>
            <?php foreach ($chamados as $c): ?>
                <tr>
                    <td><?= e($c['titulo']) ?></td>
                    <td><?= ti_prioridade_badge($c['prioridade']) ?></td>
                    <td><?= ti_estado_chamado_badge($c['estado']) ?></td>
                    <td><a class="btn btn-sm btn-outline" href="<?= url('/admin/tecnologia/chamado.php?id=' . (int) $c['id']) ?>">Abrir</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div></div>

    <div class="card"><div class="card-head"><h2>Projectos em curso</h2><a class="link" href="<?= url('/admin/tecnologia/projetos.php') ?>">Ver todos</a></div>
        <div class="card-body table-wrap"><table>
            <thead><tr><th>Projecto</th><th>Progresso</th><th>Estado</th></tr></thead>
            <tbody>
            <?php if (!$projetos): ?><tr><td colspan="3" class="empty">Nenhum projecto activo.</td></tr><?php endif; ?>
            <?php foreach ($projetos as $p): ?>
                <tr>
                    <td><strong><?= e($p['nome']) ?></strong><?php if ($p['cliente_ref']): ?><br><span style="font-size:.8rem;color:var(--muted)"><?= e($p['cliente_ref']) ?></span><?php endif; ?></td>
                    <td><?= (int) $p['progresso'] ?>%</td>
                    <td><?= status_badge($p['estado']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div></div>
</div>

<?php if ($alertas): ?>
<div class="card" style="margin-top:16px"><div class="card-head"><h2>Activos — atenção</h2><a class="link" href="<?= url('/admin/tecnologia/ativos.php') ?>">Inventário</a></div><div class="card-body table-wrap"><table>
    <thead><tr><th>Código</th><th>Equipamento</th><th>Local</th><th>Estado</th></tr></thead>
    <tbody>
    <?php foreach ($alertas as $a): ?>
        <tr>
            <td><?= e($a['codigo'] ?: '—') ?></td>
            <td><?= e($a['nome']) ?></td>
            <td><?= e($a['localizacao'] ?: '—') ?></td>
            <td><?= status_badge($a['estado']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table></div></div>
<?php endif; ?>

<div class="card" style="margin-top:16px"><div class="card-head"><h2>Atalhos</h2></div><div class="card-body" style="display:flex;flex-wrap:wrap;gap:8px">
    <a class="btn btn-primary" href="<?= url('/admin/tecnologia/chamados.php') ?>"><i class="fas fa-plus"></i> Novo chamado</a>
    <a class="btn btn-outline" href="<?= url('/admin/tecnologia/projetos.php') ?>"><i class="fas fa-diagram-project"></i> Novo projecto</a>
    <a class="btn btn-outline" href="<?= url('/admin/tecnologia/ativos.php') ?>"><i class="fas fa-server"></i> Registar activo</a>
    <a class="btn btn-outline" href="<?= url('/admin/mensagens/index.php') ?>"><i class="fas fa-envelope"></i> Mensagens do site</a>
    <a class="btn btn-outline" href="<?= site_url('') ?>" target="_blank" rel="noopener"><i class="fas fa-external-link-alt"></i> Ver site</a>
</div></div>

<?php
$pageFootScripts = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>'
    . '<script>window.tiDashCharts = ' . json_encode($chartPayload, JSON_UNESCAPED_UNICODE) . ';</script>'
    . '<script src="' . e(url('/admin/tecnologia/assets/dashboard-charts.js')) . '"></script>';
require __DIR__ . '/includes/footer.php';
