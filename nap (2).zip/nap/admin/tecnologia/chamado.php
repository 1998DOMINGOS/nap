<?php
require_once __DIR__ . '/../../config/app.php';
ensure_ti_schema();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM ti_chamados WHERE id=?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    flash('error', 'Chamado não encontrado.');
    redirect('/admin/tecnologia/chamados.php');
}

$pageTitle = 'Chamado #' . $id;
$current = 'ti-chamados';
$errors = [];
$ok = null;
$tecnicos = db()->query("SELECT id, nome FROM usuarios WHERE ativo=1 AND nivel IN ('admin','editor','ti') ORDER BY nome")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $estado = in_array($_POST['estado'] ?? '', ['aberto', 'em_andamento', 'resolvido', 'fechado'], true) ? $_POST['estado'] : $item['estado'];
    $prio = in_array($_POST['prioridade'] ?? '', ['baixa', 'media', 'alta', 'critica'], true) ? $_POST['prioridade'] : $item['prioridade'];
    $atrib = (int) ($_POST['atribuido_a'] ?? 0);
    $resolvido = $item['resolvido_em'];
    if (in_array($estado, ['resolvido', 'fechado'], true) && empty($item['resolvido_em'])) {
        $resolvido = date('Y-m-d H:i:s');
    } elseif (in_array($estado, ['aberto', 'em_andamento'], true)) {
        $resolvido = null;
    }
    db()->prepare(
        'UPDATE ti_chamados SET titulo=?, descricao=?, solicitante=?, categoria=?, prioridade=?, estado=?, atribuido_a=?, resolvido_em=? WHERE id=?'
    )->execute([
        trim($_POST['titulo'] ?? '') ?: $item['titulo'],
        trim($_POST['descricao'] ?? '') ?: null,
        trim($_POST['solicitante'] ?? '') ?: null,
        in_array($_POST['categoria'] ?? '', ['hardware', 'software', 'rede', 'site', 'seguranca', 'outro'], true) ? $_POST['categoria'] : $item['categoria'],
        $prio,
        $estado,
        $atrib > 0 ? $atrib : null,
        $resolvido,
        $id,
    ]);
    $ok = 'Chamado actualizado.';
    $stmt->execute([$id]);
    $item = $stmt->fetch();
}

require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endif; ?>

<div class="card"><div class="card-body">
<p style="margin:0 0 16px"><a class="btn btn-outline btn-sm" href="<?= url('/admin/tecnologia/chamados.php') ?>"><i class="fas fa-arrow-left"></i> Voltar</a></p>
<form method="post"><?= csrf_field() ?>
<div class="form-group"><label>Título</label><input class="form-control" name="titulo" required value="<?= e($item['titulo']) ?>"></div>
<div class="form-group"><label>Solicitante</label><input class="form-control" name="solicitante" value="<?= e($item['solicitante'] ?? '') ?>"></div>
<div class="form-grid">
<div class="form-group"><label>Categoria</label><select name="categoria" class="form-control">
<?php foreach (['hardware' => 'Hardware', 'software' => 'Software', 'rede' => 'Rede', 'site' => 'Site / Web', 'seguranca' => 'Segurança', 'outro' => 'Outro'] as $k => $l): ?>
<option value="<?= $k ?>" <?= $item['categoria'] === $k ? 'selected' : '' ?>><?= e($l) ?></option>
<?php endforeach; ?>
</select></div>
<div class="form-group"><label>Prioridade</label><select name="prioridade" class="form-control">
<?php foreach (['baixa', 'media', 'alta', 'critica'] as $p): ?>
<option value="<?= $p ?>" <?= $item['prioridade'] === $p ? 'selected' : '' ?>><?= e(ucfirst($p === 'media' ? 'Média' : ($p === 'critica' ? 'Crítica' : $p))) ?></option>
<?php endforeach; ?>
</select></div>
</div>
<div class="form-grid">
<div class="form-group"><label>Estado</label><select name="estado" class="form-control">
<?php foreach (['aberto' => 'Aberto', 'em_andamento' => 'Em andamento', 'resolvido' => 'Resolvido', 'fechado' => 'Fechado'] as $k => $l): ?>
<option value="<?= $k ?>" <?= $item['estado'] === $k ? 'selected' : '' ?>><?= e($l) ?></option>
<?php endforeach; ?>
</select></div>
<div class="form-group"><label>Atribuído a</label><select name="atribuido_a" class="form-control">
<option value="0">— Não atribuído —</option>
<?php foreach ($tecnicos as $t): ?>
<option value="<?= (int) $t['id'] ?>" <?= (int) $item['atribuido_a'] === (int) $t['id'] ? 'selected' : '' ?>><?= e($t['nome']) ?></option>
<?php endforeach; ?>
</select></div>
</div>
<div class="form-group"><label>Descrição</label><textarea class="form-control" name="descricao" rows="6"><?= e($item['descricao'] ?? '') ?></textarea></div>
<p style="font-size:.85rem;color:var(--muted)">Aberto em <?= e(format_date($item['criado_em'], 'd/m/Y H:i')) ?><?php if ($item['resolvido_em']): ?> · Resolvido em <?= e(format_date($item['resolvido_em'], 'd/m/Y H:i')) ?><?php endif; ?></p>
<button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
</form>
</div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
