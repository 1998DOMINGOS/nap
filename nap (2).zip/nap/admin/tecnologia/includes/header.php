<?php

require_once __DIR__ . '/../../../config/app.php';

require_ti();



$user = current_user();

$pageTitle = $pageTitle ?? 'Tecnologia';

$current = $current ?? 'ti-dashboard';

$flash = get_flash();

$tiKpiNav = ti_dashboard_kpis();

?>

<!DOCTYPE html>

<html lang="pt">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= e($pageTitle) ?> — TI · <?= e(APP_NAME) ?></title>

    <link rel="stylesheet" href="<?= url('/css/fonts.css') ?>">

    <link rel="stylesheet" href="<?= url('/vendor/fontawesome/css/all.min.css') ?>">

    <link rel="stylesheet" href="<?= url('/admin/assets/css/admin.css') ?>">

    <?php nap_swal_styles(); ?>

</head>

<body>

<script>

(function () {

    try {

        var stored = localStorage.getItem('informatiza-theme');

        if (stored === 'dark' || (!stored && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)) {

            document.body.classList.add('dark-mode');

        }

    } catch (e) {}

})();

</script>

<div class="app">

    <aside class="sidebar" id="sidebar">

        <div class="brand">

            <div class="brand-mark"><img src="<?= e(url('/imgs/logo-informatiza.svg?v=4')) ?>" alt=""></div>

            <div>

                <strong>Tecnologia</strong>

                <span><?= e(APP_NAME) ?></span>

            </div>

        </div>

        <nav class="nav">

            <a href="<?= url('/admin/tecnologia/dashboard.php') ?>" class="<?= $current === 'ti-dashboard' ? 'active' : '' ?>"><i class="fas fa-gauge-high"></i> Dashboard</a>

            <a href="<?= url('/admin/tecnologia/chamados.php') ?>" class="<?= $current === 'ti-chamados' ? 'active' : '' ?>"><i class="fas fa-headset"></i> Chamados<?php if ($tiKpiNav['chamados_abertos'] > 0): ?> <span class="nav-count"><?= (int) $tiKpiNav['chamados_abertos'] ?></span><?php endif; ?></a>

            <a href="<?= url('/admin/tecnologia/projetos.php') ?>" class="<?= $current === 'ti-projetos' ? 'active' : '' ?>"><i class="fas fa-diagram-project"></i> Projectos</a>

            <a href="<?= url('/admin/tecnologia/ativos.php') ?>" class="<?= $current === 'ti-ativos' ? 'active' : '' ?>"><i class="fas fa-server"></i> Activos IT</a>

            <a href="<?= url('/admin/mensagens/index.php') ?>" class="<?= $current === 'mensagens' ? 'active' : '' ?>"><i class="fas fa-envelope"></i> Mensagens (site)<?php if ($tiKpiNav['mensagens_novas'] > 0): ?> <span class="nav-count"><?= (int) $tiKpiNav['mensagens_novas'] ?></span><?php endif; ?></a>

            <a href="<?= url('/admin/servicos/index.php') ?>" class="<?= $current === 'servicos' ? 'active' : '' ?>"><i class="fas fa-briefcase"></i> Serviços (site)</a>

            <a href="<?= url('/admin/noticias/index.php') ?>" class="<?= $current === 'noticias' ? 'active' : '' ?>"><i class="fas fa-newspaper"></i> Notícias</a>

            <a href="<?= url('/admin/certificacoes/index.php') ?>" class="<?= $current === 'certificacoes' ? 'active' : '' ?>"><i class="fas fa-certificate"></i> Certificações</a>

            <a href="<?= url('/admin/agenda/index.php') ?>" class="<?= $current === 'agenda' ? 'active' : '' ?>"><i class="fas fa-calendar-days"></i> Agenda</a>

            <a href="<?= url('/admin/galeria/index.php') ?>" class="<?= $current === 'galeria' ? 'active' : '' ?>"><i class="fas fa-images"></i> Galeria</a>

            <?php if (is_admin_user() || ($_SESSION['user_nivel'] ?? '') === 'editor'): ?>

                <a href="<?= url('/admin/dashboard.php') ?>" style="margin-top:12px;border-top:1px solid rgba(255,255,255,.1);padding-top:12px"><i class="fas fa-arrow-left"></i> Administração geral</a>

            <?php endif; ?>

        </nav>

        <div class="sidebar-foot">

            <a href="<?= url('/admin/logout.php') ?>" class="logout-link"><i class="fas fa-right-from-bracket"></i> Sair</a>

        </div>

    </aside>

    <div class="main">

        <header class="topbar">

            <button class="menu-toggle" id="menuToggle" type="button" aria-label="Menu"><i class="fas fa-bars"></i></button>

            <div class="topbar-title">

                <h1><?= e($pageTitle) ?></h1>

                <?php if (!empty($pageSubtitle)): ?><p><?= e($pageSubtitle) ?></p><?php endif; ?>

            </div>

            <div class="topbar-tools">

                <button id="theme-toggle" class="theme-toggle" type="button" aria-label="Modo escuro" title="Modo escuro"><i class="fas fa-moon"></i></button>

            </div>

            <div class="topbar-user">

                <div class="avatar"><?= e(user_initials($user['nome'] ?? '')) ?></div>

                <div>

                    <strong><?= e($user['nome'] ?? '') ?></strong>

                    <span>Departamento de Tecnologia</span>

                </div>

            </div>

        </header>

        <main class="content">

        <?php if ($flash): ?><div class="alert alert-<?= e($flash['type'] === 'error' ? 'error' : 'success') ?>"><?= e($flash['message']) ?></div><?php endif; ?>

