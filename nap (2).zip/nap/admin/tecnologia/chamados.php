<?php
$pageTitle = 'Chamados de suporte';
$current = 'ti-chamados';
require_once __DIR__ . '/../../config/app.php';
ensure_ti_schema();

$errors = [];
$ok = null;
$uid = (int) (current_user()['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'create';
    if ($action === 'delete') {
        db()->prepare('DELETE FROM ti_chamados WHERE id=?')->execute([(int) ($_POST['id'] ?? 0)]);
        $ok = 'Chamado eliminado.';
    } else {
        $titulo = trim($_POST['titulo'] ?? '');
        if ($titulo === '') {
            $errors[] = 'O título é obrigatório.';
        } else {
            $cat = in_array($_POST['categoria'] ?? '', ['hardware', 'software', 'rede', 'site', 'seguranca', 'outro'], true) ? $_POST['categoria'] : 'outro';
            $prio = in_array($_POST['prioridade'] ?? '', ['baixa', 'media', 'alta', 'critica'], true) ? $_POST['prioridade'] : 'media';
            db()->prepare(
                'INSERT INTO ti_chamados (titulo, descricao, solicitante, categoria, prioridade, criado_por) VALUES (?,?,?,?,?,?)'
            )->execute([
                $titulo,
                trim($_POST['descricao'] ?? '') ?: null,
                trim($_POST['solicitante'] ?? '') ?: null,
                $cat,
                $prio,
                $uid ?: null,
            ]);
            $ok = 'Chamado registado.';
        }
    }
}

$items = db()->query(
    'SELECT c.*, u.nome AS atribuido_nome FROM ti_chamados c
     LEFT JOIN usuarios u ON u.id=c.atribuido_a
     ORDER BY FIELD(c.estado,"aberto","em_andamento","resolvido","fechado"), FIELD(c.prioridade,"critica","alta","media","baixa"), c.id DESC
     LIMIT 150'
)->fetchAll();

require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>

<div class="grid-2">
<div class="card"><div class="card-body"><h3>Novo chamado</h3>
<form method="post"><?= csrf_field() ?>
<div class="form-group"><label>Título *</label><input class="form-control" name="titulo" required maxlength="200"></div>
<div class="form-group"><label>Solicitante</label><input class="form-control" name="solicitante" placeholder="Nome ou departamento"></div>
<div class="form-grid">
<div class="form-group"><label>Categoria</label><select name="categoria" class="form-control">
<option value="hardware">Hardware</option><option value="software">Software</option><option value="rede">Rede</option>
<option value="site">Site / Web</option><option value="seguranca">Segurança</option><option value="outro">Outro</option>
</select></div>
<div class="form-group"><label>Prioridade</label><select name="prioridade" class="form-control">
<option value="baixa">Baixa</option><option value="media" selected>Média</option><option value="alta">Alta</option><option value="critica">Crítica</option>
</select></div>
</div>
<div class="form-group"><label>Descrição</label><textarea class="form-control" name="descricao" rows="4"></textarea></div>
<button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Registar</button>
</form></div></div>

<div class="card"><div class="card-body"><h3>Lista de chamados</h3>
<div class="table-wrap"><table>
<thead><tr><th>ID</th><th>Assunto</th><th>Prioridade</th><th>Estado</th><th></th></tr></thead>
<tbody>
<?php if (!$items): ?><tr><td colspan="5" class="empty">Sem chamados.</td></tr><?php endif; ?>
<?php foreach ($items as $c): ?>
<tr>
<td>#<?= (int) $c['id'] ?></td>
<td><strong><?= e($c['titulo']) ?></strong><br><span style="font-size:.75rem;color:var(--muted)"><?= e($c['solicitante'] ?: '—') ?> · <?= e(ucfirst($c['categoria'])) ?></span></td>
<td><?= ti_prioridade_badge($c['prioridade']) ?></td>
<td><?= ti_estado_chamado_badge($c['estado']) ?></td>
<td style="white-space:nowrap">
<a class="btn btn-sm btn-outline" href="<?= url('/admin/tecnologia/chamado.php?id=' . (int) $c['id']) ?>">Abrir</a>
<form method="post" style="display:inline" data-confirm="Eliminar este chamado?"><?= csrf_field() ?>
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
<button class="btn btn-sm btn-danger" type="submit"><i class="fas fa-trash"></i></button></form>
</td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
