(function () {

  var data = window.tiDashCharts;

  if (!data || typeof Chart === 'undefined') {

    return;

  }



  var gridColor = 'rgba(148, 163, 184, 0.25)';

  var defaults = {

    responsive: true,

    maintainAspectRatio: false,

    plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, padding: 14 } } },

  };



  var c = data.chamados;

  var elCh = document.getElementById('tiChartChamados');

  if (elCh) {

    new Chart(elCh, {

      type: 'line',

      data: {

        labels: c.labels,

        datasets: [

          { label: 'Novos chamados', data: c.abertos, borderColor: '#6366f1', backgroundColor: 'rgba(99,102,241,.12)', fill: true, tension: 0.3 },

          { label: 'Resolvidos', data: c.resolvidos, borderColor: '#22c55e', backgroundColor: 'rgba(34,197,94,.1)', fill: false, tension: 0.3 },

        ],

      },

      options: Object.assign({}, defaults, {

        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } }, x: { grid: { display: false } } },

      }),

    });

  }



  var p = data.pipeline;

  var elPipe = document.getElementById('tiChartPipeline');

  if (elPipe) {

    new Chart(elPipe, {

      type: 'doughnut',

      data: {

        labels: ['Abertos', 'Em andamento', 'Resolvidos', 'Fechados'],

        datasets: [{

          data: [p.aberto, p.em_andamento, p.resolvido, p.fechado],

          backgroundColor: ['#3b82f6', '#f59e0b', '#22c55e', '#94a3b8'],

        }],

      },

      options: defaults,

    });

  }



  var pr = data.projetos;

  var elProj = document.getElementById('tiChartProjetos');

  if (elProj) {

    new Chart(elProj, {

      type: 'bar',

      data: {

        labels: pr.labels,

        datasets: [{

          label: 'Projectos',

          data: pr.valores,

          backgroundColor: ['#8b5cf6', '#6366f1', '#f59e0b', '#22c55e', '#ef4444'],

          borderRadius: 4,

        }],

      },

      options: Object.assign({}, defaults, {

        plugins: Object.assign({}, defaults.plugins, { legend: { display: false } }),

        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } }, x: { grid: { display: false } } },

      }),

    });

  }

})();

