<?php
$pageTitle = 'Projectos técnicos';
$current = 'ti-projetos';
require_once __DIR__ . '/../../config/app.php';
ensure_ti_schema();

$errors = [];
$ok = null;
$editId = (int) ($_GET['edit'] ?? 0);
$form = null;
if ($editId) {
    $st = db()->prepare('SELECT * FROM ti_projetos WHERE id=?');
    $st->execute([$editId]);
    $form = $st->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (($_POST['action'] ?? '') === 'delete') {
        db()->prepare('DELETE FROM ti_projetos WHERE id=?')->execute([(int) ($_POST['id'] ?? 0)]);
        $ok = 'Projecto eliminado.';
        $form = null;
        $editId = 0;
    } else {
        $nome = trim($_POST['nome'] ?? '');
        if ($nome === '') {
            $errors[] = 'Nome do projecto é obrigatório.';
        } else {
            $estado = in_array($_POST['estado'] ?? '', ['planeamento', 'em_curso', 'pausado', 'concluido', 'cancelado'], true) ? $_POST['estado'] : 'planeamento';
            $prio = in_array($_POST['prioridade'] ?? '', ['baixa', 'media', 'alta'], true) ? $_POST['prioridade'] : 'media';
            $prog = max(0, min(100, (int) ($_POST['progresso'] ?? 0)));
            $params = [
                $nome,
                trim($_POST['cliente_ref'] ?? '') ?: null,
                trim($_POST['descricao'] ?? '') ?: null,
                $estado,
                $prio,
                $prog,
                trim($_POST['data_inicio'] ?? '') ?: null,
                trim($_POST['data_fim_prev'] ?? '') ?: null,
                trim($_POST['responsavel'] ?? '') ?: null,
            ];
            $pid = (int) ($_POST['id'] ?? 0);
            if ($pid) {
                $params[] = $pid;
                db()->prepare(
                    'UPDATE ti_projetos SET nome=?, cliente_ref=?, descricao=?, estado=?, prioridade=?, progresso=?, data_inicio=?, data_fim_prev=?, responsavel=? WHERE id=?'
                )->execute($params);
                $ok = 'Projecto actualizado.';
            } else {
                db()->prepare(
                    'INSERT INTO ti_projetos (nome, cliente_ref, descricao, estado, prioridade, progresso, data_inicio, data_fim_prev, responsavel) VALUES (?,?,?,?,?,?,?,?,?)'
                )->execute($params);
                $ok = 'Projecto criado.';
            }
            $editId = 0;
            $form = null;
        }
    }
}

$items = db()->query('SELECT * FROM ti_projetos ORDER BY FIELD(estado,"em_curso","planeamento","pausado","concluido","cancelado"), id DESC')->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>

<div class="grid-2">
<div class="card"><div class="card-body"><h3><?= $form ? 'Editar projecto' : 'Novo projecto' ?></h3>
<form method="post"><?= csrf_field() ?>
<?php if ($form): ?><input type="hidden" name="id" value="<?= (int) $form['id'] ?>"><?php endif; ?>
<div class="form-group"><label>Nome *</label><input class="form-control" name="nome" required value="<?= e($form['nome'] ?? '') ?>"></div>
<div class="form-group"><label>Cliente / referência</label><input class="form-control" name="cliente_ref" value="<?= e($form['cliente_ref'] ?? '') ?>"></div>
<div class="form-group"><label>Responsável</label><input class="form-control" name="responsavel" value="<?= e($form['responsavel'] ?? '') ?>"></div>
<div class="form-grid">
<div class="form-group"><label>Estado</label><select name="estado" class="form-control">
<?php foreach (['planeamento' => 'Planeamento', 'em_curso' => 'Em curso', 'pausado' => 'Pausado', 'concluido' => 'Concluído', 'cancelado' => 'Cancelado'] as $k => $l): ?>
<option value="<?= $k ?>" <?= ($form['estado'] ?? 'planeamento') === $k ? 'selected' : '' ?>><?= e($l) ?></option>
<?php endforeach; ?>
</select></div>
<div class="form-group"><label>Prioridade</label><select name="prioridade" class="form-control">
<option value="baixa" <?= ($form['prioridade'] ?? '') === 'baixa' ? 'selected' : '' ?>>Baixa</option>
<option value="media" <?= ($form['prioridade'] ?? 'media') === 'media' ? 'selected' : '' ?>>Média</option>
<option value="alta" <?= ($form['prioridade'] ?? '') === 'alta' ? 'selected' : '' ?>>Alta</option>
</select></div>
</div>
<div class="form-grid">
<div class="form-group"><label>Início</label><input class="form-control" type="date" name="data_inicio" value="<?= e($form['data_inicio'] ?? '') ?>"></div>
<div class="form-group"><label>Fim previsto</label><input class="form-control" type="date" name="data_fim_prev" value="<?= e($form['data_fim_prev'] ?? '') ?>"></div>
</div>
<div class="form-group"><label>Progresso (%)</label><input class="form-control" type="number" min="0" max="100" name="progresso" value="<?= (int) ($form['progresso'] ?? 0) ?>"></div>
<div class="form-group"><label>Descrição</label><textarea class="form-control" name="descricao" rows="3"><?= e($form['descricao'] ?? '') ?></textarea></div>
<button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
<?php if ($form): ?><a class="btn btn-outline" href="<?= url('/admin/tecnologia/projetos.php') ?>">Cancelar</a><?php endif; ?>
</form></div></div>

<div class="card"><div class="card-body"><h3>Projectos</h3>
<table><thead><tr><th>Projecto</th><th>Progresso</th><th>Estado</th><th></th></tr></thead><tbody>
<?php foreach ($items as $p): ?>
<tr>
<td><strong><?= e($p['nome']) ?></strong><?php if ($p['cliente_ref']): ?><br><span style="font-size:.8rem;color:var(--muted)"><?= e($p['cliente_ref']) ?></span><?php endif; ?></td>
<td><?= (int) $p['progresso'] ?>%</td>
<td><?= status_badge($p['estado']) ?></td>
<td style="white-space:nowrap">
<a class="btn btn-sm btn-outline" href="<?= url('/admin/tecnologia/projetos.php?edit=' . (int) $p['id']) ?>">Editar</a>
<form method="post" style="display:inline" data-confirm="Eliminar projecto?"><?= csrf_field() ?>
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
<button class="btn btn-sm btn-danger" type="submit"><i class="fas fa-trash"></i></button></form>
</td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
