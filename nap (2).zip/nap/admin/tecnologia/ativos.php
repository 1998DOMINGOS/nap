<?php
$pageTitle = 'Inventário IT';
$current = 'ti-ativos';
require_once __DIR__ . '/../../config/app.php';
ensure_ti_schema();

$errors = [];
$ok = null;
$editId = (int) ($_GET['edit'] ?? 0);
$form = null;
if ($editId) {
    $st = db()->prepare('SELECT * FROM ti_ativos WHERE id=?');
    $st->execute([$editId]);
    $form = $st->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (($_POST['action'] ?? '') === 'delete') {
        db()->prepare('DELETE FROM ti_ativos WHERE id=?')->execute([(int) ($_POST['id'] ?? 0)]);
        $ok = 'Activo eliminado.';
        $form = null;
        $editId = 0;
    } else {
        $nome = trim($_POST['nome'] ?? '');
        if ($nome === '') {
            $errors[] = 'Nome do equipamento é obrigatório.';
        } else {
            $codigo = trim($_POST['codigo'] ?? '') ?: null;
            $tipo = in_array($_POST['tipo'] ?? '', ['computador', 'servidor', 'rede', 'impressora', 'telemovel', 'outro'], true) ? $_POST['tipo'] : 'computador';
            $estado = in_array($_POST['estado'] ?? '', ['ativo', 'manutencao', 'baixa'], true) ? $_POST['estado'] : 'ativo';
            $params = [
                $codigo,
                $nome,
                $tipo,
                trim($_POST['localizacao'] ?? '') ?: null,
                $estado,
                trim($_POST['numero_serie'] ?? '') ?: null,
                trim($_POST['notas'] ?? '') ?: null,
            ];
            $pid = (int) ($_POST['id'] ?? 0);
            try {
                if ($pid) {
                    $params[] = $pid;
                    db()->prepare(
                        'UPDATE ti_ativos SET codigo=?, nome=?, tipo=?, localizacao=?, estado=?, numero_serie=?, notas=? WHERE id=?'
                    )->execute($params);
                    $ok = 'Activo actualizado.';
                } else {
                    db()->prepare(
                        'INSERT INTO ti_ativos (codigo, nome, tipo, localizacao, estado, numero_serie, notas) VALUES (?,?,?,?,?,?,?)'
                    )->execute($params);
                    $ok = 'Activo registado.';
                }
                $editId = 0;
                $form = null;
            } catch (PDOException $e) {
                if (str_contains($e->getMessage(), 'uq_ti_ativo_codigo')) {
                    $errors[] = 'Já existe um activo com este código.';
                } else {
                    throw $e;
                }
            }
        }
    }
}

$items = db()->query('SELECT * FROM ti_ativos ORDER BY FIELD(estado,"ativo","manutencao","baixa"), nome')->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>

<div class="grid-2">
<div class="card"><div class="card-body"><h3><?= $form ? 'Editar activo' : 'Novo activo' ?></h3>
<form method="post"><?= csrf_field() ?>
<?php if ($form): ?><input type="hidden" name="id" value="<?= (int) $form['id'] ?>"><?php endif; ?>
<div class="form-grid">
<div class="form-group"><label>Código</label><input class="form-control" name="codigo" placeholder="IT-001" value="<?= e($form['codigo'] ?? '') ?>"></div>
<div class="form-group"><label>Nome *</label><input class="form-control" name="nome" required value="<?= e($form['nome'] ?? '') ?>"></div>
</div>
<div class="form-grid">
<div class="form-group"><label>Tipo</label><select name="tipo" class="form-control">
<?php foreach (['computador' => 'Computador', 'servidor' => 'Servidor', 'rede' => 'Rede', 'impressora' => 'Impressora', 'telemovel' => 'Telemóvel', 'outro' => 'Outro'] as $k => $l): ?>
<option value="<?= $k ?>" <?= ($form['tipo'] ?? 'computador') === $k ? 'selected' : '' ?>><?= e($l) ?></option>
<?php endforeach; ?>
</select></div>
<div class="form-group"><label>Estado</label><select name="estado" class="form-control">
<option value="ativo" <?= ($form['estado'] ?? 'ativo') === 'ativo' ? 'selected' : '' ?>>Activo</option>
<option value="manutencao" <?= ($form['estado'] ?? '') === 'manutencao' ? 'selected' : '' ?>>Manutenção</option>
<option value="baixa" <?= ($form['estado'] ?? '') === 'baixa' ? 'selected' : '' ?>>Baixa</option>
</select></div>
</div>
<div class="form-group"><label>Localização</label><input class="form-control" name="localizacao" value="<?= e($form['localizacao'] ?? '') ?>"></div>
<div class="form-group"><label>N.º série</label><input class="form-control" name="numero_serie" value="<?= e($form['numero_serie'] ?? '') ?>"></div>
<div class="form-group"><label>Notas</label><textarea class="form-control" name="notas" rows="2"><?= e($form['notas'] ?? '') ?></textarea></div>
<button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
<?php if ($form): ?><a class="btn btn-outline" href="<?= url('/admin/tecnologia/ativos.php') ?>">Cancelar</a><?php endif; ?>
</form></div></div>

<div class="card"><div class="card-body"><h3>Inventário</h3>
<table><thead><tr><th>Código</th><th>Equipamento</th><th>Local</th><th>Estado</th><th></th></tr></thead><tbody>
<?php if (!$items): ?><tr><td colspan="5" class="empty">Sem activos registados.</td></tr><?php endif; ?>
<?php foreach ($items as $a): ?>
<tr>
<td><?= e($a['codigo'] ?: '—') ?></td>
<td><?= e($a['nome']) ?><br><span style="font-size:.75rem;color:var(--muted)"><?= e(ucfirst($a['tipo'])) ?></span></td>
<td><?= e($a['localizacao'] ?: '—') ?></td>
<td><?= status_badge($a['estado']) ?></td>
<td style="white-space:nowrap">
<a class="btn btn-sm btn-outline" href="<?= url('/admin/tecnologia/ativos.php?edit=' . (int) $a['id']) ?>">Editar</a>
<form method="post" style="display:inline" data-confirm="Eliminar activo?"><?= csrf_field() ?>
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
<button class="btn btn-sm btn-danger" type="submit"><i class="fas fa-trash"></i></button></form>
</td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
