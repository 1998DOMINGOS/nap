<?php
$pageTitle = 'Salários';
$current = 'cont-sal';
require_once __DIR__ . '/../../config/app.php';
ensure_contabilidade_schema();
$errors = [];
$ok = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'funcionario') {
        db()->prepare('INSERT INTO cont_funcionarios (nome, nif, cargo, salario_base, subsidio, data_admissao) VALUES (?,?,?,?,?,?)')
            ->execute([
                trim($_POST['nome'] ?? ''),
                trim($_POST['nif'] ?? ''),
                trim($_POST['cargo'] ?? ''),
                (float) str_replace(',', '.', $_POST['salario_base'] ?? '0'),
                (float) str_replace(',', '.', $_POST['subsidio'] ?? '0'),
                $_POST['data_admissao'] ?? null,
            ]);
        $ok = 'Funcionário registado.';
    }
    if ($action === 'folha') {
        $ano = (int) ($_POST['ano'] ?? date('Y'));
        $mes = (int) ($_POST['mes'] ?? date('n'));
        $dataPag = $_POST['data_pagamento'] ?? date('Y-m-d');
        $substituir = !empty($_POST['substituir_folha']);
        $userId = (int) (current_user()['id'] ?? 0) ?: null;
        try {
            cont_gerar_folha_mensal($ano, $mes, $dataPag, $userId, $substituir);
            $ok = 'Folha ' . sprintf('%02d/%04d', $mes, $ano) . ($substituir ? ' substituída, ' : ' ') . 'processada e lançada.';
        } catch (RuntimeException $e) {
            $errors[] = $e->getMessage();
        }
    }
}

$funcionarios = db()->query('SELECT * FROM cont_funcionarios WHERE ativo=1 ORDER BY nome')->fetchAll();
$folhas = db()->query('SELECT * FROM cont_folhas ORDER BY ano DESC, mes DESC LIMIT 24')->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>
<div class="grid-2">
<div class="card"><div class="card-body"><h3>Funcionário</h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="funcionario">
<div class="form-group"><label>Nome *</label><input class="form-control" name="nome" required></div>
<div class="form-grid"><div class="form-group"><label>NIF</label><input class="form-control" name="nif"></div><div class="form-group"><label>Cargo</label><input class="form-control" name="cargo"></div></div>
<div class="form-grid"><div class="form-group"><label>Salário base</label><input class="form-control" name="salario_base"></div><div class="form-group"><label>Subsídio</label><input class="form-control" name="subsidio" value="0"></div></div>
<div class="form-group"><label>Admissão</label><input class="form-control" type="date" name="data_admissao"></div>
<button class="btn btn-primary" type="submit">Adicionar</button>
</form>
<h4 style="margin-top:20px">Activos (<?= count($funcionarios) ?>)</h4>
<ul><?php foreach ($funcionarios as $f): ?><li><?= e($f['nome']) ?> — <?= e(fat_format_money((float) $f['salario_base'] + (float) $f['subsidio'])) ?></li><?php endforeach; ?></ul>
</div></div>
<div class="card"><div class="card-body"><h3>Processar folha mensal</h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="folha">
<div class="form-grid">
<div class="form-group"><label>Ano</label><input class="form-control" type="number" name="ano" value="<?= (int) date('Y') ?>"></div>
<div class="form-group"><label>Mês</label><input class="form-control" type="number" min="1" max="12" name="mes" value="<?= (int) date('n') ?>"></div>
<div class="form-group"><label>Data pagamento</label><input class="form-control" type="date" name="data_pagamento" value="<?= date('Y-m-d') ?>"></div>
</div>
<p style="font-size:.85rem;color:#6b7280">Calcula INSS (3%) e IRT simplificado; gera lançamentos em 631/632/25/24/12.</p>
<label style="display:flex;align-items:center;gap:8px;margin:12px 0;font-size:.9rem"><input type="checkbox" name="substituir_folha" value="1"> Substituir folha existente (estorna lançamento anterior e recalcula)</label>
<button class="btn btn-primary" type="submit">Gerar e contabilizar folha</button>
</form>
<h4 style="margin-top:20px">Histórico</h4>
<table><thead><tr><th>Período</th><th>Bruto</th><th>Líquido</th><th>Estado</th></tr></thead><tbody>
<?php foreach ($folhas as $fo): ?><tr><td><?= sprintf('%02d/%04d', (int) $fo['mes'], (int) $fo['ano']) ?></td><td><?= e(fat_format_money((float) $fo['total_bruto'])) ?></td><td><?= e(fat_format_money((float) $fo['total_liquido'])) ?></td><td><?= e($fo['estado']) ?></td></tr><?php endforeach; ?>
</tbody></table>
</div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
