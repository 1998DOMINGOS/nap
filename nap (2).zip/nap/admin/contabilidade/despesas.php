<?php
$pageTitle = 'Despesas';
$current = 'cont-desp';
require_once __DIR__ . '/../../config/app.php';
ensure_contabilidade_schema();
$errors = [];
$ok = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $desc = trim($_POST['descricao'] ?? '');
    $cat = trim($_POST['categoria'] ?? 'Geral');
    $data = trim($_POST['data_despesa'] ?? date('Y-m-d'));
    $forn = trim($_POST['fornecedor_nome'] ?? '');
    $conta = trim($_POST['conta_despesa'] ?? '622');
    $sub = (float) str_replace(',', '.', $_POST['subtotal'] ?? '0');
    $iva = (float) str_replace(',', '.', $_POST['total_iva'] ?? '0');
    $metodo = in_array($_POST['metodo_pagamento'] ?? '', ['numerario', 'banco', 'multicaixa', 'outro'], true) ? $_POST['metodo_pagamento'] : 'banco';
    $ref = trim($_POST['referencia_doc'] ?? '');
    $aPagar = !empty($_POST['pagamento_pendiente']);
    $venc = trim($_POST['data_vencimento'] ?? '') ?: null;
    if ($venc && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $venc)) {
        $venc = null;
    }
    if ($desc === '') {
        $errors[] = 'Descrição obrigatória.';
    }
    if (!$errors) {
        $total = round($sub + $iva, 2);
        db()->prepare(
            'INSERT INTO cont_despesas (categoria, descricao, data_despesa, fornecedor_nome, conta_despesa, subtotal, total_iva, total, metodo_pagamento, pagamento_pendiente, data_vencimento, referencia_doc, criado_por) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)'
        )->execute([$cat, $desc, $data, $forn ?: null, $conta, $sub, $iva, $total, $metodo, $aPagar ? 1 : 0, $venc, $ref ?: null, current_user()['id'] ?? null]);
        $id = (int) db()->lastInsertId();
        cont_post_despesa($id, (int) (current_user()['id'] ?? 0));
        $ok = 'Despesa registada e lançada na contabilidade.';
    }
}

$items = db()->query('SELECT * FROM cont_despesas ORDER BY data_despesa DESC, id DESC LIMIT 200')->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>
<div class="grid-2">
<div class="card"><div class="card-body"><h3>Nova despesa</h3>
<form method="post"><?= csrf_field() ?>
<div class="form-group"><label>Descrição *</label><input class="form-control" name="descricao" required></div>
<div class="form-grid">
<div class="form-group"><label>Categoria</label><input class="form-control" name="categoria" value="Geral"></div>
<div class="form-group"><label>Data</label><input class="form-control" type="date" name="data_despesa" value="<?= date('Y-m-d') ?>"></div>
</div>
<div class="form-group"><label>Fornecedor / beneficiário</label><input class="form-control" name="fornecedor_nome"></div>
<div class="form-grid">
<div class="form-group"><label>Conta (plano)</label><input class="form-control" name="conta_despesa" value="622"></div>
<div class="form-group"><label>Pagamento</label><select name="metodo_pagamento"><option value="banco">Banco</option><option value="numerario">Numerário</option><option value="multicaixa">Multicaixa</option><option value="outro">Outro</option></select></div>
</div>
<div class="form-grid">
<div class="form-group"><label>Valor s/ IVA</label><input class="form-control" name="subtotal" required></div>
<div class="form-group"><label>IVA</label><input class="form-control" name="total_iva" value="0"></div>
</div>
<div class="form-group"><label>Referência documento</label><input class="form-control" name="referencia_doc"></div>
<div class="form-grid">
<div class="form-group"><label>Vencimento (se a pagar)</label><input class="form-control" type="date" name="data_vencimento"></div>
<div class="form-group" style="display:flex;align-items:flex-end"><label style="display:flex;gap:8px;align-items:center;margin:0"><input type="checkbox" name="pagamento_pendiente" value="1"> Conta a pagar (pendente)</label></div>
</div>
<button class="btn btn-primary" type="submit">Registar despesa</button>
</form></div></div>
<div class="card"><div class="card-body"><h3>Últimas despesas</h3>
<table><thead><tr><th>Data</th><th>Descrição</th><th>Total</th></tr></thead><tbody>
<?php foreach ($items as $i): ?><tr><td><?= e($i['data_despesa']) ?></td><td><?= e($i['descricao']) ?></td><td class="right"><?= e(fat_format_money((float) $i['total'])) ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
