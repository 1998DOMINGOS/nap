<?php
$pageTitle = 'Lançamentos contabilísticos';
$current = 'cont-mov';
require_once __DIR__ . '/../../config/app.php';
ensure_contabilidade_schema();
$errors = [];
$ok = null;
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$detalheId = !empty($_GET['id']) ? (int) $_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'manual') {
            $data = trim($_POST['data_movimento'] ?? date('Y-m-d'));
            $ref = trim($_POST['referencia'] ?? '');
            $desc = trim($_POST['descricao'] ?? '');
            if ($ref === '' || $desc === '') {
                throw new RuntimeException('Referência e descrição são obrigatórias.');
            }
            $contas = $_POST['conta'] ?? [];
            $debitos = $_POST['debito'] ?? [];
            $creditos = $_POST['credito'] ?? [];
            $linhas = [];
            $n = max(count($contas), count($debitos), count($creditos));
            for ($i = 0; $i < $n; ++$i) {
                $conta = trim((string) ($contas[$i] ?? ''));
                if ($conta === '') {
                    continue;
                }
                $d = (float) str_replace(',', '.', (string) ($debitos[$i] ?? '0'));
                $c = (float) str_replace(',', '.', (string) ($creditos[$i] ?? '0'));
                if ($d <= 0 && $c <= 0) {
                    continue;
                }
                $linhas[] = ['conta' => $conta, 'debito' => $d, 'credito' => $c, 'descricao' => trim((string) ($_POST['linha_desc'][$i] ?? ''))];
            }
            if (count($linhas) < 2) {
                throw new RuntimeException('Indique pelo menos duas linhas com conta e valor.');
            }
            cont_criar_movimento('ODI', $data, $ref, $desc, 'manual', null, $linhas, (int) (current_user()['id'] ?? 0));
            $ok = 'Lançamento manual (ODI) registado.';
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

$contasLanc = db()->query('SELECT codigo, nome FROM cont_contas WHERE ativo=1 AND aceita_lancamento=1 ORDER BY codigo')->fetchAll();
$stmt = db()->prepare(
    'SELECT m.*, d.codigo AS diario FROM cont_movimentos m INNER JOIN cont_diarios d ON d.id=m.diario_id
     WHERE m.anulado=0 AND m.data_movimento BETWEEN ? AND ? ORDER BY m.data_movimento DESC, m.id DESC LIMIT 300'
);
$stmt->execute([$from, $to]);
$movs = $stmt->fetchAll();
$detalhe = null;
$detalheLinhas = [];
if ($detalheId > 0) {
    $st = db()->prepare('SELECT m.*, d.codigo AS diario FROM cont_movimentos m INNER JOIN cont_diarios d ON d.id=m.diario_id WHERE m.id=?');
    $st->execute([$detalheId]);
    $detalhe = $st->fetch();
    if ($detalhe) {
        $ls = db()->prepare('SELECT * FROM cont_movimento_linhas WHERE movimento_id=? ORDER BY linha');
        $ls->execute([$detalheId]);
        $detalheLinhas = $ls->fetchAll();
    }
}
require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>
<div class="card"><div class="card-body">
<h3>Lançamento manual — diário ODI</h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="manual">
<div class="form-grid">
<div class="form-group"><label>Data</label><input type="date" class="form-control" name="data_movimento" value="<?= date('Y-m-d') ?>" required></div>
<div class="form-group"><label>Referência</label><input class="form-control" name="referencia" required placeholder="ODI-001"></div>
</div>
<div class="form-group"><label>Descrição</label><input class="form-control" name="descricao" required></div>
<table style="margin-top:12px"><thead><tr><th>Conta</th><th>Débito</th><th>Crédito</th><th>Nota</th></tr></thead><tbody>
<?php for ($r = 0; $r < 4; ++$r): ?>
<tr>
<td><input class="form-control" name="conta[]" list="contas-list" placeholder="622"></td>
<td><input class="form-control" name="debito[]" placeholder="0.00"></td>
<td><input class="form-control" name="credito[]" placeholder="0.00"></td>
<td><input class="form-control" name="linha_desc[]"></td>
</tr>
<?php endfor; ?>
</tbody></table>
<datalist id="contas-list">
<?php foreach ($contasLanc as $c): ?><option value="<?= e($c['codigo']) ?>"><?= e($c['nome']) ?></option><?php endforeach; ?>
</datalist>
<button class="btn btn-primary" type="submit" style="margin-top:12px">Registar ODI</button>
</form>
</div></div>
<div class="card"><div class="card-body">
<form method="get" class="form-grid"><div class="form-group"><label>De</label><input type="date" name="from" class="form-control" value="<?= e($from) ?>"></div><div class="form-group"><label>Até</label><input type="date" name="to" class="form-control" value="<?= e($to) ?>"></div><div class="form-actions"><button class="btn btn-primary">Filtrar</button></div></form>
<table style="margin-top:16px"><thead><tr><th>Data</th><th>Diário</th><th>Referência</th><th>Origem</th><th>Descrição</th><th></th></tr></thead><tbody>
<?php foreach ($movs as $m): ?>
<tr>
<td><?= e($m['data_movimento']) ?></td>
<td><?= e($m['diario']) ?></td>
<td><?= e($m['referencia']) ?></td>
<td><?= e($m['origem_tipo']) ?></td>
<td><?= e($m['descricao']) ?></td>
<td><a href="?from=<?= e(urlencode($from)) ?>&to=<?= e(urlencode($to)) ?>&id=<?= (int) $m['id'] ?>">Detalhe</a></td>
</tr>
<?php endforeach; ?>
</tbody></table>
<?php if ($detalhe): ?>
<h4 style="margin-top:20px">Detalhe #<?= (int) $detalhe['id'] ?> — <?= e($detalhe['referencia']) ?></h4>
<table><thead><tr><th>Conta</th><th>Débito</th><th>Crédito</th><th>Descrição</th></tr></thead><tbody>
<?php foreach ($detalheLinhas as $l): ?>
<tr><td><code><?= e($l['conta_codigo']) ?></code></td><td class="right"><?= e(number_format((float) $l['debito'], 2, ',', ' ')) ?></td><td class="right"><?= e(number_format((float) $l['credito'], 2, ',', ' ')) ?></td><td><?= e($l['descricao'] ?? '') ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php endif; ?>
</div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
