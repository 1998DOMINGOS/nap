<?php
$pageTitle = 'Contas a receber e a pagar';
$pageSubtitle = 'Clientes (2111) e fornecedores (2211)';
$current = 'cont-terceiros';
require_once __DIR__ . '/../../config/app.php';
require_contabilidade();
ensure_facturacao_schema();
ensure_contabilidade_schema();

$errors = [];
$ok = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'pagar_compra') {
            cont_marcar_compra_paga((int) ($_POST['compra_id'] ?? 0), trim($_POST['data_pagamento'] ?? '') ?: null);
            $ok = 'Compra marcada como paga.';
        }
        if ($action === 'pagar_despesa') {
            cont_marcar_despesa_paga((int) ($_POST['despesa_id'] ?? 0));
            $ok = 'Despesa marcada como paga.';
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

$receber = cont_listar_contas_receber();
$pagar = cont_listar_contas_pagar();
$totais = cont_totais_terceiros();

require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>

<div class="stats-grid" style="margin-bottom:18px">
    <article class="stat-card"><div class="stat-icon info"><i class="fas fa-hand-holding-dollar"></i></div><div><span>A receber (clientes)</span><strong><?= e(fat_format_money($totais['receber'])) ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon warn"><i class="fas fa-file-invoice"></i></div><div><span>A pagar (fornecedores)</span><strong><?= e(fat_format_money($totais['pagar'])) ?></strong></div></article>
</div>

<div class="card" style="margin-bottom:18px"><div class="card-body">
    <div class="toolbar" style="margin-bottom:12px">
        <h3 style="margin:0">Contas a receber</h3>
        <?php if (is_admin_user()): ?>
        <a class="btn btn-outline btn-sm" href="<?= url('/admin/facturacao/cobrancas.php') ?>">Cobranças (facturação)</a>
        <?php endif; ?>
    </div>
    <?php if (!$receber): ?>
        <p class="subtitle">Não há saldos em aberto de clientes.</p>
    <?php else: ?>
    <div class="table-wrap"><table>
        <thead><tr><th>Documento</th><th>Cliente</th><th>Data</th><th class="right">Total doc.</th><th class="right">Em dívida</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($receber as $r): ?>
            <tr>
                <td><?= e($r['tipo'] . ' ' . $r['numero_completo']) ?></td>
                <td><?= e($r['cliente_nome']) ?><br><span style="font-size:.8rem;color:var(--muted)"><?= e($r['cliente_nif']) ?></span></td>
                <td><?= e(format_date($r['data_documento'], 'd/m/Y')) ?></td>
                <td class="right"><?= e(fat_format_money((float) $r['total_doc'])) ?></td>
                <td class="right"><strong><?= e(fat_format_money((float) $r['saldo'])) ?></strong></td>
                <td><?php if (is_admin_user()): ?><a class="btn btn-outline btn-sm" href="<?= url('/admin/facturacao/documentos/ver.php?id=' . (int) $r['id']) ?>">Ver</a><?php endif; ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php endif; ?>
</div></div>

<div class="card"><div class="card-body">
    <h3>Contas a pagar</h3>
    <p class="subtitle" style="margin-top:0">Compras registadas a crédito e despesas marcadas como «a pagar».</p>
    <?php if (!$pagar): ?>
        <p class="subtitle">Não há contas a pagar pendentes.</p>
    <?php else: ?>
    <div class="table-wrap"><table>
        <thead><tr><th>Origem</th><th>Referência</th><th>Terceiro</th><th>Data</th><th>Vencimento</th><th class="right">Valor</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($pagar as $p): ?>
            <tr>
                <td><?= $p['origem'] === 'compra' ? 'Compra' : 'Despesa' ?></td>
                <td><?= e($p['referencia']) ?><?php if (!empty($p['descricao'])): ?><br><span style="font-size:.8rem;color:var(--muted)"><?= e($p['descricao']) ?></span><?php endif; ?></td>
                <td><?= e($p['terceiro']) ?></td>
                <td><?= e(format_date($p['data'], 'd/m/Y')) ?></td>
                <td><?= !empty($p['vencimento']) ? e(format_date($p['vencimento'], 'd/m/Y')) : '—' ?></td>
                <td class="right"><strong><?= e(fat_format_money((float) $p['total'])) ?></strong></td>
                <td>
                    <form method="post" style="display:inline-flex;gap:6px;align-items:center;flex-wrap:wrap">
                        <?= csrf_field() ?>
                        <?php if ($p['origem'] === 'compra'): ?>
                            <input type="hidden" name="action" value="pagar_compra">
                            <input type="hidden" name="compra_id" value="<?= (int) $p['id'] ?>">
                            <input class="form-control" type="date" name="data_pagamento" value="<?= date('Y-m-d') ?>" style="width:auto;padding:6px 8px">
                        <?php else: ?>
                            <input type="hidden" name="action" value="pagar_despesa">
                            <input type="hidden" name="despesa_id" value="<?= (int) $p['id'] ?>">
                        <?php endif; ?>
                        <button class="btn btn-primary btn-sm" type="submit">Marcar pago</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php endif; ?>
</div></div>

<?php require __DIR__ . '/includes/footer.php'; ?>
