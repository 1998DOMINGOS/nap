<?php
$pageTitle = 'Plano de contas';
$current = 'cont-plano';
require_once __DIR__ . '/../../config/app.php';
ensure_contabilidade_schema();
$errors = [];
$ok = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save') {
            cont_guardar_conta([
                'codigo' => $_POST['codigo'] ?? '',
                'nome' => $_POST['nome'] ?? '',
                'tipo' => $_POST['tipo'] ?? 'ativo',
                'categoria' => $_POST['categoria'] ?? 'GM',
                'conta_pai' => $_POST['conta_pai'] ?? '',
                'aceita_lancamento' => !empty($_POST['aceita_lancamento']),
            ], !empty($_POST['id']) ? (int) $_POST['id'] : null);
            $ok = 'Conta guardada.';
        }
        if ($action === 'desactivar' && !empty($_POST['id'])) {
            db()->prepare('UPDATE cont_contas SET ativo=0 WHERE id=?')->execute([(int) $_POST['id']]);
            $ok = 'Conta desactivada.';
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

$contas = db()->query('SELECT * FROM cont_contas WHERE ativo=1 ORDER BY codigo')->fetchAll();
$edit = null;
if (!empty($_GET['edit'])) {
    $st = db()->prepare('SELECT * FROM cont_contas WHERE id=? AND ativo=1');
    $st->execute([(int) $_GET['edit']]);
    $edit = $st->fetch() ?: null;
}
require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= e($e) ?></div><?php endforeach; ?>
<div class="grid-2">
<div class="card"><div class="card-body">
<h3><?= $edit ? 'Editar conta' : 'Nova conta' ?></h3>
<p style="font-size:.85rem;color:#6b7280">Alinhado ao SAF-T (AO): <code>GroupingCategory</code> GR / GA / GM e <code>GroupingCode</code> = conta pai.</p>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="save">
<?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
<div class="form-grid">
<div class="form-group"><label>Código (AccountID) *</label><input class="form-control" name="codigo" required value="<?= e($edit['codigo'] ?? '') ?>" <?= $edit ? 'readonly' : '' ?>></div>
<div class="form-group"><label>Nome *</label><input class="form-control" name="nome" required value="<?= e($edit['nome'] ?? '') ?>"></div>
<div class="form-group"><label>Tipo interno</label>
<select name="tipo" class="form-control">
<?php foreach (['ativo', 'passivo', 'patrimonio', 'custo', 'receita'] as $t): ?>
<option value="<?= $t ?>" <?= ($edit['tipo'] ?? '') === $t ? 'selected' : '' ?>><?= e($t) ?></option>
<?php endforeach; ?>
</select></div>
<div class="form-group"><label>Categoria SAF-T</label>
<select name="categoria" class="form-control">
<?php foreach (['GR' => 'GR — 1.º grau', 'GA' => 'GA — agregadora', 'GM' => 'GM — movimento'] as $k => $lab): ?>
<option value="<?= $k ?>" <?= ($edit['categoria'] ?? 'GM') === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
<?php endforeach; ?>
</select></div>
<div class="form-group"><label>Conta pai (GroupingCode)</label><input class="form-control" name="conta_pai" placeholder="Obrigatório se GA/GM" value="<?= e($edit['conta_pai'] ?? '') ?>"></div>
<div class="form-group"><label><input type="checkbox" name="aceita_lancamento" value="1" <?= !isset($edit['aceita_lancamento']) || !empty($edit['aceita_lancamento']) ? 'checked' : '' ?>> Aceita lançamentos</label></div>
</div>
<button class="btn btn-primary" type="submit">Guardar</button>
<?php if ($edit): ?><a class="btn btn-outline" href="<?= url('/admin/contabilidade/plano-contas.php') ?>">Cancelar</a><?php endif; ?>
</form>
</div></div>
<div class="card"><div class="card-body">
<table><thead><tr><th>Código</th><th>Nome</th><th>Cat.</th><th>Pai</th><th></th></tr></thead><tbody>
<?php foreach ($contas as $c): ?>
<tr>
<td><code><?= e($c['codigo']) ?></code></td>
<td><?= e($c['nome']) ?></td>
<td><?= e($c['categoria']) ?></td>
<td><?= e($c['conta_pai'] ?? '') ?></td>
<td>
<a class="btn btn-sm btn-outline" href="?edit=<?= (int) $c['id'] ?>">Editar</a>
<form method="post" style="display:inline" data-confirm="Desactivar esta conta?"><?= csrf_field() ?>
<input type="hidden" name="action" value="desactivar"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
<button class="btn btn-sm btn-outline" type="submit">Desactivar</button></form>
</td>
</tr>
<?php endforeach; ?>
</tbody></table>
</div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
