<?php
require_once __DIR__ . '/../../../config/app.php';
require_contabilidade();

$user = current_user();
$pageTitle = $pageTitle ?? 'Contabilidade';
$current = $current ?? 'cont-dashboard';
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> — Contabilidade · <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= url('/css/fonts.css') ?>">
    <link rel="stylesheet" href="<?= url('/vendor/fontawesome/css/all.min.css') ?>">
    <link rel="stylesheet" href="<?= url('/admin/assets/css/admin.css') ?>">
    <?php nap_swal_styles(); ?>
</head>
<body>
<script>
(function () {
    try {
        var stored = localStorage.getItem('informatiza-theme');
        if (stored === 'dark' || (!stored && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.body.classList.add('dark-mode');
        }
    } catch (e) {}
})();
</script>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <div class="brand-mark"><img src="<?= e(url('/imgs/logo-informatiza.svg?v=4')) ?>" alt=""></div>
            <div>
                <strong>Contabilidade</strong>
                <span><?= e(APP_NAME) ?></span>
            </div>
        </div>
        <nav class="nav">
            <a href="<?= url('/admin/contabilidade/dashboard.php') ?>" class="<?= $current === 'cont-dashboard' ? 'active' : '' ?>"><i class="fas fa-gauge-high"></i> Dashboard</a>
            <a href="<?= url('/admin/contabilidade/index.php') ?>" class="<?= $current === 'cont-resumo' ? 'active' : '' ?>"><i class="fas fa-chart-pie"></i> Resumo & IVA</a>
            <a href="<?= url('/admin/contabilidade/plano-contas.php') ?>" class="<?= $current === 'cont-plano' ? 'active' : '' ?>"><i class="fas fa-sitemap"></i> Plano de contas</a>
            <a href="<?= url('/admin/contabilidade/movimentos.php') ?>" class="<?= $current === 'cont-mov' ? 'active' : '' ?>"><i class="fas fa-book"></i> Lançamentos</a>
            <a href="<?= url('/admin/contabilidade/terceiros.php') ?>" class="<?= $current === 'cont-terceiros' ? 'active' : '' ?>"><i class="fas fa-arrows-left-right"></i> A receber / A pagar</a>
            <a href="<?= url('/admin/contabilidade/despesas.php') ?>" class="<?= $current === 'cont-desp' ? 'active' : '' ?>"><i class="fas fa-receipt"></i> Despesas</a>
            <a href="<?= url('/admin/contabilidade/salarios.php') ?>" class="<?= $current === 'cont-sal' ? 'active' : '' ?>"><i class="fas fa-users"></i> Salários</a>
            <a href="<?= url('/admin/contabilidade/declaracoes.php') ?>" class="<?= $current === 'cont-decl' ? 'active' : '' ?>"><i class="fas fa-file-invoice"></i> Declarações</a>
            <a href="<?= url('/admin/balancetes.php') ?>" class="<?= $current === 'cont-bal' ? 'active' : '' ?>"><i class="fas fa-scale-balanced"></i> Balancete</a>
            <?php if (is_admin_user()): ?>
                <a href="<?= url('/admin/dashboard.php') ?>" style="margin-top:12px;border-top:1px solid rgba(255,255,255,.1);padding-top:12px"><i class="fas fa-arrow-left"></i> Administração geral</a>
            <?php endif; ?>
        </nav>
        <div class="sidebar-foot">
            <a href="<?= url('/admin/logout.php') ?>" class="logout-link"><i class="fas fa-right-from-bracket"></i> Sair</a>
        </div>
    </aside>
    <div class="main">
        <header class="topbar">
            <button class="menu-toggle" id="menuToggle" type="button" aria-label="Menu"><i class="fas fa-bars"></i></button>
            <div class="topbar-title">
                <h1><?= e($pageTitle) ?></h1>
                <?php if (!empty($pageSubtitle)): ?><p><?= e($pageSubtitle) ?></p><?php endif; ?>
            </div>
            <div class="topbar-tools">
                <button id="theme-toggle" class="theme-toggle" type="button" aria-label="Modo escuro" title="Modo escuro"><i class="fas fa-moon"></i></button>
            </div>
            <div class="topbar-user">
                <div class="avatar"><?= e(user_initials($user['nome'] ?? '')) ?></div>
                <div>
                    <strong><?= e($user['nome'] ?? '') ?></strong>
                    <span>Contabilista</span>
                </div>
            </div>
        </header>
        <main class="content">
        <?php if ($flash): ?><div class="alert alert-<?= e($flash['type'] === 'error' ? 'error' : 'success') ?>"><?= e($flash['message']) ?></div><?php endif; ?>
