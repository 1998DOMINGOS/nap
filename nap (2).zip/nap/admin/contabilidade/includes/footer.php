        </main>
        <footer class="app-footer">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?> · Contabilidade</footer>
    </div>
</div>
<script src="<?= url('/js/site.js') ?>"></script>
<?php nap_swal_scripts(); ?>
<script src="<?= url('/admin/assets/js/admin.js') ?>"></script>
<?php if (!empty($pageFootScripts)): ?>
<?= $pageFootScripts ?>
<?php endif; ?>
</body>
</html>
