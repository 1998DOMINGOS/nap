(function () {
  var data = window.contDashCharts;
  if (!data || typeof Chart === 'undefined') {
    return;
  }

  var fmtKwanza = function (value) {
    var n = Number(value) || 0;
    return n.toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + ' Kz';
  };

  var gridColor = 'rgba(148, 163, 184, 0.25)';
  var defaults = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'bottom', labels: { boxWidth: 12, padding: 14 } },
      tooltip: {
        callbacks: {
          label: function (ctx) {
            var label = ctx.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (ctx.parsed.y !== undefined && ctx.parsed.y !== null) {
              label += fmtKwanza(ctx.parsed.y);
            } else if (ctx.parsed !== undefined) {
              label += fmtKwanza(ctx.parsed);
            }
            return label;
          },
        },
      },
    },
  };

  var s = data.series;
  var elFluxo = document.getElementById('chartFluxo');
  if (elFluxo) {
    new Chart(elFluxo, {
      type: 'bar',
      data: {
        labels: s.labels,
        datasets: [
          {
            label: 'Vendas (base)',
            data: s.vendas,
            backgroundColor: 'rgba(34, 197, 94, 0.75)',
            borderRadius: 4,
          },
          {
            label: 'Compras (base)',
            data: s.compras,
            backgroundColor: 'rgba(249, 115, 22, 0.75)',
            borderRadius: 4,
          },
          {
            label: 'Despesas (base)',
            data: s.despesas,
            backgroundColor: 'rgba(234, 179, 8, 0.75)',
            borderRadius: 4,
          },
        ],
      },
      options: Object.assign({}, defaults, {
        scales: {
          x: { grid: { display: false } },
          y: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: {
              callback: function (v) {
                return fmtKwanza(v);
              },
            },
          },
        },
      }),
    });
  }

  var elGastos = document.getElementById('chartGastos');
  if (elGastos) {
    new Chart(elGastos, {
      type: 'bar',
      data: {
        labels: s.labels,
        datasets: [
          {
            label: 'Compras',
            data: s.compras,
            backgroundColor: 'rgba(249, 115, 22, 0.85)',
            borderRadius: 4,
            stack: 'gastos',
          },
          {
            label: 'Despesas',
            data: s.despesas,
            backgroundColor: 'rgba(239, 68, 68, 0.85)',
            borderRadius: 4,
            stack: 'gastos',
          },
        ],
      },
      options: Object.assign({}, defaults, {
        scales: {
          x: { stacked: true, grid: { display: false } },
          y: {
            stacked: true,
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: {
              callback: function (v) {
                return fmtKwanza(v);
              },
            },
          },
        },
      }),
    });
  }

  var gc = data.gastosCategorias;
  var elGastosCat = document.getElementById('chartGastosCat');
  if (elGastosCat && gc && gc.labels.length) {
    new Chart(elGastosCat, {
      type: 'bar',
      data: {
        labels: gc.labels,
        datasets: [
          {
            label: 'Total',
            data: gc.values,
            backgroundColor: 'rgba(239, 68, 68, 0.75)',
            borderRadius: 4,
          },
        ],
      },
      options: Object.assign({}, defaults, {
        indexAxis: 'y',
        plugins: Object.assign({}, defaults.plugins, {
          legend: { display: false },
        }),
        scales: {
          x: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: {
              callback: function (v) {
                return fmtKwanza(v);
              },
            },
          },
          y: { grid: { display: false } },
        },
      }),
    });
  } else if (elGastosCat) {
    var gctx = elGastosCat.getContext('2d');
    gctx.font = '14px system-ui, sans-serif';
    gctx.fillStyle = '#6b7280';
    gctx.textAlign = 'center';
    gctx.fillText('Sem gastos registados neste mês', elGastosCat.width / 2, elGastosCat.height / 2);
  }

  var elIva = document.getElementById('chartIva');
  if (elIva) {
    new Chart(elIva, {
      type: 'line',
      data: {
        labels: s.labels,
        datasets: [
          {
            label: 'IVA liquidado',
            data: s.iva_liquidado,
            borderColor: 'rgb(59, 130, 246)',
            backgroundColor: 'rgba(59, 130, 246, 0.12)',
            fill: true,
            tension: 0.3,
          },
          {
            label: 'IVA dedutível',
            data: s.iva_dedutivel,
            borderColor: 'rgb(168, 85, 247)',
            backgroundColor: 'rgba(168, 85, 247, 0.08)',
            fill: true,
            tension: 0.3,
          },
        ],
      },
      options: Object.assign({}, defaults, {
        scales: {
          x: { grid: { display: false } },
          y: {
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: {
              callback: function (v) {
                return fmtKwanza(v);
              },
            },
          },
        },
      }),
    });
  }

  var im = data.ivaMes;
  var elIvaMes = document.getElementById('chartIvaMes');
  if (elIvaMes) {
    new Chart(elIvaMes, {
      type: 'doughnut',
      data: {
        labels: ['IVA liquidado', 'IVA ded. compras', 'IVA ded. despesas'],
        datasets: [
          {
            data: [im.liquidado, im.dedCompras, im.dedDespesas],
            backgroundColor: ['#3b82f6', '#a855f7', '#eab308'],
            borderWidth: 0,
          },
        ],
      },
      options: Object.assign({}, defaults, {
        cutout: '58%',
        plugins: Object.assign({}, defaults.plugins, {
          tooltip: {
            callbacks: {
              label: function (ctx) {
                return ctx.label + ': ' + fmtKwanza(ctx.parsed);
              },
            },
          },
        }),
      }),
    });
  }

  var d = data.diarios;
  var elDiarios = document.getElementById('chartDiarios');
  if (elDiarios && d.labels.length) {
    new Chart(elDiarios, {
      type: 'pie',
      data: {
        labels: d.labels,
        datasets: [
          {
            data: d.values,
            backgroundColor: ['#22c55e', '#3b82f6', '#f97316', '#6366f1', '#14b8a6', '#ec4899'],
            borderWidth: 2,
            borderColor: '#fff',
          },
        ],
      },
      options: Object.assign({}, defaults, {
        plugins: Object.assign({}, defaults.plugins, {
          tooltip: {
            callbacks: {
              label: function (ctx) {
                return ctx.label + ': ' + ctx.parsed + ' lançamento(s)';
              },
            },
          },
        }),
      }),
    });
  } else if (elDiarios) {
    var ctx = elDiarios.getContext('2d');
    ctx.font = '14px system-ui, sans-serif';
    ctx.fillStyle = '#6b7280';
    ctx.textAlign = 'center';
    ctx.fillText('Sem lançamentos neste mês', elDiarios.width / 2, elDiarios.height / 2);
  }
})();
