<?php

require_once __DIR__ . '/../../config/app.php';

require_contabilidade();

ensure_contabilidade_schema();



$pageTitle = 'Declarações fiscais';

$pageSubtitle = 'Mapas, anexos e exportação para a AGT';

$current = 'cont-decl';



$from = $_GET['from'] ?? date('Y-m-01');

$to = $_GET['to'] ?? date('Y-m-d');

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {

    $from = date('Y-m-01');

}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {

    $to = date('Y-m-d');

}

if ($from > $to) {

    [$from, $to] = [$to, $from];

}



$export = trim((string) ($_GET['export'] ?? ''));

if ($export !== '') {

    cont_export_declaracao($export, $from, $to);

}



$mapa = cont_mapa_iva($from, $to);

$empresa = fat_empresa();



function cont_decl_export_url(string $tipo, string $from, string $to): string

{

    return url('/admin/contabilidade/declaracoes.php?from=' . rawurlencode($from) . '&to=' . rawurlencode($to) . '&export=' . rawurlencode($tipo));

}



require __DIR__ . '/includes/header.php';

?>

<div class="card no-print"><div class="card-body">

<form method="get"><div class="form-grid"><div class="form-group"><label>Período — de</label><input type="date" class="form-control" name="from" value="<?= e($from) ?>"></div><div class="form-group"><label>Até</label><input type="date" class="form-control" name="to" value="<?= e($to) ?>"></div></div><div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-filter"></i> Actualizar período</button></div></form>

</div></div>



<div class="card no-print" style="margin-top:16px"><div class="card-head"><h2>Exportar declarações (CSV)</h2></div><div class="card-body">

<p style="font-size:.9rem;color:#6b7280;margin:0 0 12px">Ficheiros separados por ponto e vírgula (<code>;</code>), UTF-8 com BOM — compatível com Excel. Use o pacote ZIP para descarregar tudo de uma vez.</p>

<div style="display:flex;flex-wrap:wrap;gap:8px">

    <a class="btn btn-primary" href="<?= e(cont_decl_export_url('zip', $from, $to)) ?>"><i class="fas fa-file-zipper"></i> Pacote completo (ZIP)</a>

    <a class="btn btn-outline" href="<?= e(cont_decl_export_url('mapa_iva', $from, $to)) ?>"><i class="fas fa-file-csv"></i> Mapa IVA</a>

    <a class="btn btn-outline" href="<?= e(cont_decl_export_url('vendas', $from, $to)) ?>"><i class="fas fa-file-csv"></i> Vendas</a>

    <a class="btn btn-outline" href="<?= e(cont_decl_export_url('compras', $from, $to)) ?>"><i class="fas fa-file-csv"></i> Compras</a>

    <a class="btn btn-outline" href="<?= e(cont_decl_export_url('despesas', $from, $to)) ?>"><i class="fas fa-file-csv"></i> Despesas</a>

    <a class="btn btn-outline" href="<?= e(cont_decl_export_url('balancete', $from, $to)) ?>"><i class="fas fa-file-csv"></i> Balancete</a>

    <a class="btn btn-outline" href="<?= e(cont_decl_export_url('movimentos', $from, $to)) ?>"><i class="fas fa-file-csv"></i> Razão (lançamentos)</a>

</div>

</div></div>



<div class="toolbar no-print" style="margin-top:16px">

    <button class="btn btn-outline" type="button" onclick="window.print()"><i class="fas fa-print"></i> Imprimir / PDF</button>

    <a class="btn btn-outline" href="<?= url('/admin/balancetes.php?from=' . rawurlencode($from) . '&to=' . rawurlencode($to)) ?>"><i class="fas fa-scale-balanced"></i> Ver balancete</a>

</div>



<div class="report-sheet" style="margin-top:16px">

    <div class="report-header">

        <div>

            <h1>Mapa de IVA — apoio à declaração</h1>

            <p><?= e($empresa['nome'] ?? '') ?> · NIF <?= e($empresa['nif'] ?? '') ?></p>

        </div>

        <div><strong>Período</strong><br><?= e(format_date($from, 'd/m/Y')) ?> a <?= e(format_date($to, 'd/m/Y')) ?></div>

    </div>

    <table>

        <tbody>

            <tr><td>Vendas (base tributável)</td><td class="right"><?= e(fat_format_money($mapa['vendas_liquidas'])) ?></td></tr>

            <tr><td>IVA liquidado (vendas)</td><td class="right"><?= e(fat_format_money($mapa['iva_liquidado'])) ?></td></tr>

            <tr><td>Compras (base)</td><td class="right"><?= e(fat_format_money($mapa['compras_liquidas'])) ?></td></tr>

            <tr><td>IVA dedutível (compras)</td><td class="right"><?= e(fat_format_money($mapa['iva_dedutivel_compras'])) ?></td></tr>

            <tr><td>Despesas (base)</td><td class="right"><?= e(fat_format_money($mapa['despesas_liquidas'])) ?></td></tr>

            <tr><td>IVA dedutível (despesas)</td><td class="right"><?= e(fat_format_money($mapa['iva_dedutivel_despesas'])) ?></td></tr>

            <tr><td>IVA dedutível (total)</td><td class="right"><?= e(fat_format_money($mapa['iva_dedutivel_total'])) ?></td></tr>

            <tr class="total-row"><td><strong>IVA a pagar (estimativa)</strong></td><td class="right"><strong><?= e(fat_format_money($mapa['iva_a_pagar'])) ?></strong></td></tr>

        </tbody>

    </table>

    <div class="report-notes">

        <p>Documento de apoio à declaração periódica. Valide com extractos bancários e documentos físicos antes de submissão à AGT.</p>

        <p>Exporte os anexos (vendas, compras, despesas, balancete) para arquivo e entrega ao contabilista certificado.</p>

    </div>

</div>



<style>

@media print { .no-print { display: none !important; } body { background: #fff; } .sidebar, .topbar, .app-footer { display: none !important; } .main { margin: 0 !important; } .content { padding: 0 !important; } .report-sheet { margin: 0; max-width: none; box-shadow: none; } }

.report-sheet { background: #fff; padding: 24px; max-width: 900px; margin: 0 auto; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,.08); }

.report-header { display: flex; justify-content: space-between; gap: 16px; border-bottom: 2px solid #111; padding-bottom: 12px; margin-bottom: 20px; }

.report-header h1 { font-size: 1.35rem; margin: 0 0 6px; }

.report-sheet table { width: 100%; border-collapse: collapse; }

.report-sheet td { border: 1px solid #ddd; padding: 10px; }

.report-sheet .total-row td { background: #f9fafb; font-weight: 600; }

.right { text-align: right !important; }

.report-notes { font-size: .8rem; color: #6b7280; margin-top: 18px; }

.report-notes p { margin: 6px 0; }

</style>

<?php require __DIR__ . '/includes/footer.php'; ?>

