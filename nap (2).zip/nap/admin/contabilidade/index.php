<?php
$pageTitle = 'Resumo & IVA';
$pageSubtitle = 'Período e sincronização';
$current = 'cont-resumo';
require_once __DIR__ . '/../../config/app.php';
ensure_contabilidade_schema();

$from = $_GET['from'] ?? date('Y-01-01');
$to = $_GET['to'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
    $from = date('Y-01-01');
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
    $to = date('Y-m-d');
}

$ok = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'sync') {
    verify_csrf();
    $n = cont_sincronizar_historico((int) (current_user()['id'] ?? 0));
    $ok = sprintf(
        'Sincronização: %d vendas, %d compras, %d despesas, %d folhas.',
        $n['vendas'],
        $n['compras'],
        $n['despesas'],
        $n['folhas']
    );
}

$mapa = cont_mapa_iva($from, $to);
$stmtM = db()->prepare('SELECT COUNT(*) FROM cont_movimentos WHERE anulado=0 AND data_movimento BETWEEN ? AND ?');
$stmtM->execute([$from, $to]);
$movCount = (int) $stmtM->fetchColumn();
$empresa = fat_empresa();

require __DIR__ . '/includes/header.php';
?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<div class="card"><div class="card-body">
<form method="get"><div class="form-grid"><div class="form-group"><label>De</label><input type="date" class="form-control" name="from" value="<?= e($from) ?>"></div><div class="form-group"><label>Até</label><input type="date" class="form-control" name="to" value="<?= e($to) ?>"></div></div><div class="form-actions"><button class="btn btn-primary" type="submit">Actualizar período</button></div></form>
<form method="post" style="margin-top:12px"><?= csrf_field() ?><input type="hidden" name="action" value="sync"><button class="btn btn-outline" type="submit"><i class="fas fa-sync"></i> Gerar lançamentos em falta (vendas/compras)</button></form>
</div></div>
<section class="stats-grid">
    <article class="stat-card"><div class="stat-icon green"><i class="fas fa-percent"></i></div><div><span>IVA liquidado</span><strong><?= e(fat_format_money($mapa['iva_liquidado'])) ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon warn"><i class="fas fa-arrow-down"></i></div><div><span>IVA dedutível</span><strong><?= e(fat_format_money($mapa['iva_dedutivel_total'])) ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon info"><i class="fas fa-calculator"></i></div><div><span>IVA estimado a pagar</span><strong><?= e(fat_format_money($mapa['iva_a_pagar'])) ?></strong></div></article>
    <article class="stat-card"><div class="stat-icon dark"><i class="fas fa-coins"></i></div><div><span>Movimentos no período</span><strong><?= (int) $movCount ?></strong></div></article>
</section>
<div class="card"><div class="card-head"><h2>Resumo para declaração</h2></div><div class="card-body"><table><tbody>
<tr><td>Base vendas</td><td class="right"><?= e(fat_format_money($mapa['vendas_liquidas'])) ?></td></tr>
<tr><td>Base compras</td><td class="right"><?= e(fat_format_money($mapa['compras_liquidas'])) ?></td></tr>
<tr><td>Base despesas</td><td class="right"><?= e(fat_format_money($mapa['despesas_liquidas'])) ?></td></tr>
<tr><td><strong>IVA a entregar (estimativa)</strong></td><td class="right"><strong><?= e(fat_format_money($mapa['iva_a_pagar'])) ?></strong></td></tr>
</tbody></table></div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
