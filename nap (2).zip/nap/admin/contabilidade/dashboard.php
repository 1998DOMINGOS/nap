<?php

$pageTitle = 'Dashboard contabilidade';

$pageSubtitle = 'Visão geral para o contabilista';

$current = 'cont-dashboard';

require_once __DIR__ . '/../../config/app.php';

ensure_contabilidade_schema();
ensure_facturacao_schema();

$terceiros = cont_totais_terceiros();

$from = date('Y-m-01');

$to = date('Y-m-d');

$mapa = cont_mapa_iva($from, $to);

$series = cont_dashboard_series(6);

$porDiario = cont_movimentos_por_diario($from, $to);
$gastosCat = cont_gastos_por_categoria($from, $to);

$stmtM = db()->prepare('SELECT COUNT(*) FROM cont_movimentos WHERE anulado=0 AND data_movimento BETWEEN ? AND ?');

$stmtM->execute([$from, $to]);

$movCount = (int) $stmtM->fetchColumn();

$recent = db()->query(

    'SELECT m.data_movimento, m.referencia, m.descricao, d.codigo AS diario FROM cont_movimentos m

     INNER JOIN cont_diarios d ON d.id=m.diario_id WHERE m.anulado=0 ORDER BY m.id DESC LIMIT 8'

)->fetchAll();

$empresa = fat_empresa();



$chartPayload = [

    'series' => $series,

    'ivaMes' => [

        'liquidado' => (float) $mapa['iva_liquidado'],

        'dedCompras' => (float) $mapa['iva_dedutivel_compras'],

        'dedDespesas' => (float) $mapa['iva_dedutivel_despesas'],

    ],

    'diarios' => $porDiario,
    'gastosCategorias' => $gastosCat,

];



require __DIR__ . '/includes/header.php';

?>

<style>

.cont-charts { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 16px; }

.cont-charts .chart-card .card-body { padding: 12px 16px 20px; }

.cont-chart-wrap { position: relative; height: 280px; max-width: 100%; }

.cont-charts .chart-card-wide { grid-column: 1 / -1; }

@media (max-width: 960px) {

    .cont-charts { grid-template-columns: 1fr; }

    .cont-charts .chart-card-wide { grid-column: auto; }

}

</style>

<div class="stats-grid" style="margin-top:0">

    <article class="stat-card"><div class="stat-icon green"><i class="fas fa-file-invoice-dollar"></i></div><div><span>IVA liquidado (mês)</span><strong><?= e(fat_format_money($mapa['iva_liquidado'])) ?></strong></div></article>

    <article class="stat-card"><div class="stat-icon warn"><i class="fas fa-percent"></i></div><div><span>IVA dedutível</span><strong><?= e(fat_format_money($mapa['iva_dedutivel_total'])) ?></strong></div></article>

    <article class="stat-card"><div class="stat-icon info"><i class="fas fa-calculator"></i></div><div><span>IVA a pagar (est.)</span><strong><?= e(fat_format_money($mapa['iva_a_pagar'])) ?></strong></div></article>

    <article class="stat-card"><div class="stat-icon dark"><i class="fas fa-book"></i></div><div><span>Lançamentos (mês)</span><strong><?= (int) $movCount ?></strong></div></article>

    <article class="stat-card"><div class="stat-icon green"><i class="fas fa-hand-holding-dollar"></i></div><div><span>A receber</span><strong><?= e(fat_format_money($terceiros['receber'])) ?></strong></div></article>

    <article class="stat-card"><div class="stat-icon warn"><i class="fas fa-file-invoice"></i></div><div><span>A pagar</span><strong><?= e(fat_format_money($terceiros['pagar'])) ?></strong></div></article>

</div>



<section class="cont-charts" aria-label="Gráficos">

    <div class="card chart-card">

        <div class="card-head"><h2>Vendas vs compras e despesas (6 meses)</h2></div>

        <div class="card-body"><div class="cont-chart-wrap"><canvas id="chartFluxo"></canvas></div></div>

    </div>

    <div class="card chart-card">

        <div class="card-head"><h2>Evolução de gastos — compras e despesas (6 meses)</h2></div>

        <div class="card-body"><div class="cont-chart-wrap"><canvas id="chartGastos"></canvas></div></div>

    </div>

    <div class="card chart-card">

        <div class="card-head"><h2>Gastos por categoria (mês)</h2></div>

        <div class="card-body"><div class="cont-chart-wrap"><canvas id="chartGastosCat"></canvas></div></div>

    </div>

    <div class="card chart-card">

        <div class="card-head"><h2>IVA liquidado vs dedutível</h2></div>

        <div class="card-body"><div class="cont-chart-wrap"><canvas id="chartIva"></canvas></div></div>

    </div>

    <div class="card chart-card">

        <div class="card-head"><h2>IVA do mês (composição)</h2></div>

        <div class="card-body"><div class="cont-chart-wrap"><canvas id="chartIvaMes"></canvas></div></div>

    </div>

    <div class="card chart-card">

        <div class="card-head"><h2>Lançamentos por diário (mês)</h2></div>

        <div class="card-body"><div class="cont-chart-wrap"><canvas id="chartDiarios"></canvas></div></div>

    </div>

</section>



<div class="grid-2" style="margin-top:16px">

    <div class="card"><div class="card-head"><h2>Empresa</h2></div><div class="card-body">

        <p><strong><?= e($empresa['nome'] ?? '') ?></strong><br>NIF emitente: <?= e($empresa['nif'] ?? '') ?><br>Produtor software: <?= e($empresa['produtor_nome'] ?? '') ?> (<?= e($empresa['produtor_nif'] ?? '') ?>)</p>

        <p style="font-size:.85rem;color:#6b7280">SAF-T: <code><?= e(fat_saft_tax_accounting_basis($empresa)) ?></code> · Validação AGT: <code><?= e(fat_saft_validation_number($empresa)) ?></code></p>

    </div></div>

    <div class="card"><div class="card-head"><h2>Atalhos</h2></div><div class="card-body" style="display:flex;flex-wrap:wrap;gap:8px">

        <a class="btn btn-primary" href="<?= url('/admin/contabilidade/declaracoes.php') ?>"><i class="fas fa-download"></i> Mapa IVA / CSV</a>

        <a class="btn btn-outline" href="<?= url('/admin/contabilidade/terceiros.php') ?>"><i class="fas fa-arrows-left-right"></i> A receber / A pagar</a>

        <a class="btn btn-outline" href="<?= url('/admin/balancetes.php') ?>"><i class="fas fa-scale-balanced"></i> Balancete</a>

        <a class="btn btn-outline" href="<?= url('/admin/contabilidade/despesas.php') ?>"><i class="fas fa-receipt"></i> Despesas</a>

        <a class="btn btn-outline" href="<?= url('/admin/contabilidade/salarios.php') ?>"><i class="fas fa-users"></i> Folha salarial</a>

        <a class="btn btn-outline" href="<?= url('/admin/contabilidade/index.php') ?>"><i class="fas fa-sync"></i> Sincronizar lançamentos</a>

    </div></div>

</div>

<div class="card" style="margin-top:16px"><div class="card-head"><h2>Últimos lançamentos</h2></div><div class="card-body">

<table><thead><tr><th>Data</th><th>Diário</th><th>Ref.</th><th>Descrição</th></tr></thead><tbody>

<?php foreach ($recent as $r): ?><tr><td><?= e($r['data_movimento']) ?></td><td><?= e($r['diario']) ?></td><td><?= e($r['referencia']) ?></td><td><?= e($r['descricao']) ?></td></tr><?php endforeach; ?>

<?php if (!$recent): ?><tr><td colspan="4">Sem movimentos. Use <a href="<?= url('/admin/contabilidade/index.php') ?>">Resumo & IVA</a> para sincronizar vendas/compras.</td></tr><?php endif; ?>

</tbody></table>

</div></div>

<?php

$pageFootScripts = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>'

    . '<script>window.contDashCharts = ' . json_encode($chartPayload, JSON_UNESCAPED_UNICODE) . ';</script>'

    . '<script src="' . e(url('/admin/contabilidade/assets/dashboard-charts.js')) . '"></script>';

require __DIR__ . '/includes/footer.php';

?>

