<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Nossa Agenda';
$pageSubtitle = 'Partilhe actividades, projectos e próximos eventos';
$current = 'agenda';
$errors = [];
$editing = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'save';
    $id = (int) ($_POST['id'] ?? 0);
    if ($action === 'delete' && $id > 0) {
        $stmt = db()->prepare('SELECT foto1, foto2, foto3, foto4, foto5 FROM agenda WHERE id=?');
        $stmt->execute([$id]);
        $old = $stmt->fetch();
        db()->prepare('DELETE FROM agenda WHERE id=?')->execute([$id]);
        if ($old) foreach (['foto1','foto2','foto3','foto4','foto5'] as $foto) delete_upload($old[$foto] ?? null);
        flash('success', 'Item da agenda eliminado.');
        redirect('/admin/agenda/index.php');
    }

    $titulo = trim($_POST['titulo'] ?? '');
    $resumo = trim($_POST['resumo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $dataEvento = trim($_POST['data_evento'] ?? '');
    $localEvento = trim($_POST['local_evento'] ?? '');
    $status = ($_POST['status'] ?? 'rascunho') === 'publicado' ? 'publicado' : 'rascunho';
    if ($titulo === '') $errors[] = 'O título é obrigatório.';

    $fotos = [];
    if ($id > 0) {
        $stmt = db()->prepare('SELECT foto1, foto2, foto3, foto4, foto5 FROM agenda WHERE id=?');
        $stmt->execute([$id]);
        $currentPhotos = $stmt->fetch() ?: [];
        foreach (['foto1','foto2','foto3','foto4','foto5'] as $foto) $fotos[$foto] = $currentPhotos[$foto] ?? null;
    } else {
        foreach (['foto1','foto2','foto3','foto4','foto5'] as $foto) $fotos[$foto] = null;
    }
    foreach (['foto1','foto2','foto3','foto4','foto5'] as $foto) {
        if (!empty($_FILES[$foto]['name'])) {
            try { $fotos[$foto] = upload_image($_FILES[$foto], 'agenda'); }
            catch (Throwable $e) { $errors[] = $foto . ': ' . $e->getMessage(); }
        }
    }
    if (!$errors) {
        $values = [$titulo, $resumo, $descricao, $dataEvento !== '' ? date('Y-m-d H:i:s', strtotime($dataEvento)) : null, $localEvento, $fotos['foto1'], $fotos['foto2'], $fotos['foto3'], $fotos['foto4'], $fotos['foto5'], $status];
        if ($id > 0) {
            db()->prepare('UPDATE agenda SET titulo=?, resumo=?, descricao=?, data_evento=?, local_evento=?, foto1=?, foto2=?, foto3=?, foto4=?, foto5=?, status=? WHERE id=?')->execute([...$values, $id]);
            flash('success', 'Item da agenda actualizado.');
        } else {
            db()->prepare('INSERT INTO agenda (titulo,resumo,descricao,data_evento,local_evento,foto1,foto2,foto3,foto4,foto5,status) VALUES (?,?,?,?,?,?,?,?,?,?,?)')->execute($values);
            flash('success', 'Item da agenda criado.');
        }
        redirect('/admin/agenda/index.php');
    }
    $editing = $_POST;
} elseif (!empty($_GET['editar'])) {
    $stmt = db()->prepare('SELECT * FROM agenda WHERE id=?');
    $stmt->execute([(int) $_GET['editar']]);
    $editing = $stmt->fetch() ?: null;
}

$items = db()->query('SELECT * FROM agenda ORDER BY COALESCE(data_evento, criado_em) DESC, id DESC')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<div class="toolbar"><p class="subtitle" style="margin:0">Até 5 fotografias por item.</p></div>
<?php foreach ($errors as $error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endforeach; ?>
<div class="card"><div class="card-body">
<form method="post" enctype="multipart/form-data">
<?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= e((string)($editing['id'] ?? 0)) ?>">
<h2 style="margin-bottom:16px"><?= $editing ? 'Editar item' : 'Novo item' ?> da agenda</h2>
<div class="form-group"><label>Título</label><input class="form-control" name="titulo" required value="<?= e($editing['titulo'] ?? '') ?>"></div>
<div class="form-grid"><div class="form-group"><label>Resumo</label><input class="form-control" name="resumo" value="<?= e($editing['resumo'] ?? '') ?>"></div><div class="form-group"><label>Local</label><input class="form-control" name="local_evento" value="<?= e($editing['local_evento'] ?? '') ?>"></div></div>
<div class="form-group"><label>Descrição</label><textarea name="descricao"><?= e($editing['descricao'] ?? '') ?></textarea></div>
<div class="form-grid"><div class="form-group"><label>Data e hora</label><input class="form-control" type="datetime-local" name="data_evento" value="<?= !empty($editing['data_evento']) ? e(date('Y-m-d\TH:i', strtotime($editing['data_evento']))) : '' ?>"></div><div class="form-group"><label>Status</label><select name="status"><option value="rascunho" <?= ($editing['status'] ?? '') === 'rascunho' ? 'selected' : '' ?>>Rascunho</option><option value="publicado" <?= ($editing['status'] ?? '') === 'publicado' ? 'selected' : '' ?>>Publicado</option></select></div></div>
<div class="form-grid"><div class="form-group"><label>Fotografia 1</label><input class="form-control" type="file" name="foto1" accept="image/*"></div><div class="form-group"><label>Fotografia 2</label><input class="form-control" type="file" name="foto2" accept="image/*"></div><div class="form-group"><label>Fotografia 3</label><input class="form-control" type="file" name="foto3" accept="image/*"></div><div class="form-group"><label>Fotografia 4</label><input class="form-control" type="file" name="foto4" accept="image/*"></div><div class="form-group"><label>Fotografia 5</label><input class="form-control" type="file" name="foto5" accept="image/*"></div></div>
<div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button><?php if ($editing): ?><a class="btn btn-outline" href="<?= url('/admin/agenda/index.php') ?>">Cancelar</a><?php endif; ?></div>
</form></div></div>
<div class="card" style="margin-top:18px"><div class="card-head"><h2>Itens publicados e rascunhos (<?= count($items) ?>)</h2></div><div class="table-wrap"><table><thead><tr><th>Título</th><th>Data</th><th>Fotos</th><th>Status</th><th>Ações</th></tr></thead><tbody><?php if (!$items): ?><tr><td colspan="5" class="empty">Nenhum item na agenda.</td></tr><?php else: foreach ($items as $item): $photos = array_filter([$item['foto1'],$item['foto2'],$item['foto3'],$item['foto4'],$item['foto5']]); ?><tr><td><strong><?= e($item['titulo']) ?></strong><div style="color:#6b7280;font-size:.82rem"><?= e($item['local_evento']) ?></div></td><td><?= e(format_date($item['data_evento'])) ?></td><td><?= count($photos) ?>/5</td><td><?= status_badge($item['status']) ?></td><td class="actions"><a class="btn btn-sm btn-outline" href="?editar=<?= (int)$item['id'] ?>"><i class="fas fa-pen"></i></a><form method="post" style="display:inline" onsubmit="return confirm('Eliminar este item?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><button class="btn btn-sm btn-danger" type="submit"><i class="fas fa-trash"></i></button></form></td></tr><?php endforeach; endif; ?></tbody></table></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
