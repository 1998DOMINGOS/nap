<?php
require_once __DIR__ . '/../../config/app.php';
require_login();
$scriptPath = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
if (is_contabilista()) {
    $allowed = str_contains($scriptPath, '/contabilidade/') || str_ends_with($scriptPath, '/balancetes.php') || str_ends_with($scriptPath, '/logout.php');
    if (!$allowed) {
        redirect(auth_home_path());
    }
}
if (is_faturacao()) {
    $ownProfile = str_contains($scriptPath, '/usuarios/editar.php') && (int) ($_GET['id'] ?? 0) === (int) ($_SESSION['user_id'] ?? 0);
    $allowed = str_contains($scriptPath, '/facturacao/') || str_ends_with($scriptPath, '/logout.php') || $ownProfile;
    if (!$allowed) {
        redirect(auth_home_path());
    }
}
if (is_rh()) {
    $allowed = str_contains($scriptPath, '/rh/')
        || str_contains($scriptPath, '/equipe/')
        || str_ends_with($scriptPath, '/logout.php');
    if (!$allowed) {
        redirect(auth_home_path());
    }
}
if (is_ti()) {
    $allowed = str_contains($scriptPath, '/tecnologia/')
        || str_contains($scriptPath, '/servicos/')
        || str_contains($scriptPath, '/mensagens/')
        || str_contains($scriptPath, '/certificacoes/')
        || str_contains($scriptPath, '/agenda/')
        || str_contains($scriptPath, '/galeria/')
        || str_contains($scriptPath, '/noticias/')
        || str_ends_with($scriptPath, '/logout.php');
    if (!$allowed) {
        redirect(auth_home_path());
    }
}

$user = current_user();
$pageTitle = $pageTitle ?? 'Painel';
$current = $current ?? '';
$flash = get_flash();
$depoimentosPendentes = 0;
try {
    $depoimentosPendentes = count_table('depoimentos', "status = 'pendente'");
} catch (Throwable $e) {
    $depoimentosPendentes = 0;
}
$showFacturacaoNav = is_faturacao() || (str_contains($scriptPath, '/facturacao/') && !is_contabilista());
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> — <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= url('/css/fonts.css') ?>">
    <link rel="stylesheet" href="<?= url('/vendor/fontawesome/css/all.min.css') ?>">
    <link rel="stylesheet" href="<?= url('/admin/assets/css/admin.css') ?>">
    <?php nap_swal_styles(); ?>
    <?php if (!empty($extraCss)): ?>
    <link rel="stylesheet" href="<?= e($extraCss) ?>">
    <?php endif; ?>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <div class="brand-mark"><img src="<?= e(url('/imgs/logo-informatiza.svg?v=4')) ?>" alt=""></div>
            <div>
                <strong><?= e(APP_NAME) ?></strong>
                <span data-i18n="administration"><?= $showFacturacaoNav ? 'Facturação' : 'Administração' ?></span>
            </div>
        </div>

        <nav class="nav<?= $showFacturacaoNav ? ' nav-facturacao' : '' ?>">
            <?php if ($showFacturacaoNav): ?>
            <?php require __DIR__ . '/facturacao-nav.php'; ?>
            <?php else: ?>
            <a href="<?= url('/admin/dashboard.php') ?>" class="<?= $current === 'dashboard' ? 'active' : '' ?>"><i class="fas fa-gauge-high"></i> <span data-i18n="dashboard">Dashboard</span></a>
            <a href="<?= url('/admin/noticias/index.php') ?>" class="<?= $current === 'noticias' ? 'active' : '' ?>"><i class="fas fa-newspaper"></i> <span data-i18n="news">Notícias</span></a>
            <a href="<?= url('/admin/servicos/index.php') ?>" class="<?= $current === 'servicos' ? 'active' : '' ?>"><i class="fas fa-briefcase"></i> <span data-i18n="services">Serviços</span></a>
            <a href="<?= url('/admin/equipe/index.php') ?>" class="<?= $current === 'equipe' ? 'active' : '' ?>"><i class="fas fa-users"></i> <span data-i18n="team_short">Equipe</span></a>
            <a href="<?= url('/admin/depoimentos/index.php') ?>" class="<?= $current === 'depoimentos' ? 'active' : '' ?>"><i class="fas fa-quote-left"></i> <span data-i18n="testimonials">Depoimentos</span><?php if ($depoimentosPendentes > 0): ?> <span class="nav-count"><?= (int) $depoimentosPendentes ?></span><?php endif; ?></a>
            <a href="<?= url('/admin/galeria/index.php') ?>" class="<?= $current === 'galeria' ? 'active' : '' ?>"><i class="fas fa-images"></i> <span data-i18n="gallery">Galeria</span></a>
            <a href="<?= url('/admin/parceiros-clientes/index.php') ?>" class="<?= $current === 'parceiros-clientes' ? 'active' : '' ?>"><i class="fas fa-handshake"></i> Parceiros e Clientes</a>
            <a href="<?= url('/admin/agenda/index.php') ?>" class="<?= $current === 'agenda' ? 'active' : '' ?>"><i class="fas fa-calendar-days"></i> Nossa Agenda</a>
            <a href="<?= url('/admin/pca/index.php') ?>" class="<?= $current === 'pca' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> Mensagem do PCA</a>
            <a href="<?= url('/admin/certificacoes/index.php') ?>" class="<?= $current === 'certificacoes' ? 'active' : '' ?>"><i class="fas fa-certificate"></i> Certificações</a>
            <?php if (!is_contabilista()): ?>
            <a href="<?= url('/admin/facturacao/index.php') ?>" class="<?= str_starts_with((string) $current, 'fat') ? 'active' : '' ?>"><i class="fas fa-file-invoice-dollar"></i> <span data-i18n="billing">Facturação</span></a>
            <?php endif; ?>
            <?php if (!is_contabilista()): ?>
            <a href="<?= url('/admin/contabilidade/dashboard.php') ?>" class="<?= str_starts_with((string) $current, 'cont') || $current === 'contabilidade' ? 'active' : '' ?>"><i class="fas fa-calculator"></i> <span data-i18n="accounting">Contabilidade</span></a>
            <a href="<?= url('/admin/balancetes.php') ?>" class="<?= $current === 'balancetes' ? 'active' : '' ?>"><i class="fas fa-scale-balanced"></i> <span data-i18n="trial_balance">Balancetes</span></a>
            <?php endif; ?>
            <a href="<?= url('/admin/mensagens/index.php') ?>" class="<?= $current === 'mensagens' ? 'active' : '' ?>"><i class="fas fa-envelope"></i> <span data-i18n="messages">Mensagens</span></a>
            <a href="<?= url('/admin/rh/dashboard.php') ?>" class="<?= str_starts_with((string) $current, 'rh') ? 'active' : '' ?>"><i class="fas fa-people-group"></i> Recursos Humanos</a>
            <a href="<?= url('/admin/tecnologia/dashboard.php') ?>" class="<?= str_starts_with((string) $current, 'ti') ? 'active' : '' ?>"><i class="fas fa-microchip"></i> Tecnologia</a>
            <a href="<?= url('/admin/carreiras/index.php') ?>" class="<?= $current === 'carreiras' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> <span data-i18n="applications">Candidaturas</span></a>
            <?php if (($user['nivel'] ?? '') === 'admin'): ?>
                <a href="<?= url('/admin/usuarios/index.php') ?>" class="<?= $current === 'usuarios' ? 'active' : '' ?>"><i class="fas fa-users-gear"></i> Utilizadores</a>
                <a href="<?= url('/admin/configuracoes/index.php') ?>" class="<?= $current === 'configuracoes' ? 'active' : '' ?>"><i class="fas fa-gear"></i> <span data-i18n="settings">Configurações</span></a>
            <?php endif; ?>
            <?php endif; ?>
        </nav>

        <div class="sidebar-foot">
            <a href="<?= url('/admin/logout.php') ?>" class="logout-link"><i class="fas fa-right-from-bracket"></i> <span data-i18n="logout">Sair</span></a>
        </div>
    </aside>

    <div class="main">
        <header class="topbar<?= !empty($hideTopbarTitle) ? ' topbar-minimal' : '' ?>">
            <button class="menu-toggle" id="menuToggle" type="button" aria-label="Menu"><i class="fas fa-bars"></i></button>
            <?php if (empty($hideTopbarTitle)): ?>
            <div>
                <h1><?= e($pageTitle) ?></h1>
                <?php if (!empty($pageSubtitle)): ?>
                    <p class="subtitle"><?= e($pageSubtitle) ?></p>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <div class="topbar-spacer"></div>
            <?php endif; ?>
            <div class="topbar-tools">
                <select id="language-selector" class="language-selector" aria-label="Idioma">
                    <option value="pt">PT</option>
                    <option value="en">EN</option>
                    <option value="fr">FR</option>
                </select>
                <button id="theme-toggle" class="theme-toggle" type="button" aria-label="Modo escuro" title="Modo escuro"><i class="fas fa-moon"></i></button>
            </div>
            <div class="topbar-user">
                <div class="avatar"><?= e(user_initials()) ?></div>
                <div class="user-meta">
                    <strong><?= e($user['nome'] ?? '') ?></strong>
                    <span><?= e(ucfirst($user['nivel'] ?? '')) ?></span>
                </div>
            </div>
        </header>

        <main class="content<?= !empty($contentClass) ? ' ' . e($contentClass) : '' ?>">
            <?php if ($flash): ?>
                <div class="alert alert-<?= e($flash['type'] === 'error' ? 'error' : 'success') ?>">
                    <?= e($flash['message']) ?>
                </div>
            <?php endif; ?>
