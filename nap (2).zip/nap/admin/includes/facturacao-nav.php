<?php
/**
 * Menu lateral do módulo de facturação (agrupado).
 * Espera $current e $user no scope.
 */
$cur = (string) ($current ?? '');
$navActive = static function (string ...$keys) use ($cur): string {
    return in_array($cur, $keys, true) ? ' active' : '';
};
$navProdServico = ($cur === 'fat-produtos' && ($_GET['tipo'] ?? '') === 'servico') ? ' active' : '';
$navProdProduto = ($cur === 'fat-produtos' && ($_GET['tipo'] ?? 'produto') !== 'servico') ? ' active' : '';
?>
<?php if (!is_faturacao() && !is_contabilista()): ?>
<a href="<?= url('/admin/dashboard.php') ?>" class="nav-module-back"><i class="fas fa-arrow-left"></i> Painel geral</a>
<?php endif; ?>

<p class="nav-group-label">Operação</p>
<a href="<?= url('/admin/facturacao/index.php') ?>" class="<?= $navActive('fat') ?>"><i class="fas fa-gauge-high"></i> Dashboard</a>
<a href="<?= url('/admin/facturacao/vender.php') ?>" class="<?= $navActive('fat-vender') ?>"><i class="fas fa-cash-register"></i> Vender</a>
<a href="<?= url('/admin/facturacao/vendas.php') ?>" class="<?= $navActive('fat-vendas') ?>"><i class="fas fa-list-check"></i> Vendas</a>
<a href="<?= url('/admin/facturacao/cobrancas.php') ?>" class="<?= $navActive('fat-cobrancas') ?>"><i class="fas fa-hand-holding-dollar"></i> Cobranças</a>
<a href="<?= url('/admin/facturacao/caixa.php') ?>" class="<?= $navActive('fat-caixa') ?>"><i class="fas fa-lock-open"></i> Caixa</a>
<a href="<?= url('/admin/facturacao/documentos/criar.php?tipo=FT&modo=servico') ?>" class="<?= $navActive('fat-servico') ?>"><i class="fas fa-hand-holding-hand"></i> Prestar serviço</a>

<p class="nav-group-label">Documentos</p>
<a href="<?= url('/admin/facturacao/documentos/criar.php?tipo=OR') ?>" class="nav-sub"><i class="fas fa-file-signature"></i> Proposta orçamental (OR)</a>
<a href="<?= url('/admin/facturacao/documentos/criar.php?tipo=FT') ?>" class="nav-sub"><i class="fas fa-file-circle-plus"></i> Nova factura (venda)</a>
<a href="<?= url('/admin/facturacao/documentos/criar.php?tipo=ND') ?>" class="nav-sub"><i class="fas fa-file-medical"></i> Nota de débito</a>
<a href="<?= url('/admin/facturacao/documentos/criar.php?tipo=FA') ?>" class="nav-sub"><i class="fas fa-file-invoice-dollar"></i> Fatura adiantamento</a>
<a href="<?= url('/admin/facturacao/documentos/index.php') ?>" class="<?= $navActive('fat-docs') ?>"><i class="fas fa-file-invoice"></i> Todos os documentos</a>
<a href="<?= url('/admin/facturacao/recibos.php') ?>" class="<?= $navActive('fat-recibos') ?>"><i class="fas fa-receipt"></i> Recibos RC</a>
<a href="<?= url('/admin/facturacao/documentos/criar.php?tipo=GT') ?>" class="nav-sub"><i class="fas fa-truck"></i> Guia GT</a>
<a href="<?= url('/admin/facturacao/conferencia.php') ?>" class="nav-sub<?= $navActive('fat-conferencia') ?>"><i class="fas fa-clipboard-check"></i> Conferência 4.3</a>

<p class="nav-group-label">Cadastros</p>
<a href="<?= url('/admin/facturacao/clientes/index.php') ?>" class="<?= $navActive('fat-clientes') ?>"><i class="fas fa-users"></i> Clientes</a>
<a href="<?= url('/admin/facturacao/produtos/index.php?tipo=produto') ?>" class="<?= $navProdProduto ?>"><i class="fas fa-box"></i> Produtos</a>
<a href="<?= url('/admin/facturacao/produtos/index.php?tipo=servico') ?>" class="<?= $navProdServico ?>"><i class="fas fa-handshake"></i> Prestação de serviços</a>

<p class="nav-group-label">Compras e análise</p>
<a href="<?= url('/admin/facturacao/compras/index.php') ?>" class="<?= $navActive('fat-compras') ?>"><i class="fas fa-cart-shopping"></i> Compras</a>
<a href="<?= url('/admin/facturacao/relatorios.php') ?>" class="<?= $navActive('fat-relatorios') ?>"><i class="fas fa-chart-column"></i> Relatórios</a>

<p class="nav-group-label">AGT e conformidade</p>
<a href="<?= url('/admin/facturacao/empresa.php') ?>" class="<?= $navActive('fat-empresa') ?>"><i class="fas fa-building"></i> Empresa fiscal</a>
<a href="<?= url('/admin/facturacao/agt.php') ?>" class="<?= $navActive('fat-agt') ?>"><i class="fas fa-satellite-dish"></i> FE AGT</a>
<a href="<?= url('/admin/facturacao/certificacao.php') ?>" class="<?= $navActive('fat-cert') ?>"><i class="fas fa-certificate"></i> Certificação AGT</a>
<a href="<?= url('/admin/facturacao/saft.php') ?>" class="<?= $navActive('fat-saft') ?>"><i class="fas fa-file-export"></i> Exportar SAF-T AO</a>
<a href="<?= url('/admin/facturacao/series.php') ?>" class="nav-sub"><i class="fas fa-list-ol"></i> Séries AGT</a>
<a href="<?= url('/admin/facturacao/recuperacao.php') ?>" class="nav-sub"><i class="fas fa-life-ring"></i> Recuperação</a>
<a href="<?= url('/admin/facturacao/integracao.php') ?>" class="nav-sub"><i class="fas fa-plug"></i> Integração</a>
<a href="<?= url('/admin/facturacao/backups.php') ?>" class="nav-sub"><i class="fas fa-database"></i> Backups</a>
<a href="<?= url('/admin/facturacao/mobilidade.php') ?>" class="nav-sub"><i class="fas fa-mobile-screen"></i> Mobilidade</a>

<p class="nav-group-label">Conta</p>
<?php if (is_faturacao()): ?>
<a href="<?= url('/admin/usuarios/editar.php?id=' . (int) ($user['id'] ?? 0)) ?>" class="<?= $navActive('usuarios') ?>"><i class="fas fa-user"></i> Meu perfil</a>
<?php elseif (is_admin_user()): ?>
<a href="<?= url('/admin/usuarios/index.php') ?>" class="<?= $navActive('usuarios') ?>"><i class="fas fa-users-gear"></i> Utilizadores</a>
<?php endif; ?>
