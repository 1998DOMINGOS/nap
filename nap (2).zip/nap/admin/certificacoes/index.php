<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Certificações';
$pageSubtitle = 'Gerir certificações e reconhecimentos da empresa';
$current = 'certificacoes';
$errors = [];
$editing = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'save';
    $id = (int) ($_POST['id'] ?? 0);
    if ($action === 'delete' && $id > 0) {
        db()->prepare('DELETE FROM certificacoes WHERE id=?')->execute([$id]);
        flash('success', 'Certificação eliminada.');
        redirect('/admin/certificacoes/index.php');
    }
    $titulo = trim($_POST['titulo'] ?? '');
    $entidade = trim($_POST['entidade'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $imagem = trim($_POST['imagem'] ?? '');
    $link = trim($_POST['link'] ?? '');
    $ordem = (int) ($_POST['ordem'] ?? 0);
    $status = ($_POST['status'] ?? 'ativo') === 'ativo' ? 'ativo' : 'inativo';
    if ($titulo === '') $errors[] = 'O título é obrigatório.';
    if ($imagem !== '' && !filter_var($imagem, FILTER_VALIDATE_URL)) $errors[] = 'O link da imagem não é válido.';
    if ($link !== '' && !filter_var($link, FILTER_VALIDATE_URL)) $errors[] = 'O link da certificação não é válido.';
    if (!$errors) {
        if ($id > 0) {
            db()->prepare('UPDATE certificacoes SET titulo=?, entidade=?, descricao=?, imagem=?, link=?, ordem=?, status=? WHERE id=?')->execute([$titulo, $entidade, $descricao, $imagem ?: null, $link ?: null, $ordem, $status, $id]);
            flash('success', 'Certificação actualizada.');
        } else {
            db()->prepare('INSERT INTO certificacoes (titulo,entidade,descricao,imagem,link,ordem,status) VALUES (?,?,?,?,?,?,?)')->execute([$titulo, $entidade, $descricao, $imagem ?: null, $link ?: null, $ordem, $status]);
            flash('success', 'Certificação criada.');
        }
        redirect('/admin/certificacoes/index.php');
    }
    $editing = $_POST;
} elseif (!empty($_GET['editar'])) {
    $stmt = db()->prepare('SELECT * FROM certificacoes WHERE id=?');
    $stmt->execute([(int) $_GET['editar']]);
    $editing = $stmt->fetch() ?: null;
}
$items = db()->query('SELECT * FROM certificacoes ORDER BY ordem, titulo')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<div class="toolbar"><p class="subtitle" style="margin:0">Adicione certificações com imagem e link de validação.</p></div>
<?php foreach ($errors as $error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endforeach; ?>
<div class="card"><div class="card-body"><form method="post">
<?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= e((string)($editing['id'] ?? 0)) ?>">
<h2 style="margin-bottom:16px"><?= $editing ? 'Editar' : 'Nova' ?> certificação</h2>
<div class="form-grid"><div class="form-group"><label>Título</label><input class="form-control" name="titulo" required value="<?= e($editing['titulo'] ?? '') ?>"></div><div class="form-group"><label>Entidade certificadora</label><input class="form-control" name="entidade" value="<?= e($editing['entidade'] ?? '') ?>"></div></div>
<div class="form-group"><label>Descrição</label><input class="form-control" name="descricao" value="<?= e($editing['descricao'] ?? '') ?>"></div>
<div class="form-grid"><div class="form-group"><label>Link da imagem</label><input class="form-control" type="url" name="imagem" value="<?= e($editing['imagem'] ?? '') ?>" placeholder="https://.../certificado.png"></div><div class="form-group"><label>Link de validação</label><input class="form-control" type="url" name="link" value="<?= e($editing['link'] ?? '') ?>" placeholder="https://.../"></div></div>
<div class="form-grid"><div class="form-group"><label>Ordem</label><input class="form-control" type="number" name="ordem" value="<?= e((string)($editing['ordem'] ?? 0)) ?>"></div><div class="form-group"><label>Status</label><select name="status"><option value="ativo" <?= ($editing['status'] ?? 'ativo') === 'ativo' ? 'selected' : '' ?>>Activo</option><option value="inativo" <?= ($editing['status'] ?? '') === 'inativo' ? 'selected' : '' ?>>Inactivo</option></select></div></div>
<div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button><?php if ($editing): ?><a class="btn btn-outline" href="<?= url('/admin/certificacoes/index.php') ?>">Cancelar</a><?php endif; ?></div>
</form></div></div>
<div class="card" style="margin-top:18px"><div class="card-head"><h2>Certificações (<?= count($items) ?>)</h2></div><div class="table-wrap"><table><thead><tr><th>Título</th><th>Entidade</th><th>Imagem</th><th>Status</th><th>Ações</th></tr></thead><tbody><?php if (!$items): ?><tr><td colspan="5" class="empty">Nenhuma certificação cadastrada.</td></tr><?php else: foreach ($items as $item): ?><tr><td><strong><?= e($item['titulo']) ?></strong><div style="color:#6b7280;font-size:.82rem"><?= e($item['descricao']) ?></div></td><td><?= e($item['entidade'] ?: '—') ?></td><td><?= $item['imagem'] ? '<a href="' . e($item['imagem']) . '" target="_blank" rel="noopener">Abrir imagem</a>' : '—' ?></td><td><?= status_badge($item['status']) ?></td><td class="actions"><a class="btn btn-sm btn-outline" href="?editar=<?= (int)$item['id'] ?>"><i class="fas fa-pen"></i></a><form method="post" style="display:inline" onsubmit="return confirm('Eliminar esta certificação?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><button class="btn btn-sm btn-danger" type="submit"><i class="fas fa-trash"></i></button></form></td></tr><?php endforeach; endif; ?></tbody></table></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
