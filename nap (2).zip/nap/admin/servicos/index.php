<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Serviços';
$current = 'servicos';
$items = db()->query('SELECT * FROM servicos ORDER BY ordem ASC, id DESC')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>

<div class="toolbar">
    <p class="subtitle" style="margin:0">Serviços apresentados no site</p>
    <a class="btn btn-primary" href="<?= url('/admin/servicos/criar.php') ?>"><i class="fas fa-plus"></i> Novo serviço</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Ordem</th><th>Serviço</th><th>Ícone</th><th>Status</th><th>Ações</th></tr>
            </thead>
            <tbody>
            <?php if (!$items): ?>
                <tr><td colspan="5" class="empty">Nenhum serviço.</td></tr>
            <?php else: foreach ($items as $item): ?>
                <tr>
                    <td><?= (int) $item['ordem'] ?></td>
                    <td>
                        <strong><?= e($item['titulo']) ?></strong>
                        <div style="color:#6b7280;font-size:.82rem"><?= e($item['resumo']) ?></div>
                    </td>
                    <td><i class="fas <?= e($item['icone']) ?>"></i> <?= e($item['icone']) ?></td>
                    <td><?= status_badge($item['status']) ?></td>
                    <td class="actions">
                        <a class="btn btn-sm btn-outline" href="<?= url('/admin/servicos/editar.php?id=' . $item['id']) ?>"><i class="fas fa-pen"></i></a>
                        <a class="btn btn-sm btn-danger" data-confirm="Eliminar este serviço?" href="<?= url('/admin/servicos/excluir.php?id=' . $item['id']) ?>"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
