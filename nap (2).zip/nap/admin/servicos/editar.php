<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM servicos WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    flash('error', 'Serviço não encontrado.');
    redirect('/admin/servicos/index.php');
}

$pageTitle = 'Editar serviço';
$current = 'servicos';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $titulo = trim($_POST['titulo'] ?? '');
    $icone = trim($_POST['icone'] ?? 'fa-shield-alt');
    $resumo = trim($_POST['resumo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $ordem = (int) ($_POST['ordem'] ?? 0);
    $status = $_POST['status'] === 'ativo' ? 'ativo' : 'inativo';
    $imagem = $item['imagem'];

    if ($titulo === '') {
        $errors[] = 'O título é obrigatório.';
    }

    try {
        if (!empty($_FILES['imagem']['name'])) {
            $nova = upload_image($_FILES['imagem'], 'servicos');
            if ($nova) {
                delete_upload($imagem);
                $imagem = $nova;
            }
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }

    if (!$errors) {
        db()->prepare('UPDATE servicos SET titulo=?, icone=?, resumo=?, descricao=?, imagem=?, ordem=?, status=? WHERE id=?')
            ->execute([$titulo, $icone, $resumo, $descricao, $imagem, $ordem, $status, $id]);
        flash('success', 'Serviço atualizado.');
        redirect('/admin/servicos/index.php');
    }
    $item = array_merge($item, compact('titulo', 'icone', 'resumo', 'descricao', 'ordem', 'status', 'imagem'));
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Título</label><input class="form-control" name="titulo" required value="<?= e($item['titulo']) ?>"></div>
        <div class="form-group"><label>Ícone Font Awesome</label><input class="form-control" name="icone" value="<?= e($item['icone']) ?>"></div>
    </div>
    <div class="form-group"><label>Resumo</label><input class="form-control" name="resumo" value="<?= e($item['resumo']) ?>"></div>
    <div class="form-group"><label>Descrição</label><textarea name="descricao"><?= e($item['descricao']) ?></textarea></div>
    <div class="form-grid">
        <div class="form-group">
            <label>Imagem</label>
            <?php if ($item['imagem']): ?><div style="margin-bottom:8px"><img class="thumb" src="<?= e(UPLOAD_URL . $item['imagem']) ?>" alt=""></div><?php endif; ?>
            <input class="form-control" type="file" name="imagem" accept="image/*">
        </div>
        <div class="form-group"><label>Ordem</label><input class="form-control" type="number" name="ordem" value="<?= e((string) $item['ordem']) ?>"></div>
    </div>
    <div class="form-group">
        <label>Status</label>
        <select name="status">
            <option value="ativo" <?= $item['status'] === 'ativo' ? 'selected' : '' ?>>Ativo</option>
            <option value="inativo" <?= $item['status'] === 'inativo' ? 'selected' : '' ?>>Inativo</option>
        </select>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Atualizar</button>
        <a class="btn btn-outline" href="<?= url('/admin/servicos/index.php') ?>">Voltar</a>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
