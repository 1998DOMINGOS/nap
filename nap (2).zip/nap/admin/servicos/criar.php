<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$pageTitle = 'Novo serviço';
$current = 'servicos';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $titulo = trim($_POST['titulo'] ?? '');
    $icone = trim($_POST['icone'] ?? 'fa-shield-alt');
    $resumo = trim($_POST['resumo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $ordem = (int) ($_POST['ordem'] ?? 0);
    $status = $_POST['status'] === 'ativo' ? 'ativo' : 'inativo';
    $imagem = null;

    if ($titulo === '') {
        $errors[] = 'O título é obrigatório.';
    }

    try {
        if (!empty($_FILES['imagem']['name'])) {
            $imagem = upload_image($_FILES['imagem'], 'servicos');
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }

    if (!$errors) {
        $slug = slugify($titulo) . '-' . time();
        db()->prepare('INSERT INTO servicos (titulo, slug, icone, resumo, descricao, imagem, ordem, status) VALUES (?,?,?,?,?,?,?,?)')
            ->execute([$titulo, $slug, $icone, $resumo, $descricao, $imagem, $ordem, $status]);
        flash('success', 'Serviço criado.');
        redirect('/admin/servicos/index.php');
    }
}

require __DIR__ . '/../includes/header.php';
?>

<div class="card"><div class="card-body">
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="form-group"><label>Título</label><input class="form-control" name="titulo" required value="<?= e($_POST['titulo'] ?? '') ?>"></div>
        <div class="form-group"><label>Ícone Font Awesome</label><input class="form-control" name="icone" value="<?= e($_POST['icone'] ?? 'fa-shield-alt') ?>" placeholder="fa-video"></div>
    </div>
    <div class="form-group"><label>Resumo</label><input class="form-control" name="resumo" value="<?= e($_POST['resumo'] ?? '') ?>"></div>
    <div class="form-group"><label>Descrição</label><textarea name="descricao"><?= e($_POST['descricao'] ?? '') ?></textarea></div>
    <div class="form-grid">
        <div class="form-group"><label>Imagem</label><input class="form-control" type="file" name="imagem" accept="image/*"></div>
        <div class="form-group"><label>Ordem</label><input class="form-control" type="number" name="ordem" value="<?= e($_POST['ordem'] ?? '0') ?>"></div>
    </div>
    <div class="form-group">
        <label>Status</label>
        <select name="status">
            <option value="ativo">Ativo</option>
            <option value="inativo">Inativo</option>
        </select>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Guardar</button>
        <a class="btn btn-outline" href="<?= url('/admin/servicos/index.php') ?>">Cancelar</a>
    </div>
</form>
</div></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
