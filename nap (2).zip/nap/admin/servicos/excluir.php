<?php
require_once __DIR__ . '/../../config/app.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM servicos WHERE id = ?');
$stmt->execute([$id]);
$item = $stmt->fetch();
if ($item) {
    delete_upload($item['imagem']);
    db()->prepare('DELETE FROM servicos WHERE id = ?')->execute([$id]);
    flash('success', 'Serviço eliminado.');
} else {
    flash('error', 'Serviço não encontrado.');
}
redirect('/admin/servicos/index.php');
