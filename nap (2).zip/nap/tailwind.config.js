﻿/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./*.php', './includes/**/*.php', './admin/**/*.php', './api/**/*.php', './js/**/*.js'],
  theme: {
    extend: {
      colors: {
        /* Identidade INFORMATIZA — extraída da logomarca (SVG) */
        'ev-dark': '#071B4A',
        'ev-darker': '#041028',
        'ev-navy-mid': '#123C7A',
        'ev-gold': '#16B7E8',
        'ev-gold-light': '#5ECBF0',
        'ev-blue': '#0077C8',
        'ev-orange': '#FF6500',
        'ev-orange-bright': '#F15A0A',
        'ev-red': '#E05263',
        'ev-gray': '#E7F0F7',
        'paciolita-azul-escuro': '#071B4A',
        'paciolita-azul-claro': '#16B7E8',
        'paciolita-cinza': '#E7F0F7',
        'paciolita-branco-suave': '#F5F9FC',
        'paciolita-cinza-escuro': '#123C7A',
      },
      fontFamily: {
        poppins: ['Poppins', 'sans-serif'],
        oswald: ['Oswald', 'sans-serif'],
      },
    },
  },
  plugins: [],
  safelist: [
    { pattern: /^(bg|text|border|from|to|via)-ev-(dark|darker|navy-mid|gold|gold-light|blue|orange|orange-bright|red|gray)/ },
    { pattern: /^(bg|text|border)-paciolita-/ },
  ],
}
