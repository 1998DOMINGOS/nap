<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Sobre Nós — ' . setting('site_nome', APP_NAME);
$pageDescription = setting('site_nome', APP_NAME) . ' — soluções tecnológicas para organizações modernas.';
$currentPage = 'sobre';

$sede = setting('site_morada', 'Sede: Uíge | Luanda: Maianga, Edifício Unitel, 5.º andar | Huíla | Benguela | Mbanza Congo');
$tel = setting('site_telefone', '935406556');

require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">A CASA</p>
        <h1 class="text-4xl md:text-5xl font-bold">Sobre Nós</h1>
    </div>
</section>

<section class="py-16 bg-white">
    <div class="container mx-auto px-4 max-w-5xl animate-enter">
        <h2 class="text-3xl font-bold text-ev-dark mb-6"><?= e(setting('site_nome', APP_NAME)) ?> — <span class="text-ev-gold">Tecnologia que ajuda o país</span></h2>
        <p class="text-lg text-gray-700 mb-5">
            Se procura soluções tecnológicas eficientes, está no lugar certo. A <strong><?= e(setting('site_nome', APP_NAME)) ?></strong> desenvolve software, sites e infra-estruturas tecnológicas para empresas, instituições e famílias.
        </p>
        <p class="text-gray-700 mb-8">
            Existimos há <strong>6 anos</strong> e estamos presentes em <strong>5 províncias</strong>: temos a nossa sede no Uíge e presença em Luanda, Huíla, Benguela e Mbanza Congo. Em Luanda, estamos na Maianga, Edifício Unitel, 5.º andar.
        </p>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
            <div class="bg-paciolita-branco-suave rounded-2xl p-5 border border-gray-100">
                <p class="text-xs uppercase tracking-wide text-ev-gold font-semibold mb-1">Marca</p>
                <p class="font-bold text-ev-dark"><?= e(setting('site_nome', APP_NAME)) ?></p>
            </div>
            <div class="bg-paciolita-branco-suave rounded-2xl p-5 border border-gray-100">
                <p class="text-xs uppercase tracking-wide text-ev-gold font-semibold mb-1">Foco</p>
                <p class="font-bold text-ev-dark">6 anos</p>
            </div>
            <div class="bg-paciolita-branco-suave rounded-2xl p-5 border border-gray-100">
                <p class="text-xs uppercase tracking-wide text-ev-gold font-semibold mb-1">Lojas</p>
                <p class="font-bold text-ev-dark">5 províncias</p>
            </div>
            <div class="bg-paciolita-branco-suave rounded-2xl p-5 border border-gray-100">
                <p class="text-xs uppercase tracking-wide text-ev-gold font-semibold mb-1">Contacto</p>
                <p class="font-bold text-ev-dark text-sm leading-snug">+244 <?= e($tel) ?></p>
            </div>
        </div>

        <h3 class="text-2xl font-bold text-ev-dark mb-4">O que oferecemos</h3>
        <ul class="space-y-3 text-gray-700 mb-10">
            <li class="flex gap-3"><i class="fas fa-check text-ev-gold mt-1"></i><span>Desenvolvimento de softwares e sistemas à medida.</span></li>
            <li class="flex gap-3"><i class="fas fa-check text-ev-gold mt-1"></i><span>Criação de sites profissionais e soluções digitais.</span></li>
            <li class="flex gap-3"><i class="fas fa-check text-ev-gold mt-1"></i><span>Reparação e manutenção de computadores e impressoras.</span></li>
            <li class="flex gap-3"><i class="fas fa-check text-ev-gold mt-1"></i><span>Instalação de internet, câmaras de segurança e formação.</span></li>
        </ul>

        <div class="bg-ev-dark text-white rounded-2xl p-8 mb-10 border-l-4 border-ev-gold">
            <p class="text-xl md:text-2xl font-bold mb-2" style="font-family:'Oswald',sans-serif;">Tecnologia para todos os desafios</p>
            <p class="text-ev-gold text-lg font-semibold">Inovação, suporte e soluções em Angola.</p>
        </div>

        <div class="flex flex-wrap gap-4 mb-4">
            <a href="<?= site_url('missao') ?>" class="btn-ev">Missão e Visão</a>
            <a href="<?= site_url('galeria') ?>" class="btn-ev-gold">Ver Galeria</a>
            <a href="<?= site_url('contato') ?>" class="btn-ev-outline !text-ev-dark !border-ev-dark hover:!border-ev-gold hover:!text-ev-gold">Pedir Orçamento</a>
        </div>

        <p class="text-sm text-gray-500 mt-8"><i class="fas fa-map-marker-alt text-ev-gold mr-2"></i><?= e($sede) ?></p>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
