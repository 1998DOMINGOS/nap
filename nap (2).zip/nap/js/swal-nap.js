/**
 * SweetAlert2 — mensagens, confirmações e toasts em todo o NAP.
 */
(function () {
  if (typeof Swal === 'undefined') {
    return;
  }

  function isDark() {
    return document.body.classList.contains('dark-mode');
  }

  function baseOptions() {
    return {
      color: isDark() ? '#e5edf5' : '#1f2937',
      background: isDark() ? '#102943' : '#ffffff',
      confirmButtonColor: '#16b7e8',
      cancelButtonColor: '#6b7280',
      customClass: {
        confirmButton: 'btn btn-primary swal2-confirm',
        cancelButton: 'btn btn-outline swal2-cancel',
        denyButton: 'btn btn-outline',
      },
      buttonsStyling: false,
    };
  }

  function titleForIcon(icon) {
    if (icon === 'success') return 'Sucesso';
    if (icon === 'error') return 'Erro';
    if (icon === 'warning') return 'Atenção';
    if (icon === 'question') return 'Confirmar';
    return 'Informação';
  }

  window.NAP = window.NAP || {};

  window.NAP.alert = function (message, icon, title) {
    icon = icon || 'info';
    return Swal.fire({
      ...baseOptions(),
      icon: icon,
      title: title || titleForIcon(icon),
      text: message,
      confirmButtonText: 'OK',
    });
  };

  window.NAP.confirm = function (message, opts) {
    opts = opts || {};
    return Swal.fire({
      ...baseOptions(),
      icon: opts.icon || 'question',
      title: opts.title || 'Confirmar',
      text: message,
      showCancelButton: true,
      confirmButtonText: opts.confirmText || 'Sim, continuar',
      cancelButtonText: opts.cancelText || 'Cancelar',
      reverseButtons: true,
      focusCancel: true,
    }).then(function (r) {
      return r.isConfirmed;
    });
  };

  window.NAP.toast = function (message, icon) {
    icon = icon || 'success';
    var Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: icon === 'error' ? 6500 : 4200,
      timerProgressBar: true,
      color: isDark() ? '#e5edf5' : '#1f2937',
      background: isDark() ? '#102943' : '#ffffff',
      didOpen: function (toast) {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });
    return Toast.fire({ icon: icon, title: message });
  };

  function iconFromElement(el) {
    if (el.classList.contains('alert-success') || el.classList.contains('ok')) return 'success';
    if (el.classList.contains('alert-error') || el.classList.contains('err')) return 'error';
    if (el.classList.contains('alert-warning')) return 'warning';
    return 'info';
  }

  function messageFromElement(el) {
    var custom = el.getAttribute('data-swal-text');
    if (custom) return custom.trim();
    return (el.textContent || '').replace(/\s+/g, ' ').trim();
  }

  async function showInlineAlerts() {
    var selector =
      '.alert.alert-success, .alert.alert-error, .alert.alert-warning, .alert-site.ok, .alert-site.err';
    var nodes = Array.prototype.slice.call(document.querySelectorAll(selector));
    nodes = nodes.filter(function (el) {
      return !el.classList.contains('alert-persist') && !el.closest('.alert-persist');
    });

    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var msg = messageFromElement(el);
      el.parentNode && el.parentNode.removeChild(el);
      if (!msg) continue;
      var icon = iconFromElement(el);
      if (icon === 'success') {
        await NAP.toast(msg, 'success');
      } else {
        await NAP.alert(msg, icon);
      }
    }
  }

  function bindConfirmAttribute() {
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
      if (el.dataset.napConfirmBound) return;
      el.dataset.napConfirmBound = '1';

      el.addEventListener('click', async function (e) {
        if (el.dataset.napConfirmed === '1') return;

        var tag = el.tagName;
        var isSubmit =
          (tag === 'BUTTON' && el.type === 'submit') ||
          (tag === 'INPUT' && el.type === 'submit');

        if (tag === 'A' || isSubmit || tag === 'FORM') {
          e.preventDefault();
        }

        var msg = el.getAttribute('data-confirm') || 'Tem a certeza?';
        var ok = await NAP.confirm(msg);
        if (!ok) return;

        if (tag === 'A' && el.href) {
          window.location.href = el.href;
          return;
        }
        if (isSubmit && el.form) {
          el.dataset.napConfirmed = '1';
          if (typeof el.form.requestSubmit === 'function') {
            el.form.requestSubmit(el);
          } else {
            el.form.submit();
          }
          return;
        }
        if (tag === 'FORM') {
          el.dataset.napConfirmed = '1';
          el.submit();
        }
      });
    });

    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
      if (form.dataset.napConfirmBound) return;
      form.dataset.napConfirmBound = '1';
      form.addEventListener('submit', async function (e) {
        if (form.dataset.napConfirmed === '1') return;
        e.preventDefault();
        var msg = form.getAttribute('data-confirm') || 'Tem a certeza?';
        var ok = await NAP.confirm(msg);
        if (!ok) return;
        form.dataset.napConfirmed = '1';
        form.submit();
      });
    });
  }

  function patchLegacyConfirmHandlers() {
    document.querySelectorAll('[onclick*="confirm("]').forEach(function (el) {
      var attr = el.getAttribute('onclick') || '';
      var m = attr.match(/confirm\s*\(\s*['"]([^'"]+)['"]\s*\)/);
      if (!m) return;
      el.removeAttribute('onclick');

      if (el.tagName === 'BUTTON' && el.type === 'submit') {
        el.setAttribute('data-confirm', m[1]);
        return;
      }
      el.setAttribute('data-confirm', m[1]);
    });

    document.querySelectorAll('form[onsubmit*="confirm("]').forEach(function (form) {
      var attr = form.getAttribute('onsubmit') || '';
      var m = attr.match(/confirm\s*\(\s*['"]([^'"]+)['"]\s*\)/);
      if (!m) return;
      form.removeAttribute('onsubmit');
      form.setAttribute('data-confirm', m[1]);
    });
  }

  function patchNativeAlert() {
    if (window.__napAlertPatched) return;
    window.__napAlertPatched = true;
    window.alert = function (msg) {
      NAP.alert(String(msg), 'info', 'Aviso');
    };
  }

  function init() {
    patchNativeAlert();
    patchLegacyConfirmHandlers();
    bindConfirmAttribute();
    showInlineAlerts();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
