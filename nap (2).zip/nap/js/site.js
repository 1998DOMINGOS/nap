(function () {
  const translations = {
    pt: {
      five_provinces: '5 províncias', admin_login: 'Login Admin', home: 'Início', company: 'A Empresa', contact_us: 'Fale Connosco', our_services: 'Nossos Serviços', see_all: 'Ver todos', team_short: 'Equipe', trial_balance: 'Balancetes', applications: 'Candidaturas', restricted_area: 'Área administrativa restrita', email: 'Email', password: 'Senha', sign_in: 'Entrar', back_to_site: 'Voltar ao site', secure_access: 'Acesso seguro',
      about: 'Quem Somos', mission_vision: 'Missão e Visão', values: 'Nossos Valores', team: 'Nossa Equipe',
      services: 'Serviços', all_services: 'Ver todos os serviços →', news: 'Notícias', gallery: 'Galeria',
      careers: 'Carreiras', testimonials: 'Depoimentos', contact: 'Contacto', dark_mode: 'Modo escuro',
      light_mode: 'Modo claro', dashboard: 'Dashboard', administration: 'Administração', logout: 'Sair',
      settings: 'Configurações', messages: 'Mensagens', accounting: 'Contabilidade', billing: 'Facturação', chat_title: 'Assistente INFORMATIZA', chat_online: 'Online agora', chat_welcome: 'Olá! Como podemos ajudar?', chat_services: 'Ver serviços', chat_locations: 'Onde estamos?', chat_contact: 'Falar com a equipa', chat_whatsapp: 'Abrir WhatsApp'
    },
    en: {
      five_provinces: '5 provinces', admin_login: 'Admin login', home: 'Home', company: 'Company', contact_us: 'Contact us', our_services: 'Our Services', see_all: 'See all', team_short: 'Team', trial_balance: 'Trial balance', applications: 'Applications', restricted_area: 'Restricted administration area', email: 'Email', password: 'Password', sign_in: 'Sign in', back_to_site: 'Back to site', secure_access: 'Secure access',
      about: 'About us', mission_vision: 'Mission & Vision', values: 'Our values', team: 'Our team',
      services: 'Services', all_services: 'View all services →', news: 'News', gallery: 'Gallery',
      careers: 'Careers', testimonials: 'Testimonials', contact: 'Contact', dark_mode: 'Dark mode',
      light_mode: 'Light mode', dashboard: 'Dashboard', administration: 'Administration', logout: 'Log out',
      settings: 'Settings', messages: 'Messages', accounting: 'Accounting', billing: 'Billing', chat_title: 'INFORMATIZA Assistant', chat_online: 'Online now', chat_welcome: 'Hello! How can we help?', chat_services: 'View services', chat_locations: 'Where are we?', chat_contact: 'Talk to our team', chat_whatsapp: 'Open WhatsApp'
    },
    fr: {
      five_provinces: '5 provinces', admin_login: 'Connexion admin', home: 'Accueil', company: "L'entreprise", contact_us: 'Contactez-nous', our_services: 'Nos services', see_all: 'Voir tout', team_short: 'Équipe', trial_balance: 'Balance comptable', applications: 'Candidatures', restricted_area: 'Espace administratif sécurisé', email: 'E-mail', password: 'Mot de passe', sign_in: 'Se connecter', back_to_site: 'Retour au site', secure_access: 'Accès sécurisé',
      about: 'Qui sommes-nous', mission_vision: 'Mission et vision', values: 'Nos valeurs', team: 'Notre équipe',
      services: 'Services', all_services: 'Voir tous les services →', news: 'Actualités', gallery: 'Galerie',
      careers: 'Carrières', testimonials: 'Témoignages', contact: 'Contact', dark_mode: 'Mode sombre',
      light_mode: 'Mode clair', dashboard: 'Tableau de bord', administration: 'Administration', logout: 'Quitter',
      settings: 'Paramètres', messages: 'Messages', accounting: 'Comptabilité', billing: 'Facturation', chat_title: 'Assistant INFORMATIZA', chat_online: 'En ligne maintenant', chat_welcome: 'Bonjour ! Comment pouvons-nous vous aider ?', chat_services: 'Voir les services', chat_locations: 'Où sommes-nous ?', chat_contact: 'Parler à notre équipe', chat_whatsapp: 'Ouvrir WhatsApp'
    }
  };

  const phraseTranslations = [
    ['A CASA', 'THE COMPANY', "L’ENTREPRISE"],
    ['O QUE CRIAMOS', 'WHAT WE CREATE', 'CE QUE NOUS CRÉONS'],
    ['TECNOLOGIA E SUPORTE', 'TECHNOLOGY & SUPPORT', 'TECHNOLOGIE ET SUPPORT'],
    ['O QUE NOS GUIA', 'WHAT GUIDES US', 'CE QUI NOUS GUIDE'],
    ['CULTURA', 'CULTURE', 'CULTURE'],
    ['PESSOAS', 'PEOPLE', 'ÉQUIPE'],
    ['MOMENTOS', 'MOMENTS', 'MOMENTS'],
    ['ACTUALIDADE', 'NEWS', 'ACTUALITÉS'],
    ['JUNTE-SE A NÓS', 'JOIN US', 'REJOIGNEZ-NOUS'],
    ['FALE CONOSCO', 'CONTACT US', 'CONTACTEZ-NOUS'],
    ['A SUA OPINIÃO CONTA', 'YOUR OPINION MATTERS', 'VOTRE AVIS COMPTE'],
    ['Sobre Nós', 'About Us', 'À propos de nous'],
    ['Nossos Serviços', 'Our Services', 'Nos services'],
    ['Soluções para o seu negócio', 'Solutions for your business', 'Des solutions pour votre entreprise'],
    ['Missão e Visão', 'Mission & Vision', 'Mission et vision'],
    ['Nossos Valores', 'Our Values', 'Nos valeurs'],
    ['Contacto', 'Contact', 'Contact'],
    ['Fale com a nossa equipa', 'Talk to our team', 'Contactez notre équipe'],
    ['Conheça a INFORMATIZA (SU), LDA', 'Discover INFORMATIZA (SU), LDA', 'Découvrez INFORMATIZA (SU), LDA'],
    ['Últimas Notícias', 'Latest News', 'Dernières actualités'],
    ['Desenvolvimento de Software', 'Software Development', 'Développement de logiciels'],
    ['Criação de Sites', 'Website Development', 'Création de sites web'],
    ['Reparação de Computadores', 'Computer Repair', 'Réparation d’ordinateurs'],
    ['Reparação de Impressoras', 'Printer Repair', 'Réparation d’imprimantes'],
    ['Instalação de Internet', 'Internet Installation', 'Installation Internet'],
    ['Câmaras de Segurança', 'Security Cameras', 'Caméras de sécurité'],
    ['Formação', 'Training', 'Formation']
  ];

  const serviceTranslations = {
    'desenvolvimento-software': {
      title: ['Desenvolvimento de Software', 'Software Development', 'Développement de logiciels'],
      resumo: ['Softwares à medida para simplificar processos e fazer o seu negócio crescer.', 'Custom software to simplify processes and grow your business.', 'Des logiciels sur mesure pour simplifier vos processus et développer votre activité.'],
      descricao: ['Analisamos os seus desafios e desenvolvemos sistemas seguros, eficientes e adaptados à realidade da sua organização.', 'We analyze your challenges and build secure, efficient systems adapted to your organization.', 'Nous analysons vos défis et développons des systèmes sûrs et efficaces adaptés à votre organisation.']
    },
    'criacao-de-sites': {
      title: ['Criação de Sites', 'Website Development', 'Création de sites web'],
      resumo: ['Sites profissionais, rápidos e preparados para todos os dispositivos.', 'Professional, fast websites ready for every device.', 'Des sites professionnels, rapides et adaptés à tous les appareils.']
    },
    'reparacao-de-computadores': {
      title: ['Reparação de Computadores', 'Computer Repair', 'Réparation d’ordinateurs'],
      resumo: ['Diagnóstico, reparação e manutenção de computadores.', 'Computer diagnostics, repair and maintenance.', 'Diagnostic, réparation et maintenance des ordinateurs.']
    },
    'reparacao-de-impressoras': {
      title: ['Reparação de Impressoras', 'Printer Repair', 'Réparation d’imprimantes'],
      resumo: ['Manutenção e reparação de impressoras para empresas e particulares.', 'Printer maintenance and repair for businesses and individuals.', 'Maintenance et réparation d’imprimantes pour entreprises et particuliers.']
    },
    'instalacao-de-internet': {
      title: ['Instalação de Internet', 'Internet Installation', 'Installation Internet'],
      resumo: ['Instalação e configuração de redes e internet.', 'Internet and network installation and configuration.', 'Installation et configuration de réseaux et d’internet.']
    },
    'cameras-de-seguranca': {
      title: ['Câmaras de Segurança', 'Security Cameras', 'Caméras de sécurité'],
      resumo: ['Soluções de videovigilância para proteger pessoas e espaços.', 'Video surveillance solutions to protect people and spaces.', 'Des solutions de vidéosurveillance pour protéger les personnes et les espaces.']
    },
    'formacao': {
      title: ['Formação', 'Training', 'Formation'],
      resumo: ['Formação prática para desenvolver competências digitais.', 'Practical training to develop digital skills.', 'Des formations pratiques pour développer les compétences numériques.']
    }
  };

  const storedTheme = localStorage.getItem('informatiza-theme');
  const storedLanguage = localStorage.getItem('informatiza-language') || 'pt';
  const themeButton = document.getElementById('theme-toggle');
  const languageSelector = document.getElementById('language-selector');

  function updateThemeButton() {
    const dark = document.body.classList.contains('dark-mode');
    if (!themeButton) return;
    themeButton.innerHTML = `<i class="fas fa-${dark ? 'sun' : 'moon'}"></i>`;
    themeButton.title = dark ? translations[document.documentElement.lang || 'pt'].light_mode : translations[document.documentElement.lang || 'pt'].dark_mode;
    themeButton.setAttribute('aria-label', themeButton.title);
  }

  function applyLanguage(language) {
    const selected = translations[language] ? language : 'pt';
    document.documentElement.lang = selected;
    localStorage.setItem('informatiza-language', selected);
    document.querySelectorAll('[data-i18n]').forEach(element => {
      const key = element.getAttribute('data-i18n');
      if (translations[selected][key]) element.textContent = translations[selected][key];
    });
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);
    textNodes.forEach(node => {
      if (node.parentElement.closest('[data-i18n], script, style, option')) return;
      const source = node.nodeValue.trim();
      const phrase = phraseTranslations.find(item => item.includes(source));
      if (!phrase || !source) return;
      const translated = phrase[['pt', 'en', 'fr'].indexOf(selected)];
      node.nodeValue = node.nodeValue.replace(source, translated);
    });
    document.querySelectorAll('[data-service-slug][data-service-field]').forEach(element => {
      const service = serviceTranslations[element.dataset.serviceSlug];
      const field = service && service[element.dataset.serviceField];
      if (field) element.textContent = field[['pt', 'en', 'fr'].indexOf(selected)];
    });
    if (languageSelector) languageSelector.value = selected;
    const titleSource = document.title.split(' — ')[0];
    const titlePhrase = phraseTranslations.find(item => item[0] === titleSource || item.includes(titleSource));
    if (titlePhrase) document.title = `${titlePhrase[['pt', 'en', 'fr'].indexOf(selected)]} — INFORMATIZA (SU), LDA`;
    updateThemeButton();
  }

  if (storedTheme === 'dark' || (!storedTheme && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.body.classList.add('dark-mode');
  }
  if (themeButton) {
    themeButton.addEventListener('click', function () {
      document.body.classList.toggle('dark-mode');
      localStorage.setItem('informatiza-theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
      updateThemeButton();
    });
  }
  if (languageSelector) languageSelector.addEventListener('change', event => applyLanguage(event.target.value));
  applyLanguage(storedLanguage);

  const chatbotToggle = document.getElementById('chatbot-toggle');
  const chatbotPanel = document.getElementById('chatbot-panel');
  const chatbotClose = document.getElementById('chatbot-close');
  const chatbotMessages = document.getElementById('chatbot-messages');
  const chatReplies = {
    services: ['Temos software, sites, reparação de computadores e impressoras, instalação de internet, câmaras de segurança e formação.', 'We offer software, websites, computer and printer repair, internet installation, security cameras and training.', 'Nous proposons des logiciels, des sites web, la réparation d’ordinateurs et d’imprimantes, l’installation Internet, des caméras de sécurité et des formations.'],
    locations: ['Estamos em 5 províncias: sede no Uíge, Luanda, Huíla, Benguela e Mbanza Congo.', 'We are present in 5 provinces: headquarters in Uíge, Luanda, Huíla, Benguela and Mbanza Congo.', 'Nous sommes présents dans 5 provinces : siège à Uíge, Luanda, Huíla, Benguela et Mbanza Congo.'],
    contact: ['Pode falar connosco pelo WhatsApp ou através da página de contacto.', 'You can reach us on WhatsApp or through the contact page.', 'Vous pouvez nous contacter sur WhatsApp ou via la page de contact.']
  };
  if (chatbotToggle && chatbotPanel) {
    chatbotToggle.addEventListener('click', () => { chatbotPanel.hidden = !chatbotPanel.hidden; });
    if (chatbotClose) chatbotClose.addEventListener('click', () => { chatbotPanel.hidden = true; });
    document.querySelectorAll('[data-chat-question]').forEach(button => {
      button.addEventListener('click', () => {
        const language = document.documentElement.lang || 'pt';
        const index = ['pt', 'en', 'fr'].indexOf(language);
        const reply = chatReplies[button.dataset.chatQuestion];
        const userMessage = document.createElement('div');
        userMessage.className = 'chatbot-message user';
        userMessage.textContent = button.textContent;
        const botMessage = document.createElement('div');
        botMessage.className = 'chatbot-message bot';
        botMessage.textContent = reply ? reply[index >= 0 ? index : 0] : '';
        chatbotMessages.append(userMessage, botMessage);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
      });
    });
  }

  document.querySelectorAll('[data-carousel]').forEach(carousel => {
    const track = carousel.querySelector('.carousel-track');
    const cards = Array.from(track ? track.children : []);
    const previous = carousel.querySelector('[data-carousel-prev]');
    const next = carousel.querySelector('[data-carousel-next]');
    if (!track || !cards.length) return;
    let position = 0;
    let interval;

    function visibleCards() {
      if (window.innerWidth <= 520) return 1;
      if (window.innerWidth <= 768) return 2;
      return 3;
    }
    function render() {
      const visible = visibleCards();
      const maximum = Math.max(0, cards.length - visible);
      position = Math.min(position, maximum);
      const distance = cards[0].getBoundingClientRect().width + 16;
      track.style.transform = `translateX(-${position * distance}px)`;
    }
    function move(step) {
      const maximum = Math.max(0, cards.length - visibleCards());
      position = position >= maximum && step > 0 ? 0 : position + step;
      position = position < 0 ? maximum : position;
      render();
    }
    function start() { clearInterval(interval); interval = setInterval(() => move(1), 3500); }
    previous?.addEventListener('click', () => { move(-1); start(); });
    next?.addEventListener('click', () => { move(1); start(); });
    window.addEventListener('resize', render);
    render();
    start();
  });

  const menuBtn = document.getElementById('mobile-menu-button');
  if (menuBtn) {
    menuBtn.addEventListener('click', function () {
      document.getElementById('mobile-menu').classList.toggle('hidden');
    });
  }
  document.querySelectorAll('#mobile-menu a').forEach(link => {
    link.addEventListener('click', () => document.getElementById('mobile-menu').classList.add('hidden'));
  });

  document.addEventListener('DOMContentLoaded', function () {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          if (entry.target.hasAttribute('data-counter') || entry.target.querySelector('[data-count]')) {
            entry.target.querySelectorAll('[data-count]').forEach(el => {
              const target = parseInt(el.getAttribute('data-count'), 10) || 0;
              const prefix = el.getAttribute('data-prefix') || '';
              const suffix = el.getAttribute('data-suffix') || '';
              let current = 0;
              const step = Math.max(1, Math.ceil(target / 40));
              const timer = setInterval(() => {
                current += step;
                if (current >= target) {
                  current = target;
                  clearInterval(timer);
                }
                el.textContent = prefix + current + suffix;
              }, 30);
            });
          }
        }
      });
    }, { threshold: 0.15 });

    document.querySelectorAll('.animate-enter, [data-counter]').forEach(el => observer.observe(el));
  });

  // Hero slider
  const slides = document.querySelectorAll('.hero-slide');
  const dotsWrap = document.getElementById('heroDots');
  const progress = document.getElementById('heroProgress');
  if (!slides.length) return;

  let index = 0;
  let timer = null;
  const texts = window.HERO_TEXTS || [];

  slides.forEach((_, i) => {
    if (!dotsWrap) return;
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = 'hero-dot' + (i === 0 ? ' active' : '');
    dot.addEventListener('click', () => go(i));
    dotsWrap.appendChild(dot);
  });

  function applyText(i) {
    if (!texts[i]) return;
    const t = texts[i];
    const tag = document.getElementById('heroTag');
    const title = document.getElementById('heroTitle');
    const desc = document.getElementById('heroDesc');
    if (tag) tag.textContent = t.tag || '';
    if (title) title.innerHTML = t.title || '';
    if (desc) desc.textContent = t.desc || '';
  }

  function go(i) {
    slides[index].classList.remove('active');
    index = (i + slides.length) % slides.length;
    slides[index].classList.add('active');
    document.querySelectorAll('.hero-dot').forEach((d, di) => d.classList.toggle('active', di === index));
    applyText(index);
    restart();
  }

  window.evSlide = function (dir) { go(index + dir); };

  function restart() {
    clearInterval(timer);
    if (progress) {
      progress.style.transition = 'none';
      progress.style.width = '0%';
      void progress.offsetWidth;
      progress.style.transition = 'width 6s linear';
      progress.style.width = '100%';
    }
    timer = setInterval(() => go(index + 1), 6000);
  }

  applyText(0);
  restart();
})();
