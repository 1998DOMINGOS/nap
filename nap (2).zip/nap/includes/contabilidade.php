<?php
/**
 * Contabilidade geral — plano de contas, lançamentos, despesas, salários, mapas fiscais.
 */

function ensure_contabilidade_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $sqlFile = __DIR__ . '/../sql/contabilidade.sql';
    if (!is_file($sqlFile)) {
        throw new RuntimeException('sql/contabilidade.sql em falta.');
    }
    db()->exec((string) file_get_contents($sqlFile));
    cont_seed_defaults();
    cont_migrate_plano_contas_saft();
    cont_migrate_terceiros_cols();
    $done = true;
}

/** Campos para contas a pagar (compras e despesas). */
function cont_migrate_terceiros_cols(): void
{
    static $migrated = false;
    if ($migrated) {
        return;
    }
    $migrated = true;
    try {
        if (!db()->query("SHOW COLUMNS FROM fat_compras LIKE 'pago'")->fetch()) {
            db()->exec('ALTER TABLE fat_compras ADD COLUMN pago TINYINT(1) NOT NULL DEFAULT 0 AFTER observacoes');
            db()->exec('ALTER TABLE fat_compras ADD COLUMN data_vencimento DATE NULL AFTER pago');
            db()->exec('ALTER TABLE fat_compras ADD COLUMN data_pagamento DATE NULL AFTER data_vencimento');
            db()->exec('UPDATE fat_compras SET pago=1');
        }
    } catch (Throwable $e) {
        // ignore
    }
    try {
        if (!db()->query("SHOW COLUMNS FROM cont_despesas LIKE 'pagamento_pendente'")->fetch()) {
            db()->exec('ALTER TABLE cont_despesas ADD COLUMN pagamento_pendiente TINYINT(1) NOT NULL DEFAULT 0 AFTER metodo_pagamento');
            db()->exec('ALTER TABLE cont_despesas ADD COLUMN data_vencimento DATE NULL AFTER pagamento_pendiente');
        }
    } catch (Throwable $e) {
        // ignore
    }
}

/** Corrige contas-pai inválidas (GroupingCode inexistente no SAF-T). */
function cont_migrate_plano_contas_saft(): void
{
    $ids = db()->query('SELECT codigo FROM cont_contas WHERE ativo=1')->fetchAll(PDO::FETCH_COLUMN);
    $set = array_fill_keys(array_map('strval', $ids), true);
    foreach (['1', '2', '3'] as $orphan) {
        db()->prepare('UPDATE cont_contas SET conta_pai=NULL, categoria=\'GM\' WHERE conta_pai=? AND ativo=1')->execute([$orphan]);
    }
    $rows = db()->query('SELECT id, conta_pai FROM cont_contas WHERE ativo=1 AND conta_pai IS NOT NULL AND conta_pai <> \'\'')->fetchAll();
    foreach ($rows as $row) {
        $pai = (string) $row['conta_pai'];
        if (!isset($set[$pai])) {
            db()->prepare('UPDATE cont_contas SET conta_pai=NULL WHERE id=?')->execute([(int) $row['id']]);
        }
    }
}

function cont_seed_defaults(): void
{
    if ((int) db()->query('SELECT COUNT(*) FROM cont_diarios')->fetchColumn() > 0) {
        return;
    }
    foreach ([
        ['VND', 'Vendas'],
        ['COM', 'Compras'],
        ['DES', 'Despesas'],
        ['FOL', 'Folha salarial'],
        ['ODI', 'Operações diversas'],
    ] as [$c, $n]) {
        db()->prepare('INSERT INTO cont_diarios (codigo, nome) VALUES (?,?)')->execute([$c, $n]);
    }
    $contas = [
        ['11', 'Caixa e equivalentes', 'ativo', 'GM', null],
        ['12', 'Depósitos bancários', 'ativo', 'GM', null],
        ['21', 'Clientes', 'ativo', 'GR', null],
        ['211', 'Clientes corrente', 'ativo', 'GA', '21'],
        ['2111', 'Clientes — conta geral', 'ativo', 'GM', '211'],
        ['22', 'Fornecedores', 'passivo', 'GR', null],
        ['221', 'Fornecedores corrente', 'passivo', 'GA', '22'],
        ['2211', 'Fornecedores — conta geral', 'passivo', 'GM', '221'],
        ['24', 'Estado e outros entes públicos', 'ativo', 'GR', null],
        ['243', 'IVA', 'ativo', 'GR', '24'],
        ['2432', 'IVA liquidado', 'passivo', 'GM', '243'],
        ['2453', 'IVA dedutível', 'ativo', 'GM', '243'],
        ['31', 'Compras de mercadorias', 'custo', 'GM', null],
        ['51', 'Vendas', 'receita', 'GR', null],
        ['71', 'Vendas e serviços', 'receita', 'GR', null],
        ['711', 'Vendas de mercadorias', 'receita', 'GM', '71'],
        ['62', 'Fornecimentos e serviços externos', 'custo', 'GR', null],
        ['622', 'Despesas gerais', 'custo', 'GM', '62'],
        ['63', 'Gastos com pessoal', 'custo', 'GR', null],
        ['631', 'Remunerações', 'custo', 'GM', '63'],
        ['632', 'Encargos sociais', 'custo', 'GM', '63'],
        ['25', 'Remunerações a pagar', 'passivo', 'GM', null],
    ];
    foreach ($contas as [$cod, $nome, $tipo, $cat, $pai]) {
        db()->prepare(
            'INSERT IGNORE INTO cont_contas (codigo, nome, tipo, categoria, conta_pai, aceita_lancamento) VALUES (?,?,?,?,?,1)'
        )->execute([$cod, $nome, $tipo, $cat, $pai]);
    }
}

function cont_diario_id(string $codigo): int
{
    $id = db()->prepare('SELECT id FROM cont_diarios WHERE codigo=?');
    $id->execute([$codigo]);
    $v = (int) $id->fetchColumn();
    if ($v < 1) {
        throw new RuntimeException('Diário contabilístico em falta: ' . $codigo);
    }
    return $v;
}

/** @param array<int, array{conta:string,debito:float,credito:float,descricao?:string}> $linhas */
function cont_criar_movimento(
    string $diarioCodigo,
    string $data,
    string $referencia,
    string $descricao,
    string $origemTipo,
    ?int $origemId,
    array $linhas,
    ?int $userId = null
): int {
    ensure_contabilidade_schema();
    $debito = 0.0;
    $credito = 0.0;
    foreach ($linhas as $l) {
        $debito += (float) $l['debito'];
        $credito += (float) $l['credito'];
    }
    if (abs($debito - $credito) > 0.009) {
        throw new RuntimeException('Lançamento desequilibrado (débito ≠ crédito).');
    }
    if ($origemId !== null) {
        $ex = db()->prepare('SELECT id FROM cont_movimentos WHERE origem_tipo=? AND origem_id=? AND anulado=0');
        $ex->execute([$origemTipo, $origemId]);
        $existing = $ex->fetchColumn();
        if ($existing) {
            return (int) $existing;
        }
    }
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare(
            'INSERT INTO cont_movimentos (diario_id, data_movimento, periodo, referencia, descricao, origem_tipo, origem_id, criado_por)
             VALUES (?,?,?,?,?,?,?,?)'
        )->execute([
            cont_diario_id($diarioCodigo),
            $data,
            (int) date('n', strtotime($data)),
            $referencia,
            $descricao,
            $origemTipo,
            $origemId,
            $userId,
        ]);
        $movId = (int) $pdo->lastInsertId();
        $n = 0;
        foreach ($linhas as $l) {
            ++$n;
            $pdo->prepare(
                'INSERT INTO cont_movimento_linhas (movimento_id, linha, conta_codigo, debito, credito, descricao) VALUES (?,?,?,?,?,?)'
            )->execute([
                $movId,
                $n,
                $l['conta'],
                number_format((float) $l['debito'], 2, '.', ''),
                number_format((float) $l['credito'], 2, '.', ''),
                $l['descricao'] ?? null,
            ]);
        }
        $pdo->commit();
        return $movId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function cont_post_venda(int $documentoId, ?int $userId = null): void
{
    ensure_contabilidade_schema();
    $d = db()->prepare('SELECT * FROM fat_documentos WHERE id=? AND estado=?');
    $d->execute([$documentoId, 'emitido']);
    $doc = $d->fetch();
    if (!$doc || ($doc['tipo'] ?? '') === 'OR') {
        return;
    }
    if (function_exists('fat_agt_is_sales_type') && !fat_agt_is_sales_type((string) $doc['tipo'])) {
        return;
    }
    $gross = (float) $doc['total'];
    $net = (float) $doc['subtotal'];
    $iva = (float) $doc['total_iva'];
    $ref = (string) $doc['numero_completo'];
    $data = (string) $doc['data_documento'];
    $isCredit = in_array($doc['tipo'], ['NC'], true);

    $linhas = [];
    if (!$isCredit) {
        $linhas[] = ['conta' => '2111', 'debito' => $gross, 'credito' => 0, 'descricao' => $ref];
        $linhas[] = ['conta' => '711', 'debito' => 0, 'credito' => $net, 'descricao' => $ref];
        if ($iva > 0) {
            $linhas[] = ['conta' => '2432', 'debito' => 0, 'credito' => $iva, 'descricao' => 'IVA ' . $ref];
        }
    } else {
        $linhas[] = ['conta' => '2111', 'debito' => 0, 'credito' => $gross, 'descricao' => $ref];
        $linhas[] = ['conta' => '711', 'debito' => $net, 'credito' => 0, 'descricao' => $ref];
        if ($iva > 0) {
            $linhas[] = ['conta' => '2432', 'debito' => $iva, 'credito' => 0, 'descricao' => 'IVA ' . $ref];
        }
    }
    cont_criar_movimento('VND', $data, $ref, 'Venda ' . $ref, 'venda', $documentoId, $linhas, $userId);
}

function cont_post_compra(int $compraId, ?int $userId = null): void
{
    ensure_contabilidade_schema();
    $c = db()->prepare('SELECT * FROM fat_compras WHERE id=?');
    $c->execute([$compraId]);
    $compra = $c->fetch();
    if (!$compra) {
        return;
    }
    $net = (float) $compra['subtotal'];
    $iva = (float) $compra['total_iva'];
    $gross = (float) $compra['total'];
    $ref = (string) $compra['referencia'];
    $data = (string) $compra['data_compra'];
    $linhas = [
        ['conta' => '31', 'debito' => $net, 'credito' => 0, 'descricao' => $ref],
        ['conta' => '2211', 'debito' => 0, 'credito' => $gross, 'descricao' => $compra['fornecedor_nome']],
    ];
    if ($iva > 0) {
        array_splice($linhas, 1, 0, [['conta' => '2453', 'debito' => $iva, 'credito' => 0, 'descricao' => 'IVA ded.']]);
    }
    cont_criar_movimento('COM', $data, $ref, 'Compra ' . $ref, 'compra', $compraId, $linhas, $userId);
}

function cont_post_despesa(int $despesaId, ?int $userId = null): void
{
    $d = db()->prepare('SELECT * FROM cont_despesas WHERE id=?');
    $d->execute([$despesaId]);
    $row = $d->fetch();
    if (!$row) {
        return;
    }
    $contaDesp = preg_match('/^\d+/', (string) $row['conta_despesa']) ? $row['conta_despesa'] : '622';
    $caixa = ($row['metodo_pagamento'] ?? '') === 'numerario' ? '11' : '12';
    $net = (float) $row['subtotal'];
    $iva = (float) $row['total_iva'];
    $gross = (float) $row['total'];
    $ref = $row['referencia_doc'] ?: ('DESP-' . $despesaId);
    $linhas = [
        ['conta' => $contaDesp, 'debito' => $net, 'credito' => 0],
        ['conta' => $caixa, 'debito' => 0, 'credito' => $gross],
    ];
    if ($iva > 0) {
        $linhas = [
            ['conta' => $contaDesp, 'debito' => $net, 'credito' => 0],
            ['conta' => '2453', 'debito' => $iva, 'credito' => 0, 'descricao' => 'IVA ded.'],
            ['conta' => $caixa, 'debito' => 0, 'credito' => $gross],
        ];
    }
    cont_criar_movimento('DES', (string) $row['data_despesa'], $ref, $row['descricao'], 'despesa', $despesaId, $linhas, $userId);
}

function cont_processar_folha(int $folhaId, ?int $userId = null): void
{
    $f = db()->prepare('SELECT * FROM cont_folhas WHERE id=?');
    $f->execute([$folhaId]);
    $folha = $f->fetch();
    if (!$folha) {
        return;
    }
    $temMov = db()->prepare('SELECT id FROM cont_movimentos WHERE origem_tipo=? AND origem_id=? AND anulado=0');
    $temMov->execute(['folha', $folhaId]);
    if ($temMov->fetchColumn()) {
        return;
    }
    if (($folha['estado'] ?? '') === 'processada' && ($folha['total_bruto'] ?? 0) <= 0) {
        return;
    }
    $bruto = (float) $folha['total_bruto'];
    $liquido = (float) $folha['total_liquido'];
    $encargosEmpresa = round($bruto * 0.08, 2);
    $retencoes = round($bruto - $liquido, 2);
    $ref = sprintf('FOL-%04d-%02d', (int) $folha['ano'], (int) $folha['mes']);
    $data = (string) $folha['data_pagamento'];
    $linhas = [
        ['conta' => '631', 'debito' => $bruto, 'credito' => 0],
        ['conta' => '632', 'debito' => $encargosEmpresa, 'credito' => 0],
        ['conta' => '25', 'debito' => 0, 'credito' => $liquido],
        ['conta' => '24', 'debito' => 0, 'credito' => $retencoes],
        ['conta' => '12', 'debito' => 0, 'credito' => $encargosEmpresa],
    ];
    cont_criar_movimento('FOL', $data, $ref, 'Folha salarial ' . $ref, 'folha', $folhaId, $linhas, $userId);
    db()->prepare('UPDATE cont_folhas SET estado=? WHERE id=?')->execute(['processada', $folhaId]);
}

/**
 * Gera ou recalcula a folha de um mês (único por ano/mês).
 *
 * @throws RuntimeException se o período já existir e $substituir for false
 */
function cont_gerar_folha_mensal(int $ano, int $mes, string $dataPag, ?int $userId, bool $substituir = false): int
{
    ensure_contabilidade_schema();
    if ($mes < 1 || $mes > 12) {
        throw new RuntimeException('Mês inválido.');
    }
    $ex = db()->prepare('SELECT id FROM cont_folhas WHERE ano=? AND mes=?');
    $ex->execute([$ano, $mes]);
    $existId = $ex->fetchColumn();

    if ($existId && !$substituir) {
        throw new RuntimeException(sprintf(
            'Já existe folha para %02d/%04d. Marque «Substituir folha existente» para recalcular e relançar.',
            $mes,
            $ano
        ));
    }

    if ($existId && $substituir) {
        $folhaId = (int) $existId;
        cont_reverter_lancamento_origem('folha', $folhaId, $userId);
        db()->prepare('DELETE FROM cont_folha_linhas WHERE folha_id=?')->execute([$folhaId]);
        db()->prepare(
            'UPDATE cont_folhas SET data_pagamento=?, estado=?, total_bruto=0, total_descontos=0, total_liquido=?, criado_por=? WHERE id=?'
        )->execute([$dataPag, 'rascunho', 0, $userId, $folhaId]);
    } else {
        db()->prepare('INSERT INTO cont_folhas (ano, mes, data_pagamento, estado, criado_por) VALUES (?,?,?,?,?)')
            ->execute([$ano, $mes, $dataPag, 'rascunho', $userId]);
        $folhaId = (int) db()->lastInsertId();
    }

    $funcs = db()->query('SELECT * FROM cont_funcionarios WHERE ativo=1 ORDER BY nome')->fetchAll();
    if (!$funcs) {
        throw new RuntimeException('Registe funcionários activos antes de processar a folha.');
    }

    $bruto = 0.0;
    $liq = 0.0;
    foreach ($funcs as $f) {
        $base = (float) $f['salario_base'] + (float) $f['subsidio'];
        $inss = round($base * 0.03, 2);
        $irt = round(max(0, $base - 70000) * 0.1, 2);
        $outros = 0.0;
        $liquido = round($base - $inss - $irt - $outros, 2);
        db()->prepare(
            'INSERT INTO cont_folha_linhas (folha_id, funcionario_id, bruto, desconto_inss, desconto_irt, outros_descontos, liquido) VALUES (?,?,?,?,?,?,?)'
        )->execute([$folhaId, $f['id'], $base, $inss, $irt, $outros, $liquido]);
        $bruto += $base;
        $liq += $liquido;
    }
    db()->prepare('UPDATE cont_folhas SET total_bruto=?, total_descontos=?, total_liquido=? WHERE id=?')
        ->execute([$bruto, $bruto - $liq, $liq, $folhaId]);
    cont_processar_folha($folhaId, $userId);

    return $folhaId;
}

/** @return list<array<string,mixed>> */
function cont_listar_contas_receber(): array
{
    ensure_contabilidade_schema();
    ensure_facturacao_schema();
    $docs = db()->query(
        "SELECT id, tipo, numero_completo, data_documento, cliente_id, cliente_nome, cliente_nif, total
         FROM fat_documentos
         WHERE estado='emitido' AND tipo IN ('FT','FR','FA','ND')
         ORDER BY data_documento DESC, id DESC"
    )->fetchAll(PDO::FETCH_ASSOC);
    $out = [];
    foreach ($docs as $d) {
        $saldo = fat_saldo_documento_cliente((int) $d['id']);
        if ($saldo < 0.01) {
            continue;
        }
        $d['saldo'] = $saldo;
        $d['total_doc'] = (float) $d['total'];
        $out[] = $d;
    }

    return $out;
}

/** @return list<array<string,mixed>> */
function cont_listar_contas_pagar(): array
{
    ensure_contabilidade_schema();
    ensure_facturacao_schema();
    $out = [];
    $compras = db()->query(
        "SELECT id, referencia, data_compra, fornecedor_nome, fornecedor_nif, total, data_vencimento, pago
         FROM fat_compras WHERE COALESCE(pago,0)=0 ORDER BY data_compra DESC, id DESC"
    )->fetchAll(PDO::FETCH_ASSOC);
    foreach ($compras as $c) {
        $out[] = [
            'origem' => 'compra',
            'id' => (int) $c['id'],
            'referencia' => $c['referencia'],
            'terceiro' => $c['fornecedor_nome'],
            'nif' => $c['fornecedor_nif'],
            'data' => $c['data_compra'],
            'vencimento' => $c['data_vencimento'],
            'total' => (float) $c['total'],
        ];
    }
    $desp = db()->query(
        "SELECT id, descricao, data_despesa, fornecedor_nome, total, data_vencimento, referencia_doc
         FROM cont_despesas WHERE COALESCE(pagamento_pendiente,0)=1 ORDER BY data_despesa DESC, id DESC"
    )->fetchAll(PDO::FETCH_ASSOC);
    foreach ($desp as $d) {
        $out[] = [
            'origem' => 'despesa',
            'id' => (int) $d['id'],
            'referencia' => $d['referencia_doc'] ?: ('DESP-' . $d['id']),
            'terceiro' => $d['fornecedor_nome'] ?: '—',
            'nif' => '',
            'data' => $d['data_despesa'],
            'vencimento' => $d['data_vencimento'],
            'total' => (float) $d['total'],
            'descricao' => $d['descricao'],
        ];
    }
    usort($out, static fn ($a, $b) => strcmp((string) $b['data'], (string) $a['data']));

    return $out;
}

function cont_marcar_compra_paga(int $compraId, ?string $dataPagamento = null): void
{
    ensure_contabilidade_schema();
    $dataPagamento = $dataPagamento && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dataPagamento) ? $dataPagamento : date('Y-m-d');
    db()->prepare('UPDATE fat_compras SET pago=1, data_pagamento=? WHERE id=?')->execute([$dataPagamento, $compraId]);
}

function cont_marcar_despesa_paga(int $despesaId): void
{
    ensure_contabilidade_schema();
    db()->prepare('UPDATE cont_despesas SET pagamento_pendiente=0 WHERE id=?')->execute([$despesaId]);
}

/** @return array{receber:float,pagar:float} */
function cont_totais_terceiros(): array
{
    $receber = 0.0;
    foreach (cont_listar_contas_receber() as $r) {
        $receber += (float) $r['saldo'];
    }
    $pagar = 0.0;
    foreach (cont_listar_contas_pagar() as $p) {
        $pagar += (float) $p['total'];
    }

    return ['receber' => round($receber, 2), 'pagar' => round($pagar, 2)];
}

/** @return list<array{codigo:string,nome:string,debito:float,credito:float,saldo:float}> */
function cont_balancete(string $from, string $to): array
{
    ensure_contabilidade_schema();
    $stmt = db()->prepare(
        'SELECT c.codigo, c.nome,
            COALESCE(SUM(l.debito),0) AS td,
            COALESCE(SUM(l.credito),0) AS tc
         FROM cont_contas c
         LEFT JOIN cont_movimento_linhas l ON l.conta_codigo = c.codigo
         LEFT JOIN cont_movimentos m ON m.id = l.movimento_id AND m.anulado = 0 AND m.data_movimento BETWEEN ? AND ?
         WHERE c.ativo = 1
         GROUP BY c.id, c.codigo, c.nome
         HAVING td > 0 OR tc > 0
         ORDER BY c.codigo'
    );
    $stmt->execute([$from, $to]);
    $out = [];
    foreach ($stmt->fetchAll() as $r) {
        $d = (float) $r['td'];
        $c = (float) $r['tc'];
        $out[] = [
            'codigo' => $r['codigo'],
            'nome' => $r['nome'],
            'debito' => $d,
            'credito' => $c,
            'saldo' => $d - $c,
        ];
    }
    return $out;
}

/** Mapa IVA para declarações (baseado em lançamentos + documentos). */
function cont_mapa_iva(string $from, string $to): array
{
    ensure_contabilidade_schema();
    $vendas = db()->prepare(
        "SELECT COALESCE(SUM(CASE WHEN tipo='NC' THEN -subtotal ELSE subtotal END),0),
                COALESCE(SUM(CASE WHEN tipo='NC' THEN -total_iva ELSE total_iva END),0)
         FROM fat_documentos WHERE estado='emitido' AND data_documento BETWEEN ? AND ? AND tipo IN ('FT','FR','NC','ND','FA')"
    );
    $vendas->execute([$from, $to]);
    [$baseVendas, $ivaVendas] = array_map('floatval', $vendas->fetch(PDO::FETCH_NUM));

    $compras = db()->prepare('SELECT COALESCE(SUM(subtotal),0), COALESCE(SUM(total_iva),0) FROM fat_compras WHERE data_compra BETWEEN ? AND ?');
    $compras->execute([$from, $to]);
    [$baseCompras, $ivaCompras] = array_map('floatval', $compras->fetch(PDO::FETCH_NUM));

    $desp = db()->prepare('SELECT COALESCE(SUM(subtotal),0), COALESCE(SUM(total_iva),0) FROM cont_despesas WHERE data_despesa BETWEEN ? AND ?');
    $desp->execute([$from, $to]);
    [$baseDesp, $ivaDesp] = array_map('floatval', $desp->fetch(PDO::FETCH_NUM));

    return [
        'periodo' => [$from, $to],
        'vendas_liquidas' => $baseVendas,
        'iva_liquidado' => $ivaVendas,
        'compras_liquidas' => $baseCompras,
        'iva_dedutivel_compras' => $ivaCompras,
        'despesas_liquidas' => $baseDesp,
        'iva_dedutivel_despesas' => $ivaDesp,
        'iva_dedutivel_total' => $ivaCompras + $ivaDesp,
        'iva_a_pagar' => $ivaVendas - ($ivaCompras + $ivaDesp),
    ];
}

/** Séries mensais para gráficos do dashboard (últimos N meses, incluindo o corrente). */
function cont_dashboard_series(int $months = 6): array
{
    ensure_contabilidade_schema();
    $months = max(1, min(24, $months));
    $end = new DateTime('last day of this month');
    $labels = [];
    $keys = [];
    $mesesCurto = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    for ($i = $months - 1; $i >= 0; --$i) {
        $d = (clone $end)->modify('-' . $i . ' months');
        $ym = $d->format('Y-m');
        $keys[] = $ym;
        $labels[] = $mesesCurto[(int) $d->format('n') - 1] . ' ' . $d->format('Y');
    }
    $from = $keys[0] . '-01';
    $to = $end->format('Y-m-d');

    $zero = array_fill_keys($keys, 0.0);
    $vendas = $compras = $despesas = $ivaLiq = $ivaDed = $zero;

    $fill = static function (PDOStatement $stmt, array &$bucket): void {
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $ym = $row['ym'] ?? '';
            if ($ym !== '' && array_key_exists($ym, $bucket)) {
                $bucket[$ym] = (float) ($row['total'] ?? 0);
            }
        }
    };

    $sv = db()->prepare(
        "SELECT DATE_FORMAT(data_documento,'%Y-%m') AS ym,
            COALESCE(SUM(CASE WHEN tipo='NC' THEN -subtotal ELSE subtotal END),0) AS total
         FROM fat_documentos
         WHERE estado='emitido' AND data_documento BETWEEN ? AND ? AND tipo IN ('FT','FR','NC','ND','FA')
         GROUP BY ym"
    );
    $sv->execute([$from, $to]);
    $fill($sv, $vendas);

    $siv = db()->prepare(
        "SELECT DATE_FORMAT(data_documento,'%Y-%m') AS ym,
            COALESCE(SUM(CASE WHEN tipo='NC' THEN -total_iva ELSE total_iva END),0) AS total
         FROM fat_documentos
         WHERE estado='emitido' AND data_documento BETWEEN ? AND ? AND tipo IN ('FT','FR','NC','ND','FA')
         GROUP BY ym"
    );
    $siv->execute([$from, $to]);
    $fill($siv, $ivaLiq);

    $sc = db()->prepare(
        "SELECT DATE_FORMAT(data_compra,'%Y-%m') AS ym, COALESCE(SUM(subtotal),0) AS total
         FROM fat_compras WHERE data_compra BETWEEN ? AND ? GROUP BY ym"
    );
    $sc->execute([$from, $to]);
    $fill($sc, $compras);

    $sd = db()->prepare(
        "SELECT DATE_FORMAT(data_despesa,'%Y-%m') AS ym, COALESCE(SUM(subtotal),0) AS total
         FROM cont_despesas WHERE data_despesa BETWEEN ? AND ? GROUP BY ym"
    );
    $sd->execute([$from, $to]);
    $fill($sd, $despesas);

    $sid = db()->prepare(
        "SELECT ym, COALESCE(SUM(total),0) AS total FROM (
            SELECT DATE_FORMAT(data_compra,'%Y-%m') AS ym, total_iva AS total FROM fat_compras WHERE data_compra BETWEEN ? AND ?
            UNION ALL
            SELECT DATE_FORMAT(data_despesa,'%Y-%m') AS ym, total_iva AS total FROM cont_despesas WHERE data_despesa BETWEEN ? AND ?
         ) x GROUP BY ym"
    );
    $sid->execute([$from, $to, $from, $to]);
    $fill($sid, $ivaDed);

    $ordered = static fn (array $map, array $keys): array => array_map(static fn ($k) => $map[$k], $keys);

    return [
        'labels' => $labels,
        'vendas' => $ordered($vendas, $keys),
        'compras' => $ordered($compras, $keys),
        'despesas' => $ordered($despesas, $keys),
        'iva_liquidado' => $ordered($ivaLiq, $keys),
        'iva_dedutivel' => $ordered($ivaDed, $keys),
    ];
}

/** Gastos do período agrupados por categoria (despesas) + compras a fornecedores. */
function cont_gastos_por_categoria(string $from, string $to, int $limit = 8): array
{
    ensure_contabilidade_schema();
    $limit = max(3, min(20, $limit));
    $stmt = db()->prepare(
        'SELECT categoria AS label, COALESCE(SUM(total),0) AS total
         FROM cont_despesas WHERE data_despesa BETWEEN ? AND ?
         GROUP BY categoria ORDER BY total DESC'
    );
    $stmt->execute([$from, $to]);
    $rows = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $rows[] = ['label' => (string) $r['label'], 'total' => (float) $r['total']];
    }
    $stmtC = db()->prepare('SELECT COALESCE(SUM(total),0) FROM fat_compras WHERE data_compra BETWEEN ? AND ?');
    $stmtC->execute([$from, $to]);
    $comprasTotal = (float) $stmtC->fetchColumn();
    if ($comprasTotal > 0) {
        array_unshift($rows, ['label' => 'Compras a fornecedores', 'total' => $comprasTotal]);
    }
    usort($rows, static fn ($a, $b) => $b['total'] <=> $a['total']);
    if (count($rows) > $limit) {
        $top = array_slice($rows, 0, $limit - 1);
        $rest = array_slice($rows, $limit - 1);
        $outros = 0.0;
        foreach ($rest as $r) {
            $outros += $r['total'];
        }
        if ($outros > 0) {
            $top[] = ['label' => 'Outros', 'total' => $outros];
        }
        $rows = $top;
    }
    $labels = [];
    $values = [];
    foreach ($rows as $r) {
        if ($r['total'] <= 0) {
            continue;
        }
        $labels[] = $r['label'];
        $values[] = $r['total'];
    }
    return ['labels' => $labels, 'values' => $values];
}

/** Contagem de lançamentos por diário no período. */
function cont_movimentos_por_diario(string $from, string $to): array
{
    ensure_contabilidade_schema();
    $stmt = db()->prepare(
        'SELECT d.codigo AS label, COUNT(*) AS total
         FROM cont_movimentos m
         INNER JOIN cont_diarios d ON d.id = m.diario_id
         WHERE m.anulado = 0 AND m.data_movimento BETWEEN ? AND ?
         GROUP BY d.id, d.codigo
         ORDER BY total DESC'
    );
    $stmt->execute([$from, $to]);
    $labels = [];
    $values = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $labels[] = (string) $r['label'];
        $values[] = (int) $r['total'];
    }
    return ['labels' => $labels, 'values' => $values];
}

function cont_sincronizar_historico(?int $userId = null): array
{
    ensure_contabilidade_schema();
    $n = ['vendas' => 0, 'compras' => 0, 'despesas' => 0, 'folhas' => 0];
    $docs = db()->query("SELECT id FROM fat_documentos WHERE estado='emitido' AND tipo <> 'OR' ORDER BY data_documento, id")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($docs as $id) {
        try {
            cont_post_venda((int) $id, $userId);
            ++$n['vendas'];
        } catch (Throwable $e) {
            // skip duplicate
        }
    }
    $comps = db()->query('SELECT id FROM fat_compras ORDER BY data_compra, id')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($comps as $id) {
        try {
            cont_post_compra((int) $id, $userId);
            ++$n['compras'];
        } catch (Throwable $e) {
        }
    }
    foreach (db()->query('SELECT id FROM cont_despesas ORDER BY data_despesa, id')->fetchAll(PDO::FETCH_COLUMN) as $id) {
        try {
            cont_post_despesa((int) $id, $userId);
            ++$n['despesas'];
        } catch (Throwable $e) {
        }
    }
    foreach (db()->query("SELECT id FROM cont_folhas WHERE estado='processada' ORDER BY ano, mes")->fetchAll(PDO::FETCH_COLUMN) as $id) {
        try {
            $chk = db()->prepare('SELECT id FROM cont_movimentos WHERE origem_tipo=? AND origem_id=? AND anulado=0');
            $chk->execute(['folha', (int) $id]);
            if (!$chk->fetchColumn()) {
                cont_processar_folha((int) $id, $userId);
            }
            ++$n['folhas'];
        } catch (Throwable $e) {
        }
    }

    return $n;
}

/** Estorno contabilístico (inverte débitos/créditos) de um lançamento por origem. */
function cont_reverter_lancamento_origem(string $origemTipo, int $origemId, ?int $userId = null): ?int
{
    ensure_contabilidade_schema();
    $stmt = db()->prepare(
        'SELECT m.*, d.codigo AS diario FROM cont_movimentos m INNER JOIN cont_diarios d ON d.id=m.diario_id
         WHERE m.origem_tipo=? AND m.origem_id=? AND m.anulado=0 ORDER BY m.id DESC LIMIT 1'
    );
    $stmt->execute([$origemTipo, $origemId]);
    $mov = $stmt->fetch();
    if (!$mov) {
        return null;
    }
    $est = db()->prepare('SELECT id FROM cont_movimentos WHERE referencia=? AND anulado=0');
    $est->execute(['EST-' . $mov['referencia']]);
    if ($est->fetchColumn()) {
        return null;
    }
    $ls = db()->prepare('SELECT * FROM cont_movimento_linhas WHERE movimento_id=? ORDER BY linha');
    $ls->execute([(int) $mov['id']]);
    $linhas = [];
    foreach ($ls->fetchAll() as $l) {
        $linhas[] = [
            'conta' => $l['conta_codigo'],
            'debito' => (float) $l['credito'],
            'credito' => (float) $l['debito'],
            'descricao' => 'Estorno: ' . ($l['descricao'] ?? ''),
        ];
    }
    db()->prepare('UPDATE cont_movimentos SET anulado=1 WHERE id=?')->execute([(int) $mov['id']]);

    return cont_criar_movimento(
        'ODI',
        date('Y-m-d'),
        'EST-' . $mov['referencia'],
        'Estorno ' . $mov['descricao'] . ' (origem ' . $origemTipo . ' #' . $origemId . ')',
        'manual',
        null,
        $linhas,
        $userId
    );
}

function cont_reverter_venda(int $documentoId, ?int $userId = null): ?int
{
    return cont_reverter_lancamento_origem('venda', $documentoId, $userId);
}

/** @return array{debito:float,credito:float} */
function cont_saft_saldos_conta(string $codigo, string $from, string $to): array
{
    $open = db()->prepare(
        'SELECT COALESCE(SUM(l.debito),0), COALESCE(SUM(l.credito),0)
         FROM cont_movimento_linhas l
         INNER JOIN cont_movimentos m ON m.id=l.movimento_id AND m.anulado=0 AND m.data_movimento < ?
         WHERE l.conta_codigo=?'
    );
    $open->execute([$from, $codigo]);
    [$od, $oc] = array_map('floatval', $open->fetch(PDO::FETCH_NUM) ?: [0, 0]);
    $period = db()->prepare(
        'SELECT COALESCE(SUM(l.debito),0), COALESCE(SUM(l.credito),0)
         FROM cont_movimento_linhas l
         INNER JOIN cont_movimentos m ON m.id=l.movimento_id AND m.anulado=0 AND m.data_movimento BETWEEN ? AND ?
         WHERE l.conta_codigo=?'
    );
    $period->execute([$from, $to, $codigo]);
    [$pd, $pc] = array_map('floatval', $period->fetch(PDO::FETCH_NUM) ?: [0, 0]);

    return [
        'opening_debit' => $od,
        'opening_credit' => $oc,
        'closing_debit' => $od + $pd,
        'closing_credit' => $oc + $pc,
    ];
}

function cont_saft_doc_archival(string $referencia, int $movId): string
{
    $arch = substr(preg_replace('/[^A-Za-z0-9\-\/]/', '', $referencia) ?: (string) $movId, 0, 20);

    return $arch !== '' ? $arch : (string) $movId;
}

function cont_saft_append_gl_accounts(DOMDocument $xml, DOMElement $master, string $from, string $to): void
{
    ensure_contabilidade_schema();
    $glRoot = $xml->createElement('GeneralLedgerAccounts');
    if ($master->firstChild) {
        $master->insertBefore($glRoot, $master->firstChild);
    } else {
        $master->appendChild($glRoot);
    }
    $contas = db()->query('SELECT * FROM cont_contas WHERE ativo=1 ORDER BY codigo')->fetchAll();
    $codigos = [];
    foreach ($contas as $c) {
        $codigos[(string) $c['codigo']] = true;
    }
    foreach ($contas as $c) {
        $cod = (string) $c['codigo'];
        $bal = cont_saft_saldos_conta($cod, $from, $to);
        $acc = $xml->createElement('Account');
        $glRoot->appendChild($acc);
        $acc->appendChild($xml->createElement('AccountID', $cod));
        $acc->appendChild($xml->createElement('AccountDescription', (string) $c['nome']));
        $acc->appendChild($xml->createElement('OpeningDebitBalance', number_format($bal['opening_debit'], 2, '.', '')));
        $acc->appendChild($xml->createElement('OpeningCreditBalance', number_format($bal['opening_credit'], 2, '.', '')));
        $acc->appendChild($xml->createElement('ClosingDebitBalance', number_format($bal['closing_debit'], 2, '.', '')));
        $acc->appendChild($xml->createElement('ClosingCreditBalance', number_format($bal['closing_credit'], 2, '.', '')));
        $cat = in_array($c['categoria'], ['GR', 'GA', 'GM'], true) ? $c['categoria'] : 'GM';
        $acc->appendChild($xml->createElement('GroupingCategory', $cat));
        $pai = trim((string) ($c['conta_pai'] ?? ''));
        if ($cat !== 'GR' && $pai !== '' && isset($codigos[$pai])) {
            $acc->appendChild($xml->createElement('GroupingCode', $pai));
        }
    }
}

/** @return array<int, array{transaction_id:string,customer_id:int}> */
function cont_saft_venda_ledger_plan(string $from, string $to): array
{
    ensure_contabilidade_schema();
    $plan = [];
    $stmt = db()->prepare(
        'SELECT m.*, d.codigo AS diario FROM cont_movimentos m
         INNER JOIN cont_diarios d ON d.id=m.diario_id
         WHERE m.anulado=0 AND m.origem_tipo=? AND m.data_movimento BETWEEN ? AND ?'
    );
    $stmt->execute(['venda', $from, $to]);
    foreach ($stmt->fetchAll() as $m) {
        $docId = (int) ($m['origem_id'] ?? 0);
        if ($docId < 1) {
            continue;
        }
        $arch = cont_saft_doc_archival((string) $m['referencia'], (int) $m['id']);
        $txId = fat_saft_transaction_id((string) $m['data_movimento'], (string) $m['diario'], $arch);
        $doc = db()->prepare('SELECT cliente_id FROM fat_documentos WHERE id=?');
        $doc->execute([$docId]);
        $cust = (int) ($doc->fetchColumn() ?: 1);
        $plan[$docId] = ['transaction_id' => $txId, 'customer_id' => $cust > 0 ? $cust : 1];
    }

    return $plan;
}

function cont_saft_count_movimentos(string $from, string $to): int
{
    ensure_contabilidade_schema();
    $stmt = db()->prepare('SELECT COUNT(*) FROM cont_movimentos WHERE anulado=0 AND data_movimento BETWEEN ? AND ?');
    $stmt->execute([$from, $to]);

    return (int) $stmt->fetchColumn();
}

/**
 * Exporta GeneralLedgerEntries a partir de cont_movimentos (basis I integrado).
 *
 * @return bool true se exportou razão da BD
 */
function cont_saft_export_ledger(DOMDocument $xml, DOMElement $master, DOMElement $root, string $from, string $to): bool
{
    if (cont_saft_count_movimentos($from, $to) === 0) {
        return false;
    }
    cont_saft_append_gl_accounts($xml, $master, $from, $to);

    $stmt = db()->prepare(
        'SELECT m.*, d.codigo AS diario, d.nome AS diario_nome FROM cont_movimentos m
         INNER JOIN cont_diarios d ON d.id=m.diario_id
         WHERE m.anulado=0 AND m.data_movimento BETWEEN ? AND ?
         ORDER BY d.codigo, m.data_movimento, m.id'
    );
    $stmt->execute([$from, $to]);
    $rows = $stmt->fetchAll();
    if ($rows === []) {
        return false;
    }

    $byJournal = [];
    $totalDebit = 0.0;
    $totalCredit = 0.0;
    foreach ($rows as $m) {
        $ls = db()->prepare('SELECT * FROM cont_movimento_linhas WHERE movimento_id=? ORDER BY linha');
        $ls->execute([(int) $m['id']]);
        $lines = $ls->fetchAll();
        $deb = 0.0;
        $cred = 0.0;
        foreach ($lines as $l) {
            $deb += (float) $l['debito'];
            $cred += (float) $l['credito'];
        }
        $totalDebit += $deb;
        $totalCredit += $cred;
        $j = (string) $m['diario'];
        $byJournal[$j]['nome'] = (string) $m['diario_nome'];
        $byJournal[$j]['tx'][] = ['mov' => $m, 'lines' => $lines];
    }

    $gl = $xml->createElement('GeneralLedgerEntries');
    $root->appendChild($gl);
    $gl->appendChild($xml->createElement('NumberOfEntries', (string) count($rows)));
    $gl->appendChild($xml->createElement('TotalDebit', number_format($totalDebit, 2, '.', '')));
    $gl->appendChild($xml->createElement('TotalCredit', number_format($totalCredit, 2, '.', '')));

    foreach ($byJournal as $journalId => $block) {
        $journal = $xml->createElement('Journal');
        $gl->appendChild($journal);
        $journal->appendChild($xml->createElement('JournalID', $journalId));
        $journal->appendChild($xml->createElement('Description', $block['nome'] ?: $journalId));
        foreach ($block['tx'] as $item) {
            $m = $item['mov'];
            $lines = $item['lines'];
            $arch = cont_saft_doc_archival((string) $m['referencia'], (int) $m['id']);
            $date = (string) $m['data_movimento'];
            $txId = fat_saft_transaction_id($date, $journalId, $arch);
            $sys = date('Y-m-d\TH:i:s', strtotime($m['criado_em'] ?: $date . ' 12:00:00'));

            $tx = $xml->createElement('Transaction');
            $journal->appendChild($tx);
            $tx->appendChild($xml->createElement('TransactionID', $txId));
            $tx->appendChild($xml->createElement('Period', (string) (int) $m['periodo']));
            $tx->appendChild($xml->createElement('TransactionDate', $date));
            $tx->appendChild($xml->createElement('SourceID', (string) ($m['criado_por'] ?: 1)));
            $tx->appendChild($xml->createElement('Description', (string) $m['descricao']));
            $tx->appendChild($xml->createElement('DocArchivalNumber', $arch));
            $tx->appendChild($xml->createElement('TransactionType', 'N'));
            $tx->appendChild($xml->createElement('GLPostingDate', $date));

            $linesEl = $xml->createElement('Lines');
            $tx->appendChild($linesEl);
            $rid = 0;
            foreach ($lines as $l) {
                if ((float) $l['debito'] <= 0) {
                    continue;
                }
                ++$rid;
                $dl = $xml->createElement('DebitLine');
                $linesEl->appendChild($dl);
                $dl->appendChild($xml->createElement('RecordID', (string) $rid));
                $dl->appendChild($xml->createElement('AccountID', (string) $l['conta_codigo']));
                $dl->appendChild($xml->createElement('SystemEntryDate', $sys));
                $dl->appendChild($xml->createElement('Description', (string) ($l['descricao'] ?: $m['descricao'])));
                $dl->appendChild($xml->createElement('DebitAmount', number_format((float) $l['debito'], 2, '.', '')));
            }
            foreach ($lines as $l) {
                if ((float) $l['credito'] <= 0) {
                    continue;
                }
                ++$rid;
                $cl = $xml->createElement('CreditLine');
                $linesEl->appendChild($cl);
                $cl->appendChild($xml->createElement('RecordID', (string) $rid));
                $cl->appendChild($xml->createElement('AccountID', (string) $l['conta_codigo']));
                $cl->appendChild($xml->createElement('SystemEntryDate', $sys));
                $cl->appendChild($xml->createElement('Description', (string) ($l['descricao'] ?: $m['descricao'])));
                $cl->appendChild($xml->createElement('CreditAmount', number_format((float) $l['credito'], 2, '.', '')));
            }
        }
    }

    return true;
}

/** Guarda ou actualiza conta do plano (SAF-T GroupingCategory GR/GA/GM). */
function cont_guardar_conta(array $data, ?int $contaId = null): int
{
    ensure_contabilidade_schema();
    $codigo = trim((string) ($data['codigo'] ?? ''));
    $nome = trim((string) ($data['nome'] ?? ''));
    $tipo = (string) ($data['tipo'] ?? 'ativo');
    $cat = strtoupper(trim((string) ($data['categoria'] ?? 'GM')));
    $pai = trim((string) ($data['conta_pai'] ?? ''));
    if ($codigo === '' || $nome === '') {
        throw new RuntimeException('Código e nome da conta são obrigatórios.');
    }
    if (!preg_match('/^[0-9A-Za-z._-]+$/', $codigo)) {
        throw new RuntimeException('Código de conta inválido para SAF-T.');
    }
    if (!in_array($tipo, ['ativo', 'passivo', 'patrimonio', 'custo', 'receita'], true)) {
        $tipo = 'ativo';
    }
    if (!in_array($cat, ['GR', 'GA', 'GM'], true)) {
        $cat = 'GM';
    }
    if ($cat === 'GR') {
        $pai = '';
    }
    if ($contaId) {
        db()->prepare('UPDATE cont_contas SET codigo=?, nome=?, tipo=?, categoria=?, conta_pai=?, aceita_lancamento=? WHERE id=?')
            ->execute([$codigo, $nome, $tipo, $cat, $pai ?: null, !empty($data['aceita_lancamento']) ? 1 : 0, $contaId]);

        return $contaId;
    }
    db()->prepare(
        'INSERT INTO cont_contas (codigo, nome, tipo, categoria, conta_pai, aceita_lancamento, ativo) VALUES (?,?,?,?,?,?,1)'
    )->execute([$codigo, $nome, $tipo, $cat, $pai ?: null, !empty($data['aceita_lancamento']) ? 1 : 0]);

    return (int) db()->lastInsertId();
}

function cont_export_csv_money(float $v): string
{
    return number_format($v, 2, '.', '');
}

/** @param resource $out */
function cont_export_csv_row($out, array $row): void
{
    fputcsv($out, $row, ';');
}

function cont_export_send_csv(string $filename)
{
    $safe = preg_replace('/[^a-zA-Z0-9._-]+/', '_', $filename) ?: 'export.csv';
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $safe . '"');
    $out = fopen('php://output', 'w');
    fprintf($out, "\xEF\xBB\xBF");

    return $out;
}

/** @param resource $out */
function cont_export_csv_empresa_cabecalho($out, string $from, string $to, string $titulo): void
{
    $e = fat_empresa();
    cont_export_csv_row($out, [$titulo]);
    cont_export_csv_row($out, ['Empresa', (string) ($e['nome'] ?? '')]);
    cont_export_csv_row($out, ['NIF', (string) ($e['nif'] ?? '')]);
    cont_export_csv_row($out, ['Período', $from . ' a ' . $to]);
    cont_export_csv_row($out, ['Gerado em', date('Y-m-d H:i:s')]);
    cont_export_csv_row($out, []);
}

/** @param resource $out */
function cont_write_export_mapa_iva($out, string $from, string $to): void
{
    $mapa = cont_mapa_iva($from, $to);
    cont_export_csv_empresa_cabecalho($out, $from, $to, 'Mapa de IVA (resumo)');
    cont_export_csv_row($out, ['Campo', 'Valor (AOA)']);
    foreach ([
        'Vendas líquidas (base)' => $mapa['vendas_liquidas'],
        'IVA liquidado (vendas)' => $mapa['iva_liquidado'],
        'Compras líquidas (base)' => $mapa['compras_liquidas'],
        'IVA dedutível (compras)' => $mapa['iva_dedutivel_compras'],
        'Despesas líquidas (base)' => $mapa['despesas_liquidas'],
        'IVA dedutível (despesas)' => $mapa['iva_dedutivel_despesas'],
        'IVA dedutível (total)' => $mapa['iva_dedutivel_total'],
        'IVA a pagar (estimativa)' => $mapa['iva_a_pagar'],
    ] as $k => $v) {
        cont_export_csv_row($out, [$k, cont_export_csv_money((float) $v)]);
    }
}

/** @param resource $out */
function cont_write_export_vendas($out, string $from, string $to): void
{
    cont_export_csv_empresa_cabecalho($out, $from, $to, 'Anexo — Vendas / documentos emitidos');
    cont_export_csv_row($out, ['Data', 'Tipo', 'Número', 'Cliente', 'NIF cliente', 'Base (AOA)', 'IVA (AOA)', 'Total (AOA)']);
    $stmt = db()->prepare(
        "SELECT data_documento, tipo, numero_completo, cliente_nome, cliente_nif, subtotal, total_iva, total
         FROM fat_documentos
         WHERE estado='emitido' AND data_documento BETWEEN ? AND ? AND tipo IN ('FT','FR','NC','ND','FA')
         ORDER BY data_documento, id"
    );
    $stmt->execute([$from, $to]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $sign = ($r['tipo'] ?? '') === 'NC' ? -1 : 1;
        cont_export_csv_row($out, [
            $r['data_documento'],
            $r['tipo'],
            $r['numero_completo'],
            $r['cliente_nome'],
            $r['cliente_nif'],
            cont_export_csv_money($sign * (float) $r['subtotal']),
            cont_export_csv_money($sign * (float) $r['total_iva']),
            cont_export_csv_money($sign * (float) $r['total']),
        ]);
    }
}

/** @param resource $out */
function cont_write_export_compras($out, string $from, string $to): void
{
    cont_export_csv_empresa_cabecalho($out, $from, $to, 'Anexo — Compras a fornecedores');
    cont_export_csv_row($out, ['Data', 'Referência', 'Fornecedor', 'NIF', 'Base (AOA)', 'IVA (AOA)', 'Total (AOA)']);
    $stmt = db()->prepare(
        'SELECT data_compra, referencia, fornecedor_nome, fornecedor_nif, subtotal, total_iva, total
         FROM fat_compras WHERE data_compra BETWEEN ? AND ? ORDER BY data_compra, id'
    );
    $stmt->execute([$from, $to]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        cont_export_csv_row($out, [
            $r['data_compra'],
            $r['referencia'],
            $r['fornecedor_nome'],
            $r['fornecedor_nif'],
            cont_export_csv_money((float) $r['subtotal']),
            cont_export_csv_money((float) $r['total_iva']),
            cont_export_csv_money((float) $r['total']),
        ]);
    }
}

/** @param resource $out */
function cont_write_export_despesas($out, string $from, string $to): void
{
    cont_export_csv_empresa_cabecalho($out, $from, $to, 'Anexo — Despesas operacionais');
    cont_export_csv_row($out, ['Data', 'Categoria', 'Descrição', 'Fornecedor', 'Conta', 'Base (AOA)', 'IVA (AOA)', 'Total (AOA)', 'Pagamento', 'Ref. doc.']);
    $stmt = db()->prepare(
        'SELECT data_despesa, categoria, descricao, fornecedor_nome, conta_despesa, subtotal, total_iva, total, metodo_pagamento, referencia_doc
         FROM cont_despesas WHERE data_despesa BETWEEN ? AND ? ORDER BY data_despesa, id'
    );
    $stmt->execute([$from, $to]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        cont_export_csv_row($out, [
            $r['data_despesa'],
            $r['categoria'],
            $r['descricao'],
            $r['fornecedor_nome'],
            $r['conta_despesa'],
            cont_export_csv_money((float) $r['subtotal']),
            cont_export_csv_money((float) $r['total_iva']),
            cont_export_csv_money((float) $r['total']),
            $r['metodo_pagamento'],
            $r['referencia_doc'],
        ]);
    }
}

/** @param resource $out */
function cont_write_export_balancete($out, string $from, string $to): void
{
    cont_export_csv_empresa_cabecalho($out, $from, $to, 'Balancete analítico');
    cont_export_csv_row($out, ['Código', 'Conta', 'Débito (AOA)', 'Crédito (AOA)', 'Saldo (AOA)']);
    $rows = cont_balancete($from, $to);
    $td = $tc = 0.0;
    foreach ($rows as $r) {
        $d = (float) $r['debito'];
        $c = (float) $r['credito'];
        $td += $d;
        $tc += $c;
        cont_export_csv_row($out, [
            $r['codigo'],
            $r['nome'],
            cont_export_csv_money($d),
            cont_export_csv_money($c),
            cont_export_csv_money((float) $r['saldo']),
        ]);
    }
    cont_export_csv_row($out, []);
    cont_export_csv_row($out, ['Totais', '', cont_export_csv_money($td), cont_export_csv_money($tc), cont_export_csv_money($td - $tc)]);
}

/** @param resource $out */
function cont_write_export_movimentos($out, string $from, string $to): void
{
    cont_export_csv_empresa_cabecalho($out, $from, $to, 'Razão — lançamentos e linhas');
    cont_export_csv_row($out, ['Data', 'Diário', 'Referência', 'Origem', 'Descrição mov.', 'Conta', 'Débito (AOA)', 'Crédito (AOA)', 'Linha descrição']);
    $stmt = db()->prepare(
        'SELECT m.data_movimento, d.codigo AS diario, m.referencia, m.origem_tipo, m.descricao AS mov_desc,
                l.conta_codigo, l.debito, l.credito, l.descricao AS linha_desc
         FROM cont_movimentos m
         INNER JOIN cont_diarios d ON d.id = m.diario_id
         INNER JOIN cont_movimento_linhas l ON l.movimento_id = m.id
         WHERE m.anulado = 0 AND m.data_movimento BETWEEN ? AND ?
         ORDER BY m.data_movimento, m.id, l.linha'
    );
    $stmt->execute([$from, $to]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        cont_export_csv_row($out, [
            $r['data_movimento'],
            $r['diario'],
            $r['referencia'],
            $r['origem_tipo'],
            $r['mov_desc'],
            $r['conta_codigo'],
            cont_export_csv_money((float) $r['debito']),
            cont_export_csv_money((float) $r['credito']),
            $r['linha_desc'],
        ]);
    }
}

function cont_export_csv_to_string(callable $writer): string
{
    $h = fopen('php://memory', 'w+');
    if ($h === false) {
        return '';
    }
    fprintf($h, "\xEF\xBB\xBF");
    $writer($h);
    rewind($h);
    $content = stream_get_contents($h);
    fclose($h);

    return $content !== false ? $content : '';
}

function cont_export_declaracao(string $tipo, string $from, string $to): void
{
    ensure_contabilidade_schema();
    ensure_facturacao_schema();
    $tipo = strtolower(trim($tipo));
    if ($tipo === 'csv') {
        $tipo = 'mapa_iva';
    }
    $writers = [
        'mapa_iva' => 'cont_write_export_mapa_iva',
        'vendas' => 'cont_write_export_vendas',
        'compras' => 'cont_write_export_compras',
        'despesas' => 'cont_write_export_despesas',
        'balancete' => 'cont_write_export_balancete',
        'movimentos' => 'cont_write_export_movimentos',
    ];
    if ($tipo === 'zip' || $tipo === 'pacote') {
        if (!class_exists('ZipArchive')) {
            http_response_code(503);
            header('Content-Type: text/plain; charset=UTF-8');
            echo 'Exportação ZIP indisponível (extensão ZipArchive em falta no PHP).';
            exit;
        }
        $tmp = tempnam(sys_get_temp_dir(), 'decl');
        if ($tmp === false) {
            http_response_code(500);
            exit;
        }
        $zip = new ZipArchive();
        if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) {
            @unlink($tmp);
            http_response_code(500);
            exit;
        }
        $names = [
            'mapa_iva' => '01_mapa_iva.csv',
            'vendas' => '02_vendas.csv',
            'compras' => '03_compras.csv',
            'despesas' => '04_despesas.csv',
            'balancete' => '05_balancete.csv',
            'movimentos' => '06_razao_lancamentos.csv',
        ];
        foreach ($names as $key => $file) {
            $fn = $writers[$key];
            $zip->addFromString($file, cont_export_csv_to_string(static fn ($o) => $fn($o, $from, $to)));
        }
        $zip->close();
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="declaracoes_' . $from . '_' . $to . '.zip"');
        header('Content-Length: ' . (string) filesize($tmp));
        readfile($tmp);
        @unlink($tmp);
        exit;
    }
    if (!isset($writers[$tipo])) {
        http_response_code(400);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Tipo de exportação inválido.';
        exit;
    }
    $out = cont_export_send_csv('declaracao_' . $tipo . '_' . $from . '_' . $to . '.csv');
    $writers[$tipo]($out, $from, $to);
    fclose($out);
    exit;
}
