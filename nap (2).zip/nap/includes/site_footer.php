<?php
$siteNome = $siteNome ?? site_nome();
$siteEmail = $siteEmail ?? setting('site_email', 'geralnacionalajudaopais@gmail.com');
$siteTel = $siteTel ?? setting('site_telefone', '935406556');
$siteTelSec = $siteTelSec ?? setting('site_telefone_secundario', '');
$siteWhatsapp = $siteWhatsapp ?? preg_replace('/\D+/', '', setting('site_whatsapp', '935406556'));
if ($siteWhatsapp !== '' && !str_starts_with($siteWhatsapp, '244')) {
    $siteWhatsapp = '244' . $siteWhatsapp;
}
$siteMorada = $siteMorada ?? setting('site_morada', 'Sede: Uíge | Luanda: Maianga, Edifício Unitel, 5.º andar | Huíla | Benguela | Mbanza Congo');
$siteFacebook = $siteFacebook ?? setting('site_facebook', '#');
$siteInstagram = $siteInstagram ?? setting('site_instagram', '#');
$siteLinkedin = $siteLinkedin ?? setting('site_linkedin', '#');
$footerServicos = $navServicos ?? [];
$logoUrl = url('/imgs/logo-informatiza.svg?v=4');
?>
    <section class="gold-gradient">
        <div class="container mx-auto px-4 py-10">
            <div class="flex flex-col md:flex-row items-center justify-between gap-6">
                <div class="text-center md:text-left">
                    <h3 class="text-2xl md:text-3xl font-bold text-white">Leve a sua ideia mais longe</h3>
                    <p class="text-white/90 font-medium">Software, sites, conectividade, segurança e suporte tecnológico.</p>
                </div>
                <a href="<?= site_url('contato') ?>" class="bg-ev-dark text-white px-8 py-4 rounded-lg font-bold hover:bg-ev-darker transition-colors whitespace-nowrap">
                    <i class="fas fa-phone-alt mr-2 text-ev-gold"></i> Solicitar Orçamento
                </a>
            </div>
        </div>
    </section>

    <footer class="footer-gradient text-white pt-14 pb-8">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-10">
                <div>
                    <div class="flex flex-col mb-5">
                        <img src="<?= $logoUrl ?>" alt="<?= e($siteNome) ?>" class="w-full max-w-[280px] h-auto object-contain mb-3">
                        <span class="text-xs brand-tagline font-bold uppercase"><?= e(mb_strtoupper(site_tagline())) ?></span>
                    </div>
                    <p class="text-gray-400 text-sm mb-4">Há 6 anos a desenvolver soluções tecnológicas para pessoas e organizações em Angola.</p>
                    <div class="flex space-x-3">
                        <a href="<?= e($siteFacebook ?: '#') ?>" class="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-ev-gold hover:text-white transition-colors"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?= e($siteInstagram ?: '#') ?>" class="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-ev-gold hover:text-white transition-colors" target="_blank" rel="noopener"><i class="fab fa-instagram"></i></a>
                        <?php if ($siteLinkedin && $siteLinkedin !== '#'): ?>
                        <a href="<?= e($siteLinkedin) ?>" class="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-ev-gold hover:text-white transition-colors"><i class="fab fa-linkedin-in"></i></a>
                        <?php endif; ?>
                        <a href="https://wa.me/<?= e($siteWhatsapp) ?>" class="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-ev-gold hover:text-white transition-colors"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>

                <div>
                    <h3 class="text-lg font-bold mb-5 text-ev-gold" data-i18n="our_services">Nossos Serviços</h3>
                    <ul class="space-y-3 text-gray-400 text-sm">
                        <?php foreach (array_slice($footerServicos, 0, 4) as $s): ?>
                            <li><a href="<?= site_url('servico/' . $s['slug']) ?>" class="hover:text-ev-gold transition-colors"><i class="fas fa-angle-right mr-2 text-ev-gold"></i><?= e($s['titulo']) ?></a></li>
                        <?php endforeach; ?>
                        <li><a href="<?= site_url('services') ?>" class="hover:text-ev-gold transition-colors"><i class="fas fa-angle-right mr-2 text-ev-gold"></i><span data-i18n="see_all">Ver todos</span></a></li>
                    </ul>
                </div>

                <div>
                    <h3 class="text-lg font-bold mb-5 text-ev-gold" data-i18n="company">A Empresa</h3>
                    <ul class="space-y-3 text-gray-400 text-sm">
                        <li><a href="<?= site_url('sobre') ?>" class="hover:text-ev-gold transition-colors"><i class="fas fa-angle-right mr-2 text-ev-gold"></i>Quem Somos</a></li>
                        <li><a href="<?= site_url('missao') ?>" class="hover:text-ev-gold transition-colors"><i class="fas fa-angle-right mr-2 text-ev-gold"></i>Missão e Visão</a></li>
                        <li><a href="<?= site_url('valores') ?>" class="hover:text-ev-gold transition-colors"><i class="fas fa-angle-right mr-2 text-ev-gold"></i>Valores</a></li>
                        <li><a href="<?= site_url('carreiras') ?>" class="hover:text-ev-gold transition-colors"><i class="fas fa-angle-right mr-2 text-ev-gold"></i>Carreiras</a></li>
                        <li><a href="<?= site_url('depoimento') ?>" class="hover:text-ev-gold transition-colors"><i class="fas fa-angle-right mr-2 text-ev-gold"></i>Deixe um depoimento</a></li>
                        <li><a href="<?= site_url('news') ?>" class="hover:text-ev-gold transition-colors"><i class="fas fa-angle-right mr-2 text-ev-gold"></i>Notícias</a></li>
                        <li><a href="<?= site_url('galeria') ?>" class="hover:text-ev-gold transition-colors"><i class="fas fa-angle-right mr-2 text-ev-gold"></i>Galeria</a></li>
                    </ul>
                </div>

                <div>
                    <h3 class="text-lg font-bold mb-5 text-ev-gold">Contacto</h3>
                    <ul class="space-y-4 text-gray-400 text-sm">
                        <li class="flex items-start"><i class="fas fa-map-marker-alt mr-3 text-ev-gold mt-1"></i><span><?= e($siteMorada) ?></span></li>
                        <li class="flex items-center"><i class="fab fa-whatsapp mr-3 text-ev-gold"></i><a href="https://wa.me/<?= e($siteWhatsapp) ?>" class="hover:text-ev-gold" target="_blank" rel="noopener">+244 <?= e($siteTel) ?></a></li>
                        <?php if ($siteTelSec !== ''): ?>
                        <li class="flex items-center text-gray-500"><i class="fas fa-phone mr-3 text-gray-500"></i><span><?= e($siteTelSec) ?></span></li>
                        <?php endif; ?>
                        <li class="flex items-center"><i class="fas fa-envelope mr-3 text-ev-gold"></i><span><?= e($siteEmail) ?></span></li>
                        <?php if ($siteInstagram && $siteInstagram !== '#'): ?><li class="flex items-center"><i class="fab fa-instagram mr-3 text-ev-gold"></i><a href="<?= e($siteInstagram) ?>" class="hover:text-ev-gold" target="_blank" rel="noopener">Instagram</a></li><?php endif; ?>
                    </ul>
                </div>
            </div>

            <div class="border-t border-white/10 mt-10 pt-6 text-center text-gray-500 text-sm">
                <p>&copy; <?= date('Y') ?> <?= e($siteNome) ?> — <?= e(site_tagline()) ?>. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <a href="https://wa.me/<?= e($siteWhatsapp) ?>" target="_blank" rel="noopener"
       class="wa-float animate-bounce" aria-label="WhatsApp">
        <i class="fab fa-whatsapp text-3xl"></i>
    </a>

    <div class="chatbot" id="nacional-chatbot">
        <section class="chatbot-panel" id="chatbot-panel" aria-label="Assistente INFORMATIZA" hidden>
            <header class="chatbot-header">
                <div><strong data-i18n="chat_title">Assistente INFORMATIZA</strong><span data-i18n="chat_online">Online agora</span></div>
                <button type="button" class="chatbot-close" id="chatbot-close" aria-label="Fechar chat"><i class="fas fa-times"></i></button>
            </header>
            <div class="chatbot-messages" id="chatbot-messages">
                <div class="chatbot-message bot" data-i18n="chat_welcome">Olá! Como podemos ajudar?</div>
            </div>
            <div class="chatbot-quick-actions">
                <button type="button" data-chat-question="services" data-i18n="chat_services">Ver serviços</button>
                <button type="button" data-chat-question="locations" data-i18n="chat_locations">Onde estamos?</button>
                <button type="button" data-chat-question="contact" data-i18n="chat_contact">Falar com a equipa</button>
            </div>
            <a class="chatbot-whatsapp" href="https://wa.me/<?= e($siteWhatsapp) ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i><span data-i18n="chat_whatsapp">Abrir WhatsApp</span></a>
        </section>
        <button type="button" class="chatbot-toggle" id="chatbot-toggle" aria-label="Abrir chat" title="Abrir chat"><i class="fas fa-comments"></i><span class="chatbot-pulse"></span></button>
    </div>

    <script src="<?= url('/js/site.js') ?>"></script>
    <?php nap_swal_scripts(); ?>
</body>
</html>
