<?php
/**
 * Conformidade Decreto AGT + estrutura SAF-T (AO) — regras de negócio e exportação extendida.
 */

function fat_agt_compliance_migrate(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    foreach ([
        'fat_documentos' => [
            "source_billing CHAR(1) NOT NULL DEFAULT 'P' AFTER hash_control",
            'tax_point_date DATE NULL AFTER data_documento',
            'modo_formacao TINYINT(1) NOT NULL DEFAULT 0 AFTER observacoes',
            'ref_manual_serie VARCHAR(30) NULL AFTER documento_origem_id',
            'ref_manual_numero VARCHAR(40) NULL AFTER ref_manual_serie',
        ],
        'fat_empresa' => [
            'modo_formacao TINYINT(1) NOT NULL DEFAULT 0',
            'agt_backup_dias INT UNSIGNED NOT NULL DEFAULT 7',
            'agt_password_max_days INT UNSIGNED NOT NULL DEFAULT 90',
            'estabelecimento_codigo VARCHAR(20) NULL',
            'estabelecimento_nome VARCHAR(120) NULL',
            'agt_ultimo_backup_auto DATETIME NULL',
            'agt_mobilidade_ativa TINYINT(1) NOT NULL DEFAULT 0',
        ],
        'fat_series' => [
            'serie_integrada TINYINT(1) NOT NULL DEFAULT 0',
            'modo_formacao TINYINT(1) NOT NULL DEFAULT 0',
            'descontinuada TINYINT(1) NOT NULL DEFAULT 0',
        ],
        'fat_produtos' => [
            'descricao_bloqueada TINYINT(1) NOT NULL DEFAULT 0',
        ],
    ] as $table => $cols) {
        foreach ($cols as $colDef) {
            $name = strtok($colDef, ' ');
            try {
                $exists = db()->query("SHOW COLUMNS FROM {$table} LIKE '" . $name . "'")->fetch();
                if (!$exists) {
                    db()->exec("ALTER TABLE {$table} ADD COLUMN {$colDef}");
                }
            } catch (Throwable $e) {
            }
        }
    }

    try {
        db()->exec('CREATE TABLE IF NOT EXISTS fat_system_backups (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            ficheiro VARCHAR(255) NOT NULL,
            tamanho BIGINT UNSIGNED NOT NULL DEFAULT 0,
            tipo ENUM("manual","automatico") NOT NULL DEFAULT "manual",
            restauracao TINYINT(1) NOT NULL DEFAULT 0,
            criado_por INT UNSIGNED NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_backup_data (criado_em)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    } catch (Throwable $e) {
    }

    try {
        $c = db()->query("SHOW COLUMNS FROM usuarios LIKE 'senha_alterada_em'")->fetch();
        if (!$c) {
            db()->exec('ALTER TABLE usuarios ADD COLUMN senha_alterada_em DATETIME NULL AFTER senha');
            db()->exec('UPDATE usuarios SET senha_alterada_em = COALESCE(ultimo_acesso, NOW()) WHERE senha_alterada_em IS NULL');
        }
    } catch (Throwable $e) {
    }

    try {
        db()->exec('UPDATE fat_documentos SET tax_point_date = data_documento WHERE tax_point_date IS NULL');
    } catch (Throwable $e) {
    }

    $docEnum = "ENUM('FT','FR','NC','ND','FA','OR','GT','GR','GD','GA','RC','AR')";
    try {
        db()->exec("ALTER TABLE fat_documentos MODIFY tipo {$docEnum} NOT NULL");
        db()->exec("ALTER TABLE fat_series MODIFY tipo {$docEnum} NOT NULL");
    } catch (Throwable $e) {
    }

    foreach ([
        'hash_externo VARCHAR(512) NULL AFTER hash_control',
        'hash_control_custom VARCHAR(80) NULL AFTER hash_externo',
        'doc_duplicado_ref VARCHAR(80) NULL AFTER ref_manual_numero',
        'movement_start DATETIME NULL AFTER doc_duplicado_ref',
        'movement_end DATETIME NULL AFTER movement_start',
        'ship_from_morada VARCHAR(255) NULL AFTER movement_end',
        'ship_to_morada VARCHAR(255) NULL AFTER ship_from_morada',
        "copia_original TINYINT(1) NOT NULL DEFAULT 0 AFTER ship_to_morada",
        "work_type VARCHAR(2) NULL DEFAULT 'PF' AFTER copia_original",
        'meio_pagamento VARCHAR(30) NULL AFTER work_type',
        'warehouse_from VARCHAR(50) NULL AFTER meio_pagamento',
        'warehouse_to VARCHAR(50) NULL AFTER warehouse_from',
        'emissao_movel TINYINT(1) NOT NULL DEFAULT 0 AFTER warehouse_to',
        'dispositivo_movel_id INT UNSIGNED NULL AFTER emissao_movel',
    ] as $colDef) {
        $name = strtok($colDef, ' ');
        try {
            $exists = db()->query("SHOW COLUMNS FROM fat_documentos LIKE '" . $name . "'")->fetch();
            if (!$exists) {
                db()->exec('ALTER TABLE fat_documentos ADD COLUMN ' . $colDef);
            }
        } catch (Throwable $e) {
        }
    }

    $ano = (int) date('Y');
    foreach (['GT', 'GR', 'GD', 'GA', 'RC', 'AR'] as $t) {
        try {
            $chk = db()->prepare('SELECT id FROM fat_series WHERE tipo=? AND serie=? AND ano=?');
            $chk->execute([$t, 'A', $ano]);
            if (!$chk->fetch()) {
                db()->prepare('INSERT INTO fat_series (tipo, serie, ano, proximo_numero, ativo) VALUES (?,?,?,1,1)')
                    ->execute([$t, 'A', $ano]);
            }
            $chk->execute([$t, 'RM', $ano]);
            if (!$chk->fetch()) {
                db()->prepare('INSERT INTO fat_series (tipo, serie, ano, proximo_numero, ativo, modo_formacao) VALUES (?,?,?,1,1,0)')
                    ->execute([$t, 'RM', $ano]);
            }
        } catch (Throwable $e) {
        }
    }

    try {
        db()->exec('CREATE TABLE IF NOT EXISTS fat_dispositivos_movel (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(120) NOT NULL,
            identificador VARCHAR(80) NOT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_disp_id (identificador)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    } catch (Throwable $e) {
    }

    foreach (['FT', 'FR', 'NC', 'ND'] as $t) {
        try {
            $chk = db()->prepare('SELECT id FROM fat_series WHERE tipo=? AND serie=? AND ano=?');
            $chk->execute([$t, 'INT', $ano]);
            if (!$chk->fetch()) {
                db()->prepare('INSERT INTO fat_series (tipo, serie, ano, proximo_numero, ativo, serie_integrada) VALUES (?,?,?,1,1,1)')
                    ->execute([$t, 'INT', $ano]);
            }
        } catch (Throwable $e) {
        }
    }
}

function fat_agt_work_types(): array
{
    return ['PF', 'OR', 'CM', 'CC', 'GR', 'NR', 'FO', 'NE', 'OU', 'DC', 'RP', 'RE', 'CS', 'LD', 'RA', 'GC'];
}

function fat_agt_work_type_for_doc(array $doc): string
{
    $wt = strtoupper(trim((string) ($doc['work_type'] ?? 'PF')));
    if (in_array($wt, fat_agt_work_types(), true)) {
        return $wt;
    }

    return ($doc['tipo'] ?? '') === 'OR' ? 'PF' : 'PF';
}

function fat_agt_meio_pagamento_saft(?string $metodo): string
{
    $m = strtolower(trim((string) $metodo));

    return match ($m) {
        'multicaixa', 'mb' => 'MB',
        'cartao', 'cartao_credito', 'cc' => 'CC',
        'cartao_debito', 'cd' => 'CD',
        'cheque', 'ch' => 'CH',
        'transferencia', 'tb' => 'TB',
        default => 'NU',
    };
}

/** Série de emissão (integração I → série marcada integrada). */
function fat_agt_resolve_serie_emissao(array $doc): string
{
    $tipo = (string) ($doc['tipo'] ?? 'FT');
    $serie = trim((string) ($doc['serie'] ?: 'A'));
    $ano = (int) date('Y', strtotime((string) ($doc['data_documento'] ?? date('Y-m-d'))));
    $billing = fat_agt_source_billing_for_doc($doc);
    if ($billing !== 'I') {
        return $serie ?: 'A';
    }
    $q = db()->prepare(
        'SELECT serie FROM fat_series WHERE tipo=? AND ano=? AND serie_integrada=1 AND ativo=1 AND COALESCE(descontinuada,0)=0 ORDER BY serie LIMIT 1'
    );
    $q->execute([$tipo, $ano]);
    $s = $q->fetchColumn();
    if (!$s) {
        throw new RuntimeException('SourceBilling I: configure uma série «Integrada» (ex.: INT) em Facturação → Séries AGT.');
    }

    return (string) $s;
}

function fat_agt_mysqldump_path(): string
{
    if (is_file('C:/xampp/mysql/bin/mysqldump.exe')) {
        return 'C:/xampp/mysql/bin/mysqldump.exe';
    }

    return 'mysqldump';
}

/** Cópia SQL + registo AGT (manual ou automático). */
function fat_agt_executar_backup_sql(?int $userId = null, string $tipo = 'manual'): string
{
    fat_agt_compliance_migrate();
    $dir = dirname(__DIR__) . '/storage/backups';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $name = 'nap_' . date('Ymd_His') . '.sql';
    $path = $dir . '/' . $name;
    $host = DB_HOST;
    $user = DB_USER;
    $pass = DB_PASS;
    $dbName = DB_NAME;
    $mysqldump = fat_agt_mysqldump_path();
    $cmd = escapeshellarg($mysqldump) . ' -h' . escapeshellarg($host) . ' -u' . escapeshellarg($user);
    if ($pass !== '') {
        $cmd .= ' -p' . escapeshellarg($pass);
    }
    $cmd .= ' ' . escapeshellarg($dbName) . ' > ' . escapeshellarg($path);
    exec($cmd, $out, $code);
    if ($code !== 0 || !is_file($path)) {
        throw new RuntimeException('Falha ao executar mysqldump.');
    }
    fat_agt_registar_backup($path, $userId ?? 0, $tipo === 'automatico' ? 'automatico' : 'manual');
    if ($tipo === 'automatico') {
        db()->exec('UPDATE fat_empresa SET agt_ultimo_backup_auto=NOW() ORDER BY id ASC LIMIT 1');
    }

    return $name;
}

function fat_agt_dias_sem_backup(): ?int
{
    fat_agt_compliance_migrate();
    $emp = fat_empresa();
    if (!$emp) {
        return null;
    }
    $maxDays = max(1, (int) ($emp['agt_backup_dias'] ?? 7));
    $last = db()->query('SELECT MAX(criado_em) FROM fat_system_backups WHERE restauracao=0')->fetchColumn();
    if (!$last) {
        return $maxDays + 1;
    }
    $days = (int) floor((time() - strtotime((string) $last)) / 86400);

    return max(0, $days);
}

function fat_agt_backup_em_atraso(): bool
{
    $emp = fat_empresa();
    if (!$emp) {
        return false;
    }
    $maxDays = max(1, (int) ($emp['agt_backup_dias'] ?? 7));
    $dias = fat_agt_dias_sem_backup();

    return $dias !== null && $dias > $maxDays;
}

function fat_agt_registar_restauracao(string $ficheiro, int $userId, string $notas = ''): void
{
    fat_agt_compliance_migrate();
    db()->prepare('INSERT INTO fat_system_backups (ficheiro, tamanho, tipo, restauracao, criado_por) VALUES (?,?,?,?,?)')
        ->execute([$ficheiro, 0, 'manual', 1, $userId ?: null]);
}

function fat_saft_append_payment_method(DOMDocument $xml, DOMElement $payment, string $mechanism, float $amount, string $payDate): void
{
    $pm = $xml->createElement('PaymentMethod');
    $payment->appendChild($pm);
    $pm->appendChild($xml->createElement('PaymentMechanism', $mechanism));
    $pm->appendChild($xml->createElement('PaymentAmount', number_format($amount, 2, '.', '')));
    $pm->appendChild($xml->createElement('PaymentDate', $payDate));
}

function fat_agt_sales_types(): array
{
    return ['FT', 'FR', 'NC', 'ND', 'FA'];
}

function fat_agt_movement_types(): array
{
    return ['GT', 'GR', 'GD', 'GA'];
}

function fat_agt_receipt_types(): array
{
    return ['RC', 'AR'];
}

function fat_agt_is_movement_type(string $tipo): bool
{
    return in_array(strtoupper($tipo), fat_agt_movement_types(), true);
}

function fat_agt_is_receipt_type(string $tipo): bool
{
    return in_array(strtoupper($tipo), fat_agt_receipt_types(), true);
}

function fat_agt_is_sales_type(string $tipo): bool
{
    return in_array(strtoupper($tipo), fat_agt_sales_types(), true);
}

function fat_agt_hash_control_manual(string $tipo, int $keyVersion, string $manualSerie, string $manualNum): string
{
    return $keyVersion . '-' . strtoupper($tipo) . 'M ' . trim($manualSerie) . '/' . trim($manualNum);
}

function fat_agt_hash_control_duplicado(string $tipo, int $keyVersion, string $invoiceNo): string
{
    return $keyVersion . '-' . strtoupper($tipo) . 'D ' . trim($invoiceNo);
}

function fat_agt_hash_control_integrado(string $certNumber, int $keyVersion): string
{
    return trim($certNumber) . '.' . $keyVersion;
}

function fat_saft_hash_control_for_doc(array $emp, array $doc): string
{
    if (!empty($doc['hash_control_custom'])) {
        return (string) $doc['hash_control_custom'];
    }
    $stored = trim((string) ($doc['hash_control'] ?? ''));
    if ($stored !== '' && $stored !== '0' && fat_agt_source_billing_for_doc($doc) !== 'P') {
        return $stored;
    }

    return fat_saft_hash_control_value($emp);
}

/** Emissão: assinatura ou hash externo (integração / recibos). */
function fat_agt_emit_signatures(array $doc, array $num, string $dataDoc, string $sysEntry, string $prev): array
{
    $tipo = strtoupper((string) ($doc['tipo'] ?? ''));
    $emp = fat_empresa();
    $keyVer = max(1, (int) ($emp['agt_signature_version'] ?? 1));

    if (fat_agt_is_receipt_type($tipo)) {
        return [
            'hash' => '',
            'hash_anterior' => '',
            'hash_control' => fat_saft_hash_control_value($emp),
            'payload' => '',
        ];
    }

    $billing = fat_agt_source_billing_for_doc($doc);
    if ($billing === 'I' && trim((string) ($doc['hash_externo'] ?? '')) !== '') {
        $hc = trim((string) ($doc['hash_control_custom'] ?? ''));
        return [
            'hash' => fat_saft_hash_field((string) $doc['hash_externo']),
            'hash_anterior' => '',
            'hash_control' => $hc !== '' ? $hc : 'Não Validado pela AGT',
            'payload' => 'integrado',
        ];
    }

    $sign = fat_sign_document($dataDoc, $sysEntry, $num['numero_completo'], (float) $doc['total'], $prev);
    $hashControl = $sign['hash_control'];

    if ($billing === 'M' && trim((string) ($doc['ref_manual_serie'] ?? '')) !== '' && trim((string) ($doc['ref_manual_numero'] ?? '')) !== '') {
        $hashControl = fat_agt_hash_control_manual($tipo, $keyVer, (string) $doc['ref_manual_serie'], (string) $doc['ref_manual_numero']);
    } elseif (trim((string) ($doc['doc_duplicado_ref'] ?? '')) !== '') {
        $hashControl = fat_agt_hash_control_duplicado($tipo, $keyVer, (string) $doc['doc_duplicado_ref']);
    } elseif (!empty($doc['hash_control_custom'])) {
        $hashControl = (string) $doc['hash_control_custom'];
    }

    $sign['hash_control'] = $hashControl;

    return $sign;
}

function fat_agt_criar_rascunho_recibo(int $facturaId, float $valor, string $metodo = 'numerario', ?int $userId = null, string $tipoRecibo = 'RC'): int
{
    ensure_facturacao_schema();
    fat_agt_compliance_migrate();
    $tipoRecibo = strtoupper($tipoRecibo) === 'AR' ? 'AR' : 'RC';
    $f = db()->prepare("SELECT * FROM fat_documentos WHERE id=? AND tipo IN ('FT','FR') AND estado='emitido'");
    $f->execute([$facturaId]);
    $fact = $f->fetch();
    if (!$fact) {
        throw new RuntimeException('Factura de origem inválida.');
    }
    if ($valor <= 0 || $valor > (float) $fact['total'] + 0.01) {
        throw new RuntimeException('Valor do recibo inválido.');
    }
    $userId = $userId ?? (int) (current_user()['id'] ?? 0);
    db()->prepare(
        "INSERT INTO fat_documentos (tipo, serie, numero, numero_completo, cliente_id, cliente_nome, cliente_nif, cliente_morada,
         data_documento, data_sistema, tax_point_date, estado, documento_origem_id, subtotal, total_iva, total, meio_pagamento, source_billing, criado_por)
         VALUES (?,?,NULL,'RASCUNHO',?,?,?,?,?,NOW(),?, 'rascunho', ?, ?,0,?, ?, 'P', ?)"
    )->execute([
        $tipoRecibo, 'A',
        $fact['cliente_id'], $fact['cliente_nome'], $fact['cliente_nif'], $fact['cliente_morada'],
        $fact['data_documento'], $fact['data_documento'], $facturaId, $valor, $valor, $metodo, $userId,
    ]);
    $docId = (int) db()->lastInsertId();
    $descRec = 'Pagamento referente a ' . ($fact['numero_completo'] ?? 'factura');
    db()->prepare(
        'INSERT INTO fat_linhas (documento_id, linha, codigo, descricao, quantidade, unidade, preco_unitario, desconto_pct, taxa_iva, total_liquido, total_iva, total_linha)
         VALUES (?,1,?,?,1,?, ?,0,0, ?,0,?)'
    )->execute([$docId, 'REC', $descRec, 'UN', $valor, $valor, $valor]);
    return $docId;
}

function fat_agt_consumidor_final_nif(): string
{
    return '999999999';
}

function fat_agt_documento_nao_factura(string $tipo): bool
{
    return in_array(strtoupper($tipo), ['OR', 'FA'], true);
}

function fat_agt_aviso_nao_factura(string $tipo): string
{
    if (!fat_agt_documento_nao_factura($tipo)) {
        return '';
    }

    return 'Este documento não serve de factura';
}

function fat_agt_modo_formacao_ativo(?array $emp = null): bool
{
    $emp = $emp ?? fat_empresa();

    return !empty($emp['modo_formacao']);
}

function fat_agt_cliente_tem_documentos(int $clienteId): bool
{
    $stmt = db()->prepare("SELECT 1 FROM fat_documentos WHERE cliente_id=? AND estado IN ('emitido','anulado') LIMIT 1");
    $stmt->execute([$clienteId]);

    return (bool) $stmt->fetchColumn();
}

function fat_agt_validar_alteracao_cliente(int $clienteId, string $novoNif, string $novoNome, array $actual): void
{
    if (!fat_agt_cliente_tem_documentos($clienteId)) {
        return;
    }
    $nifActual = preg_replace('/\s+/', '', (string) ($actual['nif'] ?? ''));
    $nifNovo = preg_replace('/\s+/', '', $novoNif) ?: fat_agt_consumidor_final_nif();
    $gen = fat_agt_consumidor_final_nif();
    if ($nifActual !== '' && $nifActual !== $gen && $nifNovo !== $nifActual) {
        throw new RuntimeException('Não pode alterar o NIF de um cliente com documentos emitidos (regra AGT). Apenas pode preencher NIF em falta ou substituir o genérico ' . $gen . '.');
    }
    if (($nifActual === '' || $nifActual === $gen) && $nifNovo !== $gen && trim($novoNome) !== trim((string) ($actual['nome'] ?? ''))) {
        throw new RuntimeException('Enquanto o cliente não tiver NIF real averbado, não pode alterar o nome (regra AGT).');
    }
}

function fat_agt_produto_tem_movimentos(int $produtoId): bool
{
    $stmt = db()->prepare('SELECT 1 FROM fat_linhas WHERE produto_id=? LIMIT 1');
    $stmt->execute([$produtoId]);

    return (bool) $stmt->fetchColumn();
}

function fat_agt_validar_alteracao_produto(int $produtoId, string $novaDescricao, array $actual): void
{
    if (!fat_agt_produto_tem_movimentos($produtoId)) {
        return;
    }
    if (trim($novaDescricao) !== trim((string) ($actual['descricao'] ?? ''))) {
        throw new RuntimeException('Não pode alterar a descrição de um produto/serviço já usado em documentos emitidos (regra AGT / tabela 2.4).');
    }
}

function fat_agt_ultimo_system_entry(): ?string
{
    $row = db()->query("SELECT MAX(data_sistema) FROM fat_documentos WHERE estado='emitido'")->fetchColumn();

    return $row ? (string) $row : null;
}

function fat_agt_validar_data_emissao(string $dataDocumento, ?string $confirmClockOk = null): void
{
    $docDate = strtotime($dataDocumento);
    if ($docDate === false) {
        throw new RuntimeException('Data do documento inválida.');
    }
    $today = strtotime(date('Y-m-d'));
    if ($docDate > $today) {
        throw new RuntimeException('Não pode emitir documento com data posterior à data actual (regra AGT).');
    }
    $last = fat_agt_ultimo_system_entry();
    if ($last !== null) {
        $now = time();
        $lastTs = strtotime($last);
        if ($now < $lastTs && ($confirmClockOk !== '1' && $confirmClockOk !== 'sim')) {
            throw new RuntimeException('A data/hora do sistema é anterior ao último documento emitido. Confirme o relógio do servidor antes de continuar (regra AGT).');
        }
        if ($docDate < strtotime(date('Y-m-d', $lastTs)) && $lastTs >= $today) {
            throw new RuntimeException('Após emitir documento com data futura, não pode emitir com data anterior na mesma série (regra AGT).');
        }
    }
}

function fat_agt_serie_permitida(string $tipo, string $serie, int $ano): void
{
    $stmt = db()->prepare('SELECT ativo, descontinuada, modo_formacao FROM fat_series WHERE tipo=? AND serie=? AND ano=?');
    $stmt->execute([$tipo, $serie, $ano]);
    $s = $stmt->fetch();
    if (!$s) {
        return;
    }
    if (!(int) $s['ativo'] || (int) $s['descontinuada']) {
        throw new RuntimeException('Série descontinuada ou inactiva — não pode emitir (regra AGT).');
    }
    $formacao = fat_agt_modo_formacao_ativo();
    if ($formacao && !(int) $s['modo_formacao']) {
        throw new RuntimeException('Modo formação activo: use uma série marcada para formação.');
    }
    if (!$formacao && (int) $s['modo_formacao']) {
        throw new RuntimeException('Série reservada a formação — desactive o modo formação na empresa.');
    }
}

function fat_agt_validar_linhas_iva(array $linhas): void
{
    foreach ($linhas as $i => $l) {
        $taxa = (float) ($l['taxa_iva'] ?? 0);
        if ($taxa == 0.0) {
            $code = strtoupper(trim((string) ($l['codigo_isencao'] ?? '')));
            if ($code === '' && !empty($l['produto_id'])) {
                $pe = db()->prepare('SELECT codigo_isencao FROM fat_produtos WHERE id=?');
                $pe->execute([(int) $l['produto_id']]);
                $code = strtoupper(trim((string) $pe->fetchColumn()));
            }
            if ($code === '') {
                throw new RuntimeException('Linha ' . ($i + 1) . ': indique motivo de isenção/não liquidação de IVA (regra AGT).');
            }
        }
        $desc = (float) ($l['desconto_pct'] ?? 0);
        if ($desc < 0 || $desc > 100) {
            throw new RuntimeException('Descontos devem estar entre 0% e 100% (regra AGT).');
        }
    }
}

function fat_agt_documento_rectificativo_pendente(int $docId): bool
{
    $stmt = db()->prepare("SELECT 1 FROM fat_documentos WHERE documento_origem_id=? AND tipo IN ('NC','ND') AND estado='emitido' LIMIT 1");
    $stmt->execute([$docId]);

    return (bool) $stmt->fetchColumn();
}

function fat_agt_validar_anulacao(array $doc): void
{
    if (fat_agt_documento_rectificativo_pendente((int) $doc['id'])) {
        throw new RuntimeException('Anule primeiro a nota de crédito/débito associada antes de anular este documento (regra AGT).');
    }
}

function fat_agt_validar_criacao_nc(int $origemId, array $linhasNc): void
{
    $orig = db()->prepare('SELECT * FROM fat_documentos WHERE id=?');
    $orig->execute([$origemId]);
    $o = $orig->fetch();
    if (!$o || $o['estado'] !== 'emitido') {
        throw new RuntimeException('Documento de origem inválido para NC.');
    }
    if ($o['estado'] === 'anulado') {
        throw new RuntimeException('Não pode emitir NC sobre documento anulado (regra AGT).');
    }
    $stmt = db()->prepare("SELECT COALESCE(SUM(total),0) FROM fat_documentos WHERE documento_origem_id=? AND tipo='NC' AND estado='emitido'");
    $stmt->execute([$origemId]);
    $jaRect = (float) $stmt->fetchColumn();
    $novoTotal = 0.0;
    foreach ($linhasNc as $l) {
        $novoTotal += (float) ($l['total_linha'] ?? 0);
    }
    if ($jaRect + $novoTotal > (float) $o['total'] + 0.01) {
        throw new RuntimeException('Nota de crédito excede o valor da factura original — emita NC parcial dentro do limite (regra AGT).');
    }
}

function fat_agt_validar_pre_emissao(array $doc, array $linhas, ?string $confirmClockOk = null): void
{
    fat_agt_validar_data_emissao((string) $doc['data_documento'], $confirmClockOk);
    fat_agt_serie_permitida(
        (string) $doc['tipo'],
        (string) ($doc['serie'] ?: 'A'),
        (int) date('Y', strtotime($doc['data_documento']))
    );
    if (($doc['tipo'] ?? '') === 'NC' && !empty($doc['documento_origem_id'])) {
        fat_agt_validar_criacao_nc((int) $doc['documento_origem_id'], $linhas);
    }
    $tipo = strtoupper((string) ($doc['tipo'] ?? ''));
    $serieDoc = trim((string) ($doc['serie'] ?: 'A'));
    $anoDoc = (int) date('Y', strtotime((string) ($doc['data_documento'] ?? date('Y-m-d'))));
    $sInt = db()->prepare('SELECT serie_integrada FROM fat_series WHERE tipo=? AND serie=? AND ano=?');
    $sInt->execute([$tipo, $serieDoc, $anoDoc]);
    $sRow = $sInt->fetch();
    if ($sRow && (int) ($sRow['serie_integrada'] ?? 0) && fat_agt_source_billing_for_doc($doc) !== 'I') {
        throw new RuntimeException('A série «' . $serieDoc . '» é integrada — use SourceBilling I ou outra série.');
    }
    if ($tipo !== 'OR' && !fat_agt_is_movement_type($tipo) && !fat_agt_is_receipt_type($tipo)) {
        fat_agt_validar_linhas_iva($linhas);
    }
}

function fat_agt_source_billing_for_doc(array $doc): string
{
    $sb = strtoupper(trim((string) ($doc['source_billing'] ?? 'P')));
    if (in_array($sb, ['P', 'I', 'M'], true)) {
        return $sb;
    }
    if (!empty($doc['ref_manual_serie']) || !empty($doc['ref_manual_numero'])) {
        return 'M';
    }

    return 'P';
}

function fat_agt_tax_point_date(array $doc): string
{
    $tp = $doc['tax_point_date'] ?? null;

    return ($tp && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $tp)) ? (string) $tp : (string) $doc['data_documento'];
}

/** Registo de cópia de segurança (requisito AGT n.º 12–13). */
function fat_agt_registar_backup(string $path, int $userId, string $tipo = 'manual', bool $restauracao = false): void
{
    fat_agt_compliance_migrate();
    if (!is_file($path)) {
        return;
    }
    db()->prepare('INSERT INTO fat_system_backups (ficheiro, tamanho, tipo, restauracao, criado_por) VALUES (?,?,?,?,?)')
        ->execute([basename($path), (int) filesize($path), $tipo, $restauracao ? 1 : 0, $userId ?: null]);
}

function fat_agt_password_expirada(array $user): bool
{
    fat_agt_compliance_migrate();
    $userId = (int) ($user['id'] ?? 0);
    if ($userId <= 0) {
        return false;
    }
    $emp = fat_empresa();
    $max = max(30, (int) ($emp['agt_password_max_days'] ?? 90));
    $changed = $user['senha_alterada_em'] ?? null;
    if ($changed === null || $changed === '') {
        $stmt = db()->prepare('SELECT senha_alterada_em FROM usuarios WHERE id=?');
        $stmt->execute([$userId]);
        $changed = $stmt->fetchColumn();
    }
    if (!$changed) {
        db()->prepare('UPDATE usuarios SET senha_alterada_em=NOW() WHERE id=? AND senha_alterada_em IS NULL')
            ->execute([$userId]);

        return false;
    }

    return strtotime((string) $changed) < strtotime('-' . $max . ' days');
}

function fat_agt_marcar_senha_alterada(int $userId): void
{
    db()->prepare('UPDATE usuarios SET senha_alterada_em=NOW() WHERE id=?')->execute([$userId]);
}

function fat_saft_append_nc_references(DOMDocument $xml, DOMElement $line, array $doc): void
{
    if (!in_array($doc['tipo'] ?? '', ['NC', 'ND'], true) || empty($doc['documento_origem_id'])) {
        return;
    }
    $orig = db()->prepare('SELECT numero_completo, motivo_anulacao FROM fat_documentos WHERE id=?');
    $orig->execute([(int) $doc['documento_origem_id']]);
    $o = $orig->fetch();
    if (!$o) {
        return;
    }
    $refs = $xml->createElement('References');
    $line->appendChild($refs);
    $refs->appendChild($xml->createElement('Reference', (string) $o['numero_completo']));
    $reason = trim((string) ($doc['motivo_anulacao'] ?? $o['motivo_anulacao'] ?? ''));
    if ($reason !== '') {
        $refs->appendChild($xml->createElement('Reason', $reason));
    }
}

function fat_saft_append_order_reference(DOMDocument $xml, DOMElement $line, array $doc): void
{
    if (empty($doc['documento_origem_id'])) {
        return;
    }
    $orig = db()->prepare('SELECT numero_completo FROM fat_documentos WHERE id=?');
    $orig->execute([(int) $doc['documento_origem_id']]);
    $ref = $orig->fetchColumn();
    if (!$ref) {
        return;
    }
    $or = $xml->createElement('OrderReferences');
    $line->appendChild($or);
    $or->appendChild($xml->createElement('OriginatingON', (string) $ref));
}

function fat_saft_export_working_documents(DOMDocument $xml, DOMElement $source, array $documentos, array $customerTaxById): void
{
    $ors = array_filter($documentos, static fn ($d) => ($d['tipo'] ?? '') === 'OR' && ($d['estado'] ?? '') === 'emitido');
    if ($ors === []) {
        return;
    }
    $wd = $xml->createElement('WorkingDocuments');
    $source->appendChild($wd);
    $wd->appendChild($xml->createElement('NumberOfEntries', (string) count($ors)));
    $wd->appendChild($xml->createElement('TotalDebit', '0.00'));
    $wd->appendChild($xml->createElement('TotalCredit', number_format(array_sum(array_map(static fn ($d) => (float) $d['total'], $ors)), 2, '.', '')));
    foreach ($ors as $d) {
        $work = $xml->createElement('WorkDocument');
        $wd->appendChild($work);
        $work->appendChild($xml->createElement('DocumentNumber', $d['numero_completo']));
        $ds = $xml->createElement('DocumentStatus');
        $work->appendChild($ds);
        $ds->appendChild($xml->createElement('WorkStatus', 'N'));
        $ds->appendChild($xml->createElement('WorkStatusDate', date('Y-m-d\TH:i:s', strtotime($d['data_sistema'] ?: $d['criado_em']))));
        $ds->appendChild($xml->createElement('SourceID', (string) ($d['criado_por'] ?: 1)));
        $ds->appendChild($xml->createElement('SourceBilling', fat_agt_source_billing_for_doc($d)));
        $work->appendChild($xml->createElement('Hash', fat_saft_hash_field($d['hash'] ?? '')));
        $empW = fat_empresa();
        $work->appendChild($xml->createElement('HashControl', fat_saft_hash_control_for_doc($empW ?: [], $d)));
        $work->appendChild($xml->createElement('WorkDate', $d['data_documento']));
        $work->appendChild($xml->createElement('WorkType', fat_agt_work_type_for_doc($d)));
        $work->appendChild($xml->createElement('SourceID', (string) ($d['criado_por'] ?: 1)));
        $work->appendChild($xml->createElement('SystemEntryDate', date('Y-m-d\TH:i:s', strtotime($d['data_sistema'] ?: $d['criado_em']))));
        $custId = (int) ($d['cliente_id'] ?: 1);
        $work->appendChild($xml->createElement('CustomerID', (string) $custId));
        $ls = db()->prepare('SELECT * FROM fat_linhas WHERE documento_id=? ORDER BY linha');
        $ls->execute([(int) $d['id']]);
        foreach ($ls->fetchAll() as $l) {
            $line = $xml->createElement('Line');
            $work->appendChild($line);
            $line->appendChild($xml->createElement('LineNumber', (string) $l['linha']));
            $line->appendChild($xml->createElement('ProductCode', $l['codigo'] ?: 'GEN'));
            $line->appendChild($xml->createElement('ProductDescription', $l['descricao']));
            $line->appendChild($xml->createElement('Quantity', number_format((float) $l['quantidade'], 2, '.', '')));
            $line->appendChild($xml->createElement('UnitOfMeasure', $l['unidade'] ?: 'UN'));
            $line->appendChild($xml->createElement('UnitPrice', number_format((float) $l['preco_unitario'], 2, '.', '')));
            $line->appendChild($xml->createElement('TaxPointDate', fat_agt_tax_point_date($d)));
            $line->appendChild($xml->createElement('Description', $l['descricao']));
            $line->appendChild($xml->createElement('CreditAmount', number_format(abs((float) $l['total_liquido']), 2, '.', '')));
            $tax = $xml->createElement('Tax');
            $line->appendChild($tax);
            $tax->appendChild($xml->createElement('TaxType', 'IVA'));
            $tax->appendChild($xml->createElement('TaxCountryRegion', 'AO'));
            $taxCode = (float) $l['taxa_iva'] == 0.0 ? 'ISE' : 'NOR';
            $tax->appendChild($xml->createElement('TaxCode', $taxCode));
            $tax->appendChild($xml->createElement('TaxPercentage', number_format((float) $l['taxa_iva'], 2, '.', '')));
        }
        $totals = $xml->createElement('DocumentTotals');
        $work->appendChild($totals);
        $totals->appendChild($xml->createElement('TaxPayable', number_format((float) $d['total_iva'], 2, '.', '')));
        $totals->appendChild($xml->createElement('NetTotal', number_format((float) $d['subtotal'], 2, '.', '')));
        $totals->appendChild($xml->createElement('GrossTotal', number_format((float) $d['total'], 2, '.', '')));
    }
}

function fat_saft_append_shipping_point(DOMDocument $xml, DOMElement $parent, string $tag, ?string $morada, ?string $warehouseId = null): void
{
    if (($morada === null || trim($morada) === '') && ($warehouseId === null || trim($warehouseId) === '')) {
        return;
    }
    $ship = $xml->createElement($tag);
    $parent->appendChild($ship);
    if ($warehouseId !== null && trim($warehouseId) !== '') {
        $ship->appendChild($xml->createElement('WarehouseID', trim($warehouseId)));
    }
    if ($morada !== null && trim($morada) !== '') {
        $addr = $xml->createElement('Address');
        $ship->appendChild($addr);
        $addr->appendChild($xml->createElement('AddressDetail', trim($morada)));
        $addr->appendChild($xml->createElement('City', 'Luanda'));
        $addr->appendChild($xml->createElement('Country', 'AO'));
    }
}

function fat_saft_export_movements(DOMDocument $xml, DOMElement $source, array $documentos, array $customerTaxById): void
{
    if ($documentos === []) {
        return;
    }
    $emp = fat_empresa() ?: [];
    $mov = $xml->createElement('MovementOfGoods');
    $source->appendChild($mov);
    $mov->appendChild($xml->createElement('NumberOfMovementLines', (string) count($documentos)));
    $totalQty = 0.0;
    $ls = db()->prepare('SELECT COALESCE(SUM(quantidade),0) FROM fat_linhas WHERE documento_id=?');
    foreach ($documentos as $d) {
        $ls->execute([(int) $d['id']]);
        $totalQty += (float) $ls->fetchColumn();
    }
    $mov->appendChild($xml->createElement('TotalQuantityIssued', number_format($totalQty, 2, '.', '')));

    foreach ($documentos as $d) {
        $sm = $xml->createElement('StockMovement');
        $mov->appendChild($sm);
        $sm->appendChild($xml->createElement('DocumentNumber', $d['numero_completo']));
        $ds = $xml->createElement('DocumentStatus');
        $sm->appendChild($ds);
        $ds->appendChild($xml->createElement('MovementStatus', $d['estado'] === 'anulado' ? 'A' : 'N'));
        $ds->appendChild($xml->createElement('MovementStatusDate', date('Y-m-d\TH:i:s', strtotime($d['data_sistema'] ?: $d['criado_em']))));
        $ds->appendChild($xml->createElement('SourceID', (string) ($d['criado_por'] ?: 1)));
        $ds->appendChild($xml->createElement('SourceBilling', fat_agt_source_billing_for_doc($d)));
        $sm->appendChild($xml->createElement('Hash', fat_saft_hash_field($d['hash'] ?? '')));
        $sm->appendChild($xml->createElement('HashControl', fat_saft_hash_control_for_doc($emp, $d)));
        $sm->appendChild($xml->createElement('MovementDate', $d['data_documento']));
        $sm->appendChild($xml->createElement('MovementType', strtoupper((string) $d['tipo'])));
        $sysEntry = date('Y-m-d\TH:i:s', strtotime($d['data_sistema'] ?: $d['criado_em']));
        $sm->appendChild($xml->createElement('SystemEntryDate', $sysEntry));
        $custId = (int) ($d['cliente_id'] ?: 1);
        $sm->appendChild($xml->createElement('CustomerID', (string) $custId));
        $sm->appendChild($xml->createElement('SourceID', (string) ($d['criado_por'] ?: 1)));
        $eac = trim((string) ($emp['agt_eac_code'] ?? ''));
        if ($eac !== '') {
            $sm->appendChild($xml->createElement('EACCode', $eac));
        }
        fat_saft_append_shipping_point($xml, $sm, 'ShipTo', $d['ship_to_morada'] ?? null, $d['warehouse_to'] ?? null);
        fat_saft_append_shipping_point($xml, $sm, 'ShipFrom', $d['ship_from_morada'] ?? null, $d['warehouse_from'] ?? null);
        $mEnd = $d['movement_end'] ?? null;
        if ($mEnd) {
            $sm->appendChild($xml->createElement('MovementEndTime', date('Y-m-d\TH:i:s', strtotime((string) $mEnd))));
        }
        $mStart = $d['movement_start'] ?? ($d['data_sistema'] ?? $d['criado_em']);
        $sm->appendChild($xml->createElement('MovementStartTime', date('Y-m-d\TH:i:s', strtotime((string) $mStart))));

        $lsDoc = db()->prepare('SELECT * FROM fat_linhas WHERE documento_id=? ORDER BY linha');
        $lsDoc->execute([(int) $d['id']]);
        foreach ($lsDoc->fetchAll() as $l) {
            $line = $xml->createElement('Line');
            $sm->appendChild($line);
            $line->appendChild($xml->createElement('LineNumber', (string) $l['linha']));
            $line->appendChild($xml->createElement('ProductCode', $l['codigo'] ?: 'GEN'));
            $line->appendChild($xml->createElement('ProductDescription', $l['descricao']));
            $line->appendChild($xml->createElement('Quantity', number_format((float) $l['quantidade'], 2, '.', '')));
            $line->appendChild($xml->createElement('UnitOfMeasure', $l['unidade'] ?: 'UN'));
            $line->appendChild($xml->createElement('UnitPrice', number_format((float) $l['preco_unitario'], 2, '.', '')));
            $line->appendChild($xml->createElement('Description', $l['descricao']));
            $line->appendChild($xml->createElement('CreditAmount', number_format(abs((float) $l['total_liquido']), 2, '.', '')));
            if ((float) ($l['taxa_iva'] ?? 0) > 0) {
                $tax = $xml->createElement('Tax');
                $line->appendChild($tax);
                $tax->appendChild($xml->createElement('TaxType', 'IVA'));
                $tax->appendChild($xml->createElement('TaxCountryRegion', 'AO'));
                $tax->appendChild($xml->createElement('TaxCode', 'NOR'));
                $tax->appendChild($xml->createElement('TaxPercentage', number_format((float) $l['taxa_iva'], 2, '.', '')));
            }
        }
        $totals = $xml->createElement('DocumentTotals');
        $sm->appendChild($totals);
        $totals->appendChild($xml->createElement('TaxPayable', number_format((float) $d['total_iva'], 2, '.', '')));
        $totals->appendChild($xml->createElement('NetTotal', number_format((float) $d['subtotal'], 2, '.', '')));
        $totals->appendChild($xml->createElement('GrossTotal', number_format((float) $d['total'], 2, '.', '')));
    }
}

function fat_saft_export_payments(DOMDocument $xml, DOMElement $source, string $from, string $to, array $customerTaxById): void
{
    $emp = fat_empresa() ?: [];
    $entries = [];

    $rcStmt = db()->prepare(
        "SELECT rc.*, orig.numero_completo AS factura_no, orig.data_documento AS factura_data
         FROM fat_documentos rc
         LEFT JOIN fat_documentos orig ON orig.id = rc.documento_origem_id
         WHERE rc.estado='emitido' AND rc.tipo IN ('RC','AR') AND rc.data_documento BETWEEN ? AND ?
         ORDER BY rc.data_documento, rc.id"
    );
    $rcStmt->execute([$from, $to]);
    foreach ($rcStmt->fetchAll() as $rc) {
        $entries[] = ['kind' => 'rc', 'row' => $rc];
    }

    $rgStmt = db()->prepare(
        "SELECT p.*, d.numero_completo, d.cliente_id, d.cliente_nif, d.data_documento
         FROM fat_pagamentos p
         INNER JOIN fat_documentos d ON d.id = p.documento_id
         WHERE d.estado='emitido' AND d.tipo IN ('FT','FR') AND p.data_pagamento BETWEEN ? AND ?
         AND NOT EXISTS (
            SELECT 1 FROM fat_documentos rc
            WHERE rc.tipo IN ('RC','AR') AND rc.estado='emitido'
              AND rc.documento_origem_id = p.documento_id
              AND rc.data_documento = p.data_pagamento
              AND ABS(rc.total - p.valor) < 0.02
         )
         ORDER BY p.data_pagamento, p.id"
    );
    $rgStmt->execute([$from, $to]);
    foreach ($rgStmt->fetchAll() as $p) {
        $entries[] = ['kind' => 'rg', 'row' => $p];
    }

    if ($entries === []) {
        return;
    }
    $payments = $xml->createElement('Payments');
    $source->appendChild($payments);
    $payments->appendChild($xml->createElement('NumberOfEntries', (string) count($entries)));
    $total = 0.0;
    foreach ($entries as $e) {
        $total += (float) ($e['kind'] === 'rc' ? $e['row']['total'] : $e['row']['valor']);
    }
    $payments->appendChild($xml->createElement('TotalDebit', '0.00'));
    $payments->appendChild($xml->createElement('TotalCredit', number_format($total, 2, '.', '')));

    $rgSeq = 0;
    foreach ($entries as $e) {
        $pay = $xml->createElement('Payment');
        $payments->appendChild($pay);
        if ($e['kind'] === 'rc') {
            $rc = $e['row'];
            $payType = (string) $rc['tipo'];
            $pay->appendChild($xml->createElement('PaymentRefNo', $rc['numero_completo']));
            $pay->appendChild($xml->createElement('TransactionDate', $rc['data_documento']));
            $pay->appendChild($xml->createElement('PaymentType', $payType));
            $statusDate = date('Y-m-d\TH:i:s', strtotime($rc['data_sistema'] ?: $rc['criado_em']));
            $sysEntry = $statusDate;
            $custId = fat_saft_resolve_customer_id_for_export(
                (int) ($rc['cliente_id'] ?: 0),
                (string) ($rc['cliente_nif'] ?? ''),
                $customerTaxById
            );
            $valor = (float) $rc['total'];
            $factNo = (string) ($rc['factura_no'] ?? '');
            $factDate = (string) ($rc['factura_data'] ?? $rc['data_documento']);
        } else {
            $p = $e['row'];
            $refNo = sprintf('RG R/%d', ++$rgSeq);
            $pay->appendChild($xml->createElement('PaymentRefNo', $refNo));
            $pay->appendChild($xml->createElement('TransactionDate', $p['data_pagamento']));
            $pay->appendChild($xml->createElement('PaymentType', 'RG'));
            $statusDate = date('Y-m-d\TH:i:s', strtotime($p['criado_em']));
            $sysEntry = $statusDate;
            $custId = fat_saft_resolve_customer_id_for_export(
                (int) ($p['cliente_id'] ?: 0),
                (string) ($p['cliente_nif'] ?? ''),
                $customerTaxById
            );
            $valor = (float) $p['valor'];
            $factNo = (string) $p['numero_completo'];
            $factDate = (string) $p['data_documento'];
        }
        $ds = $xml->createElement('DocumentStatus');
        $pay->appendChild($ds);
        $ds->appendChild($xml->createElement('PaymentStatus', 'N'));
        $ds->appendChild($xml->createElement('PaymentStatusDate', $statusDate));
        $ds->appendChild($xml->createElement('SourceID', '1'));
        $ds->appendChild($xml->createElement('SourcePayment', 'P'));
        $mechanism = 'NU';
        $payDate = $factDate;
        if ($e['kind'] === 'rc') {
            $mechanism = fat_agt_meio_pagamento_saft((string) ($rc['meio_pagamento'] ?? 'numerario'));
            $payDate = (string) $rc['data_documento'];
        } else {
            $mechanism = fat_agt_meio_pagamento_saft((string) ($p['metodo'] ?? 'numerario'));
            $payDate = (string) $p['data_pagamento'];
        }
        fat_saft_append_payment_method($xml, $pay, $mechanism, $valor, $payDate);
        $pay->appendChild($xml->createElement('SourceID', '1'));
        $pay->appendChild($xml->createElement('SystemEntryDate', $sysEntry));
        $pay->appendChild($xml->createElement('CustomerID', (string) $custId));
        $line = $xml->createElement('Line');
        $pay->appendChild($line);
        $line->appendChild($xml->createElement('LineNumber', '1'));
        if ($factNo !== '') {
            $sdoc = $xml->createElement('SourceDocumentID');
            $line->appendChild($sdoc);
            $sdoc->appendChild($xml->createElement('OriginatingON', $factNo));
            $sdoc->appendChild($xml->createElement('InvoiceDate', $factDate));
        }
        $line->appendChild($xml->createElement('CreditAmount', number_format($valor, 2, '.', '')));
        $totals = $xml->createElement('DocumentTotals');
        $pay->appendChild($totals);
        $totals->appendChild($xml->createElement('TaxPayable', '0.00'));
        $totals->appendChild($xml->createElement('NetTotal', number_format($valor, 2, '.', '')));
        $totals->appendChild($xml->createElement('GrossTotal', number_format($valor, 2, '.', '')));
    }
}

function fat_saft_append_purchase_invoice_lines(DOMDocument $xml, DOMElement $invoice, int $compraId): void
{
    $ls = db()->prepare('SELECT * FROM fat_compra_linhas WHERE compra_id=? ORDER BY linha');
    $ls->execute([$compraId]);
    $rows = $ls->fetchAll();
    if ($rows === []) {
        return;
    }
    foreach ($rows as $l) {
        $line = $xml->createElement('Line');
        $invoice->appendChild($line);
        $line->appendChild($xml->createElement('LineNumber', (string) $l['linha']));
        $line->appendChild($xml->createElement('ProductCode', $l['codigo'] ?: 'COMPRA'));
        $line->appendChild($xml->createElement('ProductDescription', $l['descricao']));
        $line->appendChild($xml->createElement('Quantity', number_format((float) $l['quantidade'], 2, '.', '')));
        $line->appendChild($xml->createElement('UnitPrice', number_format((float) $l['preco_unitario'], 2, '.', '')));
        $line->appendChild($xml->createElement('TaxPointDate', date('Y-m-d')));
        $line->appendChild($xml->createElement('Description', $l['descricao']));
        $line->appendChild($xml->createElement('DebitAmount', number_format((float) $l['total_liquido'], 2, '.', '')));
        $tax = $xml->createElement('Tax');
        $line->appendChild($tax);
        $tax->appendChild($xml->createElement('TaxType', 'IVA'));
        $tax->appendChild($xml->createElement('TaxCountryRegion', 'AO'));
        $taxCode = (float) $l['taxa_iva'] == 0.0 ? 'ISE' : 'NOR';
        $tax->appendChild($xml->createElement('TaxCode', $taxCode));
        $tax->appendChild($xml->createElement('TaxPercentage', number_format((float) $l['taxa_iva'], 2, '.', '')));
    }
}
