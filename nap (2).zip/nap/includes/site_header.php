﻿<?php
$siteNome = site_nome();
$siteEmail = setting('site_email', 'geralnacionalajudaopais@gmail.com');
$siteTel = setting('site_telefone', '935406556');
$siteTelSec = setting('site_telefone_secundario', '');
$siteWhatsapp = preg_replace('/\D+/', '', setting('site_whatsapp', '935406556'));
if ($siteWhatsapp !== '' && !str_starts_with($siteWhatsapp, '244')) {
    $siteWhatsapp = '244' . $siteWhatsapp;
}
$siteMorada = setting('site_morada', 'Sede: Uíge | Luanda: Maianga, Edifício Unitel, 5.º andar | Huíla | Benguela | Mbanza Congo');
$siteFacebook = setting('site_facebook', '#');
$siteInstagram = setting('site_instagram', '#');
$siteLinkedin = setting('site_linkedin', '#') ?: '#';
$pageTitle = $pageTitle ?? $siteNome;
$pageDescription = $pageDescription ?? APP_NAME . ' — ' . site_tagline() . '.';
$currentPage = $currentPage ?? '';
$navServicos = [];
try {
    $navServicos = db()->query("SELECT titulo, slug, icone FROM servicos WHERE status='ativo' ORDER BY ordem, titulo LIMIT 6")->fetchAll();
} catch (Throwable $e) {
    $navServicos = [];
}
$logoUrl = url('/imgs/logo-informatiza.svg?v=4');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?></title>
    <meta name="description" content="<?= e($pageDescription) ?>">
    <link rel="canonical" href="https://informatiza.co.ao">
    <meta name="robots" content="index, follow">
    <link rel="shortcut icon" href="<?= $logoUrl ?>" type="image/svg+xml">
    <link rel="stylesheet" href="<?= url('/css/fonts.css') ?>">
    <link rel="stylesheet" href="<?= url('/css/tailwind.css') ?>">
    <link rel="stylesheet" href="<?= url('/vendor/fontawesome/css/all.min.css') ?>">
    <link rel="stylesheet" href="<?= url('/css/style.css?v=3') ?>">
    <?php nap_swal_styles(); ?>
</head>
<body class="font-poppins text-gray-800 bg-paciolita-branco-suave">
    <div class="bg-ev-dark text-gray-300 text-xs md:text-sm">
        <div class="container mx-auto px-4 flex flex-wrap justify-between items-center py-2">
            <div class="flex items-center gap-4 flex-wrap">
                <a href="tel:<?= e(preg_replace('/\D+/', '', $siteTel)) ?>" class="hover:text-ev-gold"><i class="fas fa-phone-alt text-ev-gold mr-2"></i>+244 <?= e($siteTel) ?></a>
                <?php if ($siteTelSec !== ''): ?>
                <span class="text-gray-500 hidden sm:inline">|</span>
                <span class="text-gray-400 hidden sm:inline" title="Contacto secundário"><i class="fas fa-phone text-gray-500 mr-1"></i><?= e($siteTelSec) ?></span>
                <?php endif; ?>
                <span class="hidden md:inline"><i class="fas fa-envelope text-ev-gold mr-2"></i><?= e($siteEmail) ?></span>
            </div>
            <div class="flex items-center gap-4">
                <span class="hidden md:inline text-ev-gold font-semibold"><i class="fas fa-map-marker-alt mr-2"></i><span data-i18n="five_provinces">5 províncias</span></span>
                <a href="<?= e($siteFacebook ?: '#') ?>" class="hover:text-ev-gold"><i class="fab fa-facebook"></i></a>
                <a href="<?= e($siteInstagram ?: '#') ?>" class="hover:text-ev-gold" target="_blank" rel="noopener"><i class="fab fa-instagram"></i></a>
                <?php if ($siteLinkedin && $siteLinkedin !== '#'): ?>
                <a href="<?= e($siteLinkedin) ?>" class="hover:text-ev-gold"><i class="fab fa-linkedin"></i></a>
                <?php endif; ?>
                <a href="<?= url('/admin/') ?>" class="ml-2 inline-flex items-center gap-1.5 bg-ev-gold/15 hover:bg-ev-gold text-ev-gold hover:text-white border border-ev-gold/40 px-3 py-1 rounded-full font-semibold transition-colors" title="Acesso restrito à administração">
                    <i class="fas fa-lock"></i> <span data-i18n="admin_login">Login Admin</span>
                </a>
                <select id="language-selector" class="language-selector" aria-label="Idioma">
                    <option value="pt">PT</option>
                    <option value="en">EN</option>
                    <option value="fr">FR</option>
                </select>
                <button id="theme-toggle" class="theme-toggle" type="button" aria-label="Modo escuro" title="Modo escuro"><i class="fas fa-moon"></i></button>
            </div>
        </div>
    </div>

    <nav class="sticky top-0 z-50 bg-white shadow-md brand-nav-accent">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-3">
                <div class="flex items-center">
                    <img src="<?= $logoUrl ?>" alt="<?= e($siteNome) ?>" class="w-32 h-14 object-contain mr-3">
                   
                </div>

                <div class="desktop-nav items-center gap-6">
                    <a href="<?= url('/') ?>" class="nav-link <?= $currentPage === 'home' ? 'active' : '' ?>" data-i18n="home">Início</a>
                    <div class="dropdown relative">
                        <a href="<?= site_url('sobre') ?>" class="nav-link <?= in_array($currentPage, ['sobre','missao','valores'], true) ? 'active' : '' ?> flex items-center"><span data-i18n="company">A Empresa</span> <i class="fas fa-chevron-down ml-1 text-xs"></i></a>
                        <div class="dropdown-menu">
                            <a href="<?= site_url('sobre') ?>" data-i18n="about">Quem Somos</a>
                            <a href="<?= site_url('missao') ?>" data-i18n="mission_vision">Missão e Visão</a>
                            <a href="<?= site_url('valores') ?>" data-i18n="values">Nossos Valores</a>
                            <a href="<?= site_url('equipe') ?>" data-i18n="team">Nossa Equipe</a>
                        </div>
                    </div>
                    <div class="dropdown relative">
                        <a href="<?= site_url('services') ?>" class="nav-link <?= $currentPage === 'services' ? 'active' : '' ?> flex items-center"><span data-i18n="services">Serviços</span> <i class="fas fa-chevron-down ml-1 text-xs"></i></a>
                        <div class="dropdown-menu">
                            <?php foreach ($navServicos as $s): ?>
                                <a href="<?= site_url('servico/' . $s['slug']) ?>"><i class="fas <?= e($s['icone']) ?> mr-2 text-ev-gold"></i><?= e($s['titulo']) ?></a>
                            <?php endforeach; ?>
                            <a href="<?= site_url('services') ?>" class="font-semibold text-ev-gold" data-i18n="all_services">Ver todos os serviços →</a>
                        </div>
                    </div>
                    <a href="<?= site_url('news') ?>" class="nav-link <?= $currentPage === 'news' ? 'active' : '' ?>" data-i18n="news">Notícias</a>
                    <a href="<?= site_url('galeria') ?>" class="nav-link <?= $currentPage === 'galeria' ? 'active' : '' ?>" data-i18n="gallery">Galeria</a>
                    <a href="<?= site_url('carreiras') ?>" class="nav-link <?= $currentPage === 'carreiras' ? 'active' : '' ?>" data-i18n="careers">Carreiras</a>
                    <a href="<?= site_url('depoimento') ?>" class="nav-link <?= $currentPage === 'depoimento' ? 'active' : '' ?>" data-i18n="testimonials">Depoimentos</a>
                    <a href="<?= site_url('contato') ?>" class="btn-ev-gold !py-2.5 !px-5 text-sm"><i class="fas fa-headset mr-2"></i><span data-i18n="contact">Contacto</span></a>
                </div>

                <button id="mobile-menu-button" class="text-ev-dark text-2xl p-2" type="button" aria-label="Menu"><i class="fas fa-bars"></i></button>
            </div>
            <div id="mobile-menu" class="hidden pb-4">
                <div class="flex flex-col gap-1">
                    <a href="<?= url('/') ?>" class="font-medium py-2 px-3 rounded hover:bg-gray-50"><i class="fas fa-home mr-3 w-5"></i><span data-i18n="home">Início</span></a>
                    <a href="<?= site_url('sobre') ?>" class="font-medium py-2 px-3 rounded hover:bg-gray-50"><i class="fas fa-info-circle mr-3 w-5"></i><span data-i18n="company">A Empresa</span></a>
                    <a href="<?= site_url('services') ?>" class="font-medium py-2 px-3 rounded hover:bg-gray-50"><i class="fas fa-microchip mr-3 w-5"></i><span data-i18n="services">Serviços</span></a>
                    <a href="<?= site_url('equipe') ?>" class="font-medium py-2 px-3 rounded hover:bg-gray-50"><i class="fas fa-users mr-3 w-5"></i><span data-i18n="team">Nossa Equipe</span></a>
                    <a href="<?= site_url('news') ?>" class="font-medium py-2 px-3 rounded hover:bg-gray-50"><i class="fas fa-newspaper mr-3 w-5"></i><span data-i18n="news">Notícias</span></a>
                    <a href="<?= site_url('galeria') ?>" class="font-medium py-2 px-3 rounded hover:bg-gray-50"><i class="fas fa-images mr-3 w-5"></i><span data-i18n="gallery">Galeria</span></a>
                    <a href="<?= site_url('carreiras') ?>" class="font-medium py-2 px-3 rounded hover:bg-gray-50"><i class="fas fa-briefcase mr-3 w-5"></i><span data-i18n="careers">Carreiras</span></a>
                    <a href="<?= site_url('depoimento') ?>" class="font-medium py-2 px-3 rounded hover:bg-gray-50"><i class="fas fa-quote-left mr-3 w-5"></i><span data-i18n="testimonials">Depoimentos</span></a>
                    <a href="<?= site_url('contato') ?>" class="btn-ev-gold text-center mt-2"><i class="fas fa-headset mr-2"></i><span data-i18n="contact_us">Fale Conosco</span></a>
                </div>
            </div>
        </div>
    </nav>
