<?php
/**
 * Núcleo do módulo de Facturação INFORMATIZA (SU), LDA.
 */

/** Simulação de certificação AGT para testes. Passe a false quando for real. */
function fat_simular_certificacao(): bool
{
    return false;
}

/** Número oficial de licença AGT, quando já atribuído. */
function fat_licenca_agt_exibida(): string
{
    $emp = fat_empresa();
    if ($emp) {
        $svn = fat_agt_normalize_validation_number($emp['software_validation_number'] ?? '');
        if ($svn !== null) {
            return $svn;
        }
    }
    return 'Não atribuído pela AGT';
}

/** Migração única: produto_id_agt duplicado → software_validation_number. */
function fat_agt_migrate_duplicate_cert_fields(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
        $hasLegacy = db()->query("SHOW COLUMNS FROM fat_empresa LIKE 'produto_id_agt'")->fetch();
        if ($hasLegacy) {
            $rows = db()->query('SELECT id, produto_id_agt, software_validation_number FROM fat_empresa')->fetchAll();
            foreach ($rows as $row) {
                $legacy = trim((string) ($row['produto_id_agt'] ?? ''));
                $svn = trim((string) ($row['software_validation_number'] ?? ''));
                if ($legacy !== '' && fat_agt_normalize_validation_number($legacy) !== null && fat_agt_normalize_validation_number($svn) === null) {
                    db()->prepare('UPDATE fat_empresa SET software_validation_number=? WHERE id=?')
                        ->execute([fat_agt_normalize_validation_number($legacy), (int) $row['id']]);
                }
            }
            db()->exec('ALTER TABLE fat_empresa DROP COLUMN produto_id_agt');
        }
    } catch (Throwable $e) {
        // ignore
    }
    $stale = fat_agt_cert_dir() . '/AGT_ProductID.txt';
    if (is_file($stale)) {
        @unlink($stale);
    }
}

function fat_proximo_codigo_item(string $tipo): string
{
    $prefixo = $tipo === 'servico' ? 'SRV' : 'PRO';
    $stmt = db()->prepare("SELECT codigo FROM fat_produtos WHERE codigo LIKE ? ORDER BY id DESC");
    $stmt->execute([$prefixo . '-%']);
    $usados = array_fill_keys(array_map('strval', $stmt->fetchAll(PDO::FETCH_COLUMN)), true);
    $numero = 1;
    do {
        $codigo = sprintf('%s-%04d', $prefixo, $numero++);
    } while (isset($usados[$codigo]));
    return $codigo;
}

function ensure_facturacao_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    fat_agt_migrate_duplicate_cert_fields();

    $sqlFile = __DIR__ . '/../sql/facturacao.sql';
    if (!is_file($sqlFile)) {
        throw new RuntimeException('Ficheiro sql/facturacao.sql em falta.');
    }

    $sql = file_get_contents($sqlFile);
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $statement) {
        if ($statement !== '') {
            db()->exec($statement);
        }
    }

    try {
        db()->exec("ALTER TABLE fat_produtos ADD COLUMN tipo ENUM('produto','servico') NOT NULL DEFAULT 'produto' AFTER codigo");
    } catch (Throwable $e) {
        // A coluna já existe em instalações atualizadas.
    }

    $count = (int) db()->query('SELECT COUNT(*) FROM fat_empresa')->fetchColumn();
    if ($count === 0) {
        db()->prepare('INSERT INTO fat_empresa (nome, nif, morada, cidade, telefone, email) VALUES (?,?,?,?,?,?)')
            ->execute([
                'INFORMATIZA (SU), LDA',
                '',
                'Sede: Uíge | Luanda: Maianga, Edifício Unitel, 5.º andar',
                'Luanda',
                '935406556',
                'geralnacionalajudaopais@gmail.com',
            ]);
    }

    try {
        db()->exec("ALTER TABLE fat_series MODIFY tipo ENUM('FT','FR','NC','ND','FA','OR') NOT NULL");
        db()->exec("UPDATE fat_series SET tipo='FA' WHERE tipo=''");
    } catch (Throwable $e) {
        // ignore
    }

    $ano = (int) date('Y');
    foreach (['FT', 'FR', 'NC', 'ND', 'FA', 'OR'] as $tipo) {
        $chk = db()->prepare('SELECT id FROM fat_series WHERE tipo=? AND serie=? AND ano=?');
        $chk->execute([$tipo, 'A', $ano]);
        if (!$chk->fetch()) {
            db()->prepare('INSERT INTO fat_series (tipo, serie, ano, proximo_numero, ativo) VALUES (?,?,?,1,1)')
                ->execute([$tipo, 'A', $ano]);
        }
    }

    $cli = (int) db()->query("SELECT COUNT(*) FROM fat_clientes WHERE nif='999999999'")->fetchColumn();
    if ($cli === 0) {
        db()->prepare('INSERT INTO fat_clientes (codigo, nome, nif, cidade) VALUES (?,?,?,?)')
            ->execute(['CF', 'Consumidor Final', '999999999', 'Luanda']);
    }

    $pc = (int) db()->query('SELECT COUNT(*) FROM fat_produtos')->fetchColumn();
    if ($pc === 0) {
        $seed = db()->prepare('INSERT INTO fat_produtos (codigo, tipo, descricao, unidade, preco, taxa_iva, ativo) VALUES (?,?,?,?,?,?,1)');
        $seed->execute(['SRV-0001', 'servico', 'Serviço tecnológico', 'UN', 0, 14]);
        $seed->execute(['PRO-0001', 'produto', 'Mesa de jantar', 'UN', 280000, 14]);
        $seed->execute(['PRO-0002', 'produto', 'Peça artesanal decorativa', 'UN', 35000, 14]);
    }

    ensure_facturacao_keys();
    fat_agt_apply_cert_defaults();

    // Compatibilidade: rascunhos sem número definitivo
    try {
        db()->exec('ALTER TABLE fat_documentos MODIFY numero INT UNSIGNED NULL');
    } catch (Throwable $e) {
        // já aplicado
    }

    // Ligar documentos ao caixa
    try {
        $cols = db()->query("SHOW COLUMNS FROM fat_documentos LIKE 'caixa_id'")->fetch();
        if (!$cols) {
            db()->exec('ALTER TABLE fat_documentos ADD COLUMN caixa_id INT UNSIGNED NULL AFTER criado_por');
            db()->exec('ALTER TABLE fat_documentos ADD KEY idx_doc_caixa (caixa_id)');
        }
    } catch (Throwable $e) {
        // ignore
    }

    try {
        db()->exec("UPDATE fat_empresa SET aviso_certificacao=''");
    } catch (Throwable $e) {
        // ignore
    }

    foreach ([
        'produtor_nome VARCHAR(200) NULL AFTER software_versao',
        'produtor_nif VARCHAR(20) NULL AFTER produtor_nome',
        'software_validation_number VARCHAR(80) NULL AFTER software_versao',
        'banco VARCHAR(120) NULL AFTER email',
        'titular_pagamento VARCHAR(200) NULL DEFAULT \'INFORMATIZA (SU), LDA\' AFTER banco',
        'iban VARCHAR(60) NULL AFTER titular_pagamento',
        'numero_conta VARCHAR(60) NULL AFTER iban',
        'saft_tax_accounting_basis CHAR(1) NULL DEFAULT \'F\' AFTER produtor_nif',
        'agt_saft_integrated TINYINT(1) NOT NULL DEFAULT 0 AFTER saft_tax_accounting_basis',
    ] as $column) {
        try {
            $name = strtok($column, ' ');
            $exists = db()->query("SHOW COLUMNS FROM fat_empresa LIKE '" . $name . "'")->fetch();
            if (!$exists) {
                db()->exec('ALTER TABLE fat_empresa ADD COLUMN ' . $column);
            }
        } catch (Throwable $e) {
            // ignore
        }
    }

    try {
        $exists = db()->query("SHOW COLUMNS FROM fat_documentos LIKE 'local_prestacao'")->fetch();
        if (!$exists) {
            db()->exec('ALTER TABLE fat_documentos ADD COLUMN local_prestacao VARCHAR(255) NULL AFTER cliente_morada');
        }
    } catch (Throwable $e) {
        // ignore
    }

    try {
        db()->exec("ALTER TABLE fat_documentos MODIFY tipo ENUM('FT','FR','NC','ND','FA','OR') NOT NULL");
    } catch (Throwable $e) {
        // ignore
    }

    try {
        db()->exec("ALTER TABLE fat_series MODIFY tipo ENUM('FT','FR','NC','ND','FA','OR') NOT NULL");
        db()->exec("UPDATE fat_series SET tipo='FA' WHERE tipo=''");
        $faSeries = db()->prepare('SELECT id FROM fat_series WHERE tipo=? AND serie=? AND ano=?');
        $faSeries->execute(['FA', 'A', (int) date('Y')]);
        if (!$faSeries->fetch()) {
            db()->prepare('INSERT INTO fat_series (tipo, serie, ano, proximo_numero, ativo) VALUES (?,?,?,1,1)')
                ->execute(['FA', 'A', (int) date('Y')]);
        }
    } catch (Throwable $e) {
        // ignore
    }

    foreach ([
        'preco_compra DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER preco',
        'preco_venda DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER preco_compra',
        'data_validade DATE NULL AFTER stock',
    ] as $column) {
        try {
            $name = strtok($column, ' ');
            $exists = db()->query("SHOW COLUMNS FROM fat_produtos LIKE '" . $name . "'")->fetch();
            if (!$exists) db()->exec('ALTER TABLE fat_produtos ADD COLUMN ' . $column);
        } catch (Throwable $e) {
            // ignore
        }
    }
    try {
        db()->exec('UPDATE fat_produtos SET preco_venda=preco WHERE preco_venda=0 AND preco<>0');
    } catch (Throwable $e) {
        // ignore
    }

    if (function_exists('fat_agt_ensure_schema')) {
        fat_agt_ensure_schema();
    }
    if (function_exists('fat_agt_compliance_migrate')) {
        fat_agt_compliance_migrate();
    }

    $done = true;
}

function fat_caixa_aberto(): ?array
{
    $stmt = db()->query("SELECT * FROM fat_caixa WHERE estado='aberto' ORDER BY id DESC LIMIT 1");
    $row = $stmt->fetch();
    return $row ?: null;
}

function fat_require_caixa_aberto(): array
{
    $caixa = fat_caixa_aberto();
    if (!$caixa) {
        flash('error', 'Abra o caixa antes de vender.');
        redirect('/admin/facturacao/caixa.php');
    }
    return $caixa;
}

function fat_abrir_caixa(int $userId, float $fundoInicial, string $obs = ''): array
{
    if (fat_caixa_aberto()) {
        throw new RuntimeException('Já existe um caixa aberto. Feche-o antes de abrir outro.');
    }
    db()->prepare("INSERT INTO fat_caixa (aberto_em, aberto_por, fundo_inicial, observacoes, estado) VALUES (NOW(), ?, ?, ?, 'aberto')")
        ->execute([$userId, $fundoInicial, $obs !== '' ? $obs : null]);
    $id = (int) db()->lastInsertId();
    $s = db()->prepare('SELECT * FROM fat_caixa WHERE id=?');
    $s->execute([$id]);
    return $s->fetch();
}

function fat_fechar_caixa(int $caixaId, int $userId, float $valorContado, string $obs = ''): array
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM fat_caixa WHERE id=? AND estado='aberto' FOR UPDATE");
        $stmt->execute([$caixaId]);
        $caixa = $stmt->fetch();
        if (!$caixa) {
            throw new RuntimeException('Caixa não encontrado ou já fechado.');
        }

        $tot = $pdo->prepare("SELECT COALESCE(SUM(d.total),0)
            FROM fat_documentos d
            WHERE d.caixa_id=? AND d.estado='emitido' AND d.tipo IN ('FT','FR')");
        $tot->execute([$caixaId]);
        $totalVendas = (float) $tot->fetchColumn();

        $num = $pdo->prepare("SELECT COALESCE(SUM(p.valor),0)
            FROM fat_pagamentos p
            INNER JOIN fat_documentos d ON d.id=p.documento_id
            WHERE d.caixa_id=? AND d.estado='emitido' AND p.metodo='numerario'");
        $num->execute([$caixaId]);
        $totalNumerario = (float) $num->fetchColumn();

        $out = $pdo->prepare("SELECT COALESCE(SUM(p.valor),0)
            FROM fat_pagamentos p
            INNER JOIN fat_documentos d ON d.id=p.documento_id
            WHERE d.caixa_id=? AND d.estado='emitido' AND p.metodo<>'numerario'");
        $out->execute([$caixaId]);
        $totalOutros = (float) $out->fetchColumn();

        $esperado = (float) $caixa['fundo_inicial'] + $totalNumerario;
        $diferenca = $valorContado - $esperado;

        $pdo->prepare("UPDATE fat_caixa SET
            fechado_em=NOW(), fechado_por=?, valor_contado=?, total_vendas=?, total_numerario=?, total_outros=?,
            diferenca=?, observacoes=COALESCE(?, observacoes), estado='fechado'
            WHERE id=?")
            ->execute([
                $userId, $valorContado, $totalVendas, $totalNumerario, $totalOutros,
                $diferenca, $obs !== '' ? $obs : null, $caixaId,
            ]);

        $pdo->commit();
        $s = $pdo->prepare('SELECT * FROM fat_caixa WHERE id=?');
        $s->execute([$caixaId]);
        return $s->fetch();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/**
 * Venda rápida no caixa: cria FR, emite, regista pagamento e associa ao caixa.
 */
function fat_vender_no_caixa(array $caixa, int $userId, int $clienteId, array $linhasInput, string $metodo, string $referencia = ''): array
{
    if (($caixa['estado'] ?? '') !== 'aberto') {
        throw new RuntimeException('O caixa não está aberto.');
    }
    if (!$linhasInput) {
        throw new RuntimeException('Adicione produtos à venda.');
    }

    $s = db()->prepare('SELECT * FROM fat_clientes WHERE id=? AND ativo=1');
    $s->execute([$clienteId]);
    $cli = $s->fetch();
    if (!$cli) {
        throw new RuntimeException('Cliente inválido.');
    }

    $linhas = [];
    foreach ($linhasInput as $row) {
        $desc = trim((string) ($row['descricao'] ?? ''));
        if ($desc === '') {
            continue;
        }
        $qty = (float) ($row['quantidade'] ?? 1);
        $preco = (float) ($row['preco_unitario'] ?? 0);
        $taxa = (float) ($row['taxa_iva'] ?? 14);
        if ($qty <= 0) {
            continue;
        }
        $calc = fat_calc_linha($qty, $preco, 0, $taxa);
        $isencao = null;
        if (!empty($row['produto_id'])) {
            $ps = db()->prepare('SELECT codigo_isencao FROM fat_produtos WHERE id=?');
            $ps->execute([(int) $row['produto_id']]);
            $isencao = $ps->fetchColumn() ?: null;
        }
        $linhas[] = [
            'produto_id' => !empty($row['produto_id']) ? (int) $row['produto_id'] : null,
            'codigo' => $row['codigo'] ?? null,
            'descricao' => $desc,
            'quantidade' => $qty,
            'unidade' => $row['unidade'] ?? 'UN',
            'preco_unitario' => $preco,
            'taxa_iva' => $taxa,
            'codigo_isencao' => $isencao,
            'total_liquido' => $calc['total_liquido'],
            'total_iva' => $calc['total_iva'],
            'total_linha' => $calc['total_linha'],
        ];
    }
    if (!$linhas) {
        throw new RuntimeException('Nenhuma linha válida na venda.');
    }

    $metodos = ['numerario', 'transferencia', 'multicaixa', 'outro'];
    if (!in_array($metodo, $metodos, true)) {
        $metodo = 'numerario';
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $sub = array_sum(array_column($linhas, 'total_liquido'));
        $iva = array_sum(array_column($linhas, 'total_iva'));
        $tot = array_sum(array_column($linhas, 'total_linha'));

        $pdo->prepare("INSERT INTO fat_documentos
            (tipo, serie, numero, numero_completo, cliente_id, cliente_nome, cliente_nif, cliente_morada,
             data_documento, data_sistema, estado, subtotal, total_iva, total, criado_por, caixa_id)
            VALUES ('FR','A',NULL,'RASCUNHO',?,?,?,?,?,NOW(),'rascunho',?,?,?,?,?)")
            ->execute([
                $cli['id'], $cli['nome'], $cli['nif'], $cli['morada'],
                date('Y-m-d'), $sub, $iva, $tot, $userId, $caixa['id'],
            ]);
        $docId = (int) $pdo->lastInsertId();

        $ins = $pdo->prepare('INSERT INTO fat_linhas
            (documento_id, produto_id, linha, codigo, descricao, quantidade, unidade, preco_unitario, taxa_iva, codigo_isencao, total_liquido, total_iva, total_linha)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $n = 1;
        foreach ($linhas as $l) {
            $ins->execute([
                $docId, $l['produto_id'], $n++, $l['codigo'], $l['descricao'],
                $l['quantidade'], $l['unidade'], $l['preco_unitario'], $l['taxa_iva'], $l['codigo_isencao'] ?? null,
                $l['total_liquido'], $l['total_iva'], $l['total_linha'],
            ]);
            if ($l['produto_id'] && $l['quantidade'] > 0) {
                $pdo->prepare('UPDATE fat_produtos SET stock = CASE WHEN stock IS NULL THEN NULL ELSE GREATEST(0, stock - ?) END WHERE id=?')
                    ->execute([$l['quantidade'], $l['produto_id']]);
            }
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    $emitido = fat_emitir_documento($docId, $userId);

    db()->prepare('INSERT INTO fat_pagamentos (documento_id, data_pagamento, valor, metodo, referencia) VALUES (?,?,?,?,?)')
        ->execute([$docId, date('Y-m-d'), $emitido['total'], $metodo, $referencia !== '' ? $referencia : null]);

    // Garantir ligação ao caixa (caso emitir não preserve)
    db()->prepare('UPDATE fat_documentos SET caixa_id=? WHERE id=?')->execute([$caixa['id'], $docId]);

    return $emitido;
}

function fat_keys_dir(): string
{
    $dir = __DIR__ . '/../storage/fat_keys';
    if (!is_dir($dir)) {
        mkdir($dir, 0750, true);
    }
    return $dir;
}

/** Anexos para pedido de certificação AGT (chave pública + SAF-T). */
function fat_agt_cert_dir(): string
{
    $dir = __DIR__ . '/../storage/agt_cert';
    if (!is_dir($dir)) {
        mkdir($dir, 0750, true);
    }
    return $dir;
}

function fat_agt_cert_nif_slug(): string
{
    $nif = preg_replace('/\D/', '', (string) (fat_empresa()['nif'] ?? ''));
    return $nif !== '' ? $nif : 'SEM_NIF';
}

/** Nomes fixos exigidos pelo portal AGT nos anexos de certificação. */
function fat_agt_cert_public_filename(): string
{
    return 'Chave Publica.pem';
}

function fat_agt_cert_saft_filename(): string
{
    return 'Ficheiro SAF-T.xml';
}

function fat_agt_cert_public_path(): string
{
    return fat_agt_cert_dir() . '/' . fat_agt_cert_public_filename();
}

function fat_agt_cert_saft_path(): string
{
    return fat_agt_cert_dir() . '/' . fat_agt_cert_saft_filename();
}

/** Copia a chave pública do sistema para o anexo de certificação. */
function fat_agt_preparar_anexo_chave_publica(): string
{
    ensure_facturacao_keys();
    $src = fat_keys_dir() . '/public.pem';
    if (!is_file($src)) {
        throw new RuntimeException('Gere primeiro o par de chaves RSA (Empresa fiscal).');
    }
    $dest = fat_agt_cert_public_path();
    if (!copy($src, $dest)) {
        throw new RuntimeException('Não foi possível preparar o ficheiro da chave pública.');
    }
    $pem = (string) file_get_contents($src);
    $certDir = fat_agt_cert_dir();
    @file_put_contents($certDir . '/ChavePublica.pem', $pem);
    $emp = fat_empresa();
    $prodNif = preg_replace('/\s+/', '', (string) ($emp['produtor_nif'] ?? ''));
    if ($prodNif !== '') {
        @file_put_contents($certDir . '/ChavePublica_' . $prodNif . '.pem', $pem);
    }
    if ($emp) {
        db()->prepare('UPDATE fat_empresa SET chave_publica_path=?, agt_anexo_chave_path=? WHERE id=?')
            ->execute(['storage/fat_keys/public.pem', 'storage/agt_cert/' . fat_agt_cert_public_filename(), $emp['id']]);
    }
    return $dest;
}

function fat_saft_xsd_path(): string
{
    return __DIR__ . '/../storage/saft/SAFTAO1.01_01.xsd';
}

/** Valida XML contra SAFTAO1.01_01.xsd (libxml). */
function fat_saft_validate_against_xsd(string $xml): void
{
    $xsd = fat_saft_xsd_path();
    if (!is_file($xsd)) {
        throw new RuntimeException('XSD SAF-T (AO) em falta: storage/saft/SAFTAO1.01_01.xsd');
    }
    $dom = new DOMDocument();
    if (!@$dom->loadXML($xml)) {
        throw new RuntimeException('XML SAF-T inválido ou mal formado.');
    }
    libxml_use_internal_errors(true);
    $ok = @$dom->schemaValidate($xsd);
    if (!$ok) {
        $parts = [];
        foreach (libxml_get_errors() as $err) {
            $parts[] = trim($err->message) . ' (linha ' . $err->line . ')';
        }
        libxml_clear_errors();
        $summary = $parts !== [] ? implode(' · ', array_slice($parts, 0, 8)) : 'estrutura inválida';
        throw new RuntimeException('SAF-T não conforme XSD AGT 1.01_01: ' . $summary);
    }
    libxml_clear_errors();
}

function fat_agt_validar_saft_xml(string $xml): void
{
    $trim = ltrim($xml);
    if ($trim === '' || ($trim[0] !== '<' && !str_starts_with($trim, '<?xml'))) {
        throw new RuntimeException('O ficheiro não parece XML.');
    }
    $dom = new DOMDocument();
    if (!@$dom->loadXML($xml)) {
        throw new RuntimeException('XML SAF-T inválido ou mal formado.');
    }
    $root = $dom->documentElement;
    if (!$root || strtolower($root->localName) !== 'auditfile') {
        throw new RuntimeException('Raiz esperada: AuditFile (SAF-T AO).');
    }
    $ns = $root->namespaceURI ?? '';
    if ($ns !== '' && !str_contains($ns, 'StandardAuditFile-Tax')) {
        throw new RuntimeException('Namespace SAF-T não reconhecido.');
    }
    fat_saft_validate_against_xsd($xml);
}

function fat_agt_guardar_anexo_saft(string $xml): string
{
    fat_agt_validar_saft_xml($xml);
    $dest = fat_agt_cert_saft_path();
    file_put_contents($dest, $xml);
    $emp = fat_empresa();
    if ($emp) {
        db()->prepare('UPDATE fat_empresa SET agt_anexo_saft_path=? WHERE id=?')
            ->execute(['storage/agt_cert/' . fat_agt_cert_saft_filename(), $emp['id']]);
    }
    return $dest;
}

function fat_openssl_bootstrap(): void
{
    if (getenv('OPENSSL_CONF')) {
        return;
    }
    $candidates = [
        'C:\\xampp\\php\\extras\\ssl\\openssl.cnf',
        'C:\\xampp\\apache\\bin\\openssl.cnf',
        dirname(PHP_BINARY) . DIRECTORY_SEPARATOR . 'extras' . DIRECTORY_SEPARATOR . 'ssl' . DIRECTORY_SEPARATOR . 'openssl.cnf',
    ];
    foreach ($candidates as $cnf) {
        if (is_file($cnf)) {
            putenv('OPENSSL_CONF=' . $cnf);
            break;
        }
    }
}

function ensure_facturacao_keys(): void
{
    $dir = fat_keys_dir();
    $priv = $dir . '/private.pem';
    $pub = $dir . '/public.pem';

    if (is_file($priv) && is_file($pub)) {
        $emp = fat_empresa();
        if ($emp && empty($emp['chave_privada_path'])) {
            db()->prepare('UPDATE fat_empresa SET chave_privada_path=?, chave_publica_path=? WHERE id=?')
                ->execute(['storage/fat_keys/private.pem', 'storage/fat_keys/public.pem', $emp['id']]);
        }
        return;
    }

    fat_openssl_bootstrap();

    // SAF-T (AO): assinatura RSA até 172 caracteres Base64 → RSA 1024 bits.
    $config = [
        'private_key_bits' => 1024,
        'private_key_type' => OPENSSL_KEYTYPE_RSA,
    ];
    $opensslCnf = getenv('OPENSSL_CONF');
    if ($opensslCnf && is_file($opensslCnf)) {
        $config['config'] = $opensslCnf;
    }

    $res = openssl_pkey_new($config);
    if ($res === false) {
        $res = openssl_pkey_new([
            'private_key_bits' => 1024,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ]);
    }
    if ($res === false) {
        return;
    }
    openssl_pkey_export($res, $privateKey, null, $config);
    if ($privateKey === '' || $privateKey === null) {
        openssl_pkey_export($res, $privateKey);
    }
    $details = openssl_pkey_get_details($res);
    $publicKey = $details['key'] ?? '';
    if ($privateKey === '' || $publicKey === '') {
        return;
    }

    file_put_contents($priv, $privateKey);
    file_put_contents($pub, $publicKey);
    @chmod($priv, 0600);

    $emp = fat_empresa();
    if ($emp) {
        db()->prepare('UPDATE fat_empresa SET chave_privada_path=?, chave_publica_path=? WHERE id=?')
            ->execute(['storage/fat_keys/private.pem', 'storage/fat_keys/public.pem', $emp['id']]);
    }
}

function fat_empresa(): ?array
{
    return db()->query('SELECT * FROM fat_empresa ORDER BY id ASC LIMIT 1')->fetch() ?: null;
}

function fat_tipo_label(string $tipo): string
{
    return match ($tipo) {
        'FT' => 'Factura',
        'FR' => 'Factura-Recibo',
        'NC' => 'Nota de Crédito',
        'ND' => 'Nota de Débito',
        'FA' => 'Factura de Adiantamento',
        'OR' => 'Proposta orçamental (OR)',
        'GT' => 'Guia de transporte',
        'GR' => 'Guia de remessa',
        'GD' => 'Guia / nota de devolução',
        'GA' => 'Guia de activos fixos',
        'RC' => 'Recibo',
        'AR' => 'Aviso de cobrança / recibo',
        default => $tipo,
    };
}

function fat_format_money(float|string $v): string
{
    return number_format((float) $v, 2, ',', '.') . ' Kz';
}

function fat_calc_linha(float $qty, float $preco, float $descPct, float $taxaIva): array
{
    $liquido = $qty * $preco * (1 - $descPct / 100);
    $iva = $liquido * ($taxaIva / 100);
    return [
        'total_liquido' => round($liquido, 2),
        'total_iva' => round($iva, 2),
        'total_linha' => round($liquido + $iva, 2),
    ];
}

/**
 * Aloca o próximo número de documento (transacção).
 * @return array{serie:string,numero:int,numero_completo:string}
 */
function fat_next_number(string $tipo, ?string $serie = 'A', ?int $ano = null): array
{
    $serie = $serie ?: 'A';
    $ano = $ano ?: (int) date('Y');
    $pdo = db();
    $ownTx = !$pdo->inTransaction();
    if ($ownTx) {
        $pdo->beginTransaction();
    }
    try {
        $stmt = $pdo->prepare('SELECT id, proximo_numero, descontinuada FROM fat_series WHERE tipo=? AND serie=? AND ano=? AND ativo=1 FOR UPDATE');
        $stmt->execute([$tipo, $serie, $ano]);
        $row = $stmt->fetch();
        if ($row && !empty($row['descontinuada']) && function_exists('fat_agt_compliance_migrate')) {
            throw new RuntimeException('Série descontinuada — não pode emitir (regra AGT).');
        }
        if (!$row) {
            $pdo->prepare('INSERT INTO fat_series (tipo, serie, ano, proximo_numero, ativo) VALUES (?,?,?,1,1)')
                ->execute([$tipo, $serie, $ano]);
            $numero = 1;
            $id = (int) $pdo->lastInsertId();
        } else {
            $numero = (int) $row['proximo_numero'];
            $id = (int) $row['id'];
        }
        $pdo->prepare('UPDATE fat_series SET proximo_numero = proximo_numero + 1 WHERE id=?')->execute([$id]);
        if ($ownTx) {
            $pdo->commit();
        }
        // SAF-T (AO): TIPO <série>/<nº sequencial> — sem ano no InvoiceNo (ex.: FT A/1).
        $completo = sprintf('%s %s/%d', $tipo, $serie, $numero);
        return ['serie' => $serie, 'numero' => $numero, 'numero_completo' => $completo];
    } catch (Throwable $e) {
        if ($ownTx && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function fat_saft_previous_hash_for_signing(?string $previousHash): string
{
    $previousHash = trim((string) $previousHash);
    return ($previousHash === '' || $previousHash === '0') ? '' : $previousHash;
}

function fat_previous_hash(string $tipo, string $serie): string
{
    $stmt = db()->prepare("SELECT hash FROM fat_documentos WHERE tipo=? AND serie=? AND estado IN ('emitido','anulado') AND hash IS NOT NULL ORDER BY numero DESC LIMIT 1");
    $stmt->execute([$tipo, $serie]);
    $hash = $stmt->fetchColumn();
    return $hash ? fat_saft_hash_field((string) $hash) : '';
}

/**
 * Assina o documento com RSA (SHA-1) conforme cadeia típica AGT/SAF-T.
 * Campos: InvoiceDate;SystemEntryDate;InvoiceNo;GrossTotal;PreviousHash
 */
function fat_sign_document(string $invoiceDate, string $systemEntryDate, string $invoiceNo, float $grossTotal, string $previousHash): array
{
    fat_openssl_bootstrap();
    $previousHash = fat_saft_previous_hash_for_signing($previousHash);
    $gross = fat_saft_gross_total_for_sign($grossTotal);
    $payload = $invoiceDate . ';' . $systemEntryDate . ';' . $invoiceNo . ';' . $gross . ';' . $previousHash;

    $privPath = fat_keys_dir() . '/private.pem';
    if (!is_file($privPath)) {
        ensure_facturacao_keys();
    }
    $privateKey = openssl_pkey_get_private((string) file_get_contents($privPath));
    if ($privateKey === false) {
        throw new RuntimeException('Chave privada de facturação indisponível (OpenSSL).');
    }

    $signature = '';
    if (!openssl_sign($payload, $signature, $privateKey, OPENSSL_ALGO_SHA1)) {
        throw new RuntimeException('Falha ao assinar o documento.');
    }
    $hash = fat_saft_hash_field(base64_encode($signature));
    $pubPath = fat_keys_dir() . '/public.pem';
    if (!is_file($pubPath) || openssl_verify($payload, $signature, (string) file_get_contents($pubPath), OPENSSL_ALGO_SHA1) !== 1) {
        throw new RuntimeException('A assinatura electrónica não pôde ser confirmada pela chave pública.');
    }
    $control = fat_saft_hash_control_value();

    return [
        'hash' => $hash,
        'hash_anterior' => $previousHash === '' ? '' : $previousHash,
        'hash_control' => $control,
        'payload' => $payload,
    ];
}

function fat_auditar_documento(int $docId, string $acao, ?int $userId, ?string $estadoAnterior, ?string $estadoNovo, ?string $hash): void
{
    db()->prepare('INSERT INTO fat_auditoria (documento_id, acao, utilizador_id, estado_anterior, estado_novo, dados_hash) VALUES (?,?,?,?,?,?)')
        ->execute([$docId, $acao, $userId, $estadoAnterior, $estadoNovo, $hash]);
}

function fat_validar_configuracao_eletronica(): void
{
    $emp = fat_empresa();
    if (!$emp || trim((string) $emp['nif']) === '') {
        throw new RuntimeException('Configure o NIF da empresa emitente antes de emitir documentos.');
    }
    if (trim((string) ($emp['produtor_nome'] ?? '')) === '' || trim((string) ($emp['produtor_nif'] ?? '')) === '') {
        throw new RuntimeException('Configure o nome e o NIF do produtor do software antes de emitir documentos.');
    }
    if (fat_agt_normalize_validation_number($emp['software_validation_number'] ?? '') === null) {
        throw new RuntimeException('Configure o número de validação AGT (Modelo 08, formato NNN/AGT/AAAA) antes de emitir documentos.');
    }
    if (!preg_match('/^[^\/]+\/[^\/]+$/', fat_saft_product_id($emp))) {
        throw new RuntimeException('Configure o Product ID do software (Modelo 08) antes de emitir documentos.');
    }
    if (!is_file(fat_keys_dir() . '/private.pem') || !is_file(fat_keys_dir() . '/public.pem')) {
        throw new RuntimeException('As chaves de assinatura electrónica não estão disponíveis.');
    }
}

/**
 * Emite (fecha) um documento em rascunho: numera, assina, bloqueia edição.
 */
function fat_emitir_documento(int $docId, int $userId, ?string $confirmClockOk = null): array
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT * FROM fat_documentos WHERE id=? FOR UPDATE');
        $stmt->execute([$docId]);
        $doc = $stmt->fetch();
        if (!$doc) {
            throw new RuntimeException('Documento não encontrado.');
        }
        if ($doc['estado'] !== 'rascunho') {
            throw new RuntimeException('Só rascunhos podem ser emitidos.');
        }
        $tipoDoc = (string) ($doc['tipo'] ?? '');
        $isRecibo = function_exists('fat_agt_is_receipt_type') && fat_agt_is_receipt_type($tipoDoc);
        // Proforma comercial; recibos RC/AR não usam assinatura RSA na cadeia de vendas.
        if ($tipoDoc !== 'OR' && !$isRecibo) {
            fat_validar_configuracao_eletronica();
        }

        $linStmt = $pdo->prepare('SELECT * FROM fat_linhas WHERE documento_id=? ORDER BY linha');
        $linStmt->execute([$docId]);
        $linhasRows = $linStmt->fetchAll();
        if ($linhasRows === []) {
            throw new RuntimeException('Adicione pelo menos uma linha antes de emitir.');
        }
        if ($confirmClockOk === null) {
            $confirmClockOk = $_POST['confirm_clock_ok'] ?? $_GET['confirm_clock_ok'] ?? null;
        }
        if (function_exists('fat_agt_validar_pre_emissao')) {
            fat_agt_validar_pre_emissao($doc, $linhasRows, is_string($confirmClockOk) ? $confirmClockOk : null);
        }

        $serieEmit = function_exists('fat_agt_resolve_serie_emissao')
            ? fat_agt_resolve_serie_emissao($doc)
            : ($doc['serie'] ?: 'A');
        $num = fat_next_number($doc['tipo'], $serieEmit, (int) date('Y', strtotime($doc['data_documento'])));
        $dataDoc = $doc['data_documento'];
        $systemEntry = date('Y-m-d H:i:s');
        $sysEntry = date('Y-m-d\TH:i:s', strtotime($systemEntry));
        $prev = fat_previous_hash($doc['tipo'], $num['serie']);
        if (function_exists('fat_agt_emit_signatures')) {
            $sign = fat_agt_emit_signatures($doc, $num, $dataDoc, $sysEntry, $prev);
        } else {
            $sign = fat_sign_document($dataDoc, $sysEntry, $num['numero_completo'], (float) $doc['total'], $prev);
        }

        $taxPoint = function_exists('fat_agt_tax_point_date') ? fat_agt_tax_point_date($doc) : $dataDoc;
        $formacao = function_exists('fat_agt_modo_formacao_ativo') && fat_agt_modo_formacao_ativo() ? 1 : 0;
        $movStartSql = '';
        $movParams = [];
        if (function_exists('fat_agt_is_movement_type') && fat_agt_is_movement_type($tipoDoc) && empty($doc['movement_start'])) {
            $movStartSql = ', movement_start=?';
            $movParams[] = $systemEntry;
        }
        $upd = $pdo->prepare("UPDATE fat_documentos SET
            serie=?, numero=?, numero_completo=?, data_sistema=?, tax_point_date=?, modo_formacao=?, estado='emitido',
            hash=?, hash_anterior=?, hash_control=?, criado_por=?" . $movStartSql . '
            WHERE id=?');
        $execParams = [
            $num['serie'],
            $num['numero'],
            $num['numero_completo'],
            $systemEntry,
            $taxPoint,
            $formacao,
            $sign['hash'],
            $sign['hash_anterior'],
            $sign['hash_control'],
            $userId,
        ];
        foreach ($movParams as $mp) {
            $execParams[] = $mp;
        }
        $execParams[] = $docId;
        $upd->execute($execParams);

        if ($isRecibo && !empty($doc['documento_origem_id'])) {
            $metodo = (string) ($doc['meio_pagamento'] ?? 'numerario');
            if (!in_array($metodo, ['numerario', 'multicaixa', 'transferencia', 'cartao'], true)) {
                $metodo = 'numerario';
            }
            $pdo->prepare('INSERT INTO fat_pagamentos (documento_id, data_pagamento, valor, metodo) VALUES (?,?,?,?)')
                ->execute([(int) $doc['documento_origem_id'], $dataDoc, (float) $doc['total'], $metodo]);
        }

        fat_auditar_documento($docId, 'emissao', $userId, 'rascunho', 'emitido', $sign['hash']);
        $pdo->commit();
        $fresh = $pdo->prepare('SELECT * FROM fat_documentos WHERE id=?');
        $fresh->execute([$docId]);
        $emitido = $fresh->fetch();
        $skipFeAuto = in_array($emitido['tipo'] ?? '', ['OR', 'GT', 'GR', 'GD', 'GA'], true);
        if ($emitido && !$skipFeAuto && function_exists('fat_agt_after_emit')) {
            fat_agt_after_emit($docId, $userId);
            $fresh->execute([$docId]);
            $emitido = $fresh->fetch();
        }
        if ($emitido && function_exists('cont_post_venda') && function_exists('fat_agt_is_sales_type') && fat_agt_is_sales_type((string) $emitido['tipo'])) {
            try {
                cont_post_venda($docId, $userId);
            } catch (Throwable $e) {
                // não bloqueia emissão fiscal
            }
        }
        return $emitido;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function fat_recalc_documento(int $docId): void
{
    $sum = db()->prepare('SELECT COALESCE(SUM(total_liquido),0), COALESCE(SUM(total_iva),0), COALESCE(SUM(total_linha),0) FROM fat_linhas WHERE documento_id=?');
    $sum->execute([$docId]);
    [$sub, $iva, $tot] = $sum->fetch(PDO::FETCH_NUM);
    db()->prepare('UPDATE fat_documentos SET subtotal=?, total_iva=?, total=? WHERE id=?')
        ->execute([$sub, $iva, $tot, $docId]);
}

function fat_assert_rascunho(array $doc): void
{
    if (($doc['estado'] ?? '') !== 'rascunho') {
        throw new RuntimeException('Documentos emitidos não podem ser alterados nem eliminados.');
    }
}

/** Número de documento conforme XSD SAF-T (AO), ex.: FT A/1 */
function fat_saft_canonical_invoice_no(array $doc): string
{
    return sprintf('%s %s/%d', $doc['tipo'], $doc['serie'] ?: 'A', (int) $doc['numero']);
}

/**
 * Actualiza numero_completo e recalcula hashes (por tipo/série, ordem crescente de número).
 * Necessário após corrigir o formato InvoiceNo (remover ano intermédio).
 */
function fat_rebuild_saft_document_chain(?string $from = null, ?string $to = null): int
{
    $sql = "SELECT * FROM fat_documentos WHERE estado IN ('emitido','anulado') AND tipo <> 'OR' AND hash IS NOT NULL";
    $params = [];
    if ($from !== null && $to !== null) {
        $sql .= ' AND data_documento BETWEEN ? AND ?';
        $params = [$from, $to];
    }
    $sql .= ' ORDER BY tipo, serie, numero, id';
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    $count = 0;
    $prevBySeries = [];
    $upd = db()->prepare('UPDATE fat_documentos SET numero_completo=?, hash=?, hash_anterior=?, hash_control=? WHERE id=?');
    foreach ($rows as $doc) {
        $key = $doc['tipo'] . '|' . ($doc['serie'] ?: 'A');
        $prev = $prevBySeries[$key] ?? '';
        $invoiceNo = fat_saft_canonical_invoice_no($doc);
        $sysEntry = date('Y-m-d\TH:i:s', strtotime($doc['data_sistema'] ?: $doc['criado_em']));
        $sign = fat_sign_document($doc['data_documento'], $sysEntry, $invoiceNo, (float) $doc['total'], $prev);
        $upd->execute([$invoiceNo, $sign['hash'], $sign['hash_anterior'], $sign['hash_control'], $doc['id']]);
        $prevBySeries[$key] = $sign['hash'];
        $count++;
    }
    return $count;
}

/** Hash SAF-T (AO): máximo 172 caracteres (assinatura RSA em Base64). */
function fat_saft_hash_field(?string $hash): string
{
    $hash = trim((string) $hash);
    if ($hash === '') {
        return '0';
    }
    return substr($hash, 0, 172);
}

/**
 * ProductID SAF-T (AO) — Modelo 08 campo 4 / Lei 312/18: «designação comercial» = App/Produtor.
 * Deve coincidir com o registo no portal (teste ou certificação).
 */
function fat_saft_product_id_from_empresa(array $emp): string
{
    $app = trim((string) ($emp['software_nome'] ?? ''));
    $prod = trim((string) ($emp['produtor_nome'] ?? ''));
    if ($app === '' || $prod === '') {
        throw new RuntimeException('Configure software_nome e produtor_nome na empresa fiscal (Modelo 08).');
    }
    return $app . '/' . $prod;
}

function fat_saft_product_id(array $emp): string
{
    $id = trim((string) ($emp['agt_software_product_id'] ?? ''));
    if ($id !== '' && str_contains($id, '/')) {
        [$app, $prod] = explode('/', $id, 2);

        return trim($app) . '/' . trim($prod);
    }

    return fat_saft_product_id_from_empresa($emp);
}

/** Preenche Product ID vazio a partir de software_nome/produtor_nome. */
function fat_sync_modelo8_product_id(?array $emp = null): void
{
    $emp = $emp ?? fat_empresa();
    if (!$emp || trim((string) ($emp['agt_software_product_id'] ?? '')) !== '') {
        return;
    }
    $pid = fat_saft_product_id_from_empresa($emp);
    db()->prepare('UPDATE fat_empresa SET agt_software_product_id=? WHERE id=?')
        ->execute([$pid, (int) $emp['id']]);
}

/**
 * Grava configuração única software + SAF-T + certificação (Modelo 08).
 *
 * @param array{software_nome?:string,software_versao?:string,produtor_nome?:string,produtor_nif?:string,agt_software_product_id?:string,software_validation_number?:string,saft_tax_accounting_basis?:string,agt_saft_integrated?:int,agt_signature_version?:int} $data
 */
function fat_agt_save_software_config(int $empresaId, array $data, bool $regenerarSaft = false): void
{
    $svn = trim((string) ($data['software_validation_number'] ?? ''));
    if ($svn !== '' && fat_agt_normalize_validation_number($svn) === null) {
        throw new RuntimeException('Número de validação AGT inválido. Use NNN/AGT/AAAA ou 000/AGT/AAAA (teste).');
    }
    $pid = trim((string) ($data['agt_software_product_id'] ?? ''));
    if ($pid !== '' && !preg_match('/^[^\/]+\/[^\/]+$/', $pid)) {
        throw new RuntimeException('Product ID inválido. Formato: NomePrograma/NomeProdutor.');
    }
    $basis = strtoupper(trim((string) ($data['saft_tax_accounting_basis'] ?? 'F')));
    if (!in_array($basis, ['F', 'I', 'C'], true)) {
        $basis = 'F';
    }
    $integrated = !empty($data['agt_saft_integrated']) ? 1 : 0;
    if (in_array($basis, ['I', 'C'], true)) {
        $integrated = 1;
    }

    db()->prepare(
        'UPDATE fat_empresa SET
            software_nome=COALESCE(NULLIF(?,\'\'), software_nome),
            software_versao=COALESCE(NULLIF(?,\'\'), software_versao),
            produtor_nome=COALESCE(NULLIF(?,\'\'), produtor_nome),
            produtor_nif=COALESCE(NULLIF(?,\'\'), produtor_nif),
            agt_software_product_id=?,
            software_validation_number=?,
            saft_tax_accounting_basis=?,
            agt_saft_integrated=?,
            agt_signature_version=?
         WHERE id=?'
    )->execute([
        trim((string) ($data['software_nome'] ?? '')),
        trim((string) ($data['software_versao'] ?? '')),
        trim((string) ($data['produtor_nome'] ?? '')),
        preg_replace('/\s+/', '', trim((string) ($data['produtor_nif'] ?? ''))),
        $pid !== '' ? $pid : null,
        $svn !== '' ? $svn : null,
        $basis,
        $integrated,
        max(1, (int) ($data['agt_signature_version'] ?? 1)),
        $empresaId,
    ]);

    fat_sync_modelo8_product_id(fat_empresa());

    if ($regenerarSaft && fat_agt_normalize_validation_number($svn) !== null) {
        fat_rebuild_saft_document_chain();
        $xml = fat_export_saft_ao(date('Y-01-01'), date('Y-m-d'));
        fat_agt_guardar_anexo_saft($xml);
        fat_agt_preparar_anexo_chave_publica();
    }
}

function fat_saft_gross_total_for_sign(float $total): string
{
    return number_format(round($total, 2), 2, '.', '');
}

/**
 * HashControl SAF-T (AO): número certificação + «.» + versão da chave (ex.: 456.1).
 * @see Circular AGT / Modelo 08 — não usar os 4 caracteres do Hash.
 */
function fat_saft_hash_control_value(?array $emp = null): string
{
    $emp = $emp ?? fat_empresa();
    if (!$emp) {
        return '0';
    }
    $val = fat_saft_validation_number($emp);
    if ($val === '0') {
        return '0';
    }
    if (preg_match('/^(\d+)\/AGT\/\d{4}$/', $val, $m)) {
        $version = max(1, (int) ($emp['agt_signature_version'] ?? 1));

        return $m[1] . '.' . $version;
    }

    return '0';
}

function fat_saft_hash_control_export(array $emp, ?string $storedControl): string
{
    $stored = trim((string) $storedControl);
    if ($stored !== '' && $stored !== '0') {
        return $stored;
    }

    return fat_saft_hash_control_value($emp);
}

/** Quatro caracteres do Hash para impressão no documento (posições 1, 11, 21, 31). */
function fat_hash_impressao_quatro_caracteres(?string $hash): string
{
    $hash = fat_saft_hash_field($hash);
    if ($hash === '0' || strlen($hash) < 31) {
        return substr(preg_replace('/[^A-Za-z0-9]/', '', $hash) ?: 'XXXX', 0, 4);
    }
    return $hash[0] . $hash[10] . $hash[20] . $hash[30];
}

/**
 * Legenda obrigatória na impressão (Decreto AGT, Anexo I, n.º 6 al. b/c).
 * Ex.: PbRc-Processado por programa validado n.º 000/AGT/2026
 */
function fat_legenda_programa_validado_agt(?string $hash, string $tipoDocumento, ?array $emp = null): string
{
    $emp = $emp ?? fat_empresa();
    $cert = fat_saft_validation_number($emp);
    if ($cert === '0' || $cert === '') {
        $cert = '000/AGT/' . date('Y');
    }
    $recibo = in_array(strtoupper($tipoDocumento), ['OR', 'RC', 'RG', 'AR'], true);
    $hashOk = trim((string) $hash) !== '' && fat_saft_hash_field($hash) !== '0';
    if (!$recibo && $hashOk) {
        return fat_hash_impressao_quatro_caracteres($hash) . '-Processado por programa validado n.º ' . $cert;
    }

    return 'Emitido por programa validado n.º ' . $cert;
}

/** Garante Product ID e número de validação AGT na ficha da empresa (SAF-T + API). */
function fat_agt_apply_cert_defaults(?array $emp = null): void
{
    fat_agt_migrate_duplicate_cert_fields();
    fat_sync_modelo8_product_id($emp);
}

/** Formato AGT: NNN/AGT/AAAA (ex.: atribuído no dossier de certificação). */
function fat_agt_normalize_validation_number(?string $n): ?string
{
    $n = trim((string) $n);
    if ($n === '' || strcasecmp($n, 'PENDENTE_AGT') === 0 || $n === '0') {
        return null;
    }
    if (!preg_match('/^\d+\/AGT\/\d{4}$/', $n)) {
        return null;
    }
    return $n;
}

function fat_saft_validation_number(array $emp): string
{
    return fat_agt_normalize_validation_number($emp['software_validation_number'] ?? '') ?? '0';
}

/** F facturação · I integrada com contabilidade (portal AGT). */
function fat_saft_tax_accounting_basis(array $emp): string
{
    $b = strtoupper(trim((string) ($emp['saft_tax_accounting_basis'] ?? 'F')));
    return in_array($b, ['F', 'I', 'C', 'P', 'R', 'A', 'Q', 'S', 'E'], true) ? $b : 'F';
}

function fat_saft_basis_is_accounting_file(string $basis): bool
{
    return in_array($basis, ['I', 'C'], true);
}

/** Movimentos contabilísticos no SAF-T — basis I (integrado) ou C (contabilidade). */
function fat_saft_needs_integrated_ledger(array $emp): bool
{
    $basis = fat_saft_tax_accounting_basis($emp);
    if ($basis === 'C') {
        return true;
    }
    if ($basis === 'I') {
        return !empty($emp['agt_saft_integrated']);
    }

    return false;
}

function fat_saft_tax_entity_value(array $emp): string
{
    $cod = trim((string) ($emp['estabelecimento_codigo'] ?? ''));
    if ($cod !== '') {
        return $cod;
    }

    return fat_saft_basis_is_accounting_file(fat_saft_tax_accounting_basis($emp)) ? 'Sede' : 'Global';
}

function fat_saft_transaction_id(string $docDate, string $journalId, string $docArchival): string
{
    return $docDate . ' ' . $journalId . ' ' . $docArchival;
}

function fat_saft_append_gl_account(
    DOMDocument $xml,
    DOMElement $glRoot,
    string $accountId,
    string $description,
    string $groupingCategory,
    ?string $groupingCode = null
): void {
    $acc = $xml->createElement('Account');
    $glRoot->appendChild($acc);
    $acc->appendChild($xml->createElement('AccountID', $accountId));
    $acc->appendChild($xml->createElement('AccountDescription', $description));
    foreach (['OpeningDebitBalance', 'OpeningCreditBalance', 'ClosingDebitBalance', 'ClosingCreditBalance'] as $bal) {
        $acc->appendChild($xml->createElement($bal, '0.00'));
    }
    $acc->appendChild($xml->createElement('GroupingCategory', $groupingCategory));
    if ($groupingCode !== null && $groupingCode !== '') {
        $acc->appendChild($xml->createElement('GroupingCode', $groupingCode));
    }
}

function fat_saft_prepend_standard_chart(DOMDocument $xml, DOMElement $master): void
{
    $glRoot = $xml->createElement('GeneralLedgerAccounts');
    if ($master->firstChild) {
        $master->insertBefore($glRoot, $master->firstChild);
    } else {
        $master->appendChild($glRoot);
    }
    fat_saft_append_gl_account($xml, $glRoot, '21', 'Clientes', 'GR');
    fat_saft_append_gl_account($xml, $glRoot, '211', 'Clientes corrente', 'GA', '21');
    fat_saft_append_gl_account($xml, $glRoot, '2111', 'Clientes geral', 'GM', '211');
    fat_saft_append_gl_account($xml, $glRoot, '71', 'Vendas', 'GR');
    fat_saft_append_gl_account($xml, $glRoot, '711', 'Vendas mercadorias', 'GM', '71');
    fat_saft_append_gl_account($xml, $glRoot, '243', 'IVA', 'GR');
    fat_saft_append_gl_account($xml, $glRoot, '2432', 'IVA liquidado', 'GM', '243');
}

function fat_saft_append_placeholder_supplier(DOMDocument $xml, DOMElement $master): void
{
    $supplier = $xml->createElement('Supplier');
    $master->appendChild($supplier);
    $supplier->appendChild($xml->createElement('SupplierID', '9001'));
    $supplier->appendChild($xml->createElement('AccountID', '2112'));
    $supplier->appendChild($xml->createElement('SupplierTaxID', '999999998'));
    $supplier->appendChild($xml->createElement('CompanyName', 'Fornecedor diversos (SAF-T)'));
    $address = $xml->createElement('BillingAddress');
    $supplier->appendChild($address);
    $address->appendChild($xml->createElement('AddressDetail', 'Desconhecido'));
    $address->appendChild($xml->createElement('City', 'Luanda'));
    $address->appendChild($xml->createElement('Country', 'AO'));
    $supplier->appendChild($xml->createElement('SelfBillingIndicator', '0'));
}

/**
 * @param array<int, array{transaction_id: string, customer_id: int, gross: float, net: float, tax: float, system_entry: string, invoice_no: string, invoice_date: string, period: int, is_credit: bool}> $plan
 */
function fat_saft_append_general_ledger_entries(DOMDocument $xml, DOMElement $root, array $plan): void
{
    if ($plan === []) {
        return;
    }
    $gl = $xml->createElement('GeneralLedgerEntries');
    $root->appendChild($gl);
    $totalDebit = 0.0;
    $totalCredit = 0.0;
    foreach ($plan as $row) {
        $totalDebit += $row['gross'];
        $totalCredit += $row['gross'];
    }
    $gl->appendChild($xml->createElement('NumberOfEntries', (string) count($plan)));
    $gl->appendChild($xml->createElement('TotalDebit', number_format($totalDebit, 2, '.', '')));
    $gl->appendChild($xml->createElement('TotalCredit', number_format($totalCredit, 2, '.', '')));

    $journal = $xml->createElement('Journal');
    $gl->appendChild($journal);
    $journal->appendChild($xml->createElement('JournalID', 'VND'));
    $journal->appendChild($xml->createElement('Description', 'Vendas'));

    $record = 0;
    foreach ($plan as $row) {
        $tx = $xml->createElement('Transaction');
        $journal->appendChild($tx);
        $tx->appendChild($xml->createElement('TransactionID', $row['transaction_id']));
        $tx->appendChild($xml->createElement('Period', (string) $row['period']));
        $tx->appendChild($xml->createElement('TransactionDate', $row['invoice_date']));
        $tx->appendChild($xml->createElement('SourceID', '1'));
        $tx->appendChild($xml->createElement('Description', $row['invoice_no']));
        $arch = preg_replace('/\s+/', '-', $row['invoice_no']);
        $arch = substr(preg_replace('/[^A-Za-z0-9\-\/]/', '', $arch), 0, 20);
        if ($arch === '') {
            $arch = (string) (++$record);
        }
        $tx->appendChild($xml->createElement('DocArchivalNumber', $arch));
        $tx->appendChild($xml->createElement('TransactionType', 'N'));
        $tx->appendChild($xml->createElement('GLPostingDate', $row['invoice_date']));
        $tx->appendChild($xml->createElement('CustomerID', (string) $row['customer_id']));

        $lines = $xml->createElement('Lines');
        $tx->appendChild($lines);
        $gross = number_format($row['gross'], 2, '.', '');
        $net = number_format($row['net'], 2, '.', '');
        $tax = number_format($row['tax'], 2, '.', '');
        $sys = $row['system_entry'];

        if (!$row['is_credit']) {
            $dl = $xml->createElement('DebitLine');
            $lines->appendChild($dl);
            $dl->appendChild($xml->createElement('RecordID', '1'));
            $dl->appendChild($xml->createElement('AccountID', '2111'));
            $dl->appendChild($xml->createElement('SystemEntryDate', $sys));
            $dl->appendChild($xml->createElement('Description', $row['invoice_no']));
            $dl->appendChild($xml->createElement('DebitAmount', $gross));

            $cl = $xml->createElement('CreditLine');
            $lines->appendChild($cl);
            $cl->appendChild($xml->createElement('RecordID', '2'));
            $cl->appendChild($xml->createElement('AccountID', '711'));
            $cl->appendChild($xml->createElement('SystemEntryDate', $sys));
            $cl->appendChild($xml->createElement('Description', $row['invoice_no']));
            $cl->appendChild($xml->createElement('CreditAmount', $net));

            if ((float) $row['tax'] > 0) {
                $cl2 = $xml->createElement('CreditLine');
                $lines->appendChild($cl2);
                $cl2->appendChild($xml->createElement('RecordID', '3'));
                $cl2->appendChild($xml->createElement('AccountID', '2432'));
                $cl2->appendChild($xml->createElement('SystemEntryDate', $sys));
                $cl2->appendChild($xml->createElement('Description', 'IVA ' . $row['invoice_no']));
                $cl2->appendChild($xml->createElement('CreditAmount', $tax));
            }
        } else {
            $cl = $xml->createElement('CreditLine');
            $lines->appendChild($cl);
            $cl->appendChild($xml->createElement('RecordID', '1'));
            $cl->appendChild($xml->createElement('AccountID', '2111'));
            $cl->appendChild($xml->createElement('SystemEntryDate', $sys));
            $cl->appendChild($xml->createElement('Description', $row['invoice_no']));
            $cl->appendChild($xml->createElement('CreditAmount', $gross));

            $dl = $xml->createElement('DebitLine');
            $lines->appendChild($dl);
            $dl->appendChild($xml->createElement('RecordID', '2'));
            $dl->appendChild($xml->createElement('AccountID', '711'));
            $dl->appendChild($xml->createElement('SystemEntryDate', $sys));
            $dl->appendChild($xml->createElement('Description', $row['invoice_no']));
            $dl->appendChild($xml->createElement('DebitAmount', $net));

            if ((float) $row['tax'] > 0) {
                $dl2 = $xml->createElement('DebitLine');
                $lines->appendChild($dl2);
                $dl2->appendChild($xml->createElement('RecordID', '3'));
                $dl2->appendChild($xml->createElement('AccountID', '2432'));
                $dl2->appendChild($xml->createElement('SystemEntryDate', $sys));
                $dl2->appendChild($xml->createElement('Description', 'IVA ' . $row['invoice_no']));
                $dl2->appendChild($xml->createElement('DebitAmount', $tax));
            }
        }
    }
}

/** @return array<int, array<string, mixed>> */
function fat_saft_build_sales_ledger_plan(array $documentos): array
{
    $plan = [];
    $seq = 0;
    foreach ($documentos as $d) {
        if ($d['tipo'] === 'OR') {
            continue;
        }
        ++$seq;
        $arch = (string) $seq;
        $date = (string) $d['data_documento'];
        $plan[(int) $d['id']] = [
            'transaction_id' => fat_saft_transaction_id($date, 'VND', $arch),
            'customer_id' => 1,
            'gross' => (float) $d['total'],
            'net' => (float) $d['subtotal'],
            'tax' => (float) $d['total_iva'],
            'system_entry' => date('Y-m-d\TH:i:s', strtotime($d['data_sistema'] ?: $d['criado_em'])),
            'invoice_no' => (string) $d['numero_completo'],
            'invoice_date' => $date,
            'period' => (int) date('n', strtotime($date)),
            'is_credit' => in_array($d['tipo'], ['NC'], true),
        ];
    }
    return $plan;
}

/** NIF/tax ID exportável no MasterFiles (null = inválido para o validador). */
function fat_saft_tax_id(?string $nif): ?string
{
    $nif = preg_replace('/\s+/', '', trim((string) $nif));
    if ($nif === '' || strcasecmp($nif, 'CF') === 0) {
        return '999999999';
    }
    if (preg_match('/^\d{9,14}$/', $nif)) {
        return $nif;
    }

    return null;
}

/**
 * CustomerTaxID no portal AGT: NIF angolano numérico (10–15 dígitos) ou consumidor final.
 * NIF alfanumérico (ex. …UE042) não passa no validador — usar 999999999.
 */
function fat_saft_customer_tax_id(?string $nif): string
{
    $nif = preg_replace('/\s+/', '', trim((string) $nif));
    if ($nif === '' || strcasecmp($nif, 'CF') === 0 || $nif === '999999999') {
        return '999999999';
    }
    if (preg_match('/^\d{10,15}$/', $nif)) {
        return $nif;
    }
    if (preg_match('/^\d{9}$/', $nif)) {
        return '0' . $nif;
    }

    return '999999999';
}

/** ProductCompanyTaxID / emitente: 10–15 caracteres (dígitos; mantém sufixos se já 10–15). */
function fat_saft_producer_tax_id(?string $nif): string
{
    $nif = preg_replace('/\s+/', '', trim((string) $nif));
    if ($nif === '') {
        return '';
    }
    if (preg_match('/^\d{10,15}$/', $nif)) {
        return $nif;
    }
    if (strlen($nif) >= 10 && strlen($nif) <= 15) {
        return $nif;
    }

    return $nif;
}

/** Clientes referenciados em vendas, movimentos, proformas e secção 4.4 (pagamentos). */
function fat_saft_collect_used_customer_ids(string $from, string $to, array $documentos, array $documentosMov, array $documentosOr): array
{
    $ids = [];
    $add = static function ($cid) use (&$ids): void {
        $cid = (int) $cid;
        if ($cid > 0) {
            $ids[$cid] = true;
        }
    };
    foreach ([$documentos, $documentosMov, $documentosOr] as $list) {
        foreach ($list as $d) {
            $add($d['cliente_id'] ?? 0);
        }
    }
    $rcStmt = db()->prepare(
        "SELECT cliente_id FROM fat_documentos
         WHERE estado='emitido' AND tipo IN ('RC','AR') AND data_documento BETWEEN ? AND ?"
    );
    $rcStmt->execute([$from, $to]);
    foreach ($rcStmt->fetchAll(PDO::FETCH_COLUMN) as $cid) {
        $add($cid);
    }
    $rgStmt = db()->prepare(
        "SELECT d.cliente_id FROM fat_pagamentos p
         INNER JOIN fat_documentos d ON d.id = p.documento_id
         WHERE d.estado='emitido' AND d.tipo IN ('FT','FR') AND p.data_pagamento BETWEEN ? AND ?"
    );
    $rgStmt->execute([$from, $to]);
    foreach ($rgStmt->fetchAll(PDO::FETCH_COLUMN) as $cid) {
        $add($cid);
    }

    return $ids;
}

function fat_saft_resolve_customer_id_for_export(int $custId, ?string $clienteNif, array $customerTaxById): int
{
    if ($custId > 0 && isset($customerTaxById[$custId])) {
        if ($customerTaxById[$custId] === '999999999') {
            return 1;
        }

        return $custId;
    }

    return isset($customerTaxById[1]) ? 1 : max(1, $custId);
}

/**
 * @return array{0: float, 1: float} TotalDebit, TotalCredit (soma dos montantes de linha)
 */
function fat_saft_sales_section_totals(array $documentos): array
{
    $totalDebit = 0.0;
    $totalCredit = 0.0;
    $ls = db()->prepare('SELECT total_liquido FROM fat_linhas WHERE documento_id=?');
    foreach ($documentos as $d) {
        if (($d['tipo'] ?? '') === 'OR' || ($d['estado'] ?? '') === 'anulado') {
            continue;
        }
        $ls->execute([(int) $d['id']]);
        foreach ($ls->fetchAll() as $l) {
            $amt = (float) $l['total_liquido'];
            if (in_array($d['tipo'], ['NC', 'ND'], true)) {
                $totalDebit += $amt;
            } else {
                $totalCredit += $amt;
            }
        }
    }
    return [$totalDebit, $totalCredit];
}

function fat_saft_append_invoice_line(DOMDocument $xml, DOMElement $inv, array $l, array $d, bool $debitLine): void
{
    $line = $xml->createElement('Line');
    $inv->appendChild($line);
    $line->appendChild($xml->createElement('LineNumber', (string) $l['linha']));
    $line->appendChild($xml->createElement('ProductCode', $l['codigo'] ?: 'GEN'));
    $desc = trim((string) $l['descricao']);
    $line->appendChild($xml->createElement('ProductDescription', $desc !== '' ? $desc : '—'));
    $line->appendChild($xml->createElement('Quantity', number_format((float) $l['quantidade'], 2, '.', '')));
    $line->appendChild($xml->createElement('UnitOfMeasure', $l['unidade'] ?: 'UN'));
    $line->appendChild($xml->createElement('UnitPrice', number_format((float) $l['preco_unitario'], 2, '.', '')));
    $tp = function_exists('fat_agt_tax_point_date') ? fat_agt_tax_point_date($d) : $d['data_documento'];
    $line->appendChild($xml->createElement('TaxPointDate', $tp));
    $lineDesc = $desc !== '' ? $desc : '—';
    $line->appendChild($xml->createElement('Description', $lineDesc));
    if (function_exists('fat_saft_append_order_reference')) {
        fat_saft_append_order_reference($xml, $line, $d);
    }
    if (function_exists('fat_saft_append_nc_references')) {
        fat_saft_append_nc_references($xml, $line, $d);
    }
    $amountTag = $debitLine ? 'DebitAmount' : 'CreditAmount';
    $line->appendChild($xml->createElement($amountTag, number_format((float) $l['total_liquido'], 2, '.', '')));
    $tax = $xml->createElement('Tax');
    $line->appendChild($tax);
    $tax->appendChild($xml->createElement('TaxType', 'IVA'));
    $tax->appendChild($xml->createElement('TaxCountryRegion', 'AO'));
    $taxCode = (float) $l['taxa_iva'] == 0.0 ? 'ISE' : 'NOR';
    $tax->appendChild($xml->createElement('TaxCode', $taxCode));
    $tax->appendChild($xml->createElement('TaxPercentage', number_format((float) $l['taxa_iva'], 2, '.', '')));
    if ($taxCode === 'ISE') {
        $exCode = strtoupper(trim((string) ($l['codigo_isencao'] ?? '')));
        if ($exCode === '' && !empty($l['produto_id'])) {
            $pe = db()->prepare('SELECT codigo_isencao FROM fat_produtos WHERE id=?');
            $pe->execute([(int) $l['produto_id']]);
            $exCode = strtoupper(trim((string) $pe->fetchColumn()));
        }
        if ($exCode !== '') {
            $tax->appendChild($xml->createElement('TaxExemptionReason', $exCode));
        }
    }
}

/**
 * SystemEntryDate (SAF-T) deve ser ≥ InvoiceDate — alinha data_sistema antes de reassinar.
 */
function fat_portal_cert_align_system_entry_dates(int $numMin = 2, int $numMax = 8, string $serie = 'A'): int
{
    $stmt = db()->prepare(
        "SELECT id, data_documento, data_sistema, criado_em FROM fat_documentos WHERE estado IN ('emitido','anulado') AND tipo='FR' AND serie=? AND numero BETWEEN ? AND ? ORDER BY numero"
    );
    $stmt->execute([$serie, $numMin, $numMax]);
    $upd = db()->prepare('UPDATE fat_documentos SET data_sistema=? WHERE id=?');
    $n = 0;
    foreach ($stmt->fetchAll() as $row) {
        $invDate = substr((string) $row['data_documento'], 0, 10);
        $sysTs = strtotime($row['data_sistema'] ?: $row['criado_em'] ?: 'now');
        $sysDate = date('Y-m-d', $sysTs);
        if ($sysDate >= $invDate) {
            continue;
        }
        $newSys = $invDate . ' ' . date('H:i:s', $sysTs);
        $upd->execute([$newSys, (int) $row['id']]);
        ++$n;
    }

    return $n;
}

/**
 * Reassina FR de certificação portal (série A). Por omissão cadeia começa em A/2 (hash anterior vazio).
 */
function fat_rebuild_portal_cert_fr_chain(int $numMin = 2, int $numMax = 8, string $serie = 'A'): int
{
    $stmt = db()->prepare(
        "SELECT * FROM fat_documentos WHERE estado IN ('emitido','anulado') AND tipo='FR' AND serie=? AND numero BETWEEN ? AND ? ORDER BY numero"
    );
    $stmt->execute([$serie, $numMin, $numMax]);
    $rows = $stmt->fetchAll();
    $prev = '';
    $upd = db()->prepare('UPDATE fat_documentos SET numero_completo=?, hash=?, hash_anterior=?, hash_control=? WHERE id=?');
    $count = 0;
    foreach ($rows as $doc) {
        $invoiceNo = fat_saft_canonical_invoice_no($doc);
        $sysEntry = date('Y-m-d\TH:i:s', strtotime($doc['data_sistema'] ?: $doc['criado_em']));
        $sign = fat_sign_document((string) $doc['data_documento'], $sysEntry, $invoiceNo, (float) $doc['total'], $prev);
        $upd->execute([$invoiceNo, $sign['hash'], $sign['hash_anterior'], $sign['hash_control'], (int) $doc['id']]);
        $prev = $sign['hash'];
        ++$count;
    }

    return $count;
}

/** Datas de FR A/n em ordem crescente (n >= numMin). */
function fat_fix_fr_invoice_dates_sequential(int $numMin = 2, string $serie = 'A', string $startDate = '2026-08-22'): int
{
    $stmt = db()->prepare(
        "SELECT id, numero, data_documento FROM fat_documentos WHERE estado IN ('emitido','anulado') AND tipo='FR' AND serie=? AND numero >= ? ORDER BY numero"
    );
    $stmt->execute([$serie, $numMin]);
    $rows = $stmt->fetchAll();
    $upd = db()->prepare('UPDATE fat_documentos SET data_documento=?, tax_point_date=? WHERE id=?');
    $n = 0;
    foreach ($rows as $row) {
        $num = (int) $row['numero'];
        $date = date('Y-m-d', strtotime($startDate . ' +' . ($num - $numMin) . ' days'));
        if ((string) $row['data_documento'] === $date) {
            continue;
        }
        $upd->execute([$date, $date, (int) $row['id']]);
        ++$n;
    }

    return $n;
}

/** Export SAF-T só com FR A/2–A/8 (teste portal AGT). EndDate ≤ hoje (regra portal). */
function fat_export_saft_ao_portal_cert(string $from, string $to): string
{
    $today = date('Y-m-d');
    if ($to > $today) {
        $to = $today;
    }
    if ($from > $to) {
        $from = $to;
    }

    return fat_export_saft_ao($from, $to, [
        'portal_cert_fr' => ['serie' => 'A', 'min' => 2, 'max' => 8],
        'skip_payments' => true,
    ]);
}

/**
 * Gera XML SAF-T AO simplificado (SalesInvoices + MasterFiles) para um período.
 *
 * @param array{portal_cert_fr?: array{serie:string,min:int,max:int},skip_payments?:bool} $opts
 */
function fat_export_saft_ao(string $from, string $to, array $opts = []): string
{
    fat_agt_apply_cert_defaults();
    $emp = fat_empresa();
    if (!$emp || trim((string) $emp['nif']) === '') {
        throw new RuntimeException('Configure o NIF da empresa antes de exportar o SAF-T AO.');
    }

    $docs = db()->prepare("SELECT * FROM fat_documentos WHERE estado IN ('emitido','anulado') AND data_documento BETWEEN ? AND ? ORDER BY tipo, serie, numero");
    $docs->execute([$from, $to]);
    $documentosAll = $docs->fetchAll();
    $isSales = static fn ($d) => function_exists('fat_agt_is_sales_type') && fat_agt_is_sales_type((string) ($d['tipo'] ?? ''));
    $isMove = static fn ($d) => function_exists('fat_agt_is_movement_type') && fat_agt_is_movement_type((string) ($d['tipo'] ?? ''));
    $documentos = array_values(array_filter($documentosAll, $isSales));
    usort($documentos, static function (array $a, array $b): int {
        $ta = strcmp((string) ($a['tipo'] ?? ''), (string) ($b['tipo'] ?? ''));
        if ($ta !== 0) {
            return $ta;
        }
        $sa = strcmp((string) ($a['serie'] ?? 'A'), (string) ($b['serie'] ?? 'A'));
        if ($sa !== 0) {
            return $sa;
        }
        $na = (int) ($a['numero'] ?? 0);
        $nb = (int) ($b['numero'] ?? 0);
        if ($na !== $nb) {
            return $na <=> $nb;
        }

        return strcmp((string) $a['data_documento'], (string) $b['data_documento']);
    });
    if (!empty($opts['portal_cert_fr'])) {
        $pc = $opts['portal_cert_fr'];
        $serie = (string) ($pc['serie'] ?? 'A');
        $min = (int) ($pc['min'] ?? 2);
        $max = (int) ($pc['max'] ?? 8);
        $documentos = array_values(array_filter(
            $documentos,
            static fn ($d) => ($d['tipo'] ?? '') === 'FR'
                && ($d['serie'] ?? 'A') === $serie
                && (int) ($d['numero'] ?? 0) >= $min
                && (int) ($d['numero'] ?? 0) <= $max
        ));
    }
    $documentosMov = array_values(array_filter($documentosAll, static fn ($d) => $isMove($d) && ($d['estado'] ?? '') === 'emitido'));
    $documentosOr = array_values(array_filter($documentosAll, static fn ($d) => ($d['tipo'] ?? '') === 'OR'));
    if (!empty($opts['portal_cert_fr'])) {
        $documentosMov = [];
        $documentosOr = [];
    }

    $usedCustomerIds = fat_saft_collect_used_customer_ids($from, $to, $documentos, $documentosMov, $documentosOr);
    $comprasStmt = db()->prepare('SELECT * FROM fat_compras WHERE data_compra BETWEEN ? AND ? ORDER BY data_compra, id');
    $comprasStmt->execute([$from, $to]);
    $compras = $comprasStmt->fetchAll();
    $usedSupplierIds = [];
    foreach ($compras as $compra) {
        if (!empty($compra['fornecedor_id'])) {
            $usedSupplierIds[(int) $compra['fornecedor_id']] = true;
        }
    }

    $clientes = db()->query('SELECT * FROM fat_clientes WHERE ativo=1 ORDER BY id')->fetchAll();
    $produtos = db()->query('SELECT * FROM fat_produtos WHERE ativo=1 ORDER BY id')->fetchAll();

    $saftBasis = fat_saft_tax_accounting_basis($emp);
    $needsLedger = fat_saft_needs_integrated_ledger($emp);
    $needsAccountingFile = fat_saft_basis_is_accounting_file($saftBasis);
    $supplierNodes = 0;

    $xml = new DOMDocument('1.0', 'UTF-8');
    $xml->formatOutput = true;
    $root = $xml->createElement('AuditFile');
    $root->setAttribute('xmlns', 'urn:OECD:StandardAuditFile-Tax:AO_1.01_01');
    $xml->appendChild($root);

    $header = $xml->createElement('Header');
    $root->appendChild($header);
    $header->appendChild($xml->createElement('AuditFileVersion', '1.01_01'));
    $header->appendChild($xml->createElement('CompanyID', $emp['nif']));
    $header->appendChild($xml->createElement('TaxRegistrationNumber', $emp['nif']));
    $header->appendChild($xml->createElement('TaxAccountingBasis', fat_saft_tax_accounting_basis($emp)));
    $header->appendChild($xml->createElement('CompanyName', $emp['nome']));
    $companyAddress = $xml->createElement('CompanyAddress');
    $header->appendChild($companyAddress);
    $moradaHeader = $emp['morada'] ?: 'Desconhecido';
    if (trim((string) ($emp['estabelecimento_nome'] ?? '')) !== '') {
        $moradaHeader = trim((string) $emp['estabelecimento_nome']) . ' — ' . $moradaHeader;
    }
    $companyAddress->appendChild($xml->createElement('AddressDetail', $moradaHeader));
    $companyAddress->appendChild($xml->createElement('City', $emp['cidade'] ?: 'Luanda'));
    $companyAddress->appendChild($xml->createElement('Country', 'AO'));
    $header->appendChild($xml->createElement('FiscalYear', substr($from, 0, 4)));
    $header->appendChild($xml->createElement('StartDate', $from));
    $header->appendChild($xml->createElement('EndDate', $to));
    $header->appendChild($xml->createElement('CurrencyCode', 'AOA'));
    $header->appendChild($xml->createElement('DateCreated', date('Y-m-d')));
    $header->appendChild($xml->createElement('TaxEntity', fat_saft_tax_entity_value($emp)));
    $prodTax = fat_saft_producer_tax_id($emp['produtor_nif'] ?: $emp['nif']);
    $header->appendChild($xml->createElement('ProductCompanyTaxID', $prodTax !== '' ? $prodTax : (string) $emp['nif']));
    $header->appendChild($xml->createElement('SoftwareValidationNumber', fat_saft_validation_number($emp)));
    $header->appendChild($xml->createElement('ProductID', fat_saft_product_id($emp)));
    $header->appendChild($xml->createElement('ProductVersion', $emp['software_versao'] ?: '1.0.0'));

    $comment = $xml->createComment(' INFORMATIZA Facturação — Licença: ' . fat_licenca_agt_exibida() . ' ');
    $root->appendChild($comment);

    $master = $xml->createElement('MasterFiles');
    $root->appendChild($master);

    $customerTaxById = [];
    $cfAdded = false;
    foreach ($clientes as $c) {
        $cid = (int) $c['id'];
        if ($usedCustomerIds !== [] && !isset($usedCustomerIds[$cid])) {
            continue;
        }
        $taxId = fat_saft_customer_tax_id($c['nif']);
        $exportId = $cid;
        if ($taxId === '999999999') {
            $exportId = 1;
            if ($cfAdded) {
                $customerTaxById[$cid] = '999999999';
                continue;
            }
            $cfAdded = true;
        }
        $customerTaxById[$cid] = $taxId;
        if ($exportId === 1 && isset($customerTaxById[1]) && $cid !== 1) {
            continue;
        }
        $customerTaxById[$exportId] = $taxId;
        $cust = $xml->createElement('Customer');
        $master->appendChild($cust);
        $cust->appendChild($xml->createElement('CustomerID', (string) $exportId));
        $cust->appendChild($xml->createElement('AccountID', 'Desconhecido'));
        $cust->appendChild($xml->createElement('CustomerTaxID', $taxId));
        $companyName = $taxId === '999999999' ? 'Consumidor final' : $c['nome'];
        $cust->appendChild($xml->createElement('CompanyName', $companyName));
        $ba = $xml->createElement('BillingAddress');
        $cust->appendChild($ba);
        $ba->appendChild($xml->createElement('AddressDetail', $c['morada'] ?: 'Desconhecido'));
        $ba->appendChild($xml->createElement('City', $c['cidade'] ?: 'Luanda'));
        $ba->appendChild($xml->createElement('Country', 'AO'));
        $cust->appendChild($xml->createElement('SelfBillingIndicator', '0'));
    }
    if ($customerTaxById === [] && $documentos !== []) {
        $cust = $xml->createElement('Customer');
        $master->appendChild($cust);
        $cust->appendChild($xml->createElement('CustomerID', '1'));
        $cust->appendChild($xml->createElement('AccountID', 'Desconhecido'));
        $cust->appendChild($xml->createElement('CustomerTaxID', '999999999'));
        $cust->appendChild($xml->createElement('CompanyName', 'Consumidor Final'));
        $ba = $xml->createElement('BillingAddress');
        $cust->appendChild($ba);
        $ba->appendChild($xml->createElement('AddressDetail', 'Desconhecido'));
        $ba->appendChild($xml->createElement('City', 'Luanda'));
        $ba->appendChild($xml->createElement('Country', 'AO'));
        $cust->appendChild($xml->createElement('SelfBillingIndicator', '0'));
        $customerTaxById[1] = '999999999';
    }

    if ($needsAccountingFile && $supplierNodes === 0) {
        fat_saft_append_placeholder_supplier($xml, $master);
        ++$supplierNodes;
    }

    $companyNif = preg_replace('/\s+/', '', trim((string) $emp['nif']));
    if ($usedSupplierIds !== []) {
        $fornecedores = db()->query('SELECT * FROM fat_fornecedores ORDER BY id')->fetchAll();
        foreach ($fornecedores as $f) {
            $sid = (int) $f['id'];
            if (!isset($usedSupplierIds[$sid])) {
                continue;
            }
            $taxId = fat_saft_tax_id($f['nif']);
            if ($taxId === null || $taxId === $companyNif) {
                continue;
            }
            $supplier = $xml->createElement('Supplier');
            $master->appendChild($supplier);
            $supplier->appendChild($xml->createElement('SupplierID', (string) $sid));
            $supplier->appendChild($xml->createElement('AccountID', 'Desconhecido'));
            $supplier->appendChild($xml->createElement('SupplierTaxID', $taxId));
            $supplier->appendChild($xml->createElement('CompanyName', $f['nome']));
            $address = $xml->createElement('BillingAddress');
            $supplier->appendChild($address);
            $address->appendChild($xml->createElement('AddressDetail', $f['morada'] ?: 'Desconhecido'));
            $address->appendChild($xml->createElement('City', 'Luanda'));
            $address->appendChild($xml->createElement('Country', 'AO'));
            $supplier->appendChild($xml->createElement('SelfBillingIndicator', '0'));
            ++$supplierNodes;
        }
    }

    foreach ($produtos as $p) {
        $prod = $xml->createElement('Product');
        $master->appendChild($prod);
        $prod->appendChild($xml->createElement('ProductType', 'P'));
        $prod->appendChild($xml->createElement('ProductCode', $p['codigo']));
        $prod->appendChild($xml->createElement('ProductDescription', $p['descricao']));
        $prod->appendChild($xml->createElement('ProductNumberCode', $p['codigo']));
    }

    $taxTable = $xml->createElement('TaxTable');
    $master->appendChild($taxTable);
    foreach ([0, 5, 7, 14] as $rate) {
        $te = $xml->createElement('TaxTableEntry');
        $taxTable->appendChild($te);
        $te->appendChild($xml->createElement('TaxType', 'IVA'));
        $te->appendChild($xml->createElement('TaxCountryRegion', 'AO'));
        $te->appendChild($xml->createElement('TaxCode', $rate == 0 ? 'ISE' : 'NOR'));
        $te->appendChild($xml->createElement('Description', 'IVA ' . $rate . '%'));
        $te->appendChild($xml->createElement('TaxPercentage', number_format($rate, 2, '.', '')));
    }

    $ledgerPlan = [];
    if ($needsLedger) {
        $usedContLedger = function_exists('cont_saft_export_ledger')
            && cont_saft_export_ledger($xml, $master, $root, $from, $to);
        if ($usedContLedger) {
            $ledgerPlan = cont_saft_venda_ledger_plan($from, $to);
        } else {
            fat_saft_prepend_standard_chart($xml, $master);
            $ledgerPlan = fat_saft_build_sales_ledger_plan($documentos);
            if ($ledgerPlan !== []) {
                fat_saft_append_general_ledger_entries($xml, $root, $ledgerPlan);
            }
        }
    }

    if ($needsLedger && $ledgerPlan !== []) {
        foreach ($documentos as $d) {
            $docId = (int) $d['id'];
            if (!isset($ledgerPlan[$docId])) {
                continue;
            }
            $custId = (int) ($d['cliente_id'] ?: 0);
            if ($custId === 0 || !isset($customerTaxById[$custId])) {
                $docTax = fat_saft_tax_id($d['cliente_nif'] ?? '');
                if ($docTax !== null && $custId > 0 && !isset($customerTaxById[$custId])) {
                    $customerTaxById[$custId] = $docTax;
                }
                $custId = ($custId > 0 && isset($customerTaxById[$custId])) ? $custId : 1;
            }
            $ledgerPlan[$docId]['customer_id'] = $custId;
        }
    }

    $source = $xml->createElement('SourceDocuments');
    $root->appendChild($source);
    $sales = $xml->createElement('SalesInvoices');
    $source->appendChild($sales);
    $sales->appendChild($xml->createElement('NumberOfEntries', (string) count($documentos)));
    [$totalDebit, $totalCredit] = fat_saft_sales_section_totals($documentos);
    $sales->appendChild($xml->createElement('TotalDebit', number_format($totalDebit, 2, '.', '')));
    $sales->appendChild($xml->createElement('TotalCredit', number_format($totalCredit, 2, '.', '')));

    foreach ($documentos as $d) {
        if ($d['tipo'] === 'OR') {
            continue;
        }
        $inv = $xml->createElement('Invoice');
        $sales->appendChild($inv);
        $invoiceNoXml = fat_saft_canonical_invoice_no($d);
        $inv->appendChild($xml->createElement('InvoiceNo', $invoiceNoXml));
        $ds = $xml->createElement('DocumentStatus');
        $inv->appendChild($ds);
        $ds->appendChild($xml->createElement('InvoiceStatus', $d['estado'] === 'anulado' ? 'A' : 'N'));
        $ds->appendChild($xml->createElement('InvoiceStatusDate', date('Y-m-d\TH:i:s', strtotime($d['data_sistema'] ?: $d['criado_em']))));
        if ($d['estado'] === 'anulado' && !empty($d['motivo_anulacao'])) {
            $ds->appendChild($xml->createElement('Reason', (string) $d['motivo_anulacao']));
        }
        $ds->appendChild($xml->createElement('SourceID', (string) ($d['criado_por'] ?: 1)));
        $ds->appendChild($xml->createElement('SourceBilling', function_exists('fat_agt_source_billing_for_doc') ? fat_agt_source_billing_for_doc($d) : 'P'));
        $inv->appendChild($xml->createElement('Hash', fat_saft_hash_field($d['hash'] ?? '')));
        $hashCtrl = function_exists('fat_saft_hash_control_for_doc')
            ? fat_saft_hash_control_for_doc($emp, $d)
            : fat_saft_hash_control_export($emp, $d['hash_control'] ?? '');
        $inv->appendChild($xml->createElement('HashControl', $hashCtrl));
        $inv->appendChild($xml->createElement('InvoiceDate', $d['data_documento']));
        $inv->appendChild($xml->createElement('InvoiceType', $d['tipo']));
        $sp = $xml->createElement('SpecialRegimes');
        $inv->appendChild($sp);
        $sp->appendChild($xml->createElement('SelfBillingIndicator', '0'));
        $sp->appendChild($xml->createElement('CashVATSchemeIndicator', '0'));
        $sp->appendChild($xml->createElement('ThirdPartiesBillingIndicator', '0'));
        $inv->appendChild($xml->createElement('SourceID', (string) ($d['criado_por'] ?: 1)));
        $inv->appendChild($xml->createElement('SystemEntryDate', date('Y-m-d\TH:i:s', strtotime($d['data_sistema'] ?: $d['criado_em']))));
        $docId = (int) $d['id'];
        $custId = fat_saft_resolve_customer_id_for_export(
            (int) ($d['cliente_id'] ?: 0),
            (string) ($d['cliente_nif'] ?? ''),
            $customerTaxById
        );
        if (isset($ledgerPlan[$docId])) {
            $inv->appendChild($xml->createElement('TransactionID', $ledgerPlan[$docId]['transaction_id']));
        }
        $inv->appendChild($xml->createElement('CustomerID', (string) $custId));

        $ls = db()->prepare('SELECT * FROM fat_linhas WHERE documento_id=? ORDER BY linha');
        $ls->execute([$d['id']]);
        $debitLine = in_array($d['tipo'], ['NC', 'ND'], true);
        foreach ($ls->fetchAll() as $l) {
            fat_saft_append_invoice_line($xml, $inv, $l, $d, $debitLine);
        }

        $totals = $xml->createElement('DocumentTotals');
        $inv->appendChild($totals);
        $totals->appendChild($xml->createElement('TaxPayable', number_format((float) $d['total_iva'], 2, '.', '')));
        $totals->appendChild($xml->createElement('NetTotal', number_format((float) $d['subtotal'], 2, '.', '')));
        $totals->appendChild($xml->createElement('GrossTotal', number_format((float) $d['total'], 2, '.', '')));
    }

    // SAF-T (AO) PurchaseInvoices: sem linhas; ordem InvoiceNo → Hash → SourceID → Period → InvoiceDate → PurchaseType → SupplierID → DocumentTotals.
    $comprasExport = [];
    foreach ($compras as $compra) {
        $sid = (int) ($compra['fornecedor_id'] ?? 0);
        if ($sid > 0) {
            $fn = db()->prepare('SELECT nif FROM fat_fornecedores WHERE id=?');
            $fn->execute([$sid]);
            $fnif = fat_saft_tax_id((string) $fn->fetchColumn());
            if ($fnif === null || $fnif === $companyNif) {
                continue;
            }
        }
        $comprasExport[] = $compra;
    }
    if ($comprasExport !== []) {
        $purchases = $xml->createElement('PurchaseInvoices');
        $source->appendChild($purchases);
        $purchases->appendChild($xml->createElement('NumberOfEntries', (string) count($comprasExport)));
        foreach ($comprasExport as $compra) {
            $invoice = $xml->createElement('Invoice');
            $purchases->appendChild($invoice);
            $invoice->appendChild($xml->createElement('InvoiceNo', $compra['referencia']));
            $invoice->appendChild($xml->createElement('Hash', '0'));
            $invoice->appendChild($xml->createElement('SourceID', (string) ($compra['criado_por'] ?: 1)));
            $invoice->appendChild($xml->createElement('Period', (string) (int) date('n', strtotime($compra['data_compra']))));
            $invoice->appendChild($xml->createElement('InvoiceDate', $compra['data_compra']));
            $invoice->appendChild($xml->createElement('PurchaseType', 'FT'));
            $invoice->appendChild($xml->createElement('SupplierID', (string) ($compra['fornecedor_id'] ?: '0')));
            $totals = $xml->createElement('DocumentTotals');
            $invoice->appendChild($totals);
            $totals->appendChild($xml->createElement('TaxPayable', number_format((float) $compra['total_iva'], 2, '.', '')));
            $totals->appendChild($xml->createElement('NetTotal', number_format((float) $compra['subtotal'], 2, '.', '')));
            $totals->appendChild($xml->createElement('GrossTotal', number_format((float) $compra['total'], 2, '.', '')));
        }
    }

    if (function_exists('fat_saft_export_movements')) {
        fat_saft_export_movements($xml, $source, $documentosMov, $customerTaxById);
    }
    if (function_exists('fat_saft_export_working_documents')) {
        fat_saft_export_working_documents($xml, $source, $documentosOr, $customerTaxById);
    }
    if (function_exists('fat_saft_export_payments') && empty($opts['skip_payments'])) {
        fat_saft_export_payments($xml, $source, $from, $to, $customerTaxById);
    }

    $out = $xml->saveXML();
    fat_saft_validate_against_xsd($out);
    return $out;
}

/**
 * Séries mensais para dashboard / relatórios (vendas, NC, IVA, compras).
 *
 * @return array{labels: string[], vendas: float[], nc: float[], iva: float[], compras: float[]}
 */
function fat_dashboard_series(int $months = 6): array
{
    ensure_facturacao_schema();
    $months = max(1, min(24, $months));
    $end = new DateTime('last day of this month');
    $labels = [];
    $keys = [];
    $mesesCurto = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    for ($i = $months - 1; $i >= 0; --$i) {
        $d = (clone $end)->modify('-' . $i . ' months');
        $ym = $d->format('Y-m');
        $keys[] = $ym;
        $labels[] = $mesesCurto[(int) $d->format('n') - 1] . ' ' . $d->format('Y');
    }
    $from = $keys[0] . '-01';
    $to = $end->format('Y-m-d');
    $vendas = $nc = $iva = $compras = array_fill_keys($keys, 0.0);

    $fill = static function (PDOStatement $stmt, array &$bucket, string $field = 'total'): void {
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $ym = (string) ($row['ym'] ?? '');
            if ($ym !== '' && array_key_exists($ym, $bucket)) {
                $bucket[$ym] = (float) ($row[$field] ?? 0);
            }
        }
    };

    $sv = db()->prepare(
        "SELECT DATE_FORMAT(data_documento,'%Y-%m') AS ym, COALESCE(SUM(total),0) AS total
         FROM fat_documentos WHERE estado='emitido' AND data_documento BETWEEN ? AND ? AND tipo IN ('FT','FR','FA')
         GROUP BY ym"
    );
    $sv->execute([$from, $to]);
    $fill($sv, $vendas);

    $snc = db()->prepare(
        "SELECT DATE_FORMAT(data_documento,'%Y-%m') AS ym, COALESCE(SUM(total),0) AS total
         FROM fat_documentos WHERE estado='emitido' AND data_documento BETWEEN ? AND ? AND tipo='NC'
         GROUP BY ym"
    );
    $snc->execute([$from, $to]);
    $fill($snc, $nc);

    $siva = db()->prepare(
        "SELECT DATE_FORMAT(data_documento,'%Y-%m') AS ym,
            COALESCE(SUM(CASE WHEN tipo='NC' THEN -total_iva ELSE total_iva END),0) AS total
         FROM fat_documentos WHERE estado='emitido' AND data_documento BETWEEN ? AND ?
           AND tipo IN ('FT','FR','NC','ND','FA') GROUP BY ym"
    );
    $siva->execute([$from, $to]);
    $fill($siva, $iva);

    $sc = db()->prepare(
        "SELECT DATE_FORMAT(data_compra,'%Y-%m') AS ym, COALESCE(SUM(total),0) AS total
         FROM fat_compras WHERE data_compra BETWEEN ? AND ? GROUP BY ym"
    );
    $sc->execute([$from, $to]);
    $fill($sc, $compras);

    return [
        'labels' => $labels,
        'vendas' => array_values($vendas),
        'nc' => array_values($nc),
        'iva' => array_values($iva),
        'compras' => array_values($compras),
    ];
}

/** Vendas por dia (últimos N dias). */
function fat_dashboard_vendas_diarias(int $days = 30): array
{
    ensure_facturacao_schema();
    $days = max(7, min(90, $days));
    $from = date('Y-m-d', strtotime('-' . ($days - 1) . ' days'));
    $to = date('Y-m-d');
    $labels = [];
    $ordered = [];
    $byDay = [];
    for ($i = 0; $i < $days; ++$i) {
        $d = date('Y-m-d', strtotime($from . ' +' . $i . ' days'));
        $labels[] = date('d/m', strtotime($d));
        $byDay[$d] = 0.0;
    }
    $stmt = db()->prepare(
        "SELECT data_documento, COALESCE(SUM(CASE WHEN tipo='NC' THEN -total ELSE total END),0) AS t
         FROM fat_documentos WHERE estado='emitido' AND data_documento BETWEEN ? AND ?
           AND tipo IN ('FT','FR','NC','ND','FA') GROUP BY data_documento"
    );
    $stmt->execute([$from, $to]);
    foreach ($stmt->fetchAll() as $row) {
        $key = (string) $row['data_documento'];
        if (array_key_exists($key, $byDay)) {
            $byDay[$key] = (float) $row['t'];
        }
    }
    foreach ($byDay as $v) {
        $ordered[] = $v;
    }

    return ['labels' => $labels, 'totais' => $ordered];
}

/** Documentos emitidos por tipo no período. */
function fat_dashboard_por_tipo(string $from, string $to): array
{
    $stmt = db()->prepare(
        "SELECT tipo, COUNT(*) AS n, COALESCE(SUM(total),0) AS total
         FROM fat_documentos WHERE estado='emitido' AND data_documento BETWEEN ? AND ?
         GROUP BY tipo ORDER BY total DESC"
    );
    $stmt->execute([$from, $to]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/** Top clientes por facturação no período. */
function fat_dashboard_top_clientes(string $from, string $to, int $limit = 8): array
{
    $limit = max(1, min(20, $limit));
    $stmt = db()->prepare(
        "SELECT cliente_nome, cliente_nif,
            COALESCE(SUM(CASE WHEN tipo IN ('NC') THEN -total WHEN tipo IN ('FT','FR','FA','ND') THEN total ELSE 0 END),0) AS total,
            COUNT(*) AS docs
         FROM fat_documentos WHERE estado='emitido' AND data_documento BETWEEN ? AND ?
           AND tipo IN ('FT','FR','NC','ND','FA') AND cliente_id IS NOT NULL
         GROUP BY cliente_id, cliente_nome, cliente_nif
         HAVING total > 0
         ORDER BY total DESC LIMIT " . (int) $limit
    );
    $stmt->execute([$from, $to]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/** Pagamentos por meio no período. */
function fat_dashboard_pagamentos(string $from, string $to): array
{
    try {
        $stmt = db()->prepare(
            "SELECT metodo, COALESCE(SUM(valor),0) AS total, COUNT(*) AS n
             FROM fat_pagamentos WHERE data_pagamento BETWEEN ? AND ? GROUP BY metodo ORDER BY total DESC"
        );
        $stmt->execute([$from, $to]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return [];
    }
}

/** Resumo KPI do período. */
function fat_relatorio_resumo(string $from, string $to): array
{
    $v = db()->prepare(
        "SELECT COALESCE(SUM(CASE WHEN tipo IN ('FT','FR','FA') THEN total WHEN tipo='NC' THEN -total ELSE 0 END),0),
                COALESCE(SUM(CASE WHEN tipo IN ('FT','FR','FA') THEN total_iva WHEN tipo='NC' THEN -total_iva ELSE 0 END),0),
                COUNT(*)
         FROM fat_documentos WHERE estado='emitido' AND data_documento BETWEEN ? AND ?
           AND tipo IN ('FT','FR','NC','ND','FA')"
    );
    $v->execute([$from, $to]);
    [$liq, $iva, $docs] = $v->fetch(PDO::FETCH_NUM);

    $cmp = db()->prepare('SELECT COALESCE(SUM(total),0), COALESCE(SUM(total_iva),0) FROM fat_compras WHERE data_compra BETWEEN ? AND ?');
    $cmp->execute([$from, $to]);
    [$compras, $ivaCmp] = $cmp->fetch(PDO::FETCH_NUM);

    $pag = db()->prepare('SELECT COALESCE(SUM(valor),0) FROM fat_pagamentos WHERE data_pagamento BETWEEN ? AND ?');
    $pag->execute([$from, $to]);
    $recebido = (float) $pag->fetchColumn();

    return [
        'vendas_liquidas' => (float) $liq,
        'iva_liquidado' => (float) $iva,
        'documentos' => (int) $docs,
        'compras' => (float) $compras,
        'iva_compras' => (float) $ivaCmp,
        'recebimentos' => $recebido,
    ];
}

function fat_abs_url(string $path): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

    return $scheme . '://' . $host . url($path);
}

/** Saldo em dívida do cliente num documento emitido (FT, FR, FA, ND). */
function fat_saldo_documento_cliente(int $docId): float
{
    ensure_facturacao_schema();
    $stmt = db()->prepare('SELECT id, tipo, estado, total FROM fat_documentos WHERE id=?');
    $stmt->execute([$docId]);
    $doc = $stmt->fetch();
    if (!$doc || ($doc['estado'] ?? '') !== 'emitido') {
        return 0.0;
    }
    if (!in_array($doc['tipo'] ?? '', ['FT', 'FR', 'FA', 'ND'], true)) {
        return 0.0;
    }
    $total = (float) $doc['total'];
    $paid = db()->prepare('SELECT COALESCE(SUM(valor),0) FROM fat_pagamentos WHERE documento_id=?');
    $paid->execute([$docId]);
    $paidVal = (float) $paid->fetchColumn();
    $nc = db()->prepare("SELECT COALESCE(SUM(total),0) FROM fat_documentos WHERE documento_origem_id=? AND tipo='NC' AND estado='emitido'");
    $nc->execute([$docId]);
    $ncVal = (float) $nc->fetchColumn();

    return round(max(0, $total - $paidVal - $ncVal), 2);
}

/** Email do cliente associado ao documento. */
function fat_documento_cliente_email(int $docId): string
{
    $stmt = db()->prepare('SELECT d.cliente_id, c.email FROM fat_documentos d LEFT JOIN fat_clientes c ON c.id=d.cliente_id WHERE d.id=?');
    $stmt->execute([$docId]);
    $row = $stmt->fetch();

    return trim((string) ($row['email'] ?? ''));
}

/**
 * Cria rascunho FT ou FR a partir de uma OR emitida (mesmas linhas).
 *
 * @throws RuntimeException
 */
function fat_copiar_or_para_factura(int $orId, string $tipoDestino, ?int $userId): int
{
    ensure_facturacao_schema();
    $tipoDestino = strtoupper($tipoDestino);
    if (!in_array($tipoDestino, ['FT', 'FR'], true)) {
        throw new RuntimeException('Tipo de factura inválido.');
    }
    $src = db()->prepare('SELECT * FROM fat_documentos WHERE id=?');
    $src->execute([$orId]);
    $doc = $src->fetch();
    if (!$doc || ($doc['tipo'] ?? '') !== 'OR') {
        throw new RuntimeException('Documento de origem não é uma proposta orçamental (OR).');
    }
    if (($doc['estado'] ?? '') !== 'emitido') {
        throw new RuntimeException('Emita a proposta orçamental antes de converter em factura.');
    }
    $linhas = db()->prepare('SELECT * FROM fat_linhas WHERE documento_id=? ORDER BY linha');
    $linhas->execute([$orId]);
    $linhas = $linhas->fetchAll();
    if (!$linhas) {
        throw new RuntimeException('A proposta não tem linhas.');
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare("INSERT INTO fat_documentos
            (tipo, serie, numero, numero_completo, cliente_id, cliente_nome, cliente_nif, cliente_morada, local_prestacao,
             data_documento, data_sistema, estado, documento_origem_id, subtotal, total_iva, total, observacoes, criado_por)
            VALUES (?,?,NULL,'RASCUNHO',?,?,?,?,?,?,?, 'rascunho', ?,?,?,?,?,?)")
            ->execute([
                $tipoDestino, 'A',
                $doc['cliente_id'], $doc['cliente_nome'], $doc['cliente_nif'], $doc['cliente_morada'],
                $doc['local_prestacao'] ?? null,
                date('Y-m-d'), date('Y-m-d H:i:s'),
                $orId,
                $doc['subtotal'], $doc['total_iva'], $doc['total'],
                trim('Factura com base na proposta ' . ($doc['numero_completo'] ?? '') . '. ' . (string) ($doc['observacoes'] ?? '')),
                $userId,
            ]);
        $newId = (int) $pdo->lastInsertId();
        $ins = $pdo->prepare('INSERT INTO fat_linhas
            (documento_id, produto_id, linha, codigo, descricao, quantidade, unidade, preco_unitario, desconto_pct, taxa_iva, codigo_isencao, total_liquido, total_iva, total_linha)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        foreach ($linhas as $l) {
            $ins->execute([
                $newId, $l['produto_id'], $l['linha'], $l['codigo'], $l['descricao'],
                $l['quantidade'], $l['unidade'], $l['preco_unitario'], $l['desconto_pct'] ?? 0,
                $l['taxa_iva'], $l['codigo_isencao'] ?? null,
                $l['total_liquido'], $l['total_iva'], $l['total_linha'],
            ]);
        }
        $pdo->commit();

        return $newId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/**
 * Envia documento ao cliente por email (link PDF + validação se aplicável).
 *
 * @throws RuntimeException
 */
function fat_enviar_documento_email(int $docId, string $paraEmail, string $mensagemExtra = '', ?int $userId = null): bool
{
    ensure_facturacao_schema();
    $paraEmail = trim($paraEmail);
    if ($paraEmail === '' || !filter_var($paraEmail, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('Indique um email válido do cliente.');
    }
    $stmt = db()->prepare('SELECT * FROM fat_documentos WHERE id=?');
    $stmt->execute([$docId]);
    $doc = $stmt->fetch();
    if (!$doc || ($doc['estado'] ?? '') !== 'emitido') {
        throw new RuntimeException('Só pode enviar documentos já emitidos.');
    }
    $emp = fat_empresa();
    $fromEmail = trim((string) ($emp['email'] ?? ''));
    if ($fromEmail === '') {
        $fromEmail = contact_inbox_email();
    }
    $fromName = (string) ($emp['nome'] ?? APP_NAME);
    $tipo = (string) ($doc['tipo'] ?? '');
    $ref = (string) ($doc['numero_completo'] ?? '');
    $pdfUrl = fat_abs_url('/admin/facturacao/documentos/imprimir.php?id=' . $docId);
    $isOrcamento = $tipo === 'OR';
    $subject = $isOrcamento
        ? 'Proposta orçamental ' . $ref . ' — ' . $fromName
        : fat_tipo_label($tipo) . ' ' . $ref . ' — ' . $fromName;

    $body = "Exmo(a). Sr(a). " . ($doc['cliente_nome'] ?? 'Cliente') . ",\n\n";
    if ($isOrcamento) {
        $body .= "Segue a nossa proposta orçamental referenciada abaixo.\n\n";
    } elseif ($tipo === 'FT' && !empty($doc['local_prestacao'])) {
        $body .= "Segue a factura relativa à prestação de serviços indicada.\n\n";
    } else {
        $body .= "Segue o documento fiscal indicado abaixo.\n\n";
    }
    $body .= "Documento: " . fat_tipo_label($tipo) . " " . $ref . "\n";
    $body .= "Data: " . ($doc['data_documento'] ?? '') . "\n";
    $body .= "Total: " . fat_format_money((float) ($doc['total'] ?? 0)) . "\n\n";
    $body .= "Ver / imprimir (PDF): " . $pdfUrl . "\n";
    if (!$isOrcamento && function_exists('fat_fatura_validar_url')) {
        $body .= "Validar documento: " . fat_fatura_validar_url($docId) . "\n";
    }
    if ($mensagemExtra !== '') {
        $body .= "\n" . $mensagemExtra . "\n";
    }
    $body .= "\nCom os melhores cumprimentos,\n" . $fromName . "\n";
    if (!empty($emp['telefone'])) {
        $body .= 'Tel: ' . $emp['telefone'] . "\n";
    }

    $headers = [
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'From: ' . sprintf('%s <%s>', mb_encode_mimeheader($fromName, 'UTF-8'), $fromEmail),
        'Reply-To: ' . $fromEmail,
        'X-Mailer: PHP/' . PHP_VERSION,
    ];
    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $ok = @mail($paraEmail, $encodedSubject, $body, implode("\r\n", $headers));
    if (!$ok) {
        throw new RuntimeException('O servidor não conseguiu enviar o email. Verifique a configuração de mail no XAMPP.');
    }

    return true;
}
