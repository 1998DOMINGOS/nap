<?php

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/** Caminhos internos sem sufixo .php (URLs limpas). */
function url_normalize_path(string $path): string
{
    if ($path === '' || $path === '/') {
        return '/';
    }
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }

    $query = '';
    if (str_contains($path, '?')) {
        [$path, $query] = explode('?', $path, 2);
        $query = '?' . $query;
    }

    $path = preg_replace('#/index\.php$#', '', $path);
    $path = preg_replace('#\.php$#i', '', $path);

    if ($path === '' || $path === '/index') {
        $path = '/';
    }
    if ($path === '/admin/index' || $path === '/admin') {
        $path = '/admin/login';
    }
    if ($path !== '' && !str_starts_with($path, '/')) {
        $path = '/' . $path;
    }

    return $path . $query;
}

function redirect(string $path): void
{
    $url = preg_match('#^https?://#i', $path) ? $path : url($path);
    header('Location: ' . $url);
    exit;
}

function url(string $path = ''): string
{
    if ($path === '') {
        return BASE_URL;
    }
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }

    return BASE_URL . url_normalize_path($path);
}

/**
 * URL do site público com rotas limpas.
 * Exemplos: site_url('missao') → /missao
 *           site_url('servico/' . $slug) → /servico/slug
 */
function site_url(string $path = ''): string
{
    $path = trim($path);
    if ($path === '' || $path === '/') {
        return url('/');
    }

    $path = ltrim($path, '/');
    $path = preg_replace('/\.php($|\?)/', '$1', $path);

    $aliases = [
        'servicos' => 'services',
        'noticias' => 'news',
        'contacto' => 'contato',
        'nosso-grupo' => 'equipe',
    ];

    $file = strtolower(explode('?', $path, 2)[0]);
    $query = str_contains($path, '?') ? substr($path, strpos($path, '?')) : '';

    if (isset($aliases[$file])) {
        $file = $aliases[$file];
    }

    // servico.php?slug=x ou noticia.php?slug=x
    if ($file === 'servico' && preg_match('/[?&]slug=([^&]+)/', $query, $m)) {
        return url('/servico/' . rawurlencode(rawurldecode($m[1])));
    }
    if ($file === 'noticia' && preg_match('/[?&]slug=([^&]+)/', $query, $m)) {
        return url('/noticia/' . rawurlencode(rawurldecode($m[1])));
    }

    // Formato servico/slug ou noticia/slug
    if (preg_match('#^servico/([a-z0-9\-]+)$#i', $file, $m)) {
        return url('/servico/' . rawurlencode($m[1]) . $query);
    }
    if (preg_match('#^noticia/([a-z0-9\-]+)$#i', $file, $m)) {
        return url('/noticia/' . rawurlencode($m[1]) . $query);
    }

    $pages = [
        'sobre', 'missao', 'valores', 'equipe', 'services', 'news',
        'contato', 'carreiras', 'galeria', 'depoimento', 'servico', 'noticia',
    ];
    if (in_array($file, $pages, true)) {
        return url('/' . $file . $query);
    }

    return url('/' . $file . $query);
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

/** CSS SweetAlert2 (incluir no &lt;head&gt;). */
function nap_swal_styles(): void
{
    static $once = false;
    if ($once) {
        return;
    }
    $once = true;
    echo '<link rel="stylesheet" href="' . e(url('/vendor/sweetalert2/sweetalert2.min.css')) . '">' . "\n";
}

/** JS SweetAlert2 + integração NAP (antes de &lt;/body&gt;). */
function nap_swal_scripts(): void
{
    static $once = false;
    if ($once) {
        return;
    }
    $once = true;
    echo '<script src="' . e(url('/vendor/sweetalert2/sweetalert2.all.min.js')) . '"></script>' . "\n";
    echo '<script src="' . e(url('/js/swal-nap.js')) . '"></script>' . "\n";
}

function slugify(string $text): string
{
    $map = [
        'á'=>'a','à'=>'a','ã'=>'a','â'=>'a','ä'=>'a',
        'é'=>'e','è'=>'e','ê'=>'e','ë'=>'e',
        'í'=>'i','ì'=>'i','î'=>'i','ï'=>'i',
        'ó'=>'o','ò'=>'o','õ'=>'o','ô'=>'o','ö'=>'o',
        'ú'=>'u','ù'=>'u','û'=>'u','ü'=>'u',
        'ç'=>'c','ñ'=>'n',
    ];
    $text = mb_strtolower(trim($text), 'UTF-8');
    $text = strtr($text, $map);
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    $text = trim($text, '-');
    return $text !== '' ? $text : 'item-' . time();
}

function format_date(?string $date, string $format = 'd/m/Y H:i'): string
{
    if (!$date) {
        return '—';
    }
    return date($format, strtotime($date));
}

function upload_image(array $file, string $subdir = 'geral'): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return null;
    }

    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowed, true)) {
        throw new RuntimeException('Formato de imagem inválido. Use JPG, PNG, WEBP ou GIF.');
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        throw new RuntimeException('Imagem demasiado grande (máx. 5MB).');
    }

    $dir = rtrim(UPLOAD_DIR, '/\\') . DIRECTORY_SEPARATOR . $subdir;
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) ?: 'jpg';
    $name = uniqid('img_', true) . '.' . $ext;
    $dest = $dir . DIRECTORY_SEPARATOR . $name;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        throw new RuntimeException('Falha ao guardar a imagem.');
    }

    return $subdir . '/' . $name;
}

function delete_upload(?string $relativePath): void
{
    if (!$relativePath) {
        return;
    }
    $full = rtrim(UPLOAD_DIR, '/\\') . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $relativePath);
    if (is_file($full)) {
        unlink($full);
    }
}

function is_upload_path(?string $path): bool
{
    $path = trim((string) $path);
    return $path !== '' && !preg_match('#^https?://#i', $path);
}

/** Logótipo de parceiro/cliente — caminho local em uploads/ ou URL externa. */
function partner_logo_url(?string $imagem): string
{
    $imagem = trim((string) $imagem);
    if ($imagem === '') {
        return '';
    }
    if (preg_match('#^https?://#i', $imagem)) {
        return $imagem;
    }
    return rtrim(UPLOAD_URL, '/') . '/' . ltrim(str_replace('\\', '/', $imagem), '/');
}

function upload_brand_logo(array $file, string $subdir): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return null;
    }

    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowed, true)) {
        throw new RuntimeException('Formato inválido. Use JPG, PNG, WEBP, GIF ou SVG.');
    }

    if ($file['size'] > 3 * 1024 * 1024) {
        throw new RuntimeException('Logótipo demasiado grande (máx. 3MB).');
    }

    return upload_file($file, $subdir, $allowed, 3 * 1024 * 1024);
}

function status_badge(string $status): string
{
    $map = [
        'publicado'  => 'badge-success',
        'rascunho'   => 'badge-warning',
        'ativo'      => 'badge-success',
        'inativo'    => 'badge-muted',
        'nova'       => 'badge-info',
        'lida'       => 'badge-muted',
        'respondida' => 'badge-success',
        'pendente'   => 'badge-warning',
        'aprovada'   => 'badge-success',
        'rejeitada'  => 'badge-danger',
        'rejeitado'  => 'badge-danger',
        'aberto'       => 'badge-info',
        'em_andamento' => 'badge-warning',
        'resolvido'    => 'badge-success',
        'fechado'      => 'badge-muted',
        'planeamento'  => 'badge-info',
        'em_curso'     => 'badge-warning',
        'pausado'      => 'badge-muted',
        'concluido'    => 'badge-success',
        'cancelado'    => 'badge-danger',
        'manutencao'   => 'badge-warning',
        'baixa'        => 'badge-muted',
    ];
    $labels = [
        'ativo'      => 'Ativo',
        'inativo'    => 'Inativo',
        'pendente'   => 'Pendente',
        'rejeitado'  => 'Rejeitado',
        'publicado'  => 'Publicado',
        'rascunho'   => 'Rascunho',
        'nova'       => 'Nova',
        'lida'       => 'Lida',
        'respondida' => 'Respondida',
        'aprovada'   => 'Aprovada',
        'rejeitada'  => 'Rejeitada',
        'aberto'       => 'Aberto',
        'em_andamento' => 'Em andamento',
        'resolvido'    => 'Resolvido',
        'fechado'      => 'Fechado',
        'planeamento'  => 'Planeamento',
        'em_curso'     => 'Em curso',
        'pausado'      => 'Pausado',
        'concluido'    => 'Concluído',
        'cancelado'    => 'Cancelado',
        'manutencao'   => 'Manutenção',
        'baixa'        => 'Baixa',
    ];
    $class = $map[$status] ?? 'badge-muted';
    $label = $labels[$status] ?? ucfirst($status);
    return '<span class="badge ' . $class . '">' . e($label) . '</span>';
}

/**
 * Garante colunas e estados da tabela depoimentos (instalação já existente).
 */
function ensure_depoimentos_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $cols = array_column(db()->query('SHOW COLUMNS FROM depoimentos')->fetchAll(), 'Field');
        if (!$cols) {
            return;
        }
        if (!in_array('email', $cols, true)) {
            db()->exec("ALTER TABLE depoimentos ADD COLUMN email VARCHAR(160) NULL AFTER nome");
        }
        if (!in_array('origem', $cols, true)) {
            db()->exec("ALTER TABLE depoimentos ADD COLUMN origem ENUM('cliente','admin') NOT NULL DEFAULT 'admin' AFTER ordem");
        }
        $statusCol = db()->query("SHOW COLUMNS FROM depoimentos LIKE 'status'")->fetch();
        $type = strtolower((string) ($statusCol['Type'] ?? ''));
        if ($type !== '' && !str_contains($type, 'pendente')) {
            db()->exec("ALTER TABLE depoimentos MODIFY COLUMN status ENUM('pendente','ativo','inativo','rejeitado') NOT NULL DEFAULT 'pendente'");
        }
    } catch (Throwable $e) {
        // Tabela ainda não existe (ex.: antes da instalação).
    }
}

function ensure_parceiros_clientes_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        db()->exec("CREATE TABLE IF NOT EXISTS parceiros (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(180) NOT NULL,
            imagem VARCHAR(500) NULL,
            link VARCHAR(500) NULL,
            descricao VARCHAR(255) NULL,
            icone VARCHAR(80) NOT NULL DEFAULT 'fa-handshake',
            ordem INT NOT NULL DEFAULT 0,
            status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        db()->exec("CREATE TABLE IF NOT EXISTS clientes (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(180) NOT NULL,
            imagem VARCHAR(500) NULL,
            link VARCHAR(500) NULL,
            descricao VARCHAR(255) NULL,
            icone VARCHAR(80) NOT NULL DEFAULT 'fa-building',
            ordem INT NOT NULL DEFAULT 0,
            status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        if ((int) db()->query('SELECT COUNT(*) FROM parceiros')->fetchColumn() === 0) {
            $partners = [
                ['Gabinete Provincial dos Registos e Modernização Administrativa do Uíge', 'fa-landmark'],
                ['ETIC', 'fa-building-columns'], ['INAPEM', 'fa-briefcase'], ['WONGO', 'fa-handshake'],
                ['ALDACUNHA', 'fa-building'], ['MAYAFARMA', 'fa-prescription-bottle-medical'], ['PACIOLITA', 'fa-industry'],
                ['PERDIDOS E ACHADOS', 'fa-magnifying-glass'], ['Administração Municipal do Uíge', 'fa-city'],
                ['Administração de Negas', 'fa-people-roof'], ['INFORMATIZA (SU), LDA', 'fa-microchip'],
            ];
            $stmt = db()->prepare('INSERT INTO parceiros (nome, imagem, icone, ordem, status) VALUES (?, ?, ?, ?, "ativo")');
            foreach ($partners as $order => [$name, $icon]) {
                $image = 'https://ui-avatars.com/api/?name=' . rawurlencode($name) . '&size=160&background=071B4A&color=FFFFFF&bold=true&font-size=0.22';
                $stmt->execute([$name, $image, $icon, $order + 1]);
            }
        }
        if ((int) db()->query('SELECT COUNT(*) FROM clientes')->fetchColumn() === 0) {
            $clients = [
                ['Empresas', 'fa-building'], ['Instituições', 'fa-landmark'], ['Comércio', 'fa-store'],
                ['Particulares', 'fa-user-group'], ['Escolas', 'fa-school'], ['Clínicas', 'fa-hospital'],
                ['Indústrias', 'fa-industry'], ['Hotelaria', 'fa-hotel'], ['Profissionais', 'fa-briefcase'],
                ['Organizações', 'fa-people-group'],
            ];
            $stmt = db()->prepare('INSERT INTO clientes (nome, imagem, icone, ordem, status) VALUES (?, ?, ?, ?, "ativo")');
            foreach ($clients as $order => [$name, $icon]) {
                $image = 'https://ui-avatars.com/api/?name=' . rawurlencode($name) . '&size=160&background=16B7E8&color=FFFFFF&bold=true';
                $stmt->execute([$name, $image, $icon, $order + 1]);
            }
        }
    } catch (Throwable $e) {
        // A base de dados pode ainda não existir durante a instalação.
    }
}

function ensure_agenda_schema(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS agenda (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            titulo VARCHAR(200) NOT NULL,
            resumo VARCHAR(255) NULL,
            descricao TEXT NULL,
            data_evento DATETIME NULL,
            local_evento VARCHAR(180) NULL,
            foto1 VARCHAR(255) NULL,
            foto2 VARCHAR(255) NULL,
            foto3 VARCHAR(255) NULL,
            foto4 VARCHAR(255) NULL,
            foto5 VARCHAR(255) NULL,
            status ENUM('publicado','rascunho') NOT NULL DEFAULT 'rascunho',
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $e) {
        // A base de dados pode ainda não existir durante a instalação.
    }
}

function ensure_pca_schema(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS mensagem_pca (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(160) NOT NULL,
            cargo VARCHAR(160) NOT NULL,
            mensagem TEXT NOT NULL,
            foto VARCHAR(255) NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        if ((int) db()->query('SELECT COUNT(*) FROM mensagem_pca')->fetchColumn() === 0) {
            db()->prepare('INSERT INTO mensagem_pca (nome, cargo, mensagem, foto, ativo) VALUES (?,?,?,?,1)')->execute([
                'DOMINGOS MIGUEL PANZO',
                'Presidente do Conselho de Administração',
                'Na INFORMATIZA (SU), LDA acreditamos que a tecnologia deve tornar o trabalho mais simples, seguro e eficiente. Há seis anos trabalhamos para levar soluções de qualidade às empresas e comunidades de Angola, com proximidade, responsabilidade e compromisso com o futuro.',
                'domingos-miguel-panzo.jpg',
            ]);
        }
    } catch (Throwable $e) {
        // A base de dados pode ainda não existir durante a instalação.
    }
}

function ensure_certificacoes_schema(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS certificacoes (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            titulo VARCHAR(180) NOT NULL,
            entidade VARCHAR(180) NULL,
            descricao VARCHAR(255) NULL,
            imagem VARCHAR(500) NULL,
            link VARCHAR(500) NULL,
            ordem INT NOT NULL DEFAULT 0,
            status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $e) {
        // A base de dados pode ainda não existir durante a instalação.
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        flash('error', 'Token de segurança inválido. Tente novamente.');
        redirect($_SERVER['HTTP_REFERER'] ?? '/admin/dashboard.php');
    }
}

function count_table(string $table, string $where = '1=1', array $params = []): int
{
    $stmt = db()->prepare("SELECT COUNT(*) FROM {$table} WHERE {$where}");
    $stmt->execute($params);
    return (int) $stmt->fetchColumn();
}

function setting(string $chave, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $rows = db()->query('SELECT chave, valor FROM configuracoes')->fetchAll();
            foreach ($rows as $row) {
                $cache[$row['chave']] = (string) ($row['valor'] ?? '');
            }
        } catch (Throwable $e) {
            $cache = [];
        }
    }
    return $cache[$chave] ?? $default;
}

/** Slogan oficial (logomarca INFORMATIZA). */
function site_tagline(): string
{
    return defined('APP_TAGLINE') ? APP_TAGLINE : 'Tecnologia que ajuda o país';
}

/** Nome público da marca (alinhado com APP_NAME após rebrand). */
function site_nome(): string
{
    $nome = trim(setting('site_nome', APP_NAME));
    if ($nome === '' || strcasecmp($nome, 'NACIONAL AJUDA O PAÍS') === 0 || strcasecmp($nome, 'NFORMATIZA (SU), LDA') === 0) {
        return APP_NAME;
    }
    return $nome;
}

/** Actualiza site_nome legado na BD para o nome actual da aplicação. */
function ensure_site_branding(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
        $stmt = db()->query("SELECT valor FROM configuracoes WHERE chave = 'site_nome' LIMIT 1");
        $current = trim((string) ($stmt->fetchColumn() ?: ''));
        if ($current === '' || strcasecmp($current, 'NACIONAL AJUDA O PAÍS') === 0 || strcasecmp($current, 'NFORMATIZA (SU), LDA') === 0) {
            db()->prepare("INSERT INTO configuracoes (chave, valor) VALUES ('site_nome', ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)")
                ->execute([APP_NAME]);
        }
    } catch (Throwable $e) {
        // BD pode ainda não existir
    }
}

function upload_file(array $file, string $subdir, array $allowedMimes, int $maxBytes = 5242880): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return null;
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowedMimes, true)) {
        throw new RuntimeException('Formato de ficheiro inválido.');
    }

    if ($file['size'] > $maxBytes) {
        throw new RuntimeException('Ficheiro demasiado grande.');
    }

    $dir = rtrim(UPLOAD_DIR, '/\\') . DIRECTORY_SEPARATOR . $subdir;
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) ?: 'bin';
    $name = uniqid('file_', true) . '.' . $ext;
    $dest = $dir . DIRECTORY_SEPARATOR . $name;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        throw new RuntimeException('Falha ao guardar o ficheiro.');
    }

    return $subdir . '/' . $name;
}

function media_url(?string $relativePath, string $fallback = ''): string
{
    if ($relativePath) {
        return rtrim(UPLOAD_URL, '/') . '/' . ltrim(str_replace('\\', '/', $relativePath), '/');
    }
    return $fallback !== '' ? $fallback : url('/imgs/logo-informatiza.svg');
}

/**
 * Email de atendimento geral (destino dos formulários de contacto).
 */
function contact_inbox_email(): string
{
    return setting('site_email', 'geralnacionalajudaopais@gmail.com') ?: 'geralnacionalajudaopais@gmail.com';
}

/**
 * Email de Recursos Humanos (destino das candidaturas).
 */
function hr_inbox_email(): string
{
    return setting('site_email', 'geralnacionalajudaopais@gmail.com') ?: 'geralnacionalajudaopais@gmail.com';
}

/**
 * Envia a mensagem do formulário de contacto por email.
 */
function send_contact_mail(
    string $nome,
    string $email,
    string $telefone,
    string $assunto,
    string $mensagem
): bool {
    $to = contact_inbox_email();
    $subjectLine = $assunto !== '' ? $assunto : 'Nova mensagem do site';
    $subject = '[Contacto INFORMATIZA] ' . $subjectLine;

    $body = "Nova mensagem recebida pelo formulário de contacto do site.\n\n"
        . "Nome: {$nome}\n"
        . "Email: {$email}\n"
        . "Telefone: " . ($telefone !== '' ? $telefone : '—') . "\n"
        . "Assunto: " . ($assunto !== '' ? $assunto : '—') . "\n\n"
        . "Mensagem:\n{$mensagem}\n\n"
        . "---\nEnviado em " . date('d/m/Y H:i') . " (Africa/Luanda)\n";

    $fromName = setting('site_nome', APP_NAME);
    $fromEmail = $to;
    $headers = [
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'From: ' . sprintf('%s <%s>', mb_encode_mimeheader($fromName, 'UTF-8'), $fromEmail),
        'Reply-To: ' . sprintf('%s <%s>', mb_encode_mimeheader($nome, 'UTF-8'), $email),
        'X-Mailer: PHP/' . PHP_VERSION,
    ];

    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';

    return @mail($to, $encodedSubject, $body, implode("\r\n", $headers));
}

/**
 * Envia notificação de candidatura para Recursos Humanos.
 * @param string|null $cvRelativePath caminho relativo em uploads/ (ex.: cv/file.pdf)
 */
function send_candidatura_mail(
    string $nome,
    string $email,
    string $telefone,
    string $vaga,
    string $mensagem,
    ?string $cvRelativePath = null
): bool {
    $to = hr_inbox_email();
    $subject = '[Candidatura INFORMATIZA] ' . ($vaga !== '' ? $vaga : 'Candidatura espontânea') . ' — ' . $nome;

    $textBody = "Nova candidatura recebida pelo site.\n\n"
        . "Nome: {$nome}\n"
        . "Email: {$email}\n"
        . "Telefone: " . ($telefone !== '' ? $telefone : '—') . "\n"
        . "Vaga: " . ($vaga !== '' ? $vaga : 'Candidatura espontânea') . "\n\n"
        . "Mensagem:\n" . ($mensagem !== '' ? $mensagem : '—') . "\n\n";

    if ($cvRelativePath) {
        $textBody .= "CV no painel: " . media_url($cvRelativePath) . "\n";
    }

    $textBody .= "\n---\nEnviado em " . date('d/m/Y H:i') . " (Africa/Luanda)\n";

    $fromName = setting('site_nome', APP_NAME);
    $fromEmail = contact_inbox_email();
    $replyTo = sprintf('%s <%s>', mb_encode_mimeheader($nome, 'UTF-8'), $email);
    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';

    $cvPath = null;
    if ($cvRelativePath) {
        $candidate = rtrim(UPLOAD_DIR, '/\\') . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $cvRelativePath);
        if (is_file($candidate)) {
            $cvPath = $candidate;
        }
    }

    if ($cvPath) {
        $boundary = '=_Informatiza_' . md5(uniqid((string) mt_rand(), true));
        $filename = basename($cvPath);
        $mime = mime_content_type($cvPath) ?: 'application/octet-stream';
        $fileData = chunk_split(base64_encode((string) file_get_contents($cvPath)));

        $body = "--{$boundary}\r\n"
            . "Content-Type: text/plain; charset=UTF-8\r\n"
            . "Content-Transfer-Encoding: 8bit\r\n\r\n"
            . $textBody . "\r\n"
            . "--{$boundary}\r\n"
            . "Content-Type: {$mime}; name=\"{$filename}\"\r\n"
            . "Content-Transfer-Encoding: base64\r\n"
            . "Content-Disposition: attachment; filename=\"{$filename}\"\r\n\r\n"
            . $fileData . "\r\n"
            . "--{$boundary}--\r\n";

        $headers = [
            'MIME-Version: 1.0',
            'Content-Type: multipart/mixed; boundary="' . $boundary . '"',
            'From: ' . sprintf('%s <%s>', mb_encode_mimeheader($fromName, 'UTF-8'), $fromEmail),
            'Reply-To: ' . $replyTo,
            'X-Mailer: PHP/' . PHP_VERSION,
        ];
    } else {
        $body = $textBody;
        $headers = [
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'From: ' . sprintf('%s <%s>', mb_encode_mimeheader($fromName, 'UTF-8'), $fromEmail),
            'Reply-To: ' . $replyTo,
            'X-Mailer: PHP/' . PHP_VERSION,
        ];
    }

    return @mail($to, $encodedSubject, $body, implode("\r\n", $headers));
}

/**
 * Notifica o atendimento de um novo depoimento enviado por um cliente.
 */
function send_depoimento_mail(
    string $nome,
    string $email,
    string $cargo,
    string $texto,
    int $nota
): bool {
    $to = contact_inbox_email();
    $subject = '[Depoimento INFORMATIZA] Novo testemunho de ' . $nome;

    $body = "Um cliente enviou um depoimento pelo site. Está pendente de validação no painel.\n\n"
        . "Nome: {$nome}\n"
        . "Email: " . ($email !== '' ? $email : '—') . "\n"
        . "Cargo / Empresa: " . ($cargo !== '' ? $cargo : '—') . "\n"
        . "Nota: {$nota}/5\n\n"
        . "Depoimento:\n{$texto}\n\n"
        . "---\nEnviado em " . date('d/m/Y H:i') . " (Africa/Luanda)\n"
        . "Valide em Admin → Depoimentos.\n";

    $fromName = setting('site_nome', APP_NAME);
    $fromEmail = $to;
    $headers = [
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'From: ' . sprintf('%s <%s>', mb_encode_mimeheader($fromName, 'UTF-8'), $fromEmail),
        'Reply-To: ' . ($email !== '' ? sprintf('%s <%s>', mb_encode_mimeheader($nome, 'UTF-8'), $email) : $fromEmail),
        'X-Mailer: PHP/' . PHP_VERSION,
    ];

    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';

    return @mail($to, $encodedSubject, $body, implode("\r\n", $headers));
}
