<?php
/**
 * Recursos Humanos — vagas, ausências, indicadores e dashboard.
 */

function ensure_rh_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    ensure_contabilidade_schema();
    $sqlFile = __DIR__ . '/../sql/rh.sql';
    if (is_file($sqlFile)) {
        db()->exec((string) file_get_contents($sqlFile));
    }
    $done = true;
}

/** Cria utilizador RH predefinido se ainda não existir (evita login sem correr o script CLI). */
function ensure_rh_default_user(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    ensure_usuario_niveis();
    $email = 'rh@informatiza.ao';
    $check = db()->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
    $check->execute([$email]);
    if ($check->fetchColumn()) {
        return;
    }
    db()->prepare('INSERT INTO usuarios (nome, email, senha, nivel, ativo) VALUES (?,?,?,?,1)')
        ->execute([
            'Recursos Humanos',
            $email,
            password_hash('Rh2026!', PASSWORD_DEFAULT),
            'rh',
        ]);
}

/** @return list<array<string,mixed>> */
function rh_vagas_abertas(): array
{
    ensure_rh_schema();

    return db()->query("SELECT * FROM rh_vagas WHERE status='aberta' ORDER BY titulo")->fetchAll(PDO::FETCH_ASSOC);
}

/** @return array<string,int|float> */
function rh_dashboard_kpis(): array
{
    ensure_rh_schema();
    $mesIni = date('Y-m-01') . ' 00:00:00';
    $candPend = (int) db()->query("SELECT COUNT(*) FROM candidaturas WHERE status='pendente'")->fetchColumn();
    $stmtCandMes = db()->prepare('SELECT COUNT(*) FROM candidaturas WHERE criado_em >= ?');
    $stmtCandMes->execute([$mesIni]);
    $candMes = (int) $stmtCandMes->fetchColumn();

    $funcAct = (int) db()->query('SELECT COUNT(*) FROM cont_funcionarios WHERE ativo=1')->fetchColumn();
    $equipeSite = (int) db()->query("SELECT COUNT(*) FROM equipe WHERE status='ativo'")->fetchColumn();
    $vagasAb = (int) db()->query("SELECT COUNT(*) FROM rh_vagas WHERE status='aberta'")->fetchColumn();
    $ausPend = (int) db()->query("SELECT COUNT(*) FROM rh_ausencias WHERE estado='pendente'")->fetchColumn();

    $massa = db()->query(
        'SELECT COALESCE(SUM(salario_base + subsidio),0) FROM cont_funcionarios WHERE ativo=1'
    )->fetchColumn();

    $folhaMes = db()->prepare(
        'SELECT total_liquido FROM cont_folhas WHERE ano=? AND mes=? AND estado=? ORDER BY id DESC LIMIT 1'
    );
    $folhaMes->execute([(int) date('Y'), (int) date('n'), 'processada']);
    $liquidoFolha = (float) ($folhaMes->fetchColumn() ?: 0);

    return [
        'candidaturas_pendentes' => $candPend,
        'candidaturas_mes' => $candMes,
        'funcionarios_ativos' => $funcAct,
        'equipe_site' => $equipeSite,
        'vagas_abertas' => $vagasAb,
        'ausencias_pendentes' => $ausPend,
        'massa_salarial_bruta' => round((float) $massa, 2),
        'folha_liquida_mes' => $liquidoFolha,
    ];
}

/** @return array{labels:list<string>,total:list<int>,aprovadas:list<int>} */
function rh_candidaturas_series(int $months = 6): array
{
    $labels = [];
    $total = [];
    $aprovadas = [];
    for ($i = $months - 1; $i >= 0; $i--) {
        $t = strtotime("-{$i} months");
        $ym = date('Y-m', $t);
        $labels[] = date('m/Y', $t);
        $from = $ym . '-01';
        $to = date('Y-m-t', strtotime($from));
        $st = db()->prepare('SELECT COUNT(*) FROM candidaturas WHERE DATE(criado_em) BETWEEN ? AND ?');
        $st->execute([$from, $to]);
        $total[] = (int) $st->fetchColumn();
        $sa = db()->prepare("SELECT COUNT(*) FROM candidaturas WHERE status='aprovada' AND DATE(criado_em) BETWEEN ? AND ?");
        $sa->execute([$from, $to]);
        $aprovadas[] = (int) $sa->fetchColumn();
    }

    return compact('labels', 'total', 'aprovadas');
}

/** @return array{pendente:int,aprovada:int,rejeitada:int} */
function rh_pipeline_candidaturas(): array
{
    $rows = db()->query('SELECT status, COUNT(*) AS n FROM candidaturas GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);

    return [
        'pendente' => (int) ($rows['pendente'] ?? 0),
        'aprovada' => (int) ($rows['aprovada'] ?? 0),
        'rejeitada' => (int) ($rows['rejeitada'] ?? 0),
    ];
}

/** @return array{labels:list<string>,liquido:list<float>,bruto:list<float>} */
function rh_folha_series(int $months = 6): array
{
    ensure_contabilidade_schema();
    $labels = [];
    $liquido = [];
    $bruto = [];
    for ($i = $months - 1; $i >= 0; $i--) {
        $t = strtotime("-{$i} months");
        $ano = (int) date('Y', $t);
        $mes = (int) date('n', $t);
        $labels[] = sprintf('%02d/%04d', $mes, $ano);
        $f = db()->prepare('SELECT total_bruto, total_liquido FROM cont_folhas WHERE ano=? AND mes=? ORDER BY id DESC LIMIT 1');
        $f->execute([$ano, $mes]);
        $row = $f->fetch(PDO::FETCH_ASSOC);
        $bruto[] = $row ? (float) $row['total_bruto'] : 0.0;
        $liquido[] = $row ? (float) $row['total_liquido'] : 0.0;
    }

    return compact('labels', 'liquido', 'bruto');
}

/** @return list<array<string,mixed>> */
function rh_ultimas_candidaturas(int $limit = 8): array
{
    $limit = max(1, min(50, $limit));
    $stmt = db()->query(
        'SELECT id, nome, email, vaga, status, criado_em FROM candidaturas ORDER BY id DESC LIMIT ' . (int) $limit
    );

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/** @return list<array<string,mixed>> */
function rh_ausencias_proximas(int $limit = 6): array
{
    ensure_rh_schema();
    $limit = max(1, min(30, $limit));
    $today = date('Y-m-d');
    $stmt = db()->prepare(
        "SELECT a.*, f.nome AS funcionario_nome FROM rh_ausencias a
         INNER JOIN cont_funcionarios f ON f.id=a.funcionario_id
         WHERE a.data_fim >= ? AND a.estado IN ('pendente','aprovada')
         ORDER BY a.data_inicio ASC LIMIT {$limit}"
    );
    $stmt->execute([$today]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/** Aniversários de admissão no mês corrente. */
function rh_admissoes_mes(): array
{
    $mes = (int) date('n');
    $stmt = db()->prepare(
        'SELECT id, nome, cargo, data_admissao FROM cont_funcionarios
         WHERE ativo=1 AND data_admissao IS NOT NULL AND MONTH(data_admissao)=? ORDER BY DAY(data_admissao)'
    );
    $stmt->execute([$mes]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
