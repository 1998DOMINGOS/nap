<?php

function attempt_login(string $email, string $password): bool
{
    $stmt = db()->prepare('SELECT * FROM usuarios WHERE email = ? AND ativo = 1 LIMIT 1');
    $stmt->execute([trim(strtolower($email))]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['senha'])) {
        return false;
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['user_nome'] = $user['nome'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_nivel'] = $user['nivel'];

    $upd = db()->prepare('UPDATE usuarios SET ultimo_acesso = NOW() WHERE id = ?');
    $upd->execute([$user['id']]);

    return true;
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

function require_login(): void
{
    if (!is_logged_in()) {
        flash('error', 'Faça login para aceder ao painel.');
        redirect('/admin/index.php');
    }
}

function ensure_usuario_niveis(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
        db()->exec("ALTER TABLE usuarios MODIFY nivel ENUM('admin','editor','contabilista','faturacao','rh','ti') NOT NULL DEFAULT 'editor'");
    } catch (Throwable $e) {
        // ignore
    }
}

function is_contabilista(): bool
{
    return ($_SESSION['user_nivel'] ?? '') === 'contabilista';
}

function is_faturacao(): bool
{
    return ($_SESSION['user_nivel'] ?? '') === 'faturacao';
}

function is_rh(): bool
{
    return ($_SESSION['user_nivel'] ?? '') === 'rh';
}

function is_ti(): bool
{
    return ($_SESSION['user_nivel'] ?? '') === 'ti';
}

function is_admin_user(): bool
{
    return ($_SESSION['user_nivel'] ?? '') === 'admin';
}

/** Página inicial após login consoante o perfil. */
function auth_home_path(): string
{
    if (is_contabilista()) {
        return '/admin/contabilidade/dashboard.php';
    }
    if (is_faturacao()) {
        return '/admin/facturacao/index.php';
    }
    if (is_rh()) {
        return '/admin/rh/dashboard.php';
    }
    if (is_ti()) {
        return '/admin/tecnologia/dashboard.php';
    }

    return '/admin/dashboard.php';
}

function require_facturacao(): void
{
    require_login();
    ensure_usuario_niveis();
    if (is_contabilista()) {
        flash('error', 'Sem permissão para facturação.');
        redirect(auth_home_path());
    }
    $n = $_SESSION['user_nivel'] ?? '';
    if (!in_array($n, ['admin', 'faturacao'], true)) {
        flash('error', 'Acesso reservado ao módulo de facturação.');
        redirect(auth_home_path());
    }
    $u = current_user();
    if ($u && function_exists('fat_agt_password_expirada') && fat_agt_password_expirada($u)) {
        $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
        if (!in_array($script, ['editar.php', 'logout.php', 'index.php'], true) || ($script === 'editar.php' && (int) ($_GET['id'] ?? 0) !== (int) $u['id'])) {
            flash('error', 'Palavra-passe expirada. Altere-a no seu perfil (requisito AGT).');
            redirect('/admin/usuarios/editar.php?id=' . (int) $u['id']);
        }
    }
}

function require_admin(): void
{
    require_login();
    ensure_usuario_niveis();
    if (is_contabilista()) {
        flash('error', 'Área reservada à administração geral.');
        redirect(auth_home_path());
    }
    if (is_faturacao()) {
        flash('error', 'Área reservada a administradores.');
        redirect(auth_home_path());
    }
    if (!is_admin_user()) {
        flash('error', 'Acesso restrito a administradores.');
        redirect(auth_home_path());
    }
    $u = current_user();
    if ($u && function_exists('fat_agt_password_expirada') && fat_agt_password_expirada($u)) {
        $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
        if (!in_array($script, ['editar.php', 'logout.php', 'index.php'], true) || ($script === 'editar.php' && (int) ($_GET['id'] ?? 0) !== (int) $u['id'])) {
            flash('error', 'Palavra-passe expirada. Altere-a no seu perfil (requisito AGT).');
            redirect('/admin/usuarios/editar.php?id=' . (int) $u['id']);
        }
    }
}

/** Recursos Humanos (admin, editor ou perfil RH). */
function require_rh(): void
{
    require_login();
    ensure_usuario_niveis();
    $n = $_SESSION['user_nivel'] ?? '';
    if (!in_array($n, ['admin', 'editor', 'rh'], true)) {
        flash('error', 'Acesso reservado ao módulo de Recursos Humanos.');
        redirect(auth_home_path());
    }
}

/** Departamento de Tecnologia (admin, editor ou perfil TI). */
function require_ti(): void
{
    require_login();
    ensure_usuario_niveis();
    $n = $_SESSION['user_nivel'] ?? '';
    if (!in_array($n, ['admin', 'editor', 'ti'], true)) {
        flash('error', 'Acesso reservado ao Departamento de Tecnologia.');
        redirect(auth_home_path());
    }
}

/** Contabilidade + salários + declarações (contabilista ou admin). */
function require_contabilidade(): void
{
    require_login();
    ensure_usuario_niveis();
    $n = $_SESSION['user_nivel'] ?? '';
    if (!in_array($n, ['admin', 'contabilista'], true)) {
        flash('error', 'Acesso reservado ao módulo de contabilidade.');
        redirect('/admin/dashboard.php');
    }
}

function require_staff(): void
{
    require_login();
    ensure_usuario_niveis();
    if (is_contabilista() || is_faturacao() || is_rh() || is_ti()) {
        flash('error', 'Sem permissão para esta área.');
        redirect(auth_home_path());
    }
}

function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    return [
        'id'    => $_SESSION['user_id'],
        'nome'  => $_SESSION['user_nome'],
        'email' => $_SESSION['user_email'],
        'nivel' => $_SESSION['user_nivel'],
    ];
}

function user_initials(?string $nome = null): string
{
    $nome = $nome ?? ($_SESSION['user_nome'] ?? 'A');
    $parts = preg_split('/\s+/', trim($nome));
    $ini = strtoupper(mb_substr($parts[0], 0, 1));
    if (count($parts) > 1) {
        $ini .= strtoupper(mb_substr(end($parts), 0, 1));
    }
    return $ini;
}
