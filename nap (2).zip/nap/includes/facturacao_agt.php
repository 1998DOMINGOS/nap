<?php
/**
 * Integração API AGT — Facturação Electrónica schema 2.0.
 * Serviços: registarFactura, obterEstado, consultarFactura, listarFacturas,
 * validarDocumento, anularFactura.
 * @see https://quiosqueagt.minfin.gov.ao/doc-agt/doc-agt/2/servicos/especificados.html
 */

function fat_agt_ensure_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $colsEmpresa = [
        'agt_ambiente VARCHAR(20) NOT NULL DEFAULT \'homologacao\' AFTER aviso_certificacao',
        'agt_api_user VARCHAR(120) NULL AFTER agt_ambiente',
        'agt_api_pass VARCHAR(255) NULL AFTER agt_api_user',
        'agt_auto_envio TINYINT(1) NOT NULL DEFAULT 1 AFTER agt_api_pass',
        'agt_simular TINYINT(1) NOT NULL DEFAULT 0 AFTER agt_auto_envio',
        'agt_eac_code VARCHAR(10) NULL AFTER agt_simular',
        'agt_signature_version INT NOT NULL DEFAULT 1 AFTER agt_eac_code',
        'agt_chave_produtor_path VARCHAR(255) NULL AFTER agt_signature_version',
        'agt_chave_emitente_path VARCHAR(255) NULL AFTER agt_chave_produtor_path',
        'agt_software_product_id VARCHAR(80) NULL AFTER agt_chave_emitente_path',
        'agt_anexo_chave_path VARCHAR(255) NULL AFTER agt_software_product_id',
        'agt_anexo_saft_path VARCHAR(255) NULL AFTER agt_anexo_chave_path',
    ];
    foreach ($colsEmpresa as $column) {
        try {
            $name = strtok($column, ' ');
            $exists = db()->query("SHOW COLUMNS FROM fat_empresa LIKE '" . $name . "'")->fetch();
            if (!$exists) {
                db()->exec('ALTER TABLE fat_empresa ADD COLUMN ' . $column);
            }
        } catch (Throwable $e) {
            // ignore
        }
    }

    $colsDoc = [
        'fe_request_id VARCHAR(20) NULL AFTER hash_control',
        'fe_validation_status VARCHAR(4) NULL AFTER fe_request_id',
        'fe_agt_estado VARCHAR(30) NULL AFTER fe_validation_status',
        'fe_rejected_document_no VARCHAR(60) NULL AFTER fe_agt_estado',
        'fe_customer_status VARCHAR(10) NULL AFTER fe_rejected_document_no',
        'fe_motivo_anulacao_agt VARCHAR(255) NULL AFTER fe_customer_status',
    ];
    foreach ($colsDoc as $column) {
        try {
            $name = strtok($column, ' ');
            $exists = db()->query("SHOW COLUMNS FROM fat_documentos LIKE '" . $name . "'")->fetch();
            if (!$exists) {
                db()->exec('ALTER TABLE fat_documentos ADD COLUMN ' . $column);
            }
        } catch (Throwable $e) {
            // ignore
        }
    }

    foreach (['codigo_isencao VARCHAR(3) NULL AFTER taxa_iva'] as $tableCol) {
        foreach (['fat_linhas', 'fat_produtos'] as $table) {
            try {
                $name = strtok($tableCol, ' ');
                $exists = db()->query("SHOW COLUMNS FROM {$table} LIKE '" . $name . "'")->fetch();
                if (!$exists) {
                    db()->exec("ALTER TABLE {$table} ADD COLUMN {$tableCol}");
                }
            } catch (Throwable $e) {
                // ignore
            }
        }
    }

    try {
        db()->exec("ALTER TABLE fat_agt_envios MODIFY estado ENUM('pendente','submetido','processando','validado','rejeitado','erro','anulado') NOT NULL DEFAULT 'pendente'");
    } catch (Throwable $e) {
        // ignore
    }
    foreach (['request_id VARCHAR(20) NULL AFTER documento_id', 'submission_uuid VARCHAR(40) NULL AFTER request_id', 'result_code VARCHAR(4) NULL AFTER resposta'] as $column) {
        try {
            $name = strtok($column, ' ');
            $exists = db()->query("SHOW COLUMNS FROM fat_agt_envios LIKE '" . $name . "'")->fetch();
            if (!$exists) {
                db()->exec('ALTER TABLE fat_agt_envios ADD COLUMN ' . $column);
            }
        } catch (Throwable $e) {
            // ignore
        }
    }
}

function fat_base64url_encode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function fat_agt_key_path(string $role): string
{
    $emp = fat_empresa() ?: [];
    if ($role === 'produtor') {
        $custom = trim((string) ($emp['agt_chave_produtor_path'] ?? ''));
        if ($custom !== '' && is_file($custom)) {
            return $custom;
        }
        if (!empty($emp['chave_privada_path']) && is_file((string) $emp['chave_privada_path'])) {
            return (string) $emp['chave_privada_path'];
        }
    }
    if ($role === 'emitente') {
        $custom = trim((string) ($emp['agt_chave_emitente_path'] ?? ''));
        if ($custom !== '' && is_file($custom)) {
            return $custom;
        }
    }
    $default = fat_keys_dir() . '/private.pem';
    if (!is_file($default)) {
        ensure_facturacao_keys();
    }
    return $default;
}

function fat_agt_private_key_pem(?string $path = null): string
{
    $path = $path ?: fat_agt_key_path('emitente');
    if (!is_file($path)) {
        ensure_facturacao_keys();
        $path = fat_keys_dir() . '/private.pem';
    }
    if (!is_file($path)) {
        throw new RuntimeException('Chave privada AGT indisponível.');
    }
    return (string) file_get_contents($path);
}

function fat_jws_rs256(array $payload, ?string $privateKeyPath = null): string
{
    fat_openssl_bootstrap();
    $header = ['typ' => 'JWT', 'alg' => 'RS256'];
    $segments = fat_base64url_encode(json_encode($header, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))
        . '.' . fat_base64url_encode(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    $key = openssl_pkey_get_private(fat_agt_private_key_pem($privateKeyPath));
    if ($key === false) {
        throw new RuntimeException('Chave privada inválida para JWS.');
    }
    $signature = '';
    if (!openssl_sign($segments, $signature, $key, OPENSSL_ALGO_SHA256)) {
        throw new RuntimeException('Falha ao assinar JWS (RS256).');
    }
    return $segments . '.' . fat_base64url_encode($signature);
}

/** Códigos de isenção IVA (Anexo 6.4 AGT) — subset usado frequentemente. */
function fat_agt_isencao_codigos(): array
{
    return [
        'M10' => 'M10 — Exportação de bens',
        'M11' => 'M11 — Transporte internacional',
        'M12' => 'M12 — Operações relacionadas com navios/aeronaves',
        'M13' => 'M13 — Instrução pública / formação',
        'M14' => 'M14 — Serviços médicos e sanitários',
        'M15' => 'M15 — Locação de imóveis (isento)',
        'M16' => 'M16 — Seguros e resseguros',
        'M17' => 'M17 — Operações financeiras',
        'M18' => 'M18 — Locação de bens móveis',
        'M19' => 'M19 — Outras isenções legalmente previstas',
        'M20' => 'M20 — Regime especial',
        'M21' => 'M21 — Isenção temporária',
        'M22' => 'M22 — Isenção por acordo',
        'M23' => 'M23 — Isenção consular/diplomática',
        'M24' => 'M24 — Outras',
        'M30' => 'M30 — Regime de não sujeição',
        'M80' => 'M80 — Artigo 12.º (outros)',
        'M90' => 'M90 — Não dedutível / outro',
    ];
}

function fat_agt_resolve_isencao(array $linha): string
{
    $code = strtoupper(trim((string) ($linha['codigo_isencao'] ?? '')));
    if ($code !== '' && isset(fat_agt_isencao_codigos()[$code])) {
        return $code;
    }
    if (!empty($linha['produto_id'])) {
        $p = db()->prepare('SELECT codigo_isencao FROM fat_produtos WHERE id=?');
        $p->execute([(int) $linha['produto_id']]);
        $pc = strtoupper(trim((string) $p->fetchColumn()));
        if ($pc !== '' && isset(fat_agt_isencao_codigos()[$pc])) {
            return $pc;
        }
    }
    return 'M19';
}

function fat_agt_payment_method_code(?string $metodo): string
{
    return match (strtolower(trim((string) $metodo))) {
        'numerario' => 'NU',
        'transferencia' => 'TB',
        'multicaixa' => 'MB',
        'cheque' => 'CH',
        'cartao', 'cartao_credito' => 'CC',
        'cartao_debito' => 'CD',
        'dinheiro_eletronico' => 'DE',
        default => 'OU',
    };
}

function fat_agt_operation_type(array $linha): string
{
    if (!empty($linha['produto_id'])) {
        $t = db()->prepare('SELECT tipo FROM fat_produtos WHERE id=?');
        $t->execute([(int) $linha['produto_id']]);
        $tipo = (string) $t->fetchColumn();
        return $tipo === 'servico' ? 'SS' : 'TB';
    }
    $desc = strtolower((string) ($linha['descricao'] ?? ''));
    if (str_contains($desc, 'servi')) {
        return 'SS';
    }
    return 'SG';
}

function fat_agt_ambiente(): string
{
    $emp = fat_empresa();
    $amb = strtolower(trim((string) ($emp['agt_ambiente'] ?? 'homologacao')));
    return $amb === 'producao' ? 'producao' : 'homologacao';
}

function fat_agt_api_base(): string
{
    return fat_agt_ambiente() === 'producao'
        ? 'https://sifp.minfin.gov.ao/sigt/fe/v1'
        : 'https://sifphml.minfin.gov.ao/sigt/fe/v1';
}

function fat_agt_simular(): bool
{
    $emp = fat_empresa();
    return !empty($emp['agt_simular']);
}

function fat_agt_api_configured(): bool
{
    $emp = fat_empresa();
    return $emp
        && trim((string) ($emp['agt_api_user'] ?? '')) !== ''
        && trim((string) ($emp['agt_api_pass'] ?? '')) !== '';
}

function fat_agt_http_post(string $endpoint, array $body): array
{
    if (fat_agt_simular()) {
        return fat_agt_simulate_response($endpoint, $body);
    }

    if (!function_exists('curl_init')) {
        throw new RuntimeException('Extensão PHP curl é obrigatória para a API AGT.');
    }
    if (!fat_agt_api_configured()) {
        throw new RuntimeException('Configure utilizador e senha API AGT em Empresa fiscal → Facturação electrónica.');
    }

    $emp = fat_empresa();
    $url = rtrim(fat_agt_api_base(), '/') . '/' . ltrim($endpoint, '/');
    $json = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Erro ao serializar pedido AGT.');
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $json,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 90,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Accept: application/json',
        ],
        CURLOPT_USERPWD => trim((string) $emp['agt_api_user']) . ':' . trim((string) $emp['agt_api_pass']),
    ]);
    $raw = curl_exec($ch);
    $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    if ($raw === false) {
        throw new RuntimeException('Falha de ligação à AGT: ' . $err);
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        throw new RuntimeException('Resposta AGT inválida (HTTP ' . $http . '). Corpo: ' . mb_substr($raw, 0, 200));
    }
    if ($http === 429) {
        throw new RuntimeException('AGT: demasiados pedidos (HTTP 429). Aguarde e repita obterEstado.');
    }

    return ['http' => $http, 'json' => $decoded, 'raw' => $raw];
}

function fat_agt_simulate_response(string $endpoint, array $body): array
{
    if (str_contains($endpoint, 'registarFactura')) {
        return ['http' => 200, 'json' => ['requestID' => 'SIM' . date('YmdHis'), 'errorList' => []]];
    }
    if (str_contains($endpoint, 'obterEstado')) {
        $docNo = (string) (($body['documents'][0]['documentNo'] ?? '') ?: 'SIM');
        return [
            'http' => 200,
            'json' => [
                'requestID' => (string) ($body['requestID'] ?? ''),
                'resultCode' => '0',
                'taxRegistrationNumber' => (string) ($body['taxRegistrationNumber'] ?? ''),
                'documentStatusList' => [
                    ['documentNo' => $docNo, 'documentStatus' => 'V', 'errorList' => []],
                ],
                'requestErrorList' => [],
            ],
        ];
    }
    if (str_contains($endpoint, 'consultarFactura')) {
        return [
            'http' => 200,
            'json' => [
                'documentNo' => (string) ($body['documentNo'] ?? ''),
                'validationStatus' => 'V',
                'customerAcceptance' => 'N',
            ],
        ];
    }
    if (str_contains($endpoint, 'listarFacturas')) {
        return ['http' => 200, 'json' => ['documentList' => [], 'numberOfEntries' => 0]];
    }
    if (str_contains($endpoint, 'validarDocumento')) {
        $action = (string) ($body['action'] ?? 'C');
        return [
            'http' => 200,
            'json' => [
                'actionResultCode' => $action === 'C' ? 'C_OK' : 'R_OK',
                'documentStatusCode' => $action === 'C' ? 'S_C' : 'S_RJ',
            ],
        ];
    }
    if (str_contains($endpoint, 'anularFactura')) {
        return ['http' => 200, 'json' => ['documentNo' => (string) ($body['documentNo'] ?? ''), 'cancelResult' => 'OK']];
    }
    return ['http' => 200, 'json' => []];
}

function fat_agt_uuid_v4(): string
{
    $data = random_bytes(16);
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
    return vsprintf('%s-%s-%s-%s-%s', str_split(bin2hex($data), 4));
}

function fat_agt_round_tax(float $value): float
{
    return ceil($value * 100) / 100;
}

function fat_agt_document_no(array $doc): string
{
    $no = trim((string) ($doc['numero_completo'] ?? ''));
    if ($no === '' || $no === 'RASCUNHO') {
        throw new RuntimeException('Documento sem numeração fiscal.');
    }
    return $no;
}

function fat_agt_build_software_info(array $emp): array
{
    fat_agt_apply_cert_defaults();
    $emp = fat_empresa() ?: $emp;
    $detail = [
        'productId' => fat_saft_product_id($emp),
        'productVersion' => (string) ($emp['software_versao'] ?? '1.0.0'),
        'softwareValidationNumber' => fat_saft_validation_number($emp),
        'signatureVersion' => (int) ($emp['agt_signature_version'] ?? 1),
    ];
    $producerKey = fat_agt_key_path('produtor');
    return [
        'softwareInfoDetail' => $detail,
        'jwsSoftwareSignature' => fat_jws_rs256($detail, $producerKey),
    ];
}

function fat_agt_request_envelope(array $emp, array $jwsPayload, ?string $keyRole = 'emitente'): array
{
    $nif = preg_replace('/\s+/', '', (string) $emp['nif']);
    $key = fat_agt_key_path($keyRole);
    return [
        'schemaVersion' => '2.0',
        'taxRegistrationNumber' => $nif,
        'submissionTimeStamp' => gmdate('Y-m-d\TH:i:s\Z'),
        'softwareInfo' => fat_agt_build_software_info($emp),
        'jwsSignature' => fat_jws_rs256($jwsPayload, $key),
    ];
}

function fat_agt_build_taxes(array $linha): array
{
    $taxPct = (float) $linha['taxa_iva'];
    $iva = (float) $linha['total_iva'];
    $taxCode = 'NOR';
    if ($taxPct == 0.0) {
        $taxCode = 'ISE';
    } elseif ($taxPct <= 5.0) {
        $taxCode = 'RED';
    } elseif ($taxPct <= 7.0) {
        $taxCode = 'INT';
    }
    $tax = [
        'taxType' => 'IVA',
        'taxCountryRegion' => 'AO',
        'taxCode' => $taxCode,
        'taxPercentage' => $taxPct,
        'taxContribution' => fat_agt_round_tax($iva),
    ];
    if ($taxCode === 'ISE') {
        $tax['taxExemptionCode'] = fat_agt_resolve_isencao($linha);
    }
    return [$tax];
}

function fat_agt_origem_documento(?int $origemId): ?array
{
    if (!$origemId) {
        return null;
    }
    $orig = db()->prepare('SELECT numero_completo, data_documento FROM fat_documentos WHERE id=?');
    $orig->execute([$origemId]);
    $row = $orig->fetch();
    return $row ?: null;
}

function fat_agt_build_document(array $doc, array $linhas, array $emp, bool $correction = false): array
{
    $nif = preg_replace('/\s+/', '', (string) $emp['nif']);
    $documentNo = fat_agt_document_no($doc);
    $tipo = (string) ($doc['tipo'] ?? '');
    $isCreditNote = $tipo === 'NC';
    $isDebitNote = $tipo === 'ND';
    $noLinesTypes = ['AR', 'RC', 'RG'];
    $systemEntry = $doc['data_sistema'] ?? date('Y-m-d H:i:s');
    $systemEntryIso = gmdate('Y-m-d\TH:i:s\Z', strtotime($systemEntry));

    $origem = fat_agt_origem_documento((int) ($doc['documento_origem_id'] ?? 0));
    $refReason = trim((string) ($doc['motivo_anulacao'] ?? '')) ?: 'Rectificação';

    $agtLines = [];
    foreach ($linhas as $l) {
        $qty = (float) $l['quantidade'];
        $unitBase = (float) $l['preco_unitario'];
        $descPct = (float) ($l['desconto_pct'] ?? 0);
        $unitNet = round($unitBase * (1 - $descPct / 100), 2);
        $liquido = (float) $l['total_liquido'];
        $settlement = round(max(0, $qty * $unitBase - $liquido), 2);

        $line = [
            'lineNumber' => (int) $l['linha'],
            'operationType' => fat_agt_operation_type($l),
            'productCode' => (string) ($l['codigo'] ?: 'GEN'),
            'productDescription' => (string) $l['descricao'],
            'quantity' => $qty,
            'unitOfMeasure' => (string) ($l['unidade'] ?: 'UN'),
            'unitPriceBase' => round($unitBase, 2),
            'unitPrice' => $unitNet,
            'settlementAmount' => $settlement,
            'taxes' => fat_agt_build_taxes($l),
        ];
        if ($isCreditNote) {
            $line['creditAmount'] = round($liquido, 2);
        } elseif ($isDebitNote) {
            $line['debitAmount'] = round($liquido, 2);
        } else {
            $line['creditAmount'] = round($liquido, 2);
        }
        if ($isCreditNote && $origem) {
            $line['referenceInfo'] = [
                'reference' => (string) $origem['numero_completo'],
                'reason' => mb_substr($refReason, 0, 60),
            ];
        }
        $agtLines[] = $line;
    }

    $totals = [
        'taxPayable' => round((float) $doc['total_iva'], 2),
        'netTotal' => round((float) $doc['subtotal'], 2),
        'grossTotal' => round((float) $doc['total'], 2),
    ];

    $signPayload = [
        'documentNo' => $documentNo,
        'taxRegistrationNumber' => $nif,
        'documentType' => $tipo,
        'documentDate' => (string) $doc['data_documento'],
        'customerTaxID' => (string) ($doc['cliente_nif'] ?: '999999999'),
        'customerCountry' => 'AO',
        'companyName' => (string) $doc['cliente_nome'],
        'documentTotals' => $totals,
    ];
    $emitterKey = fat_agt_key_path('emitente');

    $docStatus = 'N';
    $rejectedNo = null;
    if ($correction) {
        $docStatus = 'C';
        $rejectedNo = trim((string) ($doc['fe_rejected_document_no'] ?? $documentNo));
    }

    $payload = [
        'documentNo' => $documentNo,
        'documentStatus' => $docStatus,
        'jwsDocumentSignature' => fat_jws_rs256($signPayload, $emitterKey),
        'documentDate' => (string) $doc['data_documento'],
        'documentType' => $tipo,
        'systemEntryDate' => $systemEntryIso,
        'customerTaxID' => (string) ($doc['cliente_nif'] ?: '999999999'),
        'customerCountry' => 'AO',
        'companyName' => (string) $doc['cliente_nome'],
        'documentTotals' => $totals,
    ];

    if ($docStatus === 'C' && $rejectedNo) {
        $payload['rejectedDocumentNo'] = $rejectedNo;
    }

    if (!in_array($tipo, $noLinesTypes, true)) {
        $payload['lines'] = $agtLines;
    }

    if (!empty($emp['agt_eac_code'])) {
        $payload['eacCode'] = substr((string) $emp['agt_eac_code'], 0, 5);
    }

    if (in_array($tipo, ['AR', 'RC', 'RG'], true) && $origem) {
        $payload['paymentReceipt'] = [
            'sourceDocuments' => [[
                'lineNo' => 1,
                'sourceDocumentID' => [
                    'OriginatingON' => (string) $origem['numero_completo'],
                    'documentDate' => (string) $origem['data_documento'],
                ],
                'creditAmount' => round((float) $doc['total'], 2),
            ]],
        ];
    }

    return $payload;
}

function fat_agt_registar_documento(int $docId, ?int $userId = null, bool $forceCorrection = false): array
{
    fat_agt_ensure_schema();
    $stmt = db()->prepare("SELECT * FROM fat_documentos WHERE id=? AND estado='emitido'");
    $stmt->execute([$docId]);
    $doc = $stmt->fetch();
    if (!$doc) {
        throw new RuntimeException('Só documentos emitidos podem ser comunicados à AGT.');
    }
    if (($doc['tipo'] ?? '') === 'OR') {
        throw new RuntimeException('Facturas proforma não são comunicadas à AGT.');
    }
    if (function_exists('fat_agt_is_movement_type') && fat_agt_is_movement_type((string) $doc['tipo'])) {
        throw new RuntimeException('Guias de movimento (GT/GR/GD/GA) não são comunicadas por esta API.');
    }

    $emp = fat_empresa();
    if (!$emp || trim((string) $emp['nif']) === '') {
        throw new RuntimeException('Configure o NIF da empresa.');
    }
    fat_validar_configuracao_eletronica();

    $envio = db()->prepare('SELECT estado FROM fat_agt_envios WHERE documento_id=?');
    $envio->execute([$docId]);
    $envioEstado = (string) ($envio->fetchColumn() ?: '');
    $correction = $forceCorrection || $envioEstado === 'rejeitado';

    $linhas = db()->prepare('SELECT * FROM fat_linhas WHERE documento_id=? ORDER BY linha');
    $linhas->execute([$docId]);
    $linhas = $linhas->fetchAll();
    if (!$linhas && !in_array($doc['tipo'], ['AR', 'RC', 'RG'], true)) {
        throw new RuntimeException('Documento sem linhas.');
    }

    foreach ($linhas as $l) {
        if ((float) $l['taxa_iva'] == 0.0) {
            $code = fat_agt_resolve_isencao($l);
            if (!isset(fat_agt_isencao_codigos()[$code])) {
                throw new RuntimeException('Linha ' . (int) $l['linha'] . ': indique código de isenção IVA (Anexo 6.4 AGT) para taxa 0%.');
            }
        }
    }

    $nif = preg_replace('/\s+/', '', (string) $emp['nif']);
    $submissionUuid = fat_agt_uuid_v4();
    $documentPayload = fat_agt_build_document($doc, $linhas, $emp, $correction);

    $body = fat_agt_request_envelope($emp, [
        'taxRegistrationNumber' => $nif,
        'submissionUUID' => $submissionUuid,
    ]);
    $body['submissionUUID'] = $submissionUuid;
    $body['numberOfEntries'] = 1;
    $body['documents'] = [$documentPayload];

    $response = fat_agt_http_post('registarFactura', $body);
    $json = $response['json'];
    $http = $response['http'];

    if ($http === 400 && !empty($json['errorList'])) {
        $msg = fat_agt_format_errors($json['errorList']);
        fat_agt_store_envio($docId, 'rejeitado', $submissionUuid, null, json_encode($json, JSON_UNESCAPED_UNICODE), $msg);
        throw new RuntimeException('AGT rejeitou o registo: ' . $msg);
    }

    if (!in_array($http, [200, 422], true) || empty($json['requestID'])) {
        $msg = json_encode($json, JSON_UNESCAPED_UNICODE);
        fat_agt_store_envio($docId, 'erro', $submissionUuid, null, $msg, 'Resposta inesperada AGT (HTTP ' . $http . ')');
        throw new RuntimeException('Registo AGT falhou (HTTP ' . $http . ').');
    }

    $requestId = (string) $json['requestID'];
    fat_agt_store_envio($docId, 'submetido', $submissionUuid, $requestId, json_encode($body, JSON_UNESCAPED_UNICODE), 'Submetido — aguarda validação AGT');
    db()->prepare('UPDATE fat_documentos SET fe_request_id=?, fe_agt_estado=? WHERE id=?')
        ->execute([$requestId, 'submetido', $docId]);

    fat_auditar_documento($docId, $correction ? 'reenvio_agt' : 'envio_agt', $userId, 'emitido', 'submetido', $doc['hash']);

    return ['requestID' => $requestId, 'estado' => fat_agt_obter_estado($docId, $userId)];
}

function fat_agt_format_errors(array $errorList): string
{
    return implode('; ', array_map(static function ($e) {
        $id = $e['idError'] ?? $e['code'] ?? '';
        $desc = $e['descriptionError'] ?? $e['description'] ?? '';
        $doc = $e['documentNo'] ?? '';
        return trim($id . ' ' . $desc . ($doc ? ' [' . $doc . ']' : ''));
    }, $errorList));
}

function fat_agt_store_envio(int $docId, string $estado, string $uuid, ?string $requestId, string $payload, string $resposta): void
{
    db()->prepare("INSERT INTO fat_agt_envios (documento_id, request_id, submission_uuid, estado, tentativas, payload, resposta)
        VALUES (?,?,?,?,0,?,?)
        ON DUPLICATE KEY UPDATE request_id=VALUES(request_id), submission_uuid=VALUES(submission_uuid),
        estado=VALUES(estado), payload=VALUES(payload), resposta=VALUES(resposta), atualizado_em=NOW()")
        ->execute([$docId, $requestId, $uuid, $estado, $payload, $resposta]);
}

function fat_agt_apply_obter_estado(int $docId, array $json, ?string $expectedDocumentNo = null): array
{
    $resultCode = (string) ($json['resultCode'] ?? '');
    $feEstado = 'processando';
    $validation = null;

    if (in_array($resultCode, ['7', '8'], true)) {
        $feEstado = 'processando';
    } elseif ($resultCode === '9') {
        $feEstado = 'rejeitado';
        $validation = 'R';
    } elseif (in_array($resultCode, ['0', '1', '2'], true)) {
        $list = $json['documentStatusList'] ?? [];
        $match = null;
        foreach ($list as $st) {
            if ($expectedDocumentNo && ($st['documentNo'] ?? '') !== $expectedDocumentNo) {
                continue;
            }
            $match = $st;
            break;
        }
        if (!$match && $list) {
            $match = $list[0];
        }
        if ($match) {
            if (($match['documentStatus'] ?? '') === 'V') {
                $feEstado = 'validado';
                $validation = 'V';
            } else {
                $feEstado = 'rejeitado';
                $validation = 'R';
            }
        } elseif ($resultCode === '2') {
            $feEstado = 'rejeitado';
            $validation = 'R';
        } else {
            $feEstado = $resultCode === '0' ? 'validado' : 'rejeitado';
            $validation = $feEstado === 'validado' ? 'V' : 'R';
        }
    }

    db()->prepare('UPDATE fat_documentos SET fe_agt_estado=?, fe_validation_status=? WHERE id=?')
        ->execute([$feEstado, $validation, $docId]);

    if ($feEstado === 'validado') {
        db()->prepare("UPDATE fat_agt_envios SET estado='validado', enviado_em=NOW() WHERE documento_id=?")->execute([$docId]);
    } elseif ($feEstado === 'rejeitado') {
        db()->prepare("UPDATE fat_agt_envios SET estado='rejeitado' WHERE documento_id=?")->execute([$docId]);
        db()->prepare('UPDATE fat_documentos SET fe_rejected_document_no=COALESCE(fe_rejected_document_no, numero_completo) WHERE id=?')->execute([$docId]);
    } else {
        db()->prepare("UPDATE fat_agt_envios SET estado='processando' WHERE documento_id=?")->execute([$docId]);
    }

    return ['feEstado' => $feEstado, 'validation' => $validation];
}

function fat_agt_obter_estado(int $docId, ?int $userId = null): array
{
    fat_agt_ensure_schema();
    $stmt = db()->prepare('SELECT d.*, e.request_id, e.estado AS envio_estado FROM fat_documentos d LEFT JOIN fat_agt_envios e ON e.documento_id=d.id WHERE d.id=?');
    $stmt->execute([$docId]);
    $row = $stmt->fetch();
    if (!$row || empty($row['request_id'])) {
        throw new RuntimeException('Documento ainda não foi submetido à AGT.');
    }

    $emp = fat_empresa();
    $nif = preg_replace('/\s+/', '', (string) $emp['nif']);
    $requestId = (string) $row['request_id'];
    $documentNo = fat_agt_document_no($row);

    $body = fat_agt_request_envelope($emp, [
        'taxRegistrationNumber' => $nif,
        'requestID' => $requestId,
    ]);
    $body['requestID'] = $requestId;

    $response = fat_agt_http_post('obterEstado', $body);
    $json = $response['json'];
    $resultCode = (string) ($json['resultCode'] ?? '');

    db()->prepare('UPDATE fat_agt_envios SET tentativas=tentativas+1, resposta=?, result_code=?, atualizado_em=NOW() WHERE documento_id=?')
        ->execute([json_encode($json, JSON_UNESCAPED_UNICODE), $resultCode, $docId]);

    $applied = fat_agt_apply_obter_estado($docId, $json, $documentNo);
    fat_auditar_documento($docId, 'consulta_agt', $userId, $row['envio_estado'] ?? null, $applied['feEstado'], $row['hash'] ?? null);

    return $json;
}

function fat_agt_consultar_factura(int $docId, ?int $userId = null): array
{
    fat_agt_ensure_schema();
    $doc = db()->prepare("SELECT * FROM fat_documentos WHERE id=? AND estado IN ('emitido','anulado')");
    $doc->execute([$docId]);
    $row = $doc->fetch();
    if (!$row) {
        throw new RuntimeException('Documento não encontrado.');
    }
    $emp = fat_empresa();
    $nif = preg_replace('/\s+/', '', (string) $emp['nif']);
    $documentNo = fat_agt_document_no($row);

    $body = fat_agt_request_envelope($emp, [
        'taxRegistrationNumber' => $nif,
        'documentNo' => $documentNo,
    ]);
    $body['documentNo'] = $documentNo;

    $response = fat_agt_http_post('consultarFactura', $body);
    $json = $response['json'];
    if (($response['http'] ?? 0) !== 200) {
        throw new RuntimeException('consultarFactura falhou (HTTP ' . (int) $response['http'] . ').');
    }

    $vs = (string) ($json['validationStatus'] ?? '');
    if ($vs === 'V') {
        db()->prepare("UPDATE fat_documentos SET fe_validation_status='V', fe_agt_estado='validado' WHERE id=?")->execute([$docId]);
    } elseif ($vs === 'P') {
        db()->prepare("UPDATE fat_documentos SET fe_validation_status='P' WHERE id=?")->execute([$docId]);
    }
    $ca = (string) ($json['customerAcceptance'] ?? '');
    if ($ca !== '') {
        db()->prepare('UPDATE fat_documentos SET fe_customer_status=? WHERE id=?')->execute([$ca, $docId]);
    }

    fat_auditar_documento($docId, 'consulta_factura_agt', $userId, null, $vs ?: null, $row['hash'] ?? null);
    return $json;
}

function fat_agt_listar_facturas(string $from, string $to, ?string $documentType = null): array
{
    fat_agt_ensure_schema();
    $emp = fat_empresa();
    $nif = preg_replace('/\s+/', '', (string) $emp['nif']);

    $body = fat_agt_request_envelope($emp, ['taxRegistrationNumber' => $nif]);
    $body['startDate'] = $from;
    $body['endDate'] = $to;
    if ($documentType) {
        $body['documentType'] = $documentType;
    }

    $response = fat_agt_http_post('listarFacturas', $body);
    if (($response['http'] ?? 0) !== 200) {
        throw new RuntimeException('listarFacturas falhou (HTTP ' . (int) $response['http'] . ').');
    }
    return $response['json'];
}

function fat_agt_validar_documento(string $documentNo, string $buyerNif, string $action, ?float $deductiblePct = null, ?float $nonDeductible = null): array
{
    fat_agt_ensure_schema();
    $action = strtoupper($action) === 'R' ? 'R' : 'C';
    $buyerNif = preg_replace('/\s+/', '', $buyerNif);
    $emp = fat_empresa();

    $jwsPayload = [
        'taxRegistrationNumber' => $buyerNif,
        'documentNo' => $documentNo,
    ];
    $body = fat_agt_request_envelope($emp, $jwsPayload, 'emitente');
    $body['taxRegistrationNumber'] = $buyerNif;
    $body['documentNo'] = $documentNo;
    $body['action'] = $action;
    if ($action === 'C' && $deductiblePct !== null) {
        $body['deductibleVATPercentage'] = max(0, min(100, $deductiblePct));
    }
    if ($action === 'C' && $nonDeductible !== null && $nonDeductible > 0) {
        $body['nonDeductibleAmount'] = round($nonDeductible, 2);
    }
    $body['jwsSignature'] = fat_jws_rs256($jwsPayload, fat_agt_key_path('emitente'));

    $response = fat_agt_http_post('validarDocumento', $body);
    if (($response['http'] ?? 0) !== 200) {
        throw new RuntimeException('validarDocumento falhou (HTTP ' . (int) $response['http'] . ').');
    }
    return $response['json'];
}

function fat_agt_anular_factura(int $docId, string $reason, ?int $userId = null): array
{
    fat_agt_ensure_schema();
    $stmt = db()->prepare("SELECT * FROM fat_documentos WHERE id=? AND estado IN ('emitido','anulado')");
    $stmt->execute([$docId]);
    $doc = $stmt->fetch();
    if (!$doc) {
        throw new RuntimeException('Documento não encontrado.');
    }
    if (($doc['fe_agt_estado'] ?? '') !== 'validado' && ($doc['fe_validation_status'] ?? '') !== 'V') {
        throw new RuntimeException('Só documentos validados pela AGT podem ser anulados via API.');
    }

    $emp = fat_empresa();
    $nif = preg_replace('/\s+/', '', (string) $emp['nif']);
    $documentNo = fat_agt_document_no($doc);
    $reason = mb_substr(trim($reason), 0, 255);

    $jwsPayload = [
        'taxRegistrationNumber' => $nif,
        'documentNo' => $documentNo,
    ];
    $body = fat_agt_request_envelope($emp, $jwsPayload);
    $body['documentNo'] = $documentNo;
    $body['documentCancelReason'] = $reason;

    $response = fat_agt_http_post('anularFactura', $body);
    $http = (int) ($response['http'] ?? 0);
    $json = $response['json'];
    if ($http !== 200) {
        $msg = !empty($json['errorList']) ? fat_agt_format_errors($json['errorList']) : json_encode($json, JSON_UNESCAPED_UNICODE);
        throw new RuntimeException('Anulação AGT falhou: ' . $msg);
    }

    db()->prepare("UPDATE fat_documentos SET estado='anulado', motivo_anulacao=?, fe_motivo_anulacao_agt=?, fe_agt_estado='anulado' WHERE id=?")
        ->execute([$reason, $reason, $docId]);
    db()->prepare("UPDATE fat_agt_envios SET estado='anulado', resposta=? WHERE documento_id=?")
        ->execute([json_encode($json, JSON_UNESCAPED_UNICODE), $docId]);

    fat_auditar_documento($docId, 'anulacao_agt', $userId, 'emitido', 'anulado', $doc['hash'] ?? null);
    if (function_exists('cont_reverter_venda')) {
        cont_reverter_venda($docId, $userId);
    }

    return $json;
}

function fat_agt_processar_pendentes(int $limit = 20): int
{
    fat_agt_ensure_schema();
    $rows = db()->query("SELECT documento_id FROM fat_agt_envios WHERE estado IN ('submetido','processando') ORDER BY id ASC LIMIT " . (int) $limit)->fetchAll();
    $n = 0;
    foreach ($rows as $r) {
        try {
            fat_agt_obter_estado((int) $r['documento_id'], null);
            $n++;
        } catch (Throwable $e) {
            db()->prepare("UPDATE fat_agt_envios SET estado='erro', resposta=? WHERE documento_id=?")
                ->execute([$e->getMessage(), (int) $r['documento_id']]);
        }
    }

    $pendentes = db()->query("SELECT d.id FROM fat_documentos d
        LEFT JOIN fat_agt_envios e ON e.documento_id=d.id
        WHERE d.estado='emitido' AND d.tipo <> 'OR' AND (e.id IS NULL OR e.estado IN ('pendente','rejeitado'))
        ORDER BY d.id ASC LIMIT " . (int) $limit)->fetchAll();
    foreach ($pendentes as $p) {
        try {
            if (fat_agt_api_configured() || fat_agt_simular()) {
                $env = db()->prepare('SELECT estado FROM fat_agt_envios WHERE documento_id=?');
                $env->execute([(int) $p['id']]);
                $correction = ($env->fetchColumn() === 'rejeitado');
                fat_agt_registar_documento((int) $p['id'], null, $correction);
                $n++;
            }
        } catch (Throwable $e) {
            fat_agt_store_envio((int) $p['id'], 'erro', fat_agt_uuid_v4(), null, '{}', $e->getMessage());
        }
    }
    return $n;
}

function fat_agt_after_emit(int $docId, int $userId): void
{
    fat_agt_ensure_schema();
    $emp = fat_empresa();
    if (!$emp || empty($emp['agt_auto_envio'])) {
        return;
    }
    if (!fat_agt_api_configured() && !fat_agt_simular()) {
        fat_agt_store_envio($docId, 'pendente', fat_agt_uuid_v4(), null, '{}', 'Aguarda credenciais API AGT.');
        return;
    }
    try {
        fat_agt_registar_documento($docId, $userId);
    } catch (Throwable $e) {
        fat_agt_store_envio($docId, 'erro', fat_agt_uuid_v4(), null, '{}', $e->getMessage());
    }
}

function fat_preparar_envio_agt(int $docId, int $userId): void
{
    fat_agt_registar_documento($docId, $userId);
}

function fat_fatura_qr_content(array $doc, array $emp): string
{
    $validateUrl = fat_fatura_validar_url((int) $doc['id']);
    return implode("\n", array_filter([
        'Factura: ' . fat_agt_document_no($doc),
        'Emitente NIF: ' . ($emp['nif'] ?? ''),
        'Cliente NIF: ' . ($doc['cliente_nif'] ?: '999999999'),
        'Data: ' . ($doc['data_documento'] ?? ''),
        'Total AOA: ' . number_format((float) $doc['total'], 2, '.', ''),
        'Hash: ' . ($doc['hash'] ?? ''),
        'Validar: ' . $validateUrl,
    ]));
}

function fat_fatura_validar_url(int $docId): string
{
    $token = hash_hmac('sha256', (string) $docId, (string) (fat_empresa()['nif'] ?? APP_NAME));
    return url('/validar-fatura.php?id=' . $docId . '&t=' . substr($token, 0, 16));
}

function fat_agt_estado_label(?string $estado): string
{
    return match ($estado) {
        'pendente' => 'Pendente de envio',
        'submetido' => 'Submetido à AGT',
        'processando' => 'Em validação AGT',
        'validado' => 'Validado pela AGT',
        'rejeitado' => 'Rejeitado pela AGT',
        'anulado' => 'Anulado na AGT',
        'erro' => 'Erro de comunicação',
        default => $estado ?: '—',
    };
}
