<?php
/**
 * Departamento de Tecnologia — chamados, projectos, activos e dashboard.
 */

function ensure_ti_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $sqlFile = __DIR__ . '/../sql/ti.sql';
    if (is_file($sqlFile)) {
        db()->exec((string) file_get_contents($sqlFile));
    }
    $done = true;
}

/** Cria utilizador TI predefinido se ainda não existir. */
function ensure_ti_default_user(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    ensure_usuario_niveis();
    $email = 'ti@informatiza.ao';
    $check = db()->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
    $check->execute([$email]);
    if ($check->fetchColumn()) {
        return;
    }
    db()->prepare('INSERT INTO usuarios (nome, email, senha, nivel, ativo) VALUES (?,?,?,?,1)')
        ->execute([
            'Departamento de Tecnologia',
            $email,
            password_hash('Ti2026!', PASSWORD_DEFAULT),
            'ti',
        ]);
}

/** @return array<string,int|float> */
function ti_dashboard_kpis(): array
{
    ensure_ti_schema();
    ensure_certificacoes_schema();
    ensure_agenda_schema();

    $chamAb = (int) db()->query("SELECT COUNT(*) FROM ti_chamados WHERE estado IN ('aberto','em_andamento')")->fetchColumn();
    $chamCrit = (int) db()->query("SELECT COUNT(*) FROM ti_chamados WHERE prioridade='critica' AND estado IN ('aberto','em_andamento')")->fetchColumn();
    $projCurso = (int) db()->query("SELECT COUNT(*) FROM ti_projetos WHERE estado IN ('planeamento','em_curso')")->fetchColumn();
    $ativos = (int) db()->query("SELECT COUNT(*) FROM ti_ativos WHERE estado='ativo'")->fetchColumn();
    $ativosMan = (int) db()->query("SELECT COUNT(*) FROM ti_ativos WHERE estado='manutencao'")->fetchColumn();
    $msgNovas = (int) db()->query("SELECT COUNT(*) FROM mensagens WHERE status='nova'")->fetchColumn();
    $servicos = (int) db()->query("SELECT COUNT(*) FROM servicos WHERE status='ativo'")->fetchColumn();
    $certs = (int) db()->query("SELECT COUNT(*) FROM certificacoes WHERE status='ativo'")->fetchColumn();
    $noticias = (int) db()->query("SELECT COUNT(*) FROM noticias WHERE status='publicado'")->fetchColumn();

    return [
        'chamados_abertos' => $chamAb,
        'chamados_criticos' => $chamCrit,
        'projetos_ativos' => $projCurso,
        'ativos_operacionais' => $ativos,
        'ativos_manutencao' => $ativosMan,
        'mensagens_novas' => $msgNovas,
        'servicos_site' => $servicos,
        'certificacoes' => $certs,
        'noticias_publicadas' => $noticias,
    ];
}

/** @return array{labels:list<string>,abertos:list<int>,resolvidos:list<int>} */
function ti_chamados_series(int $months = 6): array
{
    ensure_ti_schema();
    $labels = [];
    $abertos = [];
    $resolvidos = [];
    for ($i = $months - 1; $i >= 0; $i--) {
        $t = strtotime("-{$i} months");
        $ym = date('Y-m', $t);
        $labels[] = date('m/Y', $t);
        $from = $ym . '-01 00:00:00';
        $to = date('Y-m-t 23:59:59', strtotime($from));
        $st = db()->prepare('SELECT COUNT(*) FROM ti_chamados WHERE criado_em BETWEEN ? AND ?');
        $st->execute([$from, $to]);
        $abertos[] = (int) $st->fetchColumn();
        $sr = db()->prepare("SELECT COUNT(*) FROM ti_chamados WHERE estado IN ('resolvido','fechado') AND resolvido_em BETWEEN ? AND ?");
        $sr->execute([$from, $to]);
        $resolvidos[] = (int) $sr->fetchColumn();
    }

    return compact('labels', 'abertos', 'resolvidos');
}

/** @return array{aberto:int,em_andamento:int,resolvido:int,fechado:int} */
function ti_chamados_pipeline(): array
{
    ensure_ti_schema();
    $rows = db()->query('SELECT estado, COUNT(*) AS n FROM ti_chamados GROUP BY estado')->fetchAll(PDO::FETCH_KEY_PAIR);

    return [
        'aberto' => (int) ($rows['aberto'] ?? 0),
        'em_andamento' => (int) ($rows['em_andamento'] ?? 0),
        'resolvido' => (int) ($rows['resolvido'] ?? 0),
        'fechado' => (int) ($rows['fechado'] ?? 0),
    ];
}

/** @return array{labels:list<string>,planeamento:list<int>,em_curso:list<int>,concluido:list<int>} */
function ti_projetos_series(): array
{
    ensure_ti_schema();
    $rows = db()->query('SELECT estado, COUNT(*) AS n FROM ti_projetos GROUP BY estado')->fetchAll(PDO::FETCH_KEY_PAIR);

    return [
        'labels' => ['Planeamento', 'Em curso', 'Pausado', 'Concluído', 'Cancelado'],
        'valores' => [
            (int) ($rows['planeamento'] ?? 0),
            (int) ($rows['em_curso'] ?? 0),
            (int) ($rows['pausado'] ?? 0),
            (int) ($rows['concluido'] ?? 0),
            (int) ($rows['cancelado'] ?? 0),
        ],
    ];
}

/** @return list<array<string,mixed>> */
function ti_ultimos_chamados(int $limit = 8): array
{
    ensure_ti_schema();
    $limit = max(1, min(50, $limit));
    $stmt = db()->query(
        'SELECT id, titulo, categoria, prioridade, estado, solicitante, criado_em
         FROM ti_chamados ORDER BY id DESC LIMIT ' . (int) $limit
    );

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/** @return list<array<string,mixed>> */
function ti_projetos_destaque(int $limit = 6): array
{
    ensure_ti_schema();
    $limit = max(1, min(30, $limit));
    $stmt = db()->query(
        "SELECT id, nome, cliente_ref, estado, progresso, data_fim_prev
         FROM ti_projetos WHERE estado IN ('planeamento','em_curso','pausado')
         ORDER BY FIELD(prioridade,'alta','media','baixa'), id DESC LIMIT {$limit}"
    );

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/** @return list<array<string,mixed>> */
function ti_ativos_alerta(int $limit = 5): array
{
    ensure_ti_schema();
    $limit = max(1, min(20, $limit));
    $stmt = db()->query(
        "SELECT id, codigo, nome, tipo, localizacao, estado FROM ti_ativos
         WHERE estado IN ('manutencao','baixa') ORDER BY FIELD(estado,'manutencao','baixa'), id DESC LIMIT {$limit}"
    );

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function ti_prioridade_badge(string $prioridade): string
{
    $map = [
        'baixa' => 'badge-muted',
        'media' => 'badge-warning',
        'alta' => 'badge-danger',
        'critica' => 'badge-danger',
    ];
    $labels = ['baixa' => 'Baixa', 'media' => 'Média', 'alta' => 'Alta', 'critica' => 'Crítica'];
    $class = $map[$prioridade] ?? 'badge-muted';
    $label = $labels[$prioridade] ?? ucfirst($prioridade);

    return '<span class="badge ' . $class . '">' . e($label) . '</span>';
}

function ti_estado_chamado_badge(string $estado): string
{
    $map = [
        'aberto' => 'badge-info',
        'em_andamento' => 'badge-warning',
        'resolvido' => 'badge-success',
        'fechado' => 'badge-muted',
    ];
    $labels = [
        'aberto' => 'Aberto',
        'em_andamento' => 'Em andamento',
        'resolvido' => 'Resolvido',
        'fechado' => 'Fechado',
    ];
    $class = $map[$estado] ?? 'badge-muted';
    $label = $labels[$estado] ?? ucfirst(str_replace('_', ' ', $estado));

    return '<span class="badge ' . $class . '">' . e($label) . '</span>';
}
