<?php
/**
 * Configuração da base de dados
 * XAMPP (local) e Host2Africa (produção)
 *
 * No Host2Africa: altere DB_HOST, DB_NAME, DB_USER e DB_PASS
 * com os dados do painel cPanel / MySQL.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'emifati_jr');
define('DB_USER', 'root');
define('DB_PASS', ''); // XAMPP: vazio | Host2Africa: senha do MySQL
define('DB_CHARSET', 'utf8mb4');

function db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    }

    return $pdo;
}
