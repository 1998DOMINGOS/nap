<?php
/**
 * Configuração geral da aplicação
 */

define('APP_NAME', 'INFORMATIZA (SU), LDA');
define('APP_TAGLINE', 'Tecnologia que ajuda o país');
define('APP_TITLE', 'Painel Administrativo');
define('APP_VERSION', '1.0.0');

// URL base — deteção automática (ex.: /casa no XAMPP; '' na raiz do domínio).
// Pode forçar: define('BASE_URL', '/casa'); antes de incluir este ficheiro.
if (!defined('BASE_URL')) {
    $base = '';
    // Preferir caminho real do projecto (evita falhas em subpastas novas: facturacao/, etc.)
    $docRoot = str_replace('\\', '/', (string) realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '');
    $appRoot = str_replace('\\', '/', (string) realpath(__DIR__ . '/..') ?: '');
    if ($docRoot !== '' && $appRoot !== '' && str_starts_with($appRoot, $docRoot)) {
        $base = substr($appRoot, strlen($docRoot));
    } else {
        $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
        $dir = str_replace('\\', '/', dirname($script));
        $parts = array_values(array_filter(explode('/', $dir), static fn($p) => $p !== '' && $p !== '.'));
        $climb = [
            'admin', 'api', 'config', 'includes', 'css', 'js', 'imgs', 'uploads', 'vendor', 'storage',
            'noticias', 'servicos', 'equipe', 'depoimentos', 'mensagens',
            'carreiras', 'usuarios', 'galeria', 'configuracoes',
            'facturacao', 'clientes', 'produtos', 'documentos', 'assets', 'caixa', 'vender',
            'rh', 'tecnologia', 'contabilidade',
        ];
        while ($parts && in_array(end($parts), $climb, true)) {
            array_pop($parts);
        }
        if ($parts) {
            $base = '/' . implode('/', $parts);
        }
    }
    define('BASE_URL', rtrim(str_replace('\\', '/', $base), '/'));
}

// Pasta de uploads (relativa à raiz do projeto)
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', (BASE_URL === '' ? '' : BASE_URL) . '/uploads/');

// Sessão
define('SESSION_NAME', 'informatiza_admin_session');

date_default_timezone_set('Africa/Luanda');

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/facturacao.php';
require_once __DIR__ . '/../includes/facturacao_agt.php';
require_once __DIR__ . '/../includes/facturacao_agt_compliance.php';
require_once __DIR__ . '/../includes/contabilidade.php';
require_once __DIR__ . '/../includes/recursos_humanos.php';
require_once __DIR__ . '/../includes/tecnologia.php';

try {
    ensure_usuario_niveis();
} catch (Throwable $e) {
}
try {
    ensure_site_branding();
} catch (Throwable $e) {
    // BD pode ainda não existir antes do install.php
}
ensure_depoimentos_schema();
ensure_parceiros_clientes_schema();
ensure_agenda_schema();
ensure_pca_schema();
ensure_certificacoes_schema();
try {
    ensure_facturacao_schema();
    ensure_contabilidade_schema();
    ensure_rh_schema();
    ensure_rh_default_user();
    ensure_ti_schema();
    ensure_ti_default_user();
} catch (Throwable $e) {
    // BD pode ainda não existir antes do install.php
}
