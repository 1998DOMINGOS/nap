<?php
require_once __DIR__ . '/config/app.php';
ensure_facturacao_schema();

$id = (int) ($_GET['id'] ?? 0);
$token = (string) ($_GET['t'] ?? '');
$emp = fat_empresa();
$expected = substr(hash_hmac('sha256', (string) $id, (string) ($emp['nif'] ?? APP_NAME)), 0, 16);
$validToken = $id > 0 && $token !== '' && hash_equals($expected, $token);

$doc = null;
$envio = null;
if ($validToken) {
    $stmt = db()->prepare('SELECT * FROM fat_documentos WHERE id=? AND estado IN (\'emitido\',\'anulado\')');
    $stmt->execute([$id]);
    $doc = $stmt->fetch();
    if ($doc) {
        $e = db()->prepare('SELECT * FROM fat_agt_envios WHERE documento_id=?');
        $e->execute([$id]);
        $envio = $e->fetch() ?: null;
    }
}

$pageTitle = 'Validar factura — ' . site_nome();
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-14">
    <div class="container mx-auto px-4">
        <h1 class="text-3xl font-bold">Validar factura electrónica</h1>
    </div>
</section>
<section class="py-12 bg-white">
    <div class="container mx-auto px-4 max-w-2xl">
        <?php if (!$validToken || !$doc): ?>
            <div class="alert-site err">Link de validação inválido ou documento indisponível.</div>
        <?php else: ?>
            <div class="form-card bg-paciolita-branco-suave border border-gray-100 rounded-2xl p-8">
                <p class="text-sm text-gray-500 mb-1">Documento</p>
                <h2 class="text-2xl font-bold text-ev-dark mb-4"><?= e($doc['numero_completo']) ?></h2>
                <p><strong>Emitente:</strong> <?= e($emp['nome'] ?? APP_NAME) ?> (NIF <?= e($emp['nif'] ?? '') ?>)</p>
                <p><strong>Cliente:</strong> <?= e($doc['cliente_nome']) ?> · NIF <?= e($doc['cliente_nif']) ?></p>
                <p><strong>Data:</strong> <?= e(format_date($doc['data_documento'], 'd/m/Y')) ?></p>
                <p><strong>Total:</strong> <?= e(fat_format_money($doc['total'])) ?></p>
                <?php if ($doc['hash_control']): ?>
                    <p class="mt-4"><strong>Hash control:</strong> <code><?= e($doc['hash_control']) ?></code></p>
                <?php endif; ?>
                <p class="mt-4"><strong>Estado interno:</strong> <?= e($doc['estado']) ?></p>
                <p><strong>Estado AGT:</strong> <?= e(fat_agt_estado_label($doc['fe_agt_estado'] ?? ($envio['estado'] ?? null))) ?></p>
                <?php if (!empty($doc['fe_validation_status'])): ?>
                    <p><strong>Validação AGT:</strong> <?= e($doc['fe_validation_status'] === 'V' ? 'Válida' : ($doc['fe_validation_status'] === 'P' ? 'Válida com penalização' : 'Rejeitada')) ?></p>
                <?php endif; ?>
                <?php if (!empty($doc['fe_customer_status'])): ?>
                    <p><strong>Confirmação adquirente (validarDocumento):</strong> <?= e($doc['fe_customer_status']) ?></p>
                <?php endif; ?>
                <p class="text-sm text-gray-500 mt-4">A confirmação fiscal pelo adquirente é efectuada via API AGT <em>validarDocumento</em> (software do comprador).</p>
                <?php if ($envio && !empty($envio['request_id'])): ?>
                    <p class="text-sm text-gray-500 mt-4">Request ID AGT: <?= e($envio['request_id']) ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
