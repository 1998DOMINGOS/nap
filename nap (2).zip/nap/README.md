# INFORMATIZA (SU), LDA — Tecnologia e Serviços (PHP + MySQL)

Site institucional e área administrativa em **PHP + MySQL**, prontos para **XAMPP** (local) e produção.

## O que inclui

### Site público
- Página inicial (serviços, notícias, depoimentos)
- Páginas: Sobre, Missão, Valores, Equipe, Serviços, Notícias, Galeria, Contacto, Carreiras
- Formulário de contacto → tabela `mensagens`
- Candidaturas com upload de CV → tabela `candidaturas`

### Painel admin (`/admin/`)
- Login seguro (sessão + `password_hash`)
- Dashboard com estatísticas
- CRUD de Notícias, Serviços, Equipe, Depoimentos, Galeria
- Gestão de Mensagens e Candidaturas
- Utilizadores e Configurações (admin)

## Instalação no XAMPP

1. Pasta do projecto: `C:\xampp\htdocs\casa`
2. Inicie **Apache** e **MySQL** no XAMPP
3. Abra: `http://localhost/casa/install.php`
4. Use:
   - Host: `localhost`
   - BD: `emifati_jr`
   - User: `root`
   - Senha: *(vazia no XAMPP)*
5. Defina o admin (ex.: `admin@emifatijr.ao` / `admin123`)
6. Site: `http://localhost/casa/`
7. Admin: `http://localhost/casa/admin/`
8. **Apague** o ficheiro `install.php` depois de instalar

## Contactos (flyer)

- Telefone / WhatsApp: +244 927 860 686
- Presença: Uíge, Luanda, Huíla, Benguela e Mbanza Congo
- Luanda: Maianga, Edifício Unitel, 5.º andar

## Facturação (admin)

Após login: **Facturação** no menu lateral.

1. Configure **Empresa fiscal** (NIF)
2. Cadastre **Clientes** e **Produtos**
3. Crie **Factura** (rascunho) → **Emitir** (gera número + hash RSA)
4. **Imprimir / PDF** (QR com link de validação) e **Exportar SAF-T AO**
5. **Facturação electrónica AGT (schema 2.0):** serviços `registarFactura`, `obterEstado`, `consultarFactura`, `listarFacturas`, `anularFactura` — ver `docs/CERTIFICACAO_AGT.md`. Admin: **FE AGT** e botões no documento emitido.
6. Isenções IVA 0%: código **Anexo 6.4** em produtos/serviços (`taxExemptionCode` na API).
7. Validação pública: `/validar-fatura.php` (consulta interna; confirmação do adquirente é `validarDocumento` na AGT).
8. Cron: `php scripts/fat_agt_process.php`.

> Requisitos: extensão PHP **curl**, chaves RSA em `storage/fat_keys/` (JWS RS256 para API AGT). **Não substitui a certificação oficial da AGT** — é necessário número de validação do software e credenciais emitidas pela AGT.

## Estilos offline

O site **não depende** do CDN do Tailwind. Os CSS locais estão em:
- `css/tailwind.css` — utilitários gerados
- `css/style.css` — estilos custom
- `css/fonts.css` + `fonts/` — Poppins e Oswald
- `vendor/fontawesome/` — ícones

Se adicionar **novas classes Tailwind** nos ficheiros PHP, regenere o CSS:

```bash
npm install
npm run build:css
```

## Segurança

- Altere a senha do admin após o primeiro acesso
- Remova `install.php` em produção
- A pasta `uploads/` bloqueia execução de PHP via `.htaccess`
