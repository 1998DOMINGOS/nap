# Referências AGT (PDF)

Copie para esta pasta os PDFs oficiais que utiliza localmente, para a equipa encontrar a mesma documentação:

| Ficheiro | Conteúdo |
|----------|----------|
| **`Decreto-Executivo-317-20-SAFT-estrutura-dados.pdf`** | **Decreto Executivo n.º 317/20, de 14/12/2020** — altera o **Anexo da Estrutura de Dados** do regime SAF-T (AO) (Decreto Presidencial 312/18). Fonte legal das tabelas 1–4 do ficheiro XML. |
| `AGT-Regras e requisitos para o Software - SAFT.pdf` | Requisitos AGT de **validação de software** (assinatura RSA, Hash, impressão, etc.) — diploma distinto do 317/20. |
| `AGT_Estrutura de dados dos Sistemas - SAFT.pdf` | Manual AGT / tabelas (complementar; no código prevalece o XSD). |

No código, a estrutura exacta está em [`storage/saft/SAFTAO1.01_01.xsd`](../storage/saft/SAFTAO1.01_01.xsd).

Índices markdown: [AGT_REQUISITOS_SAFT.md](../AGT_REQUISITOS_SAFT.md), [AGT_ESTRUTURA_DADOS_SAFT.md](../AGT_ESTRUTURA_DADOS_SAFT.md).
