# Módulo de Contabilidade

## Acesso

- **Admin:** Admin → Contabilidade (`/admin/contabilidade/dashboard.php`)
- **Contabilista:** login → dashboard dedicado (sem acesso a facturação, notícias, etc.)

Criar utilizador: `php scripts/create_contabilista_user.php email@empresa.ao SenhaSegura`

## Funcionalidades

| Área | Descrição |
|------|-----------|
| **Plano de contas** | SNC simplificado (Angola), editável (GR/GA/GM) — exportado no SAF-T basis **I/C** |
| **Lançamentos** | Razão automático (VND/COM/DES/FOL) + **ODI** manual; estorno na anulação de vendas |
| **SAF-T integrado (I)** | `GeneralLedgerAccounts` + `GeneralLedgerEntries` a partir de `cont_movimentos` (com fallback vendas) |
| **Despesas** | Gastos operacionais com IVA e conta de custo |
| **Salários** | Funcionários, folha mensal (INSS/IRT simplificado), lançamentos 631/632 |
| **Declarações / IVA** | Mapa para o contabilista + export CSV (mapa, vendas, compras, despesas, balancete, razão) e pacote ZIP |
| **Balancete** | Débito/crédito por conta no período |
| **A receber / A pagar** | Saldos de clientes (FT/FR/FA/ND − pagamentos/NC) e fornecedores (compras a crédito, despesas pendentes) |

## Integração automática

- Emissão **FT/FR/NC** → diário **VND**
- Registo de **compra** → diário **COM**
- Nova **despesa** → diário **DES**
- **Folha** processada → diário **FOL**

Use **Gerar lançamentos em falta** no painel para documentos antigos.

## Contabilista

Em **Declarações / IVA**, escolha o período e exporte ficheiros individuais ou o **pacote ZIP** completo. Imprima o mapa ou o **Balancete** para conferência antes de submeter declarações à AGT.
