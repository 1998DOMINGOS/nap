# Conformidade API AGT — Facturação Electrónica 2.0

> Requisitos legais (Decreto AGT): [AGT_REQUISITOS_SAFT.md](AGT_REQUISITOS_SAFT.md).  
> Estrutura de tabelas/campos SAF-T (AO): [AGT_ESTRUTURA_DADOS_SAFT.md](AGT_ESTRUTURA_DADOS_SAFT.md) + XSD `storage/saft/SAFTAO1.01_01.xsd`.

Implementação alinhada com a documentação pública AGT ([quiosque AGT](https://quiosqueagt.minfin.gov.ao/doc-agt/doc-agt/2/servicos/especificados.html)).

## Serviços HTTP POST (`/sigt/fe/v1/…`)

| Serviço | Função PHP |
|---------|------------|
| `registarFactura` | `fat_agt_registar_documento()` |
| `obterEstado` | `fat_agt_obter_estado()` |
| `consultarFactura` | `fat_agt_consultar_factura()` |
| `listarFacturas` | `fat_agt_listar_facturas()` |
| `anularFactura` | `fat_agt_anular_factura()` |
| `validarDocumento` | `fat_agt_validar_documento()` (adquirente) |

## Assinaturas JWS (RS256)

- **Software:** `jwsSoftwareSignature` → objecto `softwareInfoDetail` (chave **produtor**).
- **Documento:** `jwsDocumentSignature` → campos documento (chave **emitente** registada na AGT).
- **Pedido:** `jwsSignature` → pares definidos por serviço (`submissionUUID`, `requestID`, `documentNo`, …).

Configure caminhos em **Empresa fiscal → Facturação electrónica**.

## Documento JSON

- `documentStatus`: `N` (normal) ou `C` (correcção) + `rejectedDocumentNo`.
- Linhas: `operationType`, `settlementAmount`, `taxExemptionCode` se `taxCode=ISE`.
- NC: `referenceInfo` **por linha**.
- Recibos AR/RC/RG: `paymentReceipt.sourceDocuments` (não aplicável a FT/FR).

## Anexos no portal AGT

Admin → **Facturação → Certificação AGT** (`admin/facturacao/certificacao.php`):

1. **Anexar Chave Pública** — ficheiro com nome exacto: **`Chave Publica.pem`**
2. **Ficheiro SAF-T** — ficheiro com nome exacto: **`Ficheiro SAF-T.xml`**

## Antes da certificação

1. Desactivar **Simulação AGT**.
2. Preencher NIF, números AGT, credenciais homologação.
3. Registar chaves públicas na AGT = ficheiros em `storage/fat_keys/`.
4. Testar FT → validado → SAF-T → NC → anularFactura (se aplicável).

## Validação SAF-T no portal fornecedor

Portal: [invoice.minfin.gov.ao/portalSupplier](https://invoice.minfin.gov.ao/portalSupplier/)

- **ProductID** e **SoftwareValidationNumber** configuram-se apenas em **Admin → Empresa fiscal** (secção Software / SAF-T). Não use ficheiros duplicados.
- Têm de ser **iguais ao Modelo 08** submetido à AGT (não invente o texto).
- Durante a certificação, se a AGT indicar, use `000/AGT/AAAA` no número de validação.
- **Chave pública** no portal = ficheiro `Chave Publica.pem` (RSA 1024) actual; se mudou as chaves, reassine e volte a registar.
- **HashControl** no XML = `NNN.V` (ex.: `456.1`), não os 4 caracteres do Hash.
- Admin → **Empresa fiscal** guarda Modelo 08; cada export valida **XSD SAFTAO1.01_01** (`php scripts/fat_validate_saft_xsd.php`).
