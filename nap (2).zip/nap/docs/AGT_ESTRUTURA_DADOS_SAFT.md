# AGT — Estrutura de dados SAF-T (AO)

## Referência legal (estrutura do ficheiro XML)

| Diploma | Objecto |
|---------|---------|
| **Decreto Presidencial n.º 312/18** (21/12/2018) | Regime de Submissão Electrónica dos Elementos Contabilísticos e formato **SAF-T (AO)**. |
| **Decreto Executivo n.º 317/20** (14/12/2020) | Altera o **Anexo da Estrutura de Dados** (tabelas, campos obrigatórios `*` / condicionais `#`, período fiscal, secções comuns 4.4 Payments, etc.). |

Cópia no repositório: [`docs/referencias/Decreto-Executivo-317-20-SAFT-estrutura-dados.pdf`](referencias/Decreto-Executivo-317-20-SAFT-estrutura-dados.pdf).

Manual AGT **«Estrutura de dados dos Sistemas - SAFT»** e [requisitos de software certificado](AGT_REQUISITOS_SAFT.md) são documentos **complementares** (validação de aplicações vs. layout do ficheiro).

---

## Versão técnica no projecto

| Artefacto | Caminho |
|-----------|---------|
| **Esquema XSD oficial** (SAF-T AO `1.01_01`) | [`storage/saft/SAFTAO1.01_01.xsd`](../storage/saft/SAFTAO1.01_01.xsd) |
| **Gerador XML** | `fat_export_saft_ao()` em [`includes/facturacao.php`](../includes/facturacao.php) |
| **Validação** | `fat_saft_validate_against_xsd()` · `php scripts/fat_validate_saft_xsd.php` |

O PDF descreve tabelas e campos; o **XSD** é a fonte exacta para certificação (padrões, obrigatoriedade, unicidade). As notas `<xs:documentation>` no XSD reproduzem muitas regras do manual AGT.

---

## Mapa de tabelas (AuditFile)

Estrutura raiz `AuditFile` (`urn:OECD:StandardAuditFile-Tax:AO_1.01_01`):

### 1 — Cabeçalho (`Header`)

| Campo XSD | Origem INFORMATIZA |
|-----------|-------------------|
| `AuditFileVersion` | Fixo `1.01_01` |
| `CompanyID` / `TaxRegistrationNumber` | `fat_empresa.nif` |
| `TaxAccountingBasis` | `fat_saft_tax_accounting_basis()` — `F` facturação, `I` integrado (+ razão) |
| `CompanyName`, `CompanyAddress` | Empresa fiscal |
| `FiscalYear`, `StartDate`, `EndDate` | Período do export |
| `CurrencyCode` | `AOA` |
| `DateCreated` | Data do export |
| `TaxEntity` | `Global` ou `Sede` (`fat_saft_tax_entity_value`) |
| `ProductCompanyTaxID` | NIF produtor software |
| `SoftwareValidationNumber` | Modelo 08 (`fat_saft_validation_number`) |
| `ProductID` / `ProductVersion` | Modelo 08 + versão software |

### 2 — Ficheiros mestre (`MasterFiles`)

| Tabela AGT / XSD | Estado INFORMATIZA |
|------------------|-------------------|
| **2.1** `GeneralLedgerAccounts` | Só se `TaxAccountingBasis` integrado/contabilidade (`I`/`C`…): `fat_saft_prepend_standard_chart()` |
| **2.2** `Customer` | Clientes usados no período (+ consumidor final `999999999`) |
| **2.3** `Supplier` | Fornecedores de compras no período (placeholder se ficheiro contabilístico exige) |
| **2.4** `Product` | Catálogo `fat_produtos` activo |
| **2.5** `TaxTable` | IVA 0/5/7/14 % (ISE/NOR) |

### 3 — Razão (`GeneralLedgerEntries`)

| Conteúdo | Estado |
|----------|--------|
| `Journal` / `Transaction` / `DebitLine` / `CreditLine` | Com `I` + flag integrado: lançamentos mínimos por venda (`TransactionID` em 4.1) |

Módulo contabilidade (`cont_*`) alimenta razão real; export integrado usa plano SNC simplificado + transacções geradas na exportação.

### 4 — Documentos comerciais (`SourceDocuments`)

| Tabela | XSD | INFORMATIZA |
|--------|-----|-------------|
| **4.1** Vendas | `SalesInvoices` / `Invoice` | **Sim** — FT, FR, NC, ND, FA (`fat_documentos`) |
| **4.2** Mov. mercadorias | `MovementOfGoods` | **Sim** (GT/GR/GD/GA emitidos + export) |
| **4.3** Conferência / mesa | `WorkingDocuments` | **Sim** — proformas OR como `WorkType=PF` |
| **4.4** Recibos | `Payments` | **Sim** — RC/AR (`fat_documentos`) + RG (`fat_pagamentos`), ver `fat_saft_export_payments()` |
| Compras | `PurchaseInvoices` | **Parcial** — cabeçalho/totais, `Hash=0` (XSD sem linhas) |

---

## Campos críticos 4.1 (vendas)

Alinhamento com decreto + XSD:

| Campo | Regra | Implementação |
|-------|--------|----------------|
| `InvoiceNo` | `{Tipo} {Série}/{n}` — regex XSD `[^ ]+ [^/^ ]+/[0-9]+` | `fat_saft_canonical_invoice_no()` → ex. `FR A/2` |
| `InvoiceDate` | Data documento | `data_documento` |
| `SystemEntryDate` | Data/hora gravação | `data_sistema` |
| `Hash` | Assinatura RSA SHA-1 (Base64, ≤172 chars) | `fat_sign_document()` → BD |
| `HashControl` | Certificado + `.` + versão chave | `fat_saft_hash_control_value()` |
| `SourceBilling` | `P` próprio, `I` integrado, `M` manual, … | `P` por omissão |
| `InvoiceStatus` | `N` normal, `A` anulado | `estado` documento |
| `CustomerID` | Deve existir em 2.2 | `fat_clientes` / fallback `1` |
| `Line` | Taxa, `TaxExemptionReason` se ISE | `fat_saft_append_invoice_line()` |
| `DocumentTotals` | `GrossTotal` = valor assinado (2 dec.) | Totais BD |

**Mensagem assinada** (decreto / XSD):  
`InvoiceDate;SystemEntryDate;InvoiceNo;GrossTotal;HashAnterior`

---

## Tipos de ficheiro (`TaxAccountingBasis`)

| Valor | Significado | Uso típico certificação |
|-------|-------------|-------------------------|
| **F** | Facturação | Portal fornecedor — SAF-T só vendas + mestres |
| **I** | Integrado facturação + contabilidade | Exige 2.1, 3, fornecedores, `TransactionID`, compras coerentes |
| **C** | Contabilidade | Razão completo, sem 4.x obrigatório da mesma forma |
| **P**, **R**, **A**, **Q**, **S**, **E** | Parcial, recibos, aquisições, etc. | Conforme actividade |

Configuração: Admin → **Empresa fiscal** (`saft_tax_accounting_basis`, `agt_saft_integrated`).

---

## Ficheiro mensal de facturação (decreto)

Para envio periódico, o extracto de **facturação** deve incluir documentos do período e clientes referenciados. O decreto cita ainda **4.3** e **4.4** quando existirem no sistema.

INFORMATIZA exporta hoje:

- Header + MasterFiles (clientes/produtos/IVA; fornecedores se compras; plano se integrado)
- `SalesInvoices` (+ `PurchaseInvoices` resumido se houver compras)
- Opcionalmente `GeneralLedgerEntries` se integrado

---

## Validações XSD úteis na certificação

- `InvoiceNo` único globalmente no ficheiro
- `CustomerID` / `ProductCode` referenciados em mestres
- `GroupingCode` / contas em 2.1 coerentes com linhas do razão
- Moeda monetária coerente com `CurrencyCode=AOA`

---

## Documentos relacionados

- [AGT_REQUISITOS_SAFT.md](AGT_REQUISITOS_SAFT.md) — decreto (assinatura, impressão, integração)
- [CERTIFICACAO_AGT.md](CERTIFICACAO_AGT.md) — portal, anexos, API FE 2.0

```bash
php scripts/fat_validate_saft_xsd.php
php scripts/fat_verify_saft_chain.php
```
