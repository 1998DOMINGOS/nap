# Regras AGT — validação de software e SAF-T (AO)

Referência normativa (software certificado): publicação AGT **«Regras e Requisitos para Validação de Sistemas de Processamento Electrónico de Facturação»** (Anexo I — requisitos técnicos; Anexo II — OpenSSL/RSA). PDF local sugerido: `docs/referencias/AGT-Regras e requisitos para o Software - SAFT.pdf`.

**Não confundir** com o **Decreto Executivo n.º 317/20** (14/12/2020), que regula a **estrutura de dados** do SAF-T (AO) no âmbito do **Decreto Presidencial 312/18** — ver [AGT_ESTRUTURA_DADOS_SAFT.md](AGT_ESTRUTURA_DADOS_SAFT.md) e [`Decreto-Executivo-317-20-SAFT-estrutura-dados.pdf`](referencias/Decreto-Executivo-317-20-SAFT-estrutura-dados.pdf).

Documentação complementar: [AGT_ESTRUTURA_DADOS_SAFT.md](AGT_ESTRUTURA_DADOS_SAFT.md) (317/20 + XSD), [CERTIFICACAO_AGT.md](CERTIFICACAO_AGT.md), [CONTABILIDADE.md](CONTABILIDADE.md).

---

## Resumo do Anexo I (pontos críticos)

| # | Requisito AGT | INFORMATIZA / NAP |
|---|----------------|-------------------|
| 1 | Exportar SAF-T (AO) conforme XSD | `fat_export_saft_ao()`, validação `fat_saft_validate_against_xsd`, script `scripts/fat_validate_saft_xsd.php` |
| 2–5 | Assinatura RSA SHA-1, cadeia Hash por série/tipo, gravar Hash + versão chave | `fat_sign_document()` — payload `InvoiceDate;SystemEntryDate;InvoiceNo;GrossTotal;PreviousHash` |
| 5.e–f | HashControl = certificado + `.` + versão chave (ex. `456.1`) | `fat_saft_hash_control_value()` |
| 6.b | Impressão: 4 chars Hash (pos. 1, 11, 21, 31) + «Processado por programa validado n.º …/AGT» | `fat_hash_impressao_quatro_caracteres()`, `fat_legenda_programa_validado_agt()`, `imprimir.php` |
| 6.c | Recibos: «Emitido por programa validado n.º …» | `fat_legenda_programa_validado_agt()` (tipos OR/RC/RG/AR) |
| 6.e | Consumidor final sem NIF | Impressão: «Consumidor Final» / campo genérico |
| 6.f | Sem valores negativos na impressão; usar NC/ND | Emissão NC com totais negativos no SAF-T, não na impressão casual |
| 10 | Hash/HashControl na exportação = BD na emissão | Colunas `hash`, `hash_control` em `fat_documentos` |
| 34 | RSA 1024, PEM, SHA-1, assinatura ~172 chars Base64 | Chaves em `storage/fat_keys/`, upload portal `Chave Publica.pem` |
| Ficheiro mensal facturação (317/20) | Header, 2.2 Clientes, 2.4 Produtos, 2.5 Impostos, 4.1 Vendas, 4.2 Movimentos, 4.3 Conferência, 4.4 Recibos | Export: secções acima via `fat_export_saft_ao()`; validação XSD `1.01_01` |

---

## Checklist certificação (portal fornecedor)

1. **Modelo 08** alinhado com **ProductID** e **SoftwareValidationNumber** em Admin → Empresa fiscal (única fonte).
2. **Chave pública** RSA 1024 PEM → anexo `Chave Publica.pem` (renomear `.txt` se o portal pedir).
3. **SAF-T** do período de teste → `Ficheiro SAF-T.xml`, XSD OK, emitente = NIF cliente, produtor = NIF INFORMATIZA.
4. **FR/FT de teste** com Hash válido (série pedida no portal, ex. A/2–8).
5. Imprimir factura e confirmar legenda **Processado por programa validado n.º …** conforme decreto.

---

## Módulo `facturacao_agt_compliance.php` (implementado)

| Requisito | Estado |
|-----------|--------|
| Validação data/relógio na emissão | `fat_agt_validar_pre_emissao` |
| IVA isento + descontos 0–100% | `fat_agt_validar_linhas_iva` |
| NC parcial / documento anulado | `fat_agt_validar_criacao_nc` |
| Anulação vs NC existente | `fat_agt_validar_anulacao` |
| NIF/nome cliente (regras 26–27) | `fat_agt_validar_alteracao_cliente` |
| Descrição produto (regra 28) | `fat_agt_validar_alteracao_produto` |
| Séries descontinuadas / formação | `fat_series.descontinuada`, `modo_formacao` |
| Impressão legenda + não-factura + formação | `imprimir.php` |
| SAF-T 4.3 OR (WorkingDocuments PF) | `fat_saft_export_working_documents` |
| SAF-T 4.4 pagamentos + PaymentMethod | `fat_saft_export_payments` (RC/AR/RG + NU/MB/TB) |
| Backups auto + restauração | `fat_agt_executar_backup_sql`, `scripts/fat_backup_automatico.php`, `backups.php` |
| Mobilidade (n.º 18) | `mobilidade.php`, `fat_dispositivos_movel`, `emissao_movel` |
| Conferência 4.3 (WorkType) | `conferencia.php`, `work_type` |
| Multi-estabelecimento (317/20) | `estabelecimento_codigo` / `estabelecimento_nome` |
| AR recibos | `recibos.php` |
| Duplicado impressão | `copia_original`, `doc_duplicado_ref`, `imprimir.php` |
| Integração série INT | `fat_agt_resolve_serie_emissao`, `integracao.php` |
| NC References / OrderReferences | `fat_saft_append_nc_references`, `fat_saft_append_order_reference` |
| SourceBilling P/I/M | `fat_documentos.source_billing` |
| TaxPointDate | `tax_point_date` |
| Password rotation + backup log | `auth.php`, `backups.php`, `fat_system_backups` |

## Ainda por evoluir (escopo amplo / processos manuais)

- **App móvel offline** com sincronização de cadeia de hash (mobilidade = registo + flag; sem APK dedicado).
- **SOAP legacy** (Anexo II) — substituído em parte pela API FE 2.0 JSON.
- **Formulários de impressão custom** validados pelo fabricante (n.º 22) — múltiplos layouts certificados.
- **SAF-T contabilístico completo (C/I)** e ficheiro **A** (aquisições com linhas) além do export actual.
- **Vários SAF-T por estabelecimento** automatizado (hoje: um export + TaxEntity por código).

---

## Comandos úteis

```bash
php scripts/fat_validate_saft_xsd.php
php scripts/fat_portal_hash_diagnose.php
php scripts/fat_align_portal_informatiza.php
```
