<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Serviços — ' . setting('site_nome', APP_NAME);
$currentPage = 'services';
try {
    $servicos = db()->query("SELECT * FROM servicos WHERE status='ativo' ORDER BY ordem, titulo")->fetchAll();
} catch (Throwable $e) {
    $servicos = [];
}
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">TECNOLOGIA E SUPORTE</p>
        <h1 class="text-4xl md:text-5xl font-bold">Nossos Serviços</h1>
    </div>
</section>
<section class="py-16 bg-white">
    <div class="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php if (!$servicos): ?>
            <p class="text-gray-500 col-span-full text-center">Nenhum serviço activo de momento.</p>
        <?php else: foreach ($servicos as $s): ?>
            <article class="bg-paciolita-branco-suave rounded-2xl p-8 border border-gray-100 card-hover animate-enter">
                <div class="w-14 h-14 bg-ev-gold/10 rounded-xl flex items-center justify-center mb-5"><i class="fas <?= e($s['icone']) ?> text-ev-gold text-2xl"></i></div>
                <h2 class="text-xl font-bold text-ev-dark mb-3" data-service-slug="<?= e($s['slug']) ?>" data-service-field="title"><?= e($s['titulo']) ?></h2>
                <p class="text-gray-600 text-sm mb-5" data-service-slug="<?= e($s['slug']) ?>" data-service-field="resumo"><?= e($s['resumo'] ?: mb_substr(strip_tags((string)$s['descricao']), 0, 140)) ?></p>
                <a href="<?= site_url('servico/' . $s['slug']) ?>" class="text-ev-gold font-semibold">Saiba mais <i class="fas fa-arrow-right ml-1"></i></a>
            </article>
        <?php endforeach; endif; ?>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
