

CREATE TABLE IF NOT EXISTS usuarios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  nivel ENUM('admin','editor','contabilista') NOT NULL DEFAULT 'editor',
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  ultimo_acesso DATETIME NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS noticias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(200) NOT NULL,
  slug VARCHAR(220) NOT NULL UNIQUE,
  resumo TEXT NULL,
  conteudo LONGTEXT NOT NULL,
  imagem VARCHAR(255) NULL,
  status ENUM('publicado','rascunho') NOT NULL DEFAULT 'rascunho',
  autor_id INT UNSIGNED NULL,
  publicado_em DATETIME NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_noticias_autor FOREIGN KEY (autor_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS servicos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(160) NOT NULL,
  slug VARCHAR(180) NOT NULL UNIQUE,
  icone VARCHAR(80) NOT NULL DEFAULT 'fa-shield-alt',
  resumo VARCHAR(255) NULL,
  descricao TEXT NULL,
  imagem VARCHAR(255) NULL,
  ordem INT NOT NULL DEFAULT 0,
  status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS equipe (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cargo VARCHAR(120) NOT NULL,
  bio TEXT NULL,
  foto VARCHAR(255) NULL,
  ordem INT NOT NULL DEFAULT 0,
  status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS mensagens (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL,
  telefone VARCHAR(40) NULL,
  assunto VARCHAR(200) NULL,
  mensagem TEXT NOT NULL,
  status ENUM('nova','lida','respondida') NOT NULL DEFAULT 'nova',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS candidaturas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL,
  telefone VARCHAR(40) NULL,
  vaga VARCHAR(160) NULL,
  cv_arquivo VARCHAR(255) NULL,
  mensagem TEXT NULL,
  status ENUM('pendente','aprovada','rejeitada') NOT NULL DEFAULT 'pendente',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS depoimentos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NULL,
  cargo VARCHAR(120) NULL,
  texto TEXT NOT NULL,
  nota TINYINT UNSIGNED NOT NULL DEFAULT 5,
  status ENUM('pendente','ativo','inativo','rejeitado') NOT NULL DEFAULT 'pendente',
  ordem INT NOT NULL DEFAULT 0,
  origem ENUM('cliente','admin') NOT NULL DEFAULT 'cliente',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS configuracoes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  chave VARCHAR(80) NOT NULL UNIQUE,
  valor TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS galeria (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(160) NOT NULL,
  descricao VARCHAR(255) NULL,
  imagem VARCHAR(255) NOT NULL,
  ordem INT NOT NULL DEFAULT 0,
  status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS parceiros (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(180) NOT NULL,
  imagem VARCHAR(500) NULL,
  link VARCHAR(500) NULL,
  descricao VARCHAR(255) NULL,
  icone VARCHAR(80) NOT NULL DEFAULT 'fa-handshake',
  ordem INT NOT NULL DEFAULT 0,
  status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS clientes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(180) NOT NULL,
  imagem VARCHAR(500) NULL,
  link VARCHAR(500) NULL,
  descricao VARCHAR(255) NULL,
  icone VARCHAR(80) NOT NULL DEFAULT 'fa-building',
  ordem INT NOT NULL DEFAULT 0,
  status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS agenda (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(200) NOT NULL,
  resumo VARCHAR(255) NULL,
  descricao TEXT NULL,
  data_evento DATETIME NULL,
  local_evento VARCHAR(180) NULL,
  foto1 VARCHAR(255) NULL,
  foto2 VARCHAR(255) NULL,
  foto3 VARCHAR(255) NULL,
  foto4 VARCHAR(255) NULL,
  foto5 VARCHAR(255) NULL,
  status ENUM('publicado','rascunho') NOT NULL DEFAULT 'rascunho',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS mensagem_pca (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(160) NOT NULL,
  cargo VARCHAR(160) NOT NULL,
  mensagem TEXT NOT NULL,
  foto VARCHAR(255) NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS certificacoes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(180) NOT NULL,
  entidade VARCHAR(180) NULL,
  descricao VARCHAR(255) NULL,
  imagem VARCHAR(500) NULL,
  link VARCHAR(500) NULL,
  ordem INT NOT NULL DEFAULT 0,
  status ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO mensagem_pca (nome, cargo, mensagem, foto, ativo)
SELECT 'DOMINGOS MIGUEL PANZO', 'Presidente do Conselho de Administração', 'Na INFORMATIZA (SU), LDA acreditamos que a tecnologia deve tornar o trabalho mais simples, seguro e eficiente. Há seis anos trabalhamos para levar soluções de qualidade às empresas e comunidades de Angola, com proximidade, responsabilidade e compromisso com o futuro.', 'domingos-miguel-panzo.jpg', 1
WHERE NOT EXISTS (SELECT 1 FROM mensagem_pca);

INSERT INTO configuracoes (chave, valor) VALUES
('site_nome', 'INFORMATIZA (SU), LDA'),
('site_email', 'geralnacionalajudaopais@gmail.com'),
('site_telefone', '935406556'),
('site_telefone_secundario', ''),
('site_morada', 'Sede: Uíge | Luanda: Maianga, Edifício Unitel, 5.º andar | Huíla | Benguela | Mbanza Congo'),
('site_whatsapp', '935406556'),
('site_facebook', ''),
('site_instagram', ''),
('site_linkedin', '')
ON DUPLICATE KEY UPDATE valor = VALUES(valor);

INSERT INTO servicos (titulo, slug, icone, resumo, descricao, ordem, status) VALUES
('Desenvolvimento de Software', 'desenvolvimento-software', 'fa-code', 'Softwares à medida para simplificar processos e fazer o seu negócio crescer.', 'Analisamos os seus desafios e desenvolvemos sistemas seguros, eficientes e adaptados à realidade da sua organização.', 1, 'ativo'),
('Criação de Sites', 'criacao-de-sites', 'fa-globe', 'Sites profissionais, rápidos e preparados para todos os dispositivos.', 'Criamos sites institucionais e plataformas digitais com design moderno, boa experiência de utilização e foco nos seus resultados.', 2, 'ativo'),
('Reparação de Computadores', 'reparacao-de-computadores', 'fa-laptop-medical', 'Diagnóstico, reparação e manutenção de computadores.', 'Prestamos assistência técnica para computadores, com diagnóstico, manutenção preventiva e resolução de problemas de hardware e software.', 3, 'ativo'),
('Reparação de Impressoras', 'reparacao-de-impressoras', 'fa-print', 'Manutenção e reparação de impressoras para empresas e particulares.', 'Cuidamos da manutenção e reparação de impressoras para reduzir paragens e manter o seu trabalho a funcionar.', 4, 'ativo'),
('Instalação de Internet', 'instalacao-de-internet', 'fa-wifi', 'Instalação e configuração de redes e internet.', 'Instalamos e configuramos redes, internet e equipamentos para melhorar a cobertura, estabilidade e segurança da sua ligação.', 5, 'ativo'),
('Câmaras de Segurança', 'cameras-de-seguranca', 'fa-video', 'Soluções de videovigilância para proteger pessoas e espaços.', 'Planeamos e instalamos câmaras de segurança com acompanhamento técnico e soluções adequadas à sua casa ou empresa.', 6, 'ativo'),
('Formação', 'formacao', 'fa-graduation-cap', 'Formação prática para desenvolver competências digitais.', 'Promovemos formação em informática, ferramentas digitais e soluções tecnológicas para equipas e comunidades.', 7, 'ativo')
ON DUPLICATE KEY UPDATE titulo = VALUES(titulo), icone = VALUES(icone), resumo = VALUES(resumo), descricao = VALUES(descricao), ordem = VALUES(ordem), status = VALUES(status);

INSERT INTO depoimentos (nome, email, cargo, texto, nota, status, ordem, origem) VALUES
('Mariana Costa', NULL, 'Cliente — software', 'A INFORMATIZA desenvolveu uma solução simples e eficiente para a nossa organização. O acompanhamento foi excelente.', 5, 'ativo', 1, 'admin'),
('João Pedro', NULL, 'Cliente — site', 'O novo site trouxe uma presença profissional para a nossa empresa. Recomendo o trabalho da INFORMATIZA.', 5, 'ativo', 2, 'admin'),
('Ana Sofia', NULL, 'Cliente — formação', 'A formação foi prática, clara e útil para toda a equipa. Ficámos mais preparados para trabalhar com tecnologia.', 5, 'ativo', 3, 'admin');
