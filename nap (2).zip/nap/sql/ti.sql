CREATE TABLE IF NOT EXISTS ti_chamados (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(200) NOT NULL,
  descricao TEXT NULL,
  solicitante VARCHAR(160) NULL,
  categoria ENUM('hardware','software','rede','site','seguranca','outro') NOT NULL DEFAULT 'outro',
  prioridade ENUM('baixa','media','alta','critica') NOT NULL DEFAULT 'media',
  estado ENUM('aberto','em_andamento','resolvido','fechado') NOT NULL DEFAULT 'aberto',
  atribuido_a INT UNSIGNED NULL,
  criado_por INT UNSIGNED NULL,
  resolvido_em DATETIME NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_ti_cham_estado (estado),
  KEY idx_ti_cham_prio (prioridade),
  CONSTRAINT fk_ti_cham_user FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL,
  CONSTRAINT fk_ti_cham_atrib FOREIGN KEY (atribuido_a) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ti_projetos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(180) NOT NULL,
  cliente_ref VARCHAR(160) NULL,
  descricao TEXT NULL,
  estado ENUM('planeamento','em_curso','pausado','concluido','cancelado') NOT NULL DEFAULT 'planeamento',
  prioridade ENUM('baixa','media','alta') NOT NULL DEFAULT 'media',
  progresso TINYINT UNSIGNED NOT NULL DEFAULT 0,
  data_inicio DATE NULL,
  data_fim_prev DATE NULL,
  responsavel VARCHAR(120) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_ti_proj_estado (estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ti_ativos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(40) NULL,
  nome VARCHAR(160) NOT NULL,
  tipo ENUM('computador','servidor','rede','impressora','telemovel','outro') NOT NULL DEFAULT 'computador',
  localizacao VARCHAR(120) NULL,
  estado ENUM('ativo','manutencao','baixa') NOT NULL DEFAULT 'ativo',
  numero_serie VARCHAR(120) NULL,
  notas TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_ti_ativo_estado (estado),
  UNIQUE KEY uq_ti_ativo_codigo (codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
