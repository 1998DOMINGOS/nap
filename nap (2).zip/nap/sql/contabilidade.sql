-- Contabilidade geral (SNC Angola — plano simplificado INFORMATIZA)

CREATE TABLE IF NOT EXISTS cont_contas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) NOT NULL,
  nome VARCHAR(200) NOT NULL,
  tipo ENUM('ativo','passivo','patrimonio','custo','receita') NOT NULL DEFAULT 'ativo',
  categoria ENUM('GR','GA','GM') NOT NULL DEFAULT 'GM',
  conta_pai VARCHAR(30) NULL,
  aceita_lancamento TINYINT(1) NOT NULL DEFAULT 1,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_conta_codigo (codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cont_diarios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(10) NOT NULL,
  nome VARCHAR(120) NOT NULL,
  UNIQUE KEY uq_diario (codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cont_movimentos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  diario_id INT UNSIGNED NOT NULL,
  data_movimento DATE NOT NULL,
  periodo TINYINT UNSIGNED NOT NULL,
  referencia VARCHAR(80) NOT NULL,
  descricao VARCHAR(255) NOT NULL,
  origem_tipo ENUM('manual','venda','compra','despesa','folha') NOT NULL DEFAULT 'manual',
  origem_id INT UNSIGNED NULL,
  anulado TINYINT(1) NOT NULL DEFAULT 0,
  criado_por INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_origem (origem_tipo, origem_id),
  KEY idx_mov_data (data_movimento),
  CONSTRAINT fk_mov_diario FOREIGN KEY (diario_id) REFERENCES cont_diarios(id),
  CONSTRAINT fk_mov_user FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cont_movimento_linhas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  movimento_id INT UNSIGNED NOT NULL,
  linha INT UNSIGNED NOT NULL DEFAULT 1,
  conta_codigo VARCHAR(30) NOT NULL,
  debito DECIMAL(18,2) NOT NULL DEFAULT 0,
  credito DECIMAL(18,2) NOT NULL DEFAULT 0,
  descricao VARCHAR(255) NULL,
  KEY idx_linha_conta (conta_codigo),
  CONSTRAINT fk_linha_mov FOREIGN KEY (movimento_id) REFERENCES cont_movimentos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cont_despesas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  categoria VARCHAR(80) NOT NULL DEFAULT 'Geral',
  descricao VARCHAR(255) NOT NULL,
  data_despesa DATE NOT NULL,
  fornecedor_nome VARCHAR(200) NULL,
  conta_despesa VARCHAR(30) NOT NULL DEFAULT '622',
  subtotal DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_iva DECIMAL(18,2) NOT NULL DEFAULT 0,
  total DECIMAL(18,2) NOT NULL DEFAULT 0,
  metodo_pagamento ENUM('numerario','banco','multicaixa','outro') NOT NULL DEFAULT 'banco',
  referencia_doc VARCHAR(80) NULL,
  observacoes TEXT NULL,
  criado_por INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_desp_data (data_despesa),
  CONSTRAINT fk_desp_user FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cont_funcionarios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(200) NOT NULL,
  nif VARCHAR(20) NULL,
  cargo VARCHAR(120) NULL,
  salario_base DECIMAL(18,2) NOT NULL DEFAULT 0,
  subsidio DECIMAL(18,2) NOT NULL DEFAULT 0,
  data_admissao DATE NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cont_folhas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ano SMALLINT UNSIGNED NOT NULL,
  mes TINYINT UNSIGNED NOT NULL,
  data_pagamento DATE NOT NULL,
  total_bruto DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_descontos DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_liquido DECIMAL(18,2) NOT NULL DEFAULT 0,
  estado ENUM('rascunho','processada','paga') NOT NULL DEFAULT 'rascunho',
  criado_por INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_folha_periodo (ano, mes),
  CONSTRAINT fk_folha_user FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cont_folha_linhas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  folha_id INT UNSIGNED NOT NULL,
  funcionario_id INT UNSIGNED NOT NULL,
  bruto DECIMAL(18,2) NOT NULL DEFAULT 0,
  desconto_inss DECIMAL(18,2) NOT NULL DEFAULT 0,
  desconto_irt DECIMAL(18,2) NOT NULL DEFAULT 0,
  outros_descontos DECIMAL(18,2) NOT NULL DEFAULT 0,
  liquido DECIMAL(18,2) NOT NULL DEFAULT 0,
  CONSTRAINT fk_folha_linha_folha FOREIGN KEY (folha_id) REFERENCES cont_folhas(id) ON DELETE CASCADE,
  CONSTRAINT fk_folha_linha_func FOREIGN KEY (funcionario_id) REFERENCES cont_funcionarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
