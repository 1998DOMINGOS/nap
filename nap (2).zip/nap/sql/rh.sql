CREATE TABLE IF NOT EXISTS rh_vagas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(160) NOT NULL,
  departamento VARCHAR(120) NULL,
  local_trabalho VARCHAR(120) NULL,
  tipo ENUM('tempo_inteiro','meio_periodo','estagio','freelance') NOT NULL DEFAULT 'tempo_inteiro',
  descricao TEXT NULL,
  requisitos TEXT NULL,
  status ENUM('aberta','pausada','fechada') NOT NULL DEFAULT 'aberta',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_rh_vaga_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rh_ausencias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  funcionario_id INT UNSIGNED NOT NULL,
  tipo ENUM('ferias','falta_justificada','falta_injustificada','licenca','outro') NOT NULL DEFAULT 'ferias',
  data_inicio DATE NOT NULL,
  data_fim DATE NOT NULL,
  estado ENUM('pendente','aprovada','rejeitada') NOT NULL DEFAULT 'pendente',
  observacoes TEXT NULL,
  criado_por INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_aus_func (funcionario_id),
  KEY idx_aus_estado (estado),
  CONSTRAINT fk_rh_aus_func FOREIGN KEY (funcionario_id) REFERENCES cont_funcionarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
