-- Módulo Facturação INFORMATIZA (SU), LDA
-- Executado via upgrade.php / ensure_facturacao_schema()

CREATE TABLE IF NOT EXISTS fat_empresa (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(200) NOT NULL DEFAULT 'INFORMATIZA (SU), LDA',
  nif VARCHAR(20) NOT NULL DEFAULT '',
  morada VARCHAR(255) NULL,
  cidade VARCHAR(80) NULL DEFAULT 'Luanda',
  telefone VARCHAR(40) NULL,
  email VARCHAR(160) NULL,
  banco VARCHAR(120) NULL,
  titular_pagamento VARCHAR(200) NULL DEFAULT 'INFORMATIZA (SU), LDA',
  iban VARCHAR(60) NULL,
  numero_conta VARCHAR(60) NULL,
  regime_iva ENUM('geral','simplificado','isento') NOT NULL DEFAULT 'geral',
  capital_social DECIMAL(18,2) NULL,
  conservatoria VARCHAR(120) NULL,
  software_nome VARCHAR(80) NOT NULL DEFAULT 'INFORMATIZA Facturação',
  software_versao VARCHAR(20) NOT NULL DEFAULT '1.0.0',
  software_validation_number VARCHAR(80) NULL,
  produtor_nome VARCHAR(200) NULL,
  produtor_nif VARCHAR(20) NULL,
  saft_tax_accounting_basis CHAR(1) NOT NULL DEFAULT 'F',
  agt_saft_integrated TINYINT(1) NOT NULL DEFAULT 0,
  certificado_path VARCHAR(255) NULL,
  chave_privada_path VARCHAR(255) NULL,
  chave_publica_path VARCHAR(255) NULL,
  aviso_certificacao VARCHAR(255) NOT NULL DEFAULT '',
  agt_ambiente VARCHAR(20) NOT NULL DEFAULT 'homologacao',
  agt_api_user VARCHAR(120) NULL,
  agt_api_pass VARCHAR(255) NULL,
  agt_auto_envio TINYINT(1) NOT NULL DEFAULT 1,
  agt_simular TINYINT(1) NOT NULL DEFAULT 0,
  agt_eac_code VARCHAR(10) NULL,
  agt_signature_version INT NOT NULL DEFAULT 1,
  agt_chave_produtor_path VARCHAR(255) NULL,
  agt_chave_emitente_path VARCHAR(255) NULL,
  agt_software_product_id VARCHAR(80) NULL,
  agt_anexo_chave_path VARCHAR(255) NULL,
  agt_anexo_saft_path VARCHAR(255) NULL,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_series (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tipo ENUM('FT','FR','NC','ND','FA','OR') NOT NULL,
  serie VARCHAR(20) NOT NULL DEFAULT 'A',
  ano SMALLINT UNSIGNED NOT NULL,
  proximo_numero INT UNSIGNED NOT NULL DEFAULT 1,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_serie (tipo, serie, ano)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_clientes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(40) NULL,
  nome VARCHAR(200) NOT NULL,
  nif VARCHAR(20) NOT NULL DEFAULT '999999999',
  morada VARCHAR(255) NULL,
  cidade VARCHAR(80) NULL,
  telefone VARCHAR(40) NULL,
  email VARCHAR(160) NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_produtos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(40) NOT NULL,
  tipo ENUM('produto','servico') NOT NULL DEFAULT 'produto',
  descricao VARCHAR(255) NOT NULL,
  unidade VARCHAR(20) NOT NULL DEFAULT 'UN',
  preco DECIMAL(18,2) NOT NULL DEFAULT 0,
  preco_compra DECIMAL(18,2) NOT NULL DEFAULT 0,
  preco_venda DECIMAL(18,2) NOT NULL DEFAULT 0,
  taxa_iva DECIMAL(5,2) NOT NULL DEFAULT 14.00,
  codigo_isencao VARCHAR(3) NULL,
  stock DECIMAL(18,3) NULL,
  data_validade DATE NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_prod_codigo (codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_fornecedores (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(200) NOT NULL,
  nif VARCHAR(20) NOT NULL DEFAULT '',
  morada VARCHAR(255) NULL,
  telefone VARCHAR(40) NULL,
  email VARCHAR(160) NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_fornecedor_nif (nif)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_compras (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fornecedor_id INT UNSIGNED NULL,
  fornecedor_nome VARCHAR(200) NOT NULL,
  fornecedor_nif VARCHAR(20) NOT NULL DEFAULT '',
  referencia VARCHAR(80) NOT NULL,
  data_compra DATE NOT NULL,
  subtotal DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_iva DECIMAL(18,2) NOT NULL DEFAULT 0,
  total DECIMAL(18,2) NOT NULL DEFAULT 0,
  observacoes TEXT NULL,
  criado_por INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_compra_ref (referencia),
  KEY idx_compra_data (data_compra),
  CONSTRAINT fk_fat_compra_fornecedor FOREIGN KEY (fornecedor_id) REFERENCES fat_fornecedores(id) ON DELETE SET NULL,
  CONSTRAINT fk_fat_compra_user FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_compra_linhas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  compra_id INT UNSIGNED NOT NULL,
  produto_id INT UNSIGNED NULL,
  linha INT UNSIGNED NOT NULL DEFAULT 1,
  codigo VARCHAR(40) NULL,
  descricao VARCHAR(255) NOT NULL,
  quantidade DECIMAL(18,3) NOT NULL DEFAULT 1,
  preco_unitario DECIMAL(18,2) NOT NULL DEFAULT 0,
  taxa_iva DECIMAL(5,2) NOT NULL DEFAULT 14.00,
  total_liquido DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_iva DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_linha DECIMAL(18,2) NOT NULL DEFAULT 0,
  CONSTRAINT fk_fat_compra_linha_compra FOREIGN KEY (compra_id) REFERENCES fat_compras(id) ON DELETE CASCADE,
  CONSTRAINT fk_fat_compra_linha_prod FOREIGN KEY (produto_id) REFERENCES fat_produtos(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_documentos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tipo ENUM('FT','FR','NC','ND','FA','OR') NOT NULL,
  serie VARCHAR(20) NOT NULL DEFAULT 'A',
  numero INT UNSIGNED NULL,
  numero_completo VARCHAR(60) NOT NULL DEFAULT 'RASCUNHO',
  cliente_id INT UNSIGNED NULL,
  cliente_nome VARCHAR(200) NOT NULL,
  cliente_nif VARCHAR(20) NOT NULL,
  cliente_morada VARCHAR(255) NULL,
  local_prestacao VARCHAR(255) NULL,
  data_documento DATE NOT NULL,
  data_sistema DATETIME NOT NULL,
  estado ENUM('rascunho','emitido','anulado') NOT NULL DEFAULT 'rascunho',
  motivo_anulacao VARCHAR(255) NULL,
  documento_origem_id INT UNSIGNED NULL,
  subtotal DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_iva DECIMAL(18,2) NOT NULL DEFAULT 0,
  total DECIMAL(18,2) NOT NULL DEFAULT 0,
  observacoes TEXT NULL,
  hash VARCHAR(512) NULL,
  hash_anterior VARCHAR(512) NULL,
  hash_control VARCHAR(10) NULL,
  fe_request_id VARCHAR(20) NULL,
  fe_validation_status VARCHAR(4) NULL,
  fe_agt_estado VARCHAR(30) NULL,
  fe_rejected_document_no VARCHAR(60) NULL,
  fe_customer_status VARCHAR(10) NULL,
  fe_motivo_anulacao_agt VARCHAR(255) NULL,
  atcud VARCHAR(100) NULL,
  criado_por INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_doc (tipo, serie, numero),
  KEY idx_doc_data (data_documento),
  KEY idx_doc_estado (estado),
  CONSTRAINT fk_fat_doc_cliente FOREIGN KEY (cliente_id) REFERENCES fat_clientes(id) ON DELETE SET NULL,
  CONSTRAINT fk_fat_doc_user FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_auditoria (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  documento_id INT UNSIGNED NULL,
  acao VARCHAR(40) NOT NULL,
  utilizador_id INT UNSIGNED NULL,
  estado_anterior VARCHAR(20) NULL,
  estado_novo VARCHAR(20) NULL,
  dados_hash VARCHAR(512) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_auditoria_doc (documento_id),
  KEY idx_auditoria_data (criado_em),
  CONSTRAINT fk_fat_auditoria_doc FOREIGN KEY (documento_id) REFERENCES fat_documentos(id) ON DELETE SET NULL,
  CONSTRAINT fk_fat_auditoria_user FOREIGN KEY (utilizador_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_agt_envios (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  documento_id INT UNSIGNED NOT NULL,
  request_id VARCHAR(20) NULL,
  submission_uuid VARCHAR(40) NULL,
  result_code VARCHAR(4) NULL,
  estado ENUM('pendente','submetido','processando','validado','rejeitado','erro','anulado') NOT NULL DEFAULT 'pendente',
  tentativas INT UNSIGNED NOT NULL DEFAULT 0,
  payload LONGTEXT NOT NULL,
  resposta TEXT NULL,
  enviado_em DATETIME NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_agt_envio_doc (documento_id),
  CONSTRAINT fk_fat_agt_envio_doc FOREIGN KEY (documento_id) REFERENCES fat_documentos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_linhas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  documento_id INT UNSIGNED NOT NULL,
  produto_id INT UNSIGNED NULL,
  linha INT UNSIGNED NOT NULL DEFAULT 1,
  codigo VARCHAR(40) NULL,
  descricao VARCHAR(255) NOT NULL,
  quantidade DECIMAL(18,3) NOT NULL DEFAULT 1,
  unidade VARCHAR(20) NOT NULL DEFAULT 'UN',
  preco_unitario DECIMAL(18,2) NOT NULL DEFAULT 0,
  desconto_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
  taxa_iva DECIMAL(5,2) NOT NULL DEFAULT 14.00,
  codigo_isencao VARCHAR(3) NULL,
  total_liquido DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_iva DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_linha DECIMAL(18,2) NOT NULL DEFAULT 0,
  CONSTRAINT fk_fat_linha_doc FOREIGN KEY (documento_id) REFERENCES fat_documentos(id) ON DELETE CASCADE,
  CONSTRAINT fk_fat_linha_prod FOREIGN KEY (produto_id) REFERENCES fat_produtos(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_pagamentos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  documento_id INT UNSIGNED NOT NULL,
  data_pagamento DATE NOT NULL,
  valor DECIMAL(18,2) NOT NULL,
  metodo ENUM('numerario','transferencia','multicaixa','outro') NOT NULL DEFAULT 'numerario',
  referencia VARCHAR(120) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_fat_pag_doc FOREIGN KEY (documento_id) REFERENCES fat_documentos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fat_caixa (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  aberto_em DATETIME NOT NULL,
  aberto_por INT UNSIGNED NULL,
  fundo_inicial DECIMAL(18,2) NOT NULL DEFAULT 0,
  fechado_em DATETIME NULL,
  fechado_por INT UNSIGNED NULL,
  valor_contado DECIMAL(18,2) NULL,
  total_vendas DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_numerario DECIMAL(18,2) NOT NULL DEFAULT 0,
  total_outros DECIMAL(18,2) NOT NULL DEFAULT 0,
  diferenca DECIMAL(18,2) NULL,
  observacoes VARCHAR(255) NULL,
  estado ENUM('aberto','fechado') NOT NULL DEFAULT 'aberto',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_caixa_estado (estado),
  CONSTRAINT fk_fat_caixa_aberto FOREIGN KEY (aberto_por) REFERENCES usuarios(id) ON DELETE SET NULL,
  CONSTRAINT fk_fat_caixa_fechado FOREIGN KEY (fechado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
