<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Nossa Equipe — ' . setting('site_nome', APP_NAME);
$currentPage = 'equipe';
try {
    $membros = db()->query("SELECT * FROM equipe WHERE status='ativo' ORDER BY ordem, nome")->fetchAll();
} catch (Throwable $e) {
    $membros = [];
}
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">PESSOAS</p>
        <h1 class="text-4xl md:text-5xl font-bold">Nossa Equipe</h1>
    </div>
</section>
<section class="py-16 bg-paciolita-branco-suave">
    <div class="container mx-auto px-4">
        <?php if (!$membros): ?>
            <div class="bg-white rounded-2xl p-10 text-center border border-gray-100">
                <p class="text-gray-600">A equipa será publicada em breve. Pode gerir membros no painel administrativo.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($membros as $m): ?>
                    <article class="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 card-hover animate-enter">
                        <div class="h-56 bg-ev-dark bg-cover bg-center flex items-center justify-center" <?= $m['foto'] ? 'style="background-image:url(\'' . e(media_url($m['foto'])) . '\');"' : '' ?>>
                            <?php if (!$m['foto']): ?><i class="fas fa-user text-ev-gold text-5xl"></i><?php endif; ?>
                        </div>
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-ev-dark"><?= e($m['nome']) ?></h3>
                            <p class="text-ev-gold font-semibold text-sm mb-3"><?= e($m['cargo']) ?></p>
                            <?php if ($m['bio']): ?><p class="text-gray-600 text-sm"><?= e($m['bio']) ?></p><?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
