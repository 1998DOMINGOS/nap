<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Notícias — ' . setting('site_nome', APP_NAME);
$currentPage = 'news';
try {
    $noticias = db()->query("SELECT * FROM noticias WHERE status='publicado' ORDER BY COALESCE(publicado_em, criado_em) DESC")->fetchAll();
} catch (Throwable $e) {
    $noticias = [];
}
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">ACTUALIDADE</p>
        <h1 class="text-4xl md:text-5xl font-bold">Notícias</h1>
    </div>
</section>
<section class="py-16 bg-paciolita-branco-suave">
    <div class="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
        <?php if (!$noticias): ?>
            <div class="col-span-full bg-white rounded-2xl p-10 text-center border border-gray-100">
                <p class="text-gray-600">Ainda não há notícias publicadas.</p>
            </div>
        <?php else: foreach ($noticias as $n): ?>
            <article class="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 card-hover animate-enter">
                <div class="h-48 bg-ev-dark bg-cover bg-center" style="background-image:url('<?= e($n['imagem'] ? media_url($n['imagem']) : url('/imgs/hero-2.jpg')) ?>');"></div>
                <div class="p-6">
                    <p class="text-sm text-ev-gold font-semibold mb-2"><?= e(format_date($n['publicado_em'] ?? $n['criado_em'], 'd/m/Y')) ?></p>
                    <h2 class="text-xl font-bold text-ev-dark mb-3"><?= e($n['titulo']) ?></h2>
                    <p class="text-gray-600 text-sm mb-4"><?= e($n['resumo'] ?: mb_substr(strip_tags($n['conteudo']), 0, 120) . '...') ?></p>
                    <a href="<?= site_url('noticia/' . $n['slug']) ?>" class="text-ev-gold font-semibold">Ler mais</a>
                </div>
            </article>
        <?php endforeach; endif; ?>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
