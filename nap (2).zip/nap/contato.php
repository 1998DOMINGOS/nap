<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Contacto — ' . setting('site_nome', APP_NAME);
$currentPage = 'contato';
$ok = null;
$err = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $assunto = trim($_POST['assunto'] ?? '');
    $mensagem = trim($_POST['mensagem'] ?? '');

    if ($nome === '' || $email === '' || $mensagem === '') {
        $err = 'Nome, email e mensagem são obrigatórios.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'Email inválido.';
    } else {
        $mailOk = send_contact_mail($nome, $email, $telefone, $assunto, $mensagem);
        try {
            db()->prepare('INSERT INTO mensagens (nome, email, telefone, assunto, mensagem, status) VALUES (?,?,?,?,?,"nova")')
                ->execute([$nome, $email, $telefone, $assunto, $mensagem]);
        } catch (Throwable $e) {
            // Continua se o email foi enviado — a mensagem já chegou ao atendimento.
        }

        if ($mailOk) {
            $ok = 'Mensagem enviada com sucesso. Entraremos em contacto em breve.';
            $_POST = [];
        } else {
            $err = 'Não foi possível enviar a mensagem para o email de atendimento. Tente novamente ou contacte-nos directamente.';
        }
    }
}

require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">FALE CONOSCO</p>
        <h1 class="text-4xl md:text-5xl font-bold">Contacto</h1>
    </div>
</section>
<section class="py-16 bg-white">
    <div class="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div class="animate-enter">
            <h2 class="text-2xl font-bold text-ev-dark mb-4">Fale com a nossa equipa</h2>
            <p class="text-gray-600 mb-8">Conte-nos o que precisa: software, site, reparação, internet, câmaras de segurança, impressoras ou formação.</p>
            <ul class="space-y-4 text-gray-700">
                <?php
                $telPrincipal = setting('site_telefone', '935406556');
                $telSecundario = setting('site_telefone_secundario', '');
                $waNum = preg_replace('/\D+/', '', setting('site_whatsapp', '935406556'));
                if ($waNum !== '' && !str_starts_with($waNum, '244')) {
                    $waNum = '244' . $waNum;
                }
                $ig = setting('site_instagram', '#');
                ?>
                <li><i class="fas fa-map-marker-alt text-ev-gold mr-3"></i><?= e(setting('site_morada', 'Sede: Uíge | Luanda: Maianga, Edifício Unitel, 5.º andar | Huíla | Benguela | Mbanza Congo')) ?></li>
                <li>
                    <i class="fab fa-whatsapp text-ev-gold mr-3"></i>
                    <a class="hover:text-ev-gold font-semibold" href="https://wa.me/<?= e($waNum) ?>" target="_blank" rel="noopener">+244 <?= e($telPrincipal) ?></a>
                </li>
                <?php if ($telSecundario !== ''): ?>
                <li class="text-gray-500">
                    <i class="fas fa-phone text-gray-400 mr-3"></i>
                    <?= e($telSecundario) ?>
                    <span class="text-sm">(contacto secundário)</span>
                </li>
                <?php endif; ?>
                <li><i class="fas fa-envelope text-ev-gold mr-3"></i><?= e(setting('site_email', 'geralnacionalajudaopais@gmail.com')) ?></li>
                <?php if ($ig && $ig !== '#'): ?><li><i class="fab fa-instagram text-ev-gold mr-3"></i><a class="hover:text-ev-gold" href="<?= e($ig) ?>" target="_blank" rel="noopener">Instagram</a></li><?php endif; ?>
            </ul>
        </div>
        <div class="form-card bg-paciolita-branco-suave rounded-2xl p-8 border border-gray-100 animate-enter">
            <?php if ($ok): ?><div class="alert-site ok"><?= e($ok) ?></div><?php endif; ?>
            <?php if ($err): ?><div class="alert-site err"><?= e($err) ?></div><?php endif; ?>
            <form method="post" class="space-y-4">
                <div>
                    <label for="nome">Nome *</label>
                    <input id="nome" name="nome" required value="<?= e($_POST['nome'] ?? '') ?>">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="email">Email *</label>
                        <input id="email" type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>">
                    </div>
                    <div>
                        <label for="telefone">Telefone</label>
                        <input id="telefone" name="telefone" value="<?= e($_POST['telefone'] ?? '') ?>">
                    </div>
                </div>
                <div>
                    <label for="assunto">Assunto</label>
                    <input id="assunto" name="assunto" value="<?= e($_POST['assunto'] ?? '') ?>">
                </div>
                <div>
                    <label for="mensagem">Mensagem *</label>
                    <textarea id="mensagem" name="mensagem" rows="5" required><?= e($_POST['mensagem'] ?? '') ?></textarea>
                </div>
                <button type="submit" class="btn-ev-gold w-full text-center"><i class="fas fa-paper-plane mr-2"></i>Enviar mensagem</button>
            </form>
        </div>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
