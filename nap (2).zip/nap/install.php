<?php
/**
 * Instalação única — cria tabelas e utilizador admin.
 * Apague ou proteja este ficheiro após instalar (Host2Africa / XAMPP).
 */

$error = null;
$success = null;
$step = 'form';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = trim($_POST['db_host'] ?? 'localhost');
    $name = trim($_POST['db_name'] ?? 'emifati_jr');
    $user = trim($_POST['db_user'] ?? 'root');
    $pass = (string) ($_POST['db_pass'] ?? '');
    $adminNome  = trim($_POST['admin_nome'] ?? 'Administrador');
    $adminEmail = strtolower(trim($_POST['admin_email'] ?? 'admin@emifatijr.ao'));
    $adminSenha = (string) ($_POST['admin_senha'] ?? 'admin123');

    try {
        if (strlen($adminSenha) < 6) {
            throw new RuntimeException('A senha do admin deve ter pelo menos 6 caracteres.');
        }

        $pdo = new PDO("mysql:host={$host};charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `{$name}`");

        $sqlFile = __DIR__ . '/sql/schema.sql';
        if (!is_file($sqlFile)) {
            throw new RuntimeException('Ficheiro sql/schema.sql não encontrado.');
        }

        $sql = file_get_contents($sqlFile);
        $sql = preg_replace('/^CREATE DATABASE.*?;/mi', '', $sql);
        $sql = preg_replace('/^USE\s+\w+\s*;/mi', '', $sql);
        // Remover comentários de linha (senão o CREATE de usuarios é ignorado)
        $sql = preg_replace('/^\s*--.*$/m', '', $sql);

        // Instalação limpa: remove tabelas antigas (ordem por FKs)
        $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
        foreach ([
            'fat_pagamentos', 'fat_linhas', 'fat_documentos', 'fat_produtos', 'fat_clientes', 'fat_series', 'fat_empresa',
            'noticias', 'servicos', 'equipe', 'mensagens', 'candidaturas', 'depoimentos', 'galeria', 'configuracoes', 'usuarios',
        ] as $table) {
            $pdo->exec("DROP TABLE IF EXISTS `{$table}`");
        }
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');

        foreach (array_filter(array_map('trim', explode(';', $sql))) as $statement) {
            if ($statement === '') {
                continue;
            }
            $pdo->exec($statement);
        }

        $fatFile = __DIR__ . '/sql/facturacao.sql';
        if (is_file($fatFile)) {
            $fatSql = preg_replace('/^\s*--.*$/m', '', (string) file_get_contents($fatFile));
            foreach (array_filter(array_map('trim', explode(';', $fatSql))) as $statement) {
                if ($statement !== '') {
                    $pdo->exec($statement);
                }
            }
        }

        $hash = password_hash($adminSenha, PASSWORD_DEFAULT);
        $check = $pdo->prepare('SELECT id FROM usuarios WHERE email = ?');
        $check->execute([$adminEmail]);
        if ($check->fetch()) {
            $upd = $pdo->prepare('UPDATE usuarios SET nome=?, senha=?, nivel="admin", ativo=1 WHERE email=?');
            $upd->execute([$adminNome, $hash, $adminEmail]);
        } else {
            $ins = $pdo->prepare('INSERT INTO usuarios (nome, email, senha, nivel, ativo) VALUES (?, ?, ?, "admin", 1)');
            $ins->execute([$adminNome, $adminEmail, $hash]);
        }

        // Atualizar config/database.php
        $configPath = __DIR__ . '/config/database.php';
        $config = file_get_contents($configPath);
        $config = preg_replace("/define\('DB_HOST',\s*'[^']*'\);/", "define('DB_HOST', '" . addslashes($host) . "');", $config);
        $config = preg_replace("/define\('DB_NAME',\s*'[^']*'\);/", "define('DB_NAME', '" . addslashes($name) . "');", $config);
        $config = preg_replace("/define\('DB_USER',\s*'[^']*'\);/", "define('DB_USER', '" . addslashes($user) . "');", $config);
        $config = preg_replace("/define\('DB_PASS',\s*'[^']*'\);/", "define('DB_PASS', '" . addslashes($pass) . "');", $config);
        file_put_contents($configPath, $config);

        foreach (['uploads', 'uploads/noticias', 'uploads/equipe', 'uploads/servicos', 'uploads/galeria', 'uploads/cv', 'storage', 'storage/fat_keys', 'storage/saft'] as $dir) {
            $path = __DIR__ . '/' . $dir;
            if (!is_dir($path)) {
                mkdir($path, 0755, true);
            }
        }

        $success = 'Instalação concluída. Pode entrar no painel. Módulo de Facturação incluído.';
        $step = 'done';
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação — INFORMATIZA (SU), LDA</title>
    <link rel="stylesheet" href="css/fonts.css">
    <style>
        :root { --dark:#111111; --green:#FF6200; --bg:#0f1419; --card:#161b22; --text:#e8ecef; --muted:#9aa4af; }
        * { box-sizing: border-box; }
        body { margin:0; min-height:100vh; font-family:Poppins,sans-serif; background:radial-gradient(ellipse at top,#2a1508 0%,var(--bg) 55%); color:var(--text); display:flex; align-items:center; justify-content:center; padding:24px; }
        .box { width:100%; max-width:520px; background:var(--card); border:1px solid rgba(255,255,255,.08); border-radius:16px; padding:32px; box-shadow:0 24px 60px rgba(0,0,0,.45); }
        h1 { font-family:Oswald,sans-serif; margin:0 0 6px; font-size:1.8rem; }
        p.sub { color:var(--muted); margin:0 0 24px; font-size:.92rem; }
        label { display:block; font-size:.82rem; color:var(--muted); margin-bottom:6px; }
        input { width:100%; padding:12px 14px; border-radius:10px; border:1px solid rgba(255,255,255,.12); background:#0d1117; color:#fff; margin-bottom:14px; font:inherit; }
        input:focus { outline:none; border-color:var(--green); }
        .row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
        button, .btn { display:inline-flex; align-items:center; justify-content:center; width:100%; padding:13px; border:0; border-radius:10px; background:var(--green); color:#fff; font-weight:700; cursor:pointer; text-decoration:none; }
        button:hover, .btn:hover { filter:brightness(1.08); }
        .alert { padding:12px 14px; border-radius:10px; margin-bottom:16px; font-size:.9rem; }
        .alert-error { background:rgba(227,6,19,.15); border:1px solid rgba(227,6,19,.35); color:#ffb4b4; }
        .alert-ok { background:rgba(255,98,0,.15); border:1px solid rgba(255,98,0,.4); color:#ffd0a8; }
        .section { margin:18px 0 8px; font-size:.75rem; letter-spacing:.08em; text-transform:uppercase; color:var(--green); font-weight:600; }
        .warn { margin-top:16px; font-size:.8rem; color:#f0c674; }
    </style>
</head>
<body>
<div class="box">
    <h1>Instalação do Painel</h1>
    <p class="sub">INFORMATIZA (SU), LDA — Tecnologia que ajuda o país. Configure a base de dados.</p>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($step === 'done'): ?>
        <div class="alert alert-ok"><?= htmlspecialchars($success) ?></div>
        <a class="btn" href="admin/index.php">Ir para o Login Admin</a>
        <p style="margin-top:12px;text-align:center;"><a class="btn" href="index.php" style="background:transparent;border:1px solid rgba(255,255,255,.2);">Ver site público</a></p>
        <p class="warn">Importante: apague ou renomeie o ficheiro <strong>install.php</strong> após a instalação.</p>
    <?php else: ?>
        <form method="post" autocomplete="off">
            <div class="section">Base de dados</div>
            <div class="row">
                <div>
                    <label>Host</label>
                    <input name="db_host" value="localhost" required>
                </div>
                <div>
                    <label>Nome da BD</label>
                    <input name="db_name" value="emifati_jr" required>
                </div>
            </div>
            <div class="row">
                <div>
                    <label>Utilizador</label>
                    <input name="db_user" value="root" required>
                </div>
                <div>
                    <label>Senha</label>
                    <input name="db_pass" type="password" placeholder="vazio no XAMPP">
                </div>
            </div>

            <div class="section">Administrador</div>
            <label>Nome</label>
            <input name="admin_nome" value="Administrador" required>
            <label>Email</label>
                    <input name="admin_email" type="email" value="admin@emifatijr.ao" required>
            <label>Senha</label>
            <input name="admin_senha" type="password" value="admin123" required>
            <button type="submit">Instalar agora</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
