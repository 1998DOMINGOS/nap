<?php
require_once __DIR__ . '/config/app.php';
$slug = trim($_GET['slug'] ?? '');
$stmt = db()->prepare("SELECT * FROM servicos WHERE slug = ? AND status='ativo' LIMIT 1");
$stmt->execute([$slug]);
$servico = $stmt->fetch();
if (!$servico) {
    http_response_code(404);
    $pageTitle = 'Serviço não encontrado';
    $currentPage = 'services';
    require __DIR__ . '/includes/site_header.php';
    echo '<section class="py-20 container mx-auto px-4 text-center"><h1 class="text-3xl font-bold mb-4">Serviço não encontrado</h1><a class="btn-ev" href="' . e(site_url('services')) . '">Voltar aos serviços</a></section>';
    require __DIR__ . '/includes/site_footer.php';
    exit;
}
$pageTitle = $servico['titulo'] . ' — ' . setting('site_nome', APP_NAME);
$currentPage = 'services';
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">SERVIÇO</p>
        <h1 class="text-4xl md:text-5xl font-bold" data-service-slug="<?= e($servico['slug']) ?>" data-service-field="title"><?= e($servico['titulo']) ?></h1>
    </div>
</section>
<section class="py-16 bg-white">
    <div class="container mx-auto px-4 max-w-4xl animate-enter">
        <div class="w-16 h-16 bg-ev-gold/10 rounded-xl flex items-center justify-center mb-6"><i class="fas <?= e($servico['icone']) ?> text-ev-gold text-3xl"></i></div>
        <?php if ($servico['resumo']): ?><p class="text-xl text-gray-700 mb-6" data-service-slug="<?= e($servico['slug']) ?>" data-service-field="resumo"><?= e($servico['resumo']) ?></p><?php endif; ?>
        <div class="prose max-w-none text-gray-700 leading-relaxed whitespace-pre-line" data-service-slug="<?= e($servico['slug']) ?>" data-service-field="descricao"><?= e($servico['descricao'] ?: 'Descrição em actualização.') ?></div>
        <div class="mt-10 flex flex-wrap gap-4">
            <a href="<?= site_url('contato') ?>" class="btn-ev-gold">Pedir orçamento</a>
            <a href="<?= site_url('services') ?>" class="btn-ev">Outros serviços</a>
        </div>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
