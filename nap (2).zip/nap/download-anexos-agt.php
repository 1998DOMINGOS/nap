<?php
/**
 * Descarregar anexos de certificação (chave pública + SAF-T) com token.
 * URL: /download-anexos-agt.php?f=chave|saft&t=TOKEN
 * Token: primeiros 20 chars de hash_hmac('sha256', NIF da empresa, APP_NAME)
 */
require_once __DIR__ . '/config/app.php';
ensure_facturacao_schema();

$emp = fat_empresa();
$nif = (string) ($emp['nif'] ?? '');
$expected = substr(hash_hmac('sha256', $nif !== '' ? $nif : APP_NAME, APP_NAME), 0, 20);
$t = (string) ($_GET['t'] ?? '');
if ($t === '' || !hash_equals($expected, $t)) {
    http_response_code(403);
    exit('Link inválido ou expirado. Gere o token em Admin → Certificação AGT.');
}

$file = $_GET['f'] ?? '';
if ($file === 'chave') {
    $candidates = [
        fat_agt_cert_public_path(),
        fat_agt_cert_dir() . '/Chave Publica.pem',
        fat_agt_cert_dir() . '/ChavePublica.pem',
        fat_keys_dir() . '/public.pem',
    ];
    $path = null;
    foreach ($candidates as $c) {
        if (is_file($c)) {
            $path = $c;
            break;
        }
    }
    if (!$path) {
        http_response_code(404);
        exit('Chave pública não encontrada.');
    }
    header('Content-Type: application/x-pem-file; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . fat_agt_cert_public_filename() . '"');
    readfile($path);
    exit;
}

if ($file === 'saft') {
    $candidates = [
        fat_agt_cert_saft_path(),
        fat_agt_cert_dir() . '/Ficheiro SAF-T.xml',
        fat_agt_cert_dir() . '/SAFT_AO_certificacao.xml',
    ];
    $glob = glob(fat_agt_cert_dir() . '/SAFT_AO_*.xml') ?: [];
    $candidates = array_merge($candidates, $glob);
    if (is_dir(__DIR__ . '/storage/saft')) {
        $latest = glob(__DIR__ . '/storage/saft/SAFT_AO_*.xml') ?: [];
        usort($latest, static fn($a, $b) => filemtime($b) <=> filemtime($a));
        if ($latest) {
            $candidates[] = $latest[0];
        }
    }
    $path = null;
    foreach ($candidates as $c) {
        if (is_file($c)) {
            $path = $c;
            break;
        }
    }
    if (!$path) {
        http_response_code(404);
        exit('SAF-T não encontrado. Gere em Admin → Certificação AGT.');
    }
    header('Content-Type: application/xml; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . fat_agt_cert_saft_filename() . '"');
    readfile($path);
    exit;
}

http_response_code(400);
exit('Parâmetro f=chave ou f=saft');
