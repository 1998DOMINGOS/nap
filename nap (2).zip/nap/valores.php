<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Valores — ' . setting('site_nome', APP_NAME);
$currentPage = 'valores';
$valores = [
    ['Inovação', 'fa-lightbulb', 'Criamos soluções actuais para problemas reais de pessoas e organizações.'],
    ['Qualidade', 'fa-award', 'Entregamos tecnologia estável, funcional e pensada para durar.'],
    ['Proximidade', 'fa-handshake', 'Acompanhamos cada cliente antes, durante e depois do projecto.'],
    ['Segurança', 'fa-shield-halved', 'Protegemos dados, equipamentos, redes e espaços.'],
    ['Capacitação', 'fa-graduation-cap', 'Partilhamos conhecimento através de formação prática e relevante.'],
    ['Compromisso', 'fa-circle-check', 'Cumprimos o que prometemos com responsabilidade e transparência.'],
];
require __DIR__ . '/includes/site_header.php';
?>
<section class="page-header text-white py-16">
    <div class="container mx-auto px-4">
        <p class="text-ev-gold font-semibold mb-2">CULTURA</p>
        <h1 class="text-4xl md:text-5xl font-bold">Nossos Valores</h1>
    </div>
</section>
<section class="py-16 bg-white">
    <div class="container mx-auto px-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($valores as [$titulo, $icone, $texto]): ?>
            <div class="bg-paciolita-branco-suave rounded-2xl p-7 border border-gray-100 animate-enter">
                <h3 class="font-bold text-ev-dark text-xl mb-3"><i class="fas <?= e($icone) ?> text-ev-gold mr-2"></i><?= e($titulo) ?></h3>
                <p class="text-gray-600"><?= e($texto) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php require __DIR__ . '/includes/site_footer.php'; ?>
