<?php
require_once __DIR__ . '/../config/app.php';
$e = fat_empresa();
echo 'validation=' . fat_saft_validation_number($e) . "\n";
echo 'hash_control_export=' . fat_saft_hash_control_export($e, 'srHT') . "\n";
echo 'product_id=' . fat_saft_product_id($e) . "\n";
