<?php
/**
 * Valida Ficheiro SAF-T.xml (ou export recente) contra XSD oficial.
 */
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();

$path = $argv[1] ?? fat_agt_cert_saft_path();
if (!is_file($path)) {
    $xml = fat_export_saft_ao(date('Y-01-01'), date('Y-m-d'));
    fat_saft_validate_against_xsd($xml);
    echo "Export gerado e validado XSD OK.\n";
    exit(0);
}

$xml = (string) file_get_contents($path);
fat_saft_validate_against_xsd($xml);
echo "XSD OK: {$path}\n";
