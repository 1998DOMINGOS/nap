<?php
require_once __DIR__ . '/../config/app.php';
$path = fat_agt_cert_saft_path();
$dom = new DOMDocument();
$dom->load($path);
$x = new DOMXPath($dom);
$x->registerNamespace('s', 'urn:OECD:StandardAuditFile-Tax:AO_1.01_01');
$pub = file_get_contents(fat_keys_dir() . '/public.pem');
$pubCert = file_get_contents(fat_agt_cert_public_path());
echo 'public_keys_match=' . (trim($pub) === trim($pubCert) ? 'yes' : 'NO') . "\n";
$invoices = $x->query('//s:SalesInvoices/s:Invoice');
$prevBySeries = [];
for ($i = 0; $i < $invoices->length; $i++) {
    $inv = $invoices->item($i);
    $no = $x->evaluate('string(s:InvoiceNo)', $inv);
    $parts = explode(' ', $no, 2);
    $key = ($parts[0] ?? '') . '|' . (explode('/', $parts[1] ?? '')[0] ?? '');
    $date = $x->evaluate('string(s:InvoiceDate)', $inv);
    $sys = $x->evaluate('string(s:SystemEntryDate)', $inv);
    $gross = fat_saft_gross_total_for_sign((float) $x->evaluate('string(s:DocumentTotals/s:GrossTotal)', $inv));
    $hash = $x->evaluate('string(s:Hash)', $inv);
    $hc = $x->evaluate('string(s:HashControl)', $inv);
    $prevSeries = $prevBySeries[$key] ?? '';
    $prevGlobal = $globalPrev ?? '';
    $payloadSeries = $date . ';' . $sys . ';' . $no . ';' . $gross . ';' . $prevSeries;
    $payloadGlobal = $date . ';' . $sys . ';' . $no . ';' . $gross . ';' . $prevGlobal;
    $sig = base64_decode($hash, true);
    $vS = $sig ? openssl_verify($payloadSeries, $sig, $pub, OPENSSL_ALGO_SHA1) : -1;
    $vG = $sig ? openssl_verify($payloadGlobal, $sig, $pub, OPENSSL_ALGO_SHA1) : -1;
    echo ($i + 1) . " $no HashControl=$hc series_prev_len=" . strlen($prevSeries) . " verify_series=$vS verify_global=$vG\n";
    if ($vS !== 1 && $sig) {
        echo "  payload_series=[$payloadSeries]\n";
    }
    if ($hash !== '0') {
        $prevBySeries[$key] = $hash;
        $globalPrev = $hash;
    }
}
$emp = fat_empresa();
echo 'ProductID=' . fat_saft_product_id($emp) . "\n";
echo 'SVN=' . fat_saft_validation_number($emp) . "\n";
$key = openssl_pkey_get_private(file_get_contents(fat_keys_dir() . '/private.pem'));
echo 'key_bits=' . (openssl_pkey_get_details($key)['bits'] ?? '?') . "\n";
