<?php
/**
 * Simula validações típicas do portal AGT (hash, ProductID, datas FR série A).
 */
require_once __DIR__ . '/../config/app.php';

$path = $argv[1] ?? fat_agt_cert_saft_path();
if (!is_file($path)) {
    fwrite(STDERR, "Ficheiro não encontrado: {$path}\n");
    exit(1);
}

$dom = new DOMDocument();
$dom->load($path);
$x = new DOMXPath($dom);
$x->registerNamespace('s', 'urn:OECD:StandardAuditFile-Tax:AO_1.01_01');

$errors = [];
$ok = [];

$productId = trim($x->evaluate('string(//s:Header/s:ProductID)'));
$emp = fat_empresa();
$expectedPid = fat_saft_product_id($emp ?: []);
$portalPid = trim((string) (getenv('FAT_AGT_PORTAL_PRODUCT_ID') ?: ($argv[2] ?? '')));
if ($productId !== $expectedPid) {
    $errors[] = "ProductID XML [{$productId}] ≠ BD [{$expectedPid}]";
} elseif ($portalPid !== '' && $productId !== $portalPid) {
    $errors[] = "ProductID XML [{$productId}] ≠ portal Modelo 08 [{$portalPid}]";
} elseif (!preg_match('/^[^\/]+\/[^\/]+$/', $productId)) {
    $errors[] = "ProductID formato XSD inválido: {$productId}";
} else {
    $ok[] = 'ProductID XSD OK: ' . $productId;
}

$pubPath = fat_agt_cert_public_path();
if (!is_file($pubPath)) {
    $errors[] = 'Chave Publica.pem em falta';
} elseif (trim(file_get_contents($pubPath)) !== trim(file_get_contents(fat_keys_dir() . '/public.pem'))) {
    $errors[] = 'Chave cert ≠ chave storage/fat_keys/public.pem';
} else {
    $ok[] = 'Chave pública alinhada';
}
$canonicalPub = trim(file_get_contents(fat_keys_dir() . '/public.pem'));
foreach (glob(fat_agt_cert_dir() . '/*.pem') ?: [] as $pemFile) {
    if (trim((string) file_get_contents($pemFile)) !== $canonicalPub) {
        $errors[] = 'PEM desactualizado (não use no portal): ' . basename($pemFile) . ' — use só «Chave Publica.pem»';
    }
}

$pub = file_get_contents(fat_keys_dir() . '/public.pem');
$invoices = $x->query('//s:SalesInvoices/s:Invoice');
$prevBySeries = [];
$frDates = [];
$frOnlyCert = true;

for ($i = 0; $i < $invoices->length; $i++) {
    $inv = $invoices->item($i);
    $no = $x->evaluate('string(s:InvoiceNo)', $inv);
    $date = $x->evaluate('string(s:InvoiceDate)', $inv);
    $sys = $x->evaluate('string(s:SystemEntryDate)', $inv);
    $gross = fat_saft_gross_total_for_sign((float) $x->evaluate('string(s:DocumentTotals/s:GrossTotal)', $inv));
    $hash = $x->evaluate('string(s:Hash)', $inv);
    $hc = $x->evaluate('string(s:HashControl)', $inv);

    $parts = explode(' ', $no, 2);
    $seriesKey = ($parts[0] ?? '') . '|' . (explode('/', $parts[1] ?? '')[0] ?? '');
    $prev = fat_saft_previous_hash_for_signing($prevBySeries[$seriesKey] ?? '');

    $payloads = [
        'standard' => $date . ';' . $sys . ';' . $no . ';' . $gross . ';' . $prev,
        'sys_date_only' => $date . ';' . substr($sys, 0, 10) . ';' . $no . ';' . $gross . ';' . $prev,
        'status_date' => $date . ';' . $x->evaluate('string(s:DocumentStatus/s:InvoiceStatusDate)', $inv) . ';' . $no . ';' . $gross . ';' . $prev,
    ];

    $sig = base64_decode($hash, true);
    $matched = false;
    foreach ($payloads as $label => $payload) {
        if ($sig && openssl_verify($payload, $sig, $pub, OPENSSL_ALGO_SHA1) === 1) {
            $matched = true;
            break;
        }
    }

    if (!$matched && $hash !== '0') {
        $errors[] = "Hash inválido ({$no}) — nenhum payload testado assinou";
    } elseif ($hash !== '0') {
        $ok[] = "Hash OK {$no} ({$label})";
    }

    if ($hc === '0' || $hc === '') {
        $errors[] = "HashControl inválido em {$no}: [{$hc}]";
    }
    if ($date !== '' && $sys !== '' && substr($sys, 0, 10) < $date) {
        $errors[] = "{$no}: SystemEntryDate ({$sys}) anterior a InvoiceDate ({$date})";
    }

    if (str_starts_with($no, 'FR A/')) {
        $num = (int) substr($no, strrpos($no, '/') + 1);
        $frDates[$num] = $date;
        if ($num < 2 || $num > 8) {
            $frOnlyCert = false;
            $errors[] = "Documento extra no SAF-T certificação: {$no} (portal pede FR A/2–A/8)";
        }
    } elseif ($no !== '') {
        $frOnlyCert = false;
    }

    if ($hash !== '0') {
        $prevBySeries[$seriesKey] = $hash;
    }
}

ksort($frDates);
$lastDate = null;
$prevNum = null;
foreach ($frDates as $num => $d) {
    if ($lastDate !== null && $d < $lastDate) {
        $errors[] = "FR A/{$num} InvoiceDate {$d} anterior a FR A/{$prevNum} ({$lastDate}) — não sequencial";
    }
    if ($prevNum !== null && $num === $prevNum + 1 && $d === $lastDate) {
        $ok[] = "FR A/{$num} mesma data que anterior (permitido)";
    }
    $prevNum = $num;
    $lastDate = $d;
}
if ($frOnlyCert && count($frDates) >= 2) {
    $ok[] = 'SAF-T contém apenas FR A/2–A/8 (modo certificação)';
}
// Cadeia portal: FR A/2 deve assinar com previous vazio
$inv2 = $x->query("//s:Invoice[s:InvoiceNo='FR A/2']")->item(0);
if ($inv2) {
    $date = $x->evaluate('string(s:InvoiceDate)', $inv2);
    $sys = $x->evaluate('string(s:SystemEntryDate)', $inv2);
    $gross = fat_saft_gross_total_for_sign((float) $x->evaluate('string(s:DocumentTotals/s:GrossTotal)', $inv2));
    $hash = $x->evaluate('string(s:Hash)', $inv2);
    $sig = base64_decode($hash, true);
    $payloadPortal = $date . ';' . $sys . ';FR A/2;' . $gross . ';';
    if ($sig && openssl_verify($payloadPortal, $sig, $pub, OPENSSL_ALGO_SHA1) === 1) {
        $ok[] = 'FR A/2 hash OK com cadeia portal (sem hash anterior)';
    } else {
        $errors[] = 'FR A/2 não assina com previous vazio (cadeia portal AGT)';
    }
}

$taxId = $x->evaluate('string(//s:MasterFiles/s:Customer[1]/s:CustomerTaxID)');
if ($taxId !== '999999999') {
    $errors[] = "CustomerTaxID consumidor final: [{$taxId}] (esperado 999999999)";
} else {
    $ok[] = 'CustomerTaxID CF OK';
}

echo "=== Validação portal (simulada) ===\n";
echo "Ficheiro: {$path}\n\n";
foreach ($ok as $line) {
    echo "[OK] {$line}\n";
}
foreach ($errors as $line) {
    echo "[ERRO] {$line}\n";
}
if ($portalPid === '') {
    echo "\nNota: se o portal recusar ProductID, confirme o texto exacto do Modelo 08 e compare:\n";
    echo "  php scripts/fat_agt_portal_validate.php \"{$path}\" \"SEU_PRODUCT_ID_DO_PORTAL\"\n";
}

exit($errors === [] ? 0 : 1);
