<?php
/**
 * Cria utilizador RH (acesso ao módulo Recursos Humanos).
 * Uso: php scripts/create_rh_user.php [email] [senha]
 */
require_once __DIR__ . '/../config/app.php';
ensure_usuario_niveis();

$email = strtolower(trim($argv[1] ?? 'rh@informatiza.ao'));
$senha = (string) ($argv[2] ?? 'Rh2026!');
$nome = 'Recursos Humanos';

if (strlen($senha) < 6) {
    fwrite(STDERR, "Senha mínimo 6 caracteres.\n");
    exit(1);
}

$ex = db()->prepare('SELECT id FROM usuarios WHERE email=?');
$ex->execute([$email]);
if ($ex->fetchColumn()) {
    db()->prepare('UPDATE usuarios SET nome=?, senha=?, nivel=?, ativo=1 WHERE email=?')
        ->execute([$nome, password_hash($senha, PASSWORD_DEFAULT), 'rh', $email]);
    echo "Utilizador actualizado: {$email}\n";
} else {
    db()->prepare('INSERT INTO usuarios (nome, email, senha, nivel, ativo) VALUES (?,?,?,?,1)')
        ->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), 'rh']);
    echo "Utilizador criado: {$email}\n";
}
echo 'Login: ' . (BASE_URL ?: '') . "/admin/login\n";
echo "Área: /admin/rh/dashboard\n";
echo "Nível: rh\n";
