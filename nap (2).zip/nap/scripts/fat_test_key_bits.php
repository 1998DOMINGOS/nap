<?php
require_once __DIR__ . '/../config/app.php';
fat_openssl_bootstrap();
$r = openssl_pkey_new(['private_key_bits' => 1024, 'private_key_type' => OPENSSL_KEYTYPE_RSA]);
openssl_pkey_export($r, $p);
$d = openssl_pkey_get_details($r);
openssl_sign('x', $s, $p, OPENSSL_ALGO_SHA1);
echo 'bits=' . $d['bits'] . ' b64=' . strlen(base64_encode($s)) . "\n";
