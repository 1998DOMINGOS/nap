<?php
/**
 * Cópia de segurança automática (AGT n.º 12–13). Agendar no Task Scheduler / cron:
 * php C:\xampp\htdocs\nap\scripts\fat_backup_automatico.php
 */
require_once __DIR__ . '/../config/app.php';

if (!function_exists('fat_agt_executar_backup_sql')) {
    fwrite(STDERR, "Módulo AGT compliance não carregado.\n");
    exit(1);
}

try {
    fat_agt_compliance_migrate();
    $emp = fat_empresa();
    $maxDays = max(1, (int) ($emp['agt_backup_dias'] ?? 7));
    $dias = fat_agt_dias_sem_backup();
    if ($dias !== null && $dias < $maxDays) {
        echo "Backup automático ignorado (última cópia há {$dias} dia(s), limite {$maxDays}).\n";
        exit(0);
    }
    $name = fat_agt_executar_backup_sql(null, 'automatico');
    echo "Backup automático OK: {$name}\n";
    exit(0);
} catch (Throwable $e) {
    fwrite(STDERR, $e->getMessage() . "\n");
    exit(1);
}
