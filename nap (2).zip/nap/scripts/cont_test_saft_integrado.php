<?php
/**
 * Teste rápido: export SAF-T com basis I + movimentos contabilísticos.
 * Uso: php scripts/cont_test_saft_integrado.php
 */
require_once __DIR__ . '/../config/app.php';
ensure_contabilidade_schema();
ensure_facturacao_schema();

$emp = fat_empresa();
if (!$emp) {
    fwrite(STDERR, "Sem empresa.\n");
    exit(1);
}
$backup = [
    'basis' => $emp['saft_tax_accounting_basis'] ?? 'F',
    'integrated' => (int) ($emp['agt_saft_integrated'] ?? 0),
];
db()->prepare('UPDATE fat_empresa SET saft_tax_accounting_basis=?, agt_saft_integrated=1 WHERE id=?')
    ->execute(['I', (int) $emp['id']]);

$from = date('Y-01-01');
$to = date('Y-m-d');
$xml = fat_export_saft_ao($from, $to);
$hasGl = str_contains($xml, '<GeneralLedgerEntries>');
$hasAcc = str_contains($xml, '<GeneralLedgerAccounts>');
$nMov = cont_saft_count_movimentos($from, $to);

db()->prepare('UPDATE fat_empresa SET saft_tax_accounting_basis=?, agt_saft_integrated=? WHERE id=?')
    ->execute([$backup['basis'], $backup['integrated'], (int) $emp['id']]);

echo "movimentos_periodo={$nMov}\n";
echo 'GeneralLedgerAccounts=' . ($hasAcc ? 'sim' : 'nao') . "\n";
echo 'GeneralLedgerEntries=' . ($hasGl ? 'sim' : 'nao') . "\n";
exit($hasGl && $hasAcc && $nMov > 0 ? 0 : 1);
