<?php
/**
 * Alinha fat_empresa ao pedido portal INFORMATIZA / DOMINGOS MIGUEL PANZO (fonte única BD).
 */
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();
fat_agt_ensure_schema();

$productId = 'INFORMATIZA/DOMINGOS MIGUEL PANZO';
$emp = fat_empresa();
if (!$emp) {
    fwrite(STDERR, "Sem empresa.\n");
    exit(1);
}

fat_agt_save_software_config((int) $emp['id'], [
    'software_nome' => 'INFORMATIZA',
    'software_versao' => '1.0.0',
    'produtor_nome' => 'DOMINGOS MIGUEL PANZO',
    'produtor_nif' => '010075952UE042',
    'agt_software_product_id' => $productId,
    'software_validation_number' => sprintf('000/AGT/%d', (int) date('Y')),
    'saft_tax_accounting_basis' => 'F',
    'agt_saft_integrated' => 0,
    'agt_signature_version' => 1,
], true);

$emp = fat_empresa();
$dom = new DOMDocument();
$dom->loadXML(fat_export_saft_ao(date('Y-01-01'), date('Y-m-d')));
$x = new DOMXPath($dom);
$x->registerNamespace('s', 'urn:OECD:StandardAuditFile-Tax:AO_1.01_01');

echo json_encode([
    'product_id' => fat_saft_product_id($emp),
    'product_company_tax_id' => $x->evaluate('string(//s:Header/s:ProductCompanyTaxID)'),
    'tax_accounting_basis' => $x->evaluate('string(//s:Header/s:TaxAccountingBasis)'),
    'software_validation_number' => $x->evaluate('string(//s:Header/s:SoftwareValidationNumber)'),
    'saft' => fat_agt_cert_saft_path(),
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
