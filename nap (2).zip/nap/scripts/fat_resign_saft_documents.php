<?php
/**
 * Corrige InvoiceNo (FT A/1) e recalcula cadeia de hashes para documentos já emitidos.
 * Uso: php scripts/fat_resign_saft_documents.php [data_inicio] [data_fim]
 */
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();

$from = $argv[1] ?? null;
$to = $argv[2] ?? null;
if ($from !== null && $to === null) {
    $to = $from;
}

try {
    $n = fat_rebuild_saft_document_chain($from, $to);
    echo "Documentos actualizados: {$n}\n";
} catch (Throwable $e) {
    fwrite(STDERR, $e->getMessage() . "\n");
    exit(1);
}
