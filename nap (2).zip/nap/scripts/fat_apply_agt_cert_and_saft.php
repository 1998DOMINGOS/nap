<?php
/**
 * Aplica Product ID / validação AGT, regenera Ficheiro SAF-T.xml e valida cabeçalho.
 */
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();
fat_agt_ensure_schema();

fat_agt_apply_cert_defaults();
$emp = fat_empresa();
$emp = fat_empresa();

$out = [
    'agt_software_product_id' => fat_saft_product_id($emp),
    'software_validation_number' => fat_saft_validation_number($emp),
];

$from = date('Y-01-01');
$to = date('Y-m-d');
$xml = fat_export_saft_ao($from, $to);
fat_agt_guardar_anexo_saft($xml);
fat_agt_preparar_anexo_chave_publica();
$out['saft_path'] = fat_agt_cert_saft_path();

$dom = new DOMDocument();
$dom->loadXML($xml);
$x = new DOMXPath($dom);
$x->registerNamespace('s', 'urn:OECD:StandardAuditFile-Tax:AO_1.01_01');
$pid = $x->evaluate('string(//s:Header/s:ProductID)');
$svn = $x->evaluate('string(//s:Header/s:SoftwareValidationNumber)');
$out['xml_ProductID'] = $pid;
$out['xml_SoftwareValidationNumber'] = $svn;
$out['product_id_match'] = ($pid === $out['agt_software_product_id']);
$out['validation_format_ok'] = (bool) preg_match('/^\d+\/AGT\/\d{4}$/', $svn) || $svn === '0';

echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
