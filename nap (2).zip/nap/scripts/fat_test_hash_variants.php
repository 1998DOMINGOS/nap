<?php
require_once __DIR__ . '/../config/app.php';
$path = fat_agt_cert_saft_path();
$dom = new DOMDocument();
$dom->load($path);
$x = new DOMXPath($dom);
$x->registerNamespace('s', 'urn:OECD:StandardAuditFile-Tax:AO_1.01_01');
$pub = file_get_contents(fat_keys_dir() . '/public.pem');
$inv = $x->query("//s:Invoice[s:InvoiceNo='FR A/2']")->item(0);
$no = 'FR A/2';
$date = $x->evaluate('string(s:InvoiceDate)', $inv);
$sys = $x->evaluate('string(s:SystemEntryDate)', $inv);
$status = $x->evaluate('string(s:DocumentStatus/s:InvoiceStatusDate)', $inv);
$gross = fat_saft_gross_total_for_sign((float) $x->evaluate('string(s:DocumentTotals/s:GrossTotal)', $inv));
$hash = $x->evaluate('string(s:Hash)', $inv);
$prev1 = $x->evaluate("string(//s:Invoice[s:InvoiceNo='FR A/1']/s:Hash)");
$sig = base64_decode($hash, true);
$prevs = ['empty' => '', 'zero' => '0', 'a1' => $prev1];
$syses = ['full' => $sys, 'date' => substr($sys, 0, 10), 'status' => $status];
foreach ($prevs as $pl => $prev) {
    $prev = fat_saft_previous_hash_for_signing($prev);
    foreach ($syses as $sl => $se) {
        $payload = $date . ';' . $se . ';' . $no . ';' . $gross . ';' . $prev;
        $v = $sig ? openssl_verify($payload, $sig, $pub, OPENSSL_ALGO_SHA1) : -1;
        if ($v === 1) {
            echo "MATCH prev={$pl} sys={$sl}\n{$payload}\n";
        }
    }
}
