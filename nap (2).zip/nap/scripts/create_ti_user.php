<?php

/**

 * Cria utilizador TI (Departamento de Tecnologia).

 * Uso: php scripts/create_ti_user.php [email] [senha]

 */

require_once __DIR__ . '/../config/app.php';

ensure_usuario_niveis();



$email = strtolower(trim($argv[1] ?? 'ti@informatiza.ao'));

$senha = (string) ($argv[2] ?? 'Ti2026!');

$nome = 'Departamento de Tecnologia';



if (strlen($senha) < 6) {

    fwrite(STDERR, "Senha mínimo 6 caracteres.\n");

    exit(1);

}



$ex = db()->prepare('SELECT id FROM usuarios WHERE email=?');

$ex->execute([$email]);

if ($ex->fetchColumn()) {

    db()->prepare('UPDATE usuarios SET nome=?, senha=?, nivel=?, ativo=1 WHERE email=?')

        ->execute([$nome, password_hash($senha, PASSWORD_DEFAULT), 'ti', $email]);

    echo "Utilizador actualizado: {$email}\n";

} else {

    db()->prepare('INSERT INTO usuarios (nome, email, senha, nivel, ativo) VALUES (?,?,?,?,1)')

        ->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), 'ti']);

    echo "Utilizador criado: {$email}\n";

}

echo 'Login: ' . (BASE_URL ?: '') . "/admin/login\n";

echo "Área: /admin/tecnologia/dashboard\n";

echo "Nível: ti\n";

