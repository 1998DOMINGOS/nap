<?php
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();

$rows = db()->query("SELECT id, tipo, serie, numero, numero_completo, estado, total, data_documento, data_sistema, LENGTH(hash) AS hash_len, hash, hash_anterior FROM fat_documentos WHERE estado IN ('emitido','anulado') AND tipo <> 'OR' ORDER BY tipo, serie, numero, id")->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $r) {
    $sys = date('Y-m-d\TH:i:s', strtotime($r['data_sistema']));
    $payload = sprintf('%s;%s;%s;%0.2f;%s', $r['data_documento'], $sys, $r['numero_completo'], (float) $r['total'], $r['hash_anterior']);
    $pub = file_get_contents(fat_keys_dir() . '/public.pem');
    $sig = base64_decode(substr($r['hash'], 0, 172) . str_repeat('=', (4 - strlen(substr($r['hash'], 0, 172)) % 4) % 4), true);
    $ok = $sig ? openssl_verify($payload, $sig, $pub, OPENSSL_ALGO_SHA1) : -1;
    $r['verify_trunc172'] = $ok;
    $sigFull = base64_decode($r['hash'], true);
    $r['verify_full'] = ($sigFull && strlen($r['hash']) > 172) ? openssl_verify($payload, $sigFull, $pub, OPENSSL_ALGO_SHA1) : null;
    unset($r['hash']);
    echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
}

$key = openssl_pkey_get_private(file_get_contents(fat_keys_dir() . '/private.pem'));
$det = openssl_pkey_get_details($key);
echo 'key_bits=' . ($det['bits'] ?? '?') . "\n";
