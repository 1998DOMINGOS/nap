<?php
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();
fat_agt_ensure_schema();

$out = [];
try {
    fat_agt_preparar_anexo_chave_publica();
    $out['chave'] = fat_agt_cert_public_path();
} catch (Throwable $e) {
    $out['chave_error'] = $e->getMessage();
}

$emp = fat_empresa();
$from = date('Y-01-01');
$to = date('Y-m-d');
try {
    if (!trim((string) ($emp['nif'] ?? ''))) {
        throw new RuntimeException('Configure NIF em Empresa fiscal.');
    }
    try {
        fat_validar_configuracao_eletronica();
    } catch (Throwable $e) {
        // Gera SAF-T mesmo sem números AGT definitivos (pré-certificação)
    }
    $xml = fat_export_saft_ao($from, $to);
    fat_agt_guardar_anexo_saft($xml);
    $out['saft'] = fat_agt_cert_saft_path();
} catch (Throwable $e) {
    $out['saft_error'] = $e->getMessage();
    $fallback = glob(__DIR__ . '/../storage/saft/SAFT_AO_*.xml') ?: [];
    if ($fallback) {
        usort($fallback, static fn($a, $b) => filemtime($b) <=> filemtime($a));
        copy($fallback[0], fat_agt_cert_saft_path());
        $out['saft'] = fat_agt_cert_saft_path();
        $out['saft_note'] = 'Cópia do último SAF-T em storage/saft (regenerar após configurar empresa).';
    }
}

$out['nif'] = $emp['nif'] ?? '';
$out['chave_name'] = fat_agt_cert_public_filename();
$out['saft_name'] = fat_agt_cert_saft_filename();
file_put_contents(__DIR__ . '/../storage/agt_cert/prepare_result.json', json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
