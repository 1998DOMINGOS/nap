<?php
require_once __DIR__ . '/../config/app.php';
$rows = db()->query("SELECT id, numero_completo, tipo, serie, numero, hash FROM fat_documentos WHERE tipo='FR' AND serie='A' ORDER BY numero")->fetchAll();
foreach ($rows as $d) {
    $canon = fat_saft_canonical_invoice_no($d);
    $match = ($d['numero_completo'] === $canon) ? 'OK' : 'MISMATCH';
    echo "{$d['numero_completo']} vs {$canon} [{$match}]\n";
}
