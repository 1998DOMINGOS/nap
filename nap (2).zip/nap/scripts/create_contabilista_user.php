<?php
/**
 * Cria utilizador contabilista (acesso só ao módulo de contabilidade).
 * Uso: php scripts/create_contabilista_user.php [email] [senha]
 */
require_once __DIR__ . '/../config/app.php';
ensure_usuario_niveis();

$email = strtolower(trim($argv[1] ?? 'contabilista@informatiza.ao'));
$senha = (string) ($argv[2] ?? 'Contabil2026');
$nome = 'Contabilista';

if (strlen($senha) < 6) {
    fwrite(STDERR, "Senha mínimo 6 caracteres.\n");
    exit(1);
}

$ex = db()->prepare('SELECT id FROM usuarios WHERE email=?');
$ex->execute([$email]);
if ($ex->fetchColumn()) {
    db()->prepare('UPDATE usuarios SET nome=?, senha=?, nivel=?, ativo=1 WHERE email=?')
        ->execute([$nome, password_hash($senha, PASSWORD_DEFAULT), 'contabilista', $email]);
    echo "Utilizador actualizado: {$email}\n";
} else {
    db()->prepare('INSERT INTO usuarios (nome, email, senha, nivel, ativo) VALUES (?,?,?,?,1)')
        ->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), 'contabilista']);
    echo "Utilizador criado: {$email}\n";
}
echo "Login: " . (BASE_URL ?: '') . "/admin/index.php\n";
echo "Área: /admin/contabilidade/dashboard.php\n";
echo "Nível: contabilista\n";
