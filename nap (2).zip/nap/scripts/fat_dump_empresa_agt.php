<?php
require_once __DIR__ . '/../config/app.php';
$e = fat_empresa();
unset($e['agt_api_pass']);
echo json_encode([
    'nome' => $e['nome'] ?? '',
    'nif' => $e['nif'] ?? '',
    'produtor_nome' => $e['produtor_nome'] ?? '',
    'produtor_nif' => $e['produtor_nif'] ?? '',
    'software_nome' => $e['software_nome'] ?? '',
    'agt_software_product_id' => $e['agt_software_product_id'] ?? '',
    'software_validation_number' => $e['software_validation_number'] ?? '',
    'export_ProductID' => fat_saft_product_id($e),
    'export_ProductCompanyTaxID' => $e['produtor_nif'] ?: $e['nif'],
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
