<?php
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();
fat_agt_compliance_migrate();

fat_fix_fr_invoice_dates_sequential(2, 'A', '2026-08-22');
fat_portal_cert_align_system_entry_dates(2, 8, 'A');
$n = fat_rebuild_portal_cert_fr_chain(2, 8, 'A');
$from = $argv[1] ?? date('Y-01-01');
$to = $argv[2] ?? date('Y-m-d');
$xml = fat_export_saft_ao_portal_cert($from, $to);
fat_agt_guardar_anexo_saft($xml);
fat_agt_preparar_anexo_chave_publica();

$emp = fat_empresa();
echo "Documentos reassinados: {$n}\n";
echo 'HashControl=' . fat_saft_hash_control_value($emp) . "\n";
echo 'ProductID=' . fat_saft_product_id($emp) . "\n";
echo 'ProductVersion=' . ($emp['software_versao'] ?? '') . "\n";
echo 'SAFT=' . fat_agt_cert_saft_path() . "\n";
