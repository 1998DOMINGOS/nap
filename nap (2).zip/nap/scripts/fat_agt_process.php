<?php
/**
 * Processar fila AGT (cron). Ex.: php scripts/fat_agt_process.php
 */
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();
$n = fat_agt_processar_pendentes(50);
fwrite(STDOUT, "AGT: {$n} operação(ões) processada(s).\n");
