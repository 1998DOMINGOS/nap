<?php
require_once __DIR__ . '/../config/app.php';
$path = fat_agt_cert_saft_path();
$dom = new DOMDocument();
$dom->load($path);
$x = new DOMXPath($dom);
$x->registerNamespace('s', 'urn:OECD:StandardAuditFile-Tax:AO_1.01_01');
$invoices = $x->query('//s:SalesInvoices/s:Invoice');
$pub = file_get_contents(fat_keys_dir() . '/public.pem');
$prevByKey = [];
for ($i = 0; $i < $invoices->length; $i++) {
    $inv = $invoices->item($i);
    $no = $x->evaluate('string(s:InvoiceNo)', $inv);
    $parts = explode(' ', $no, 2);
    $serieCode = explode('/', $parts[1] ?? '')[0] ?? '';
    $key = ($parts[0] ?? '') . '|' . $serieCode;
    $date = $x->evaluate('string(s:InvoiceDate)', $inv);
    $sys = $x->evaluate('string(s:SystemEntryDate)', $inv);
    $gross = $x->evaluate('string(s:DocumentTotals/s:GrossTotal)', $inv);
    $gross = fat_saft_gross_total_for_sign((float) $gross);
    $hash = $x->evaluate('string(s:Hash)', $inv);
    $prev = $prevByKey[$key] ?? '';
    $payloadEmpty = $date . ';' . $sys . ';' . $no . ';' . $gross . ';';
    $payloadZero = $date . ';' . $sys . ';' . $no . ';' . $gross . ';0';
    $payloadPrev = $date . ';' . $sys . ';' . $no . ';' . $gross . ';' . $prev;
    $sig = base64_decode($hash, true);
    $v0 = $sig ? openssl_verify($payloadEmpty, $sig, $pub, OPENSSL_ALGO_SHA1) : -1;
    $vz = $sig ? openssl_verify($payloadZero, $sig, $pub, OPENSSL_ALGO_SHA1) : -1;
    $vp = $sig && $prev !== '' ? openssl_verify($payloadPrev, $sig, $pub, OPENSSL_ALGO_SHA1) : -1;
    echo ($i + 1) . " $no empty=$v0 zero=$vz chain=$vp\n";
    if ($hash !== '0') {
        $prevByKey[$key] = $hash;
    }
}
