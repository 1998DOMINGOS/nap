<?php
/**
 * Actualiza BD + SAF-T de certificação portal (FR A/2–A/8, cadeia hash, datas).
 * Uso: php scripts/fat_atualizar_bd_portal_agt.php
 */
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();
fat_agt_compliance_migrate();
fat_agt_ensure_schema();

$emp = fat_empresa();
if (!$emp) {
    fwrite(STDERR, "Sem registo em fat_empresa.\n");
    exit(1);
}

$year = (int) date('Y');
$config = [
    'software_nome' => 'INFORMATIZA Facturação',
    'software_versao' => '1.0.0',
    'produtor_nome' => 'DOMINGOS MIGUEL PANZO',
    'produtor_nif' => '010075952UE042',
    'agt_software_product_id' => 'INFORMATIZA Facturação/DOMINGOS MIGUEL PANZO',
    'software_validation_number' => sprintf('000/AGT/%d', $year),
    'saft_tax_accounting_basis' => 'F',
    'agt_saft_integrated' => 0,
    'agt_signature_version' => 1,
];

fat_agt_save_software_config((int) $emp['id'], $config, false);
db()->prepare('UPDATE fat_empresa SET agt_saft_integrated=0, saft_tax_accounting_basis=?, modo_formacao=0 WHERE id=?')
    ->execute(['F', (int) $emp['id']]);

db()->exec("UPDATE fat_clientes SET nif='999999999', nome='Consumidor Final' WHERE nif IN ('999999999','0999999999','CF','') OR nome LIKE 'Consumidor%'");

$datesFixed = fat_fix_fr_invoice_dates_sequential(2, 'A', '2026-08-22');
$sysAligned = fat_portal_cert_align_system_entry_dates(2, 8, 'A');
$signed = fat_rebuild_portal_cert_fr_chain(2, 8, 'A');

$from = '2026-01-01';
$to = date('Y-m-d');
$xml = fat_export_saft_ao_portal_cert($from, $to);
fat_agt_guardar_anexo_saft($xml);
fat_agt_preparar_anexo_chave_publica();

$emp = fat_empresa();
echo "=== Certificação portal AGT (BD + SAF-T) ===\n";
echo "Datas FR corrigidas: {$datesFixed}\n";
echo "SystemEntryDate alinhadas: {$sysAligned}\n";
echo "FR A/2–A/8 reassinados: {$signed}\n";
echo 'ProductID: ' . fat_saft_product_id($emp) . "\n";
echo 'ProductVersion: ' . ($emp['software_versao'] ?? '') . "\n";
echo 'HashControl: ' . fat_saft_hash_control_value($emp) . "\n";
echo 'SAF-T: ' . fat_agt_cert_saft_path() . "\n";
echo "\nExecute: php scripts/fat_agt_portal_validate.php\n";
