<?php
require_once __DIR__ . '/../config/app.php';
$dom = new DOMDocument();
$dom->load(fat_agt_cert_saft_path());
$x = new DOMXPath($dom);
$x->registerNamespace('s', 'urn:OECD:StandardAuditFile-Tax:AO_1.01_01');
$rows = db()->query("SELECT id, numero_completo, hash, hash_anterior FROM fat_documentos WHERE estado IN ('emitido','anulado') AND tipo <> 'OR' ORDER BY tipo, serie, numero")->fetchAll(PDO::FETCH_ASSOC);
$prevXml = [];
foreach ($rows as $r) {
    $no = $r['numero_completo'];
    $inv = $x->query("//s:SalesInvoices/s:Invoice[s:InvoiceNo='$no']")->item(0);
    $xmlHash = $inv ? $x->evaluate('string(s:Hash)', $inv) : '';
    $parts = explode(' ', $no, 2);
    $key = ($parts[0] ?? '') . '|' . (explode('/', $parts[1] ?? '')[0] ?? '');
    $expectedPrev = $prevXml[$key] ?? '';
    $matchDb = ($r['hash'] === $xmlHash);
    $matchPrev = ($r['hash_anterior'] === $expectedPrev) || ($expectedPrev === '' && $r['hash_anterior'] === '0');
    echo "$no db_hash=" . ($matchDb ? 'OK' : 'DIFF') . " prev=" . ($matchPrev ? 'OK' : 'DIFF') . " hash_anterior=" . substr($r['hash_anterior'], 0, 20) . "... expected=" . substr($expectedPrev, 0, 20) . "...\n";
    if ($xmlHash !== '' && $xmlHash !== '0') {
        $prevXml[$key] = $xmlHash;
    }
}
