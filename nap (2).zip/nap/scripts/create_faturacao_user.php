<?php
/**
 * Cria utilizador de facturação (acesso só ao módulo fiscal + dashboard).
 * Uso: php scripts/create_faturacao_user.php [email] [senha]
 */
require_once __DIR__ . '/../config/app.php';
ensure_usuario_niveis();
if (function_exists('fat_agt_compliance_migrate')) {
    fat_agt_compliance_migrate();
}

$email = strtolower(trim($argv[1] ?? 'faturacao@informatiza.ao'));
$senha = (string) ($argv[2] ?? 'Faturacao2026');
$nome = 'Operador Facturação';

if (strlen($senha) < 6) {
    fwrite(STDERR, "Senha mínimo 6 caracteres.\n");
    exit(1);
}

$ex = db()->prepare('SELECT id FROM usuarios WHERE email=?');
$ex->execute([$email]);
if ($uid = $ex->fetchColumn()) {
    $uid = (int) $uid;
    db()->prepare('UPDATE usuarios SET nome=?, senha=?, nivel=?, ativo=1 WHERE email=?')
        ->execute([$nome, password_hash($senha, PASSWORD_DEFAULT), 'faturacao', $email]);
    if (function_exists('fat_agt_marcar_senha_alterada')) {
        fat_agt_marcar_senha_alterada($uid);
    }
    echo "Utilizador actualizado: {$email}\n";
} else {
    db()->prepare('INSERT INTO usuarios (nome, email, senha, nivel, ativo) VALUES (?,?,?,?,1)')
        ->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), 'faturacao']);
    $newId = (int) db()->lastInsertId();
    if ($newId > 0 && function_exists('fat_agt_marcar_senha_alterada')) {
        fat_agt_marcar_senha_alterada($newId);
    }
    echo "Utilizador criado: {$email}\n";
}
echo 'Login: ' . (BASE_URL ?: '') . "/admin/index.php\n";
echo "Dashboard: /admin/facturacao/index.php\n";
echo "Nível: faturacao\n";
