<?php
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();
$emp = fat_empresa();
if (!$emp) {
    exit("Sem empresa\n");
}
$cur = trim((string) ($emp['software_validation_number'] ?? ''));
if ($cur === '123/AGT/2026') {
    db()->prepare('UPDATE fat_empresa SET software_validation_number=NULL WHERE id=?')->execute([(int) $emp['id']]);
    echo "Placeholder 123/AGT/2026 removido.\n";
}
$xml = fat_export_saft_ao(date('Y-01-01'), date('Y-m-d'));
fat_agt_guardar_anexo_saft($xml);
echo 'SoftwareValidationNumber no XML: ' . fat_saft_validation_number(fat_empresa()) . "\n";
