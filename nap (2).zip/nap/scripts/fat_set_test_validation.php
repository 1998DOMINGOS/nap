<?php
/**
 * Modo teste AGT: SoftwareValidationNumber 000/AGT/AAAA
 */
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();

$year = (int) date('Y');
$svn = sprintf('000/AGT/%d', $year);
$emp = fat_empresa();
if (!$emp) {
    fwrite(STDERR, "Sem empresa configurada.\n");
    exit(1);
}

db()->prepare('UPDATE fat_empresa SET software_validation_number=? WHERE id=?')
    ->execute([$svn, (int) $emp['id']]);

$n = fat_rebuild_saft_document_chain();
$xml = fat_export_saft_ao(date('Y-01-01'), date('Y-m-d'));
fat_agt_guardar_anexo_saft($xml);
fat_agt_preparar_anexo_chave_publica();

$emp = fat_empresa();
echo json_encode([
    'software_validation_number' => fat_saft_validation_number($emp),
    'hash_control' => fat_saft_hash_control_value($emp),
    'product_id' => fat_saft_product_id($emp),
    'documentos_reassinados' => $n,
    'saft' => fat_agt_cert_saft_path(),
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
