<?php
/**
 * Gera par RSA 1024 bits (hash SAF-T ≤172 chars) e recalcula assinaturas.
 * Uso: php scripts/fat_migrate_keys_1024.php
 */
require_once __DIR__ . '/../config/app.php';
ensure_facturacao_schema();

$dir = fat_keys_dir();
$ts = date('YmdHis');
foreach (['private.pem', 'public.pem'] as $f) {
    $path = $dir . '/' . $f;
    if (is_file($path)) {
        copy($path, $path . '.bak.' . $ts);
    }
}
@unlink($dir . '/private.pem');
@unlink($dir . '/public.pem');
ensure_facturacao_keys();

$key = openssl_pkey_get_private(file_get_contents($dir . '/private.pem'));
$bits = openssl_pkey_get_details($key)['bits'] ?? 0;
if ($bits !== 1024) {
    fwrite(STDERR, "Aviso: chave gerada com {$bits} bits (esperado 1024).\n");
}

$n = fat_rebuild_saft_document_chain();
fat_agt_preparar_anexo_chave_publica();
echo "Chaves RSA {$bits} bits. Documentos reassinados: {$n}\n";
echo "Actualize Chave Publica.pem no portal AGT se a chave mudou.\n";
